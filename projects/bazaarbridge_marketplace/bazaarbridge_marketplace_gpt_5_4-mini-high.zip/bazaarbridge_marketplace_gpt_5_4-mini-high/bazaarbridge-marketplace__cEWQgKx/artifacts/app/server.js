const fs = require('fs');
const express = require('express');
const Database = require('better-sqlite3');
const crypto = require('crypto');

const app = express();
const PORT = 3000;
const DB_PATH = process.env.DB_PATH || '/app/bazaarbridge.db';
const SEED_PATH = '/app/seed_data.json';
const SESSION_NAME = 'bb_session';
const sessions = new Map();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/static', express.static('/app/static'));
app.use((req, res, next) => {
  const sid = req.headers.cookie && req.headers.cookie.split(';').map(s => s.trim()).find(s => s.startsWith(SESSION_NAME + '='));
  if (sid) {
    const token = decodeURIComponent(sid.split('=')[1]);
    req.session = sessions.get(token) || {};
    req.sessionToken = token;
  } else {
    req.session = {};
  }
  next();
});
function commitSession(req, res) {
  if (req.session && req.sessionToken) sessions.set(req.sessionToken, req.session);
  if (req.session && !req.sessionToken) {
    const token = crypto.randomBytes(16).toString('hex');
    req.sessionToken = token;
    sessions.set(token, req.session);
    res.setHeader('Set-Cookie', `${SESSION_NAME}=${token}; Path=/; HttpOnly`);
  }
}
function clearSession(req, res) {
  if (req.sessionToken) sessions.delete(req.sessionToken);
  res.setHeader('Set-Cookie', `${SESSION_NAME}=; Path=/; Max-Age=0; HttpOnly`);
}
function money(cents) { return '$' + (cents / 100).toFixed(2); }
function nowIso() { return new Date().toISOString().slice(0, 19).replace('T', ' '); }
function commissionRate(total) { return total < 15000 ? 0.12 : total < 30000 ? 0.09 : 0.06; }
function roundCents(v) { return Math.round(v); }
const seed = JSON.parse(fs.readFileSync(SEED_PATH, 'utf8'));
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,name TEXT NOT NULL,role TEXT NOT NULL);CREATE TABLE IF NOT EXISTS inventory (sku TEXT PRIMARY KEY,product TEXT NOT NULL,merchant TEXT NOT NULL,hub TEXT NOT NULL,stock INTEGER NOT NULL,reorder_level INTEGER NOT NULL);CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY,customer TEXT NOT NULL,merchant TEXT NOT NULL,product TEXT NOT NULL,status TEXT NOT NULL,total INTEGER NOT NULL,quantity INTEGER NOT NULL,created_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS payouts (id TEXT PRIMARY KEY,merchant TEXT NOT NULL,amount INTEGER NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS activity (id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT NOT NULL,detail TEXT NOT NULL,actor TEXT NOT NULL,created_at TEXT NOT NULL);`);
function seedTable(table, rows) { const cols = Object.keys(rows[0]); const stmt = db.prepare(`INSERT OR IGNORE INTO ${table} (${cols.join(',')}) VALUES (${cols.map(c => '@' + c).join(',')})`); const tx = db.transaction(items => items.forEach(item => stmt.run(item))); tx(rows); }
seedTable('users', seed.users); seedTable('inventory', seed.inventory); seedTable('orders', seed.orders); seedTable('payouts', seed.payouts); seedTable('activity', seed.activity);
function currentUser(req){ return req.session.user || null; }
function authorized(user, area){ return user && ((user.role==='Administrator') || (user.role==='Operations lead' && ['orders','inventory'].includes(area)) || (user.role==='Finance manager' && area==='payouts')); }
function addActivity(action, detail, actor){ db.prepare('INSERT INTO activity (action, detail, actor, created_at) VALUES (?,?,?,?)').run(action, detail, actor, nowIso()); }
function getData(){ const orders = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all(); const inventory = db.prepare('SELECT * FROM inventory ORDER BY sku').all(); const payouts = db.prepare('SELECT * FROM payouts ORDER BY created_at DESC').all(); const activity = db.prepare('SELECT * FROM activity ORDER BY created_at DESC, id DESC LIMIT 20').all(); const grossSales = orders.reduce((a,o)=>a+o.total,0); const readyPayout = payouts.filter(p=>p.status==='Approved').reduce((a,p)=>a+p.amount,0); const settlements = [...new Set(orders.map(o=>o.merchant))].map(merchant => { const payableOrders = orders.filter(o => o.merchant===merchant && o.status==='Shipped'); let commission=0, processor=0, net=0; payableOrders.forEach(o => { const c=roundCents(o.total*commissionRate(o.total)); const p=roundCents(o.total*0.029 + 30); commission += c; processor += p; net += o.total - c - p; }); return {merchant, commission, processor, net, payableOrders}; }); return {orders, inventory, payouts, activity, grossSales, orderCount: orders.length, readyPayout, owed: settlements.reduce((a,s)=>a+s.net,0), settlements}; }
function loginPage(error){ return `<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>BazaarBridge sign in</title><link rel='stylesheet' href='/static/app.css'></head><body><main class='login'><h1>BazaarBridge</h1>${error?`<div class='banner error'>${error}</div>`:''}<form method='post' action='/login'><label>Email <input name='email' type='email' required></label><label>Password <input name='password' type='password' required></label><button type='submit'>Sign in</button></form></main></body></html>`; }
function shellNav(active){ return `<nav class='nav' aria-label='Workspace navigation'><a href='/app/dashboard' ${active==='dashboard'?'aria-current="page"':''}>Dashboard</a><a href='/app/orders' ${active==='orders'?'aria-current="page"':''}>Orders</a><a href='/app/inventory' ${active==='inventory'?'aria-current="page"':''}>Inventory</a><a href='/app/payouts' ${active==='payouts'?'aria-current="page"':''}>Payouts</a></nav>`; }
function renderPage(req,{workspace,error,query=''}={}){ const u=currentUser(req); if(!u) return loginPage(error); const d=getData(); const search=query; const orderRows=d.orders.filter(o=>!search || [o.id,o.customer,o.merchant,o.product,o.status].join(' ').toLowerCase().includes(search.toLowerCase())); return `<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>BazaarBridge</title><link rel='stylesheet' href='/static/app.css'></head><body class='theme-${req.session.theme||'light'}'><header class='topbar'><div><strong>BazaarBridge</strong><span>${u.name} · ${u.role}</span></div><form method='post' action='/theme'><button type='submit'>Toggle theme</button></form><form method='post' action='/logout'><button type='submit'>Sign out</button></form></header><main><section class='shell'>${shellNav(workspace)}<div class='workspace'><h1>${workspace[0].toUpperCase()+workspace.slice(1)}</h1>${error?`<div class='banner error'>${error}</div>`:''}${workspace==='dashboard'?`<div class='cards'><div><h2>Gross sales</h2><p>${money(d.grossSales)}</p></div><div><h2>Order count</h2><p>${d.orderCount}</p></div><div><h2>Ready payout</h2><p>${money(d.readyPayout)}</p></div><div><h2>Owed to merchants</h2><p>${money(d.owed)}</p></div></div><h2>Recent activity</h2><ul>${d.activity.map(a=>`<li>${a.created_at} — ${a.action} — ${a.detail} — ${a.actor}</li>`).join('')}</ul>`:''}${workspace==='orders'?`<form method='get'><input name='q' value='${search}' placeholder='Search orders'><button>Search</button></form><table><thead><tr><th>Order</th><th>Customer</th><th>Merchant</th><th>Product</th><th>Status</th><th>Total</th><th>Change</th></tr></thead><tbody>${orderRows.map(o=>`<tr><td>${o.id}</td><td>${o.customer}</td><td>${o.merchant}</td><td>${o.product}</td><td>${o.status}</td><td>${money(o.total)}</td><td>${authorized(u,'orders')?`<form method='post' action='/orders/${o.id}'><select name='status'>${['New','Packed','Shipped','On hold','Returned'].map(s=>`<option ${s===o.status?'selected':''}>${s}</option>`).join('')}</select><button>Save</button></form>`:'Read only'}</td></tr>`).join('')}</tbody></table>`:''}${workspace==='inventory'?`<table><thead><tr><th>SKU</th><th>Product</th><th>Merchant</th><th>Hub</th><th>Stock</th><th>Reorder</th><th>Flag</th><th>Adjust</th></tr></thead><tbody>${d.inventory.map(i=>`<tr class='${i.stock<=i.reorder_level?'low':''}'><td>${i.sku}</td><td>${i.product}</td><td>${i.merchant}</td><td>${i.hub}</td><td>${i.stock}</td><td>${i.reorder_level}</td><td>${i.stock<=i.reorder_level?'Low stock':''}</td><td>${authorized(u,'inventory')?`<form method='post' action='/inventory/${i.sku}'><input type='number' name='stock' value='${i.stock}'><button>Save</button></form>`:'Read only'}</td></tr>`).join('')}</tbody></table>`:''}${workspace==='payouts'?`<table><thead><tr><th>Payout</th><th>Merchant</th><th>Amount</th><th>Status</th><th>Change</th></tr></thead><tbody>${d.payouts.map(p=>`<tr><td>${p.id}</td><td>${p.merchant}</td><td>${money(p.amount)}</td><td>${p.status}</td><td>${authorized(u,'payouts')?`<form method='post' action='/payouts/${p.id}'><select name='status'>${['Requested','Review','Approved','Paid'].map(s=>`<option ${s===p.status?'selected':''}>${s}</option>`).join('')}</select><button>Save</button></form>`:'Read only'}</td></tr>`).join('')}</tbody></table><h2>Settlement statements</h2>${d.settlements.map(s=>`<article><h3>${s.merchant} — ${money(s.net)}</h3><p>Commission: ${money(s.commission)} · Processor: ${money(s.processor)} · Orders: ${s.payableOrders.length}</p></article>`).join('')}`:''}</div></section></main></body></html>`; }
app.get('/api/health', (req,res)=>res.json({ok:true}));
app.get('/', (req,res)=>{ if(currentUser(req)) return res.redirect('/app/dashboard'); res.send(loginPage()); });
app.post('/login',(req,res)=>{ const {email,password}=req.body; const user=db.prepare('SELECT * FROM users WHERE email=? AND password=?').get(email,password); if(!user) return res.status(401).send(loginPage('Wrong email or password.')); req.session.user={email:user.email,name:user.name,role:user.role}; commitSession(req,res); res.redirect('/app/dashboard'); });
app.post('/logout',(req,res)=>{ clearSession(req,res); res.redirect('/'); });
app.post('/theme',(req,res)=>{ req.session.theme = req.session.theme==='dark'?'light':'dark'; commitSession(req,res); res.redirect('back'); });
app.get('/app/:workspace', (req,res)=>{ if(!currentUser(req)) return res.redirect('/'); const w=req.params.workspace; if(!['dashboard','orders','inventory','payouts'].includes(w)) return res.status(404).send('Not found'); res.send(renderPage(req,{workspace:w,query:req.query.q||''})); });
app.post('/orders/:id',(req,res)=>{ const user=currentUser(req); if(!user) return res.redirect('/'); if(!authorized(user,'orders')) return res.status(403).send(renderPage(req,{workspace:'orders',error:'You are not authorised to change orders.'})); const order=db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id); if(order.status==='Returned' && req.body.status!=='Returned') return res.status(400).send(renderPage(req,{workspace:'orders',error:'Returned orders are terminal.'})); db.prepare('UPDATE orders SET status=? WHERE id=?').run(req.body.status, req.params.id); addActivity('Order status changed', `${req.params.id} · ${req.body.status}`, user.name); res.redirect('/app/orders'); });
app.post('/inventory/:sku',(req,res)=>{ const user=currentUser(req); if(!user) return res.redirect('/'); if(!authorized(user,'inventory')) return res.status(403).send(renderPage(req,{workspace:'inventory',error:'You are not authorised to change inventory.'})); const stock=Number(req.body.stock); if(!Number.isInteger(stock) || stock<0) return res.status(400).send(renderPage(req,{workspace:'inventory',error:'Stock cannot be negative.'})); db.prepare('UPDATE inventory SET stock=? WHERE sku=?').run(stock, req.params.sku); addActivity('Stock updated', `${req.params.sku} · ${stock}`, user.name); res.redirect('/app/inventory'); });
app.post('/payouts/:id',(req,res)=>{ const user=currentUser(req); if(!user) return res.redirect('/'); if(!authorized(user,'payouts')) return res.status(403).send(renderPage(req,{workspace:'payouts',error:'You are not authorised to change payouts.'})); db.prepare('UPDATE payouts SET status=? WHERE id=?').run(req.body.status, req.params.id); addActivity('Payout status changed', `${req.params.id} · ${req.body.status}`, user.name); res.redirect('/app/payouts'); });
app.listen(PORT,'0.0.0.0',()=>console.log(`BazaarBridge listening on ${PORT}`));
