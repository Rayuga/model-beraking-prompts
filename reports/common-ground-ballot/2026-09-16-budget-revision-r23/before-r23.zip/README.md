# Common Ground Ballot package

The complete implementer brief is `instruction.md`. Copy the supplied foundation
and authoritative seed into `/app` before implementing the remaining workflows.
`solution/solve.sh` installs the reference application for Oracle runs.

Five verifier dimensions run serially. Each uses the adjacent `prompt.md` named by
its `judge.toml`. `tests/test.sh` creates private evaluator helpers under
`/opt/common-ground-verifier`; RewardKit discovers no root Python helper as a reward.
The lifecycle, provenance and score helpers are standalone executable verifier
commands with explicit Python shebangs; they are not application entrypoints and
are never copied into the submitted app. The application entrypoint remains
`node /app/server.js`, which `solution/solve.sh` installs.
The image retains the genuine Codex executable. The runner installs an idempotent
private PATH shim for trace collection and forwards login/version/help unchanged.

# Scoring contract

RewardKit 0.1.7 first writes its named weighted_mean aggregate, declared in reward.toml, using the numeric weights from each dimension's judge.toml. tests/test.sh then invokes its generated private scorer exactly once to replace that intermediate aggregate with the final gated result.

Render and Constraints use all_pass over their independently reported binary criteria. If either dimension is zero, the final reward is zero. Otherwise the scorer computes the normalized weighted mean of Functional, Polish and Visual. Their sole numeric weight definitions are each [judge].weight; the current values give 60%, 20% and 20%. Gate weights are positive for RewardKit's intermediate calculation but have no final reward mass. There are no ignored weight maps or duplicated numeric coefficients in the runner. Criterion weights only govern their own dimension.

The scorer requires every dimension to be a finite JSON number between zero and one, rejecting booleans, strings and missing values. The runner initializes zero results before launch and restores zeros on grading failure. graded=1 and no_op=0 are written only after successful final composition. Unit fixtures for this plumbing are not Oracle or model scores.

## Minimum working product

Render's all_pass gate includes one new-ballot journey: Coordinator creates and
opens, an eligible Member votes, then the Coordinator closes and publishes.
Refreshed protected records must retain that new voted/published outcome. This
prerequisite runs once on a separate fixture, in addition to workspace navigation;
it does not award extra final reward. Read-only seeded displays therefore get
Render zero and final reward zero, regardless of Polish/Visual scores. The shared
authentication gate, detailed Functional criteria, score formula and all timeouts
are unchanged. The pinned runner discovers dimensions in alphabetical order and
runs one at a time, so Render's new fixture follows Functional's seed inspection.
