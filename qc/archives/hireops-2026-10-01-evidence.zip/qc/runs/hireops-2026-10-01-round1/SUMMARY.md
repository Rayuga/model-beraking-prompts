# Three-review QC result

**STALE_OR_INVALID** — 3/3 valid independent reports.

Local review only; no verification of portal model, full judge duration, Oracle or target-model score is inferred.

Unresolved findings/evidence gaps: 33. Verdict disagreements: 9.

- live task differs; prepare a new round
- reward_is_graded_not_binary_and_discriminates: missing hash-bound measured runtime record
- reward_ranking_is_monotone: missing hash-bound measured runtime record
- timeouts_fit_the_work: missing hash-bound measured runtime record
- verifier_image_can_launch_and_grade: missing hash-bound measured runtime record
## reviewer-1:quality:timeouts_fit_the_work

Not exercised: tests/test.sh:run_suite and judge timeouts:600+600=1200<1500;9000+900+900=10800<11100;12600<13200. No hash-bound full LLM workload/cold-build timing was available to this reviewer; arithmetic alone does not establish fit.

## reviewer-1:quality:solution_covers_every_deliverable

Fail: environment/instructions/integration.md:9-10 promises health before database work blocks startup; solution/app/src/index.js:30 invokes synchronous dbmod.open before listen at436. reviewer-1-health-order.json confirms database-open occurs with listening=false in a source execution with dependency stubs.

## reviewer-1:quality:solution_covers_every_graded_dimension

Not exercised: solution/app/src/{index,rules}.js and public/js/{app,hireops}.js plausibly cover the45 functional,9 polish,5 visual criteria, but this review performed no live full golden/browser/judge run. No measured Oracle verdict claimed.

## reviewer-1:quality:solution_honors_the_runtime_contract_and_is_self_contained

Fail: solution/solve.sh is valid LF bash and copies only to /app; db.js honors DB_PATH and seeds once. However integration.md:9-10 versus index.js:30,436 gives a cold-start health contract violation; reviewer-1-health-order.json records the call order.

## reviewer-1:quality:verifier_image_can_launch_and_grade

Not exercised: tests/Dockerfile contains required pinned tools,Chromium install,Python restart runtime and both npm dependencies; no configured verifier-image launch/grade measured in this review.

## reviewer-1:quality:dimensions_cover_every_graded_requirement

Fail: instruction.md:9 and integration.md:3-10 mandate Express/SQLite, only supplied packages, no external data backend and health independent of DB. tests/gates/constraints/prompt.md expressly says no database-engine probe; all judges prohibit implementation reading. Browser write/readback+restart cannot distinguish JSON-file storage, other server libraries or external backing; test.sh health fallback also accepts /.

## reviewer-1:quality:criteria_are_independent_and_noncontradictory

Fail: tests/scored/functional/judge.toml:132-137 hro_raise_roles combines offer-creation permissions with every-role requisition creation in one binary row despite saying “Do not conflate requisition and offer rights.” rules1 explicitly describes these as different permissions.

## reviewer-1:quality:criteria_are_outcome_based_and_browser_decidable

Not exercised: Criteria use observable UI/product responses and no source routes. Fresh contexts and concurrent requests specifically require browser_run_code_unsafe,newContext/request APIs; this reviewer has no bound actual MCP session log proving all required operations work. Source design is plausible but tool feasibility unmeasured.

## reviewer-1:quality:reward_is_graded_not_binary_and_discriminates

Not exercised: scoring.toml shaped .6/.2/.2 and45 functional rows provide theoretical granularity, but no hash-bound full configured partial-app judge score distribution reviewed; permission bundling row28 reduces signal.

## reviewer-1:quality:reward_ranking_is_monotone

Not exercised: scoring.toml positive weights preserves score-vector monotonicity, but task-level ordering between stronger/weaker apps needs measured paired judge runs under qc/REVIEW_POLICY.md. No such current-input record reviewed.

## reviewer-2:quality:timeouts_fit_the_work

Not exercised: reviewer-2-static.log: gates600<1500, functional9000<11100, polish900/visual900<11100,1500+11100=12600<13200. However P1-P10 require many roles, fresh offers, UI chains, concurrent requests and restart; no hash-bound configured-judge workload/cold-build measurement was reviewed. Scripted timings cannot prove the 9000-second judge budget.

## reviewer-2:quality:solution_covers_every_deliverable

Fail: solution/app/public/js/hireops.js: revision field defaults divide each stored cent value by100 before string conversion. reviewer-2-pure.log CONFIRMED stored9007199254740991 -> default90071992547409.9 ->9007199254740990 cents on unchanged resubmission. Public hireops_rules.md exact integer range includes this value. Also src/index.js calls dbmod.open() before app.listen despite integration.md health-before-database-startup contract.

## reviewer-2:quality:solution_covers_every_graded_dimension

Not exercised: solution/app/src/rules.js pure probes in reviewer-2-pure.log match P3 bands,P4 compositions,P7 calendar/caps and P8 cliff boundaries; every screen and action has implementation paths. No complete frozen golden UI/full configured judge run was performed in this review, so all45 functional,9 polish and5 visual criteria are not certified.

## reviewer-2:quality:solution_honors_the_runtime_contract_and_is_self_contained

Fail: solution/solve.sh passes bash-n/LF and copies app into /app; src/db.js honors DB_PATH and seed-once. However integration.md says health answers before database work can block startup; src/index.js executes dbmod.open() synchronously before its final app.listen().

## reviewer-2:quality:verifier_image_can_launch_and_grade

Not exercised: tests/Dockerfile sources the required Node runtime, browser, Playwright MCP, judge CLIs, RewardKit and python restart tool; syntax/static wiring is plausible and matches template. No frozen verifier image build plus actual configured judge launch/grading run was reviewed here.

## reviewer-2:quality:dimensions_cover_every_graded_requirement

Fail: hireops_rules.md section7 explicitly grants the at-hire half immediately at approval even with a future scheduled start. Functional prompt P1/P4/P6/P8 use referral starts in January/February2026, all before reference2026-08-01; no criterion explicitly requires a future referred-hire start. Public exact monetary input handling also lacks a high-cent unchanged revision witness. Shared-policy gap: mandatory Express/SQLite/no-install/health-without-database properties cannot be established by the browser-only prompts.

## reviewer-2:quality:criteria_are_independent_and_noncontradictory

Fail: tests/scored/functional/judge.toml hro_raise_roles combines non-auditor offer creation/Auditor rejection with every-role requisition creation. hro_caps combines signing full vesting with the separate equity full-vesting schedule. hro_stale combines replayed approval, stale ancestors, post-rescission actions and concurrent approval/revision/rescission exclusivity. qc/REVIEW_POLICY.md says independently useful promises keep separate credit even when scenarios share setup.

## reviewer-2:quality:floor_is_low_for_shells_mocks_and_stuffing

Not exercised: constraints hro_gate_shared logically defeats blank/static/seed-only/no-op/localStorage-only apps; render catches broken login. No measured weak/mock-app reward run on this candidate was reviewed, so floor behavior under the configured judge remains unmeasured.

## reviewer-2:quality:reward_is_graded_not_binary_and_discriminates

Fail: scoring.toml gives graded45-row functionality plus9 polish and5 visual, but Q28 counterexamples collapse independent useful outcomes. No hash-bound weak/partial/full configured reward discrimination record was reviewed. Shared tests/test.sh exits after a failed scored suite, retaining the prior gate-only score record; score.py emits graded1/no_op0 for that record, so evaluator failure can look like an ordinary graded zero.

## reviewer-2:quality:reward_ranking_is_monotone

Not exercised: scoring.toml uses nonnegative weights with functional60% and gates/floor first, but this algebra does not measure real judge monotonicity. No matched weak/partial/full app reward-ordering experiment tied to this manifest was reviewed.

## reviewer-3:quality:timeouts_fit_the_work

Not exercised: tests/test.sh:213,224 uses suite budgets1500+11100=12600<13200 verifier; judges600/600 fit gates1500 and9000+900+900=10800 fit scored11100. However no hash-bound configured GLM full-judge duration exists for this candidate. The45-functional-row P1-P10 protocol requires many UI creations, role switches, lineage snapshots, races and a restart; scripted/browser time cannot establish LLM workload fit.

## reviewer-3:quality:solution_covers_every_deliverable

Fail: solution/app/public/js/hireops.js:172-177 prefill revised money with integerCents/100. reviewer-3-numeric.json executed the frozen cents parser:9007199254740991 cents -> string90071992547409.9 ->9007199254740990 cents;7036874417766401 ->7036874417766402. Public rules section1 require exact safe-integer inputs and no intermediate rounding. All requested screens exist, but valid large money is not preserved through revision.

## reviewer-3:quality:solution_covers_every_graded_dimension

Not exercised: Source walk covers45 Functional,9 Polish,5 Visual and2 gate criteria (reviewer-3-static.json), but no full exact-candidate golden/Oracle evidence was supplied. The numeric defect in row17 also means source plausibility cannot be represented as complete reference correctness. No subjective visual score or Oracle score inferred.

## reviewer-3:quality:solution_honors_the_runtime_contract_and_is_self_contained

Fail: environment/instructions/integration.md:9-10 says /api/health answers before database work can block startup; solution/app/src/index.js:30 calls synchronous dbmod.open() before app.listen at436. db.js:open performs SQLite WAL setup/schema/seeding. The health route itself has no SQL, but no listener exists while initialization blocks. solve.sh syntax/LF and DB_PATH/copy contract otherwise pass.

## reviewer-3:quality:verifier_entrypoint_is_safe_and_always_scores

Fail: Shared template limitation: tests/test.sh:36-37 sends TERM then unbounded wait; restart lines154-181 wait5s for old group but neither kill-resistant termination nor replacement-PID liveness is required, and HTTP readiness can come from surviving old listener. After gates, score.py writes graded=1/no_op=0 even with no scored data; test.sh:224 can exit after scored-suite failure retaining that gated-zero record. Canonical logic was preserved; source equals frozen template.

## reviewer-3:quality:verifier_image_can_launch_and_grade

Not exercised: tests/Dockerfile has declared tooling/runtime, and reviewer-3-tools.json proves actual local MCP0.0.79 capabilities on Windows Chrome. No frozen Linux verifier image launch plus full GLM/RewardKit grade was exercised here; it would be incorrect to promote local tool success to verifier/Oracle evidence.

## reviewer-3:quality:dimensions_cover_every_graded_requirement

Fail: instruction.md:9 mandates Node/Express/SQLite, no package install and local-only backend; integration.md mandates health before blocking DB startup. Every judge is browser-only and constraints prompt explicitly says it cannot infer SQLite. No criterion establishes these architecture/process/build properties. Public safe-integer money handling also has no large valid money UI round-trip control; hro_numeric_validation only includes huge units/overflow. Other domain formulas/lifecycle are substantially covered.

## reviewer-3:quality:criteria_are_independent_and_noncontradictory

Fail: tests/scored/functional/judge.toml hro_raise_roles (id at132) combines offer-creation role boundary with "Any signed-in role ... can create a requisition." Public rules explicitly call requisition opening different. These are separately useful authorization outcomes despite sharing P5 setup.

## reviewer-3:quality:plural_asks_are_checked_across_all_matches

Fail: tests/scored/functional/judge.toml hro_anon_read at359 tests "a successful ordinary authenticated operational read" and hro_anon_write at368 tests only creation. Public rules section8 require ALL operational reads and writes to require a session. Known visible operation families include detail reads, approval, revision and rescission; these are not covered anonymously by those rows.

## reviewer-3:quality:core_behavior_is_graded_and_state_is_proven_durable_where_it_must_be

Fail: Domain P4/P6/P7 probes substantively grade defining compensation transitions; hro_readback and constraints gate require fresh contexts, independently feasible in reviewer-3-tools.json. However hro_restart relies on canonical restart helper that can report surviving-old-process HTTP as success (tests/test.sh:154-181). No hash-bound actual process-replacement evidence accompanies the candidate.

## reviewer-3:quality:reward_is_graded_not_binary_and_discriminates

Not exercised: tests/scoring.toml and45 independently weighted Functional rows provide theoretical shaping, but no hash-bound partial-quality app/target-builder evaluations and rewards exist in this review. Missing empirical spread cannot be declared Pass from schema or scripted golden success.

## reviewer-3:quality:reward_ranking_is_monotone

Not exercised: Canonical0.6/0.2/0.2 positive weights are mathematically monotone in individual supplied scores, but that is not measured app-quality ranking. No exact-candidate ordered mutation/weak-app reward evidence. Known hro_raise_roles bundling also threatens fair partial-credit behavior.

## reviewer-3:quality:dimension_prompts_are_accurate_and_consistent

Fail: Functional prompt.md:15 says "Request replays are reserved for authorization, validation, body-claim and stale-operation tests." P6 at35 and hro_competing require replaying two different ordinary approval requests concurrently to test budget competition, outside that exclusive list. All product/account references otherwise agree.

