from pathlib import Path
import ast, hashlib, json, re, subprocess, tomllib

base=Path('.qc-cache/hireops-2026-10-01-round1')
task=base/'task'
template=base/'rules/projects/webdev-task-template'
report=Path('qc/runs/hireops-2026-10-01-round1')
lines=[]
def out(*args):
    line=' '.join(str(x) for x in args)
    print(line)
    lines.append(line)

for p in task.rglob('*.toml'):
    d=tomllib.loads(p.read_text())
    out('TOML OK',p.relative_to(task))
    if p.name=='judge.toml':
        j=d['judge']; cs=d['criterion']
        assert not set(j)&{'model','reasoning_effort','temperature','weight'}
        assert j['judge']=='claude-code'
        assert j['mode']=='batched' and isinstance(j['isolated'],bool)
        assert len({c['id'] for c in cs})==len(cs)
        assert all(c['type'] in ['binary','likert'] and c['weight']>0 and c['description'].strip() for c in cs)
        assert '{criteria}' in (p.parent/j['prompt_template']).read_text()
        assert any(s['name']=='playwright' for s in j['mcp_servers'])
        if p.parent.name=='functional': assert any(s['name']=='verifier' and '$APP_RESTART_HELPER' in s['args'] for s in j['mcp_servers'])
        else: assert all(s['name']!='verifier' for s in j['mcp_servers'])
        out('JUDGE SCHEMA OK',p.parent.name,'criteria',len(cs),'timeout',j['timeout'])
for p in task.rglob('*.json'):
    json.loads(p.read_text());out('JSON OK',p.relative_to(task))

for f in ['environment/Dockerfile','tests/Dockerfile','tests/tools/score.py','tests/tools/restart_mcp.py','tests/scoring.toml','tests/.dockerignore','tests/test.sh']:
    assert (task/f).read_text()==(template/f).read_text()
    out('TEMPLATE TEXT MATCH (line-ending normalization only)',f)
assert tomllib.loads((task/'task.toml').read_text())['verifier']==tomllib.loads((template/'task.toml').read_text())['verifier']
out('VERIFIER CONFIG EXACT PARSED MATCH')

for p in task.rglob('*.py'):
    ast.parse(p.read_text());out('PYTHON PARSE OK',p.relative_to(task))
for p in task.rglob('*.js'):
    r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    out('NODE CHECK OK',p.relative_to(task))
gitbash=Path('C:/Program Files/Git/bin/bash.exe')
for p in task.rglob('*.sh'):
    assert b'\r' not in p.read_bytes()
    if gitbash.exists():
        r=subprocess.run([str(gitbash),'-n',str(p)],capture_output=True,text=True)
        assert r.returncode==0,r.stderr
        out('BASH PARSE AND LF OK',p.relative_to(task))
    else: out('BASH UNAVAILABLE; LF OK',p.relative_to(task))

s=json.loads((task/'environment/assets/seed_data.json').read_text())
assert (task/'environment/assets/seed_data.json').read_bytes()==(task/'solution/app/src/seed_data.json').read_bytes()
ids={k:{x['id'] for x in s[k]} for k in ['users','employees','offers','requisitions']}
for k in ids: assert len(ids[k])==len(s[k])
for o in s['offers']:
    assert o['req_id'] in ids['requisitions']
    for k in ['raised_by','approved_by']:
        assert not o.get(k) or o[k] in ids['users']
    assert not o.get('referred_by') or o['referred_by'] in ids['employees']
for k in ['seed_commitments','seed_equity_grants','seed_remittances','seed_referral_accruals']:
    for r in s[k]: assert r['offer_id'] in ids['offers']
for r in s['seed_commitments']: assert r['req_id'] in ids['requisitions']
for r in s['seed_referral_accruals']: assert r['referrer_id'] in ids['employees']
out('SEED REFERENCES OK', {k:len(v) for k,v in ids.items()})
req=next(x for x in s['requisitions'] if x['id']=='REQ-ENG-2')
net=req['budget_cents']+sum(x['movement_cents'] for x in s['seed_commitments'] if x['req_id']==req['id'])
assert net==5300000
out('SEED REQ-ENG-2 HEADROOM',net)

public=(task/'instruction.md').read_text()+'\n'+'\n'.join(p.read_text() for p in (task/'environment/instructions').glob('*.md'))
assert len((task/'instruction.md').read_text().split())>40
out('PUBLIC WORD COUNT',len((task/'instruction.md').read_text().split()))
for pat in [r'TODO|FIXME|CHANGE[_-]?ME|<placeholder>|lorem ipsum',r'/Users/[a-z]+|C:\\Users|Documents and Settings',r'\bjudge\b|\brubric\b|\bplaywright\b|\bglm\b|\bclaude\b|/tests']:
    out('PUBLIC PATTERN',pat,'MATCHES',re.findall(pat,public,re.I))
criteria='\n'.join(p.read_text() for p in (task/'tests').rglob('judge.toml'))
probe_literals=['req /?#','offer /?#','chain req /?#','chain offer /?#']
seed_and_ui='\n'.join(p.read_text() for p in [task/'environment/assets/seed_data.json',*list((task/'solution/app/public').rglob('*'))] if p.is_file())
for probe in probe_literals:
    assert probe not in seed_and_ui;out('PROBE ABSENT',probe)
for p in (task/'tests').rglob('prompt.md'):
    t=p.read_text();assert 'http://localhost:3000' in t and '{criteria}' in t and '{app_context}' in t and 'untrusted' in t
    out('PROMPT BASIC CONTRACT OK',p.relative_to(task))
for p in (task/'tests/scored').rglob('prompt.md'):
    t=p.read_text();assert 'independent' in t and 'continue' in t
    out('BATCH CONTINUE/INDEPENDENCE OK',p.parent.name)
out('BUDGET ARITHMETIC','600<1500;9000,900,900<11100;1500+11100=12600<13200; measured LLM workload NOT EXERCISED')
out('PRIVATE CHECKER EXECUTABLES','not supplied in frozen task; deterministic rows manually applied, not portal execution')
(report/'reviewer-2-static.log').write_text('\n'.join(lines)+'\n')
