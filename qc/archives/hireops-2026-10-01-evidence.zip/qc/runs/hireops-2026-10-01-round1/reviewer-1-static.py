﻿from pathlib import Path
import json,tomllib,subprocess,re,ast
root=Path('.qc-cache/hireops-2026-10-01-round1/task')
base=Path('.qc-cache/hireops-2026-10-01-round1/rules/projects/webdev-task-template')
results={}
for p in root.rglob('*'):
 if p.is_file() and p.suffix in ['.toml','.json']:
  (tomllib.loads if p.suffix=='.toml' else json.loads)(p.read_text());results[str(p.relative_to(root))]='parsed'
for p in root.rglob('*.js'):
 r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True);assert r.returncode==0,r.stderr;results[str(p.relative_to(root))]='node --check passed'
for p in root.rglob('*.sh'):
 assert b'\r' not in p.read_bytes()
 r=subprocess.run(['C:/Program Files/Git/bin/bash.exe','-n',str(p)],capture_output=True,text=True);assert r.returncode==0,r.stderr;results[str(p.relative_to(root))]='bash -n passed; LF only'
for name in ['environment/Dockerfile','environment/instructions/integration.md','tests/Dockerfile','tests/.dockerignore','tests/scoring.toml','tests/test.sh','tests/tools/score.py','tests/tools/restart_mcp.py']:
 assert (root/name).read_text().strip()==(base/name).read_text().strip(),name
results['shared_files']='8 canonical files same text after newline/trailing whitespace normalization'
t=tomllib.loads((root/'task.toml').read_text());bt=tomllib.loads((base/'task.toml').read_text())
for k in ['agent','environment','verifier']:assert t[k]==bt[k],k
judges={p.parent.name:tomllib.loads(p.read_text()) for p in (root/'tests').rglob('judge.toml')}
for name,j in judges.items():
 assert not set(j['judge']).intersection(['model','reasoning_effort','temperature','weight'])
 assert len({c['id'] for c in j['criterion']})==len(j['criterion'])
 assert all(c['weight']>0 and c['type'] in ['binary','likert'] and c['description'] for c in j['criterion'])
 prompt=(root/'tests'/('gates' if name in ['render','constraints'] else 'scored')/name/'prompt.md').read_text()
 assert '{criteria}' in prompt and '{app_context}' in prompt and 'http://localhost:3000' in prompt
results['criteria_counts']={k:len(j['criterion']) for k,j in judges.items()}
results['budgets']='gate 600+600=1200 <1500; scored 9000+900+900=10800 <11100; suites12600 <13200; no workload runtime measurement'
s=json.loads((root/'environment/assets/seed_data.json').read_text())
assert s==json.loads((root/'solution/app/src/seed_data.json').read_text())
reqs={r['id']:r for r in s['requisitions']};offers={r['id']:r for r in s['offers']};users={r['id'] for r in s['users']};emps={r['id'] for r in s['employees']}
for o in offers.values():
 assert o['req_id'] in reqs
 assert not o.get('raised_by') or o['raised_by'] in users
 assert not o.get('approved_by') or o['approved_by'] in users
 assert not o.get('referred_by') or o['referred_by'] in emps
for key in ['seed_commitments','seed_equity_grants','seed_remittances','seed_referral_accruals']:
 for x in s[key]:assert x['offer_id'] in offers
for x in s['seed_commitments']:
 o=offers[x['offer_id']];eq=o['equity_units']*max(0,o['equity_fair_cents']-o['equity_strike_cents']);annual=(eq*2+4)//8
 assert x['movement_cents']==-o['base_salary_cents']-annual
results['seed']='13 offers,7 requisitions,7 users,3 employees; IDs resolve; commitments recompute; seed copies equal; no credentials in JSON'
results['seed_headroom']={k:r['budget_cents']+sum(x['movement_cents'] for x in s['seed_commitments'] if x['req_id']==k) for k,r in reqs.items()}
results['scans']={}
for pat in [r'TODO|FIXME|CHANGE_ME|<placeholder>|lorem ipsum',r'/Users/|C:\\Users|Documents and Settings',r'BEGIN (?:RSA |EC )?PRIVATE KEY',r'(?m)^\s*exec\s',r'(?m)^FROM\s+--platform=',r'\bnproc\b']:
 results['scans'][pat]=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and re.search(pat,p.read_text(),re.I)]
results['checker_availability']='No client checker executable supplied; documented manual application plus parser checks, not portal execution.'
Path('qc/runs/hireops-2026-10-01-round1/reviewer-1-static.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
