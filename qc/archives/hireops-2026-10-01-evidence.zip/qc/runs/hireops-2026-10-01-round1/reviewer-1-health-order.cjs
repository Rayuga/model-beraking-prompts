﻿const fs=require('fs'),vm=require('vm');
const events=[];let listening=false;
const app={get(){},post(){},put(){},patch(){},delete(){},use(){},listen(){listening=true;events.push('listen');}};
function express(){return app;}express.json=()=>()=>{};express.static=()=>()=>{};
const db={reference:{constants:{}},open(){events.push({event:'database-open',listening});return {};}};
const source=fs.readFileSync('.qc-cache/hireops-2026-10-01-round1/task/solution/app/src/index.js','utf8');
vm.runInNewContext(source,{require(p){if(p==='express')return express;if(p==='./db')return db;if(p==='./rules')return {};return require(p);},__dirname:'.',process:{env:{}},console,module:{exports:{}}});
const result={kind:'source execution with dependency stubs; no application or database mutation',events};
fs.writeFileSync('qc/runs/hireops-2026-10-01-round1/reviewer-1-health-order.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
