// Read-only reproduction against the frozen UI conversion code, no app or DB mutation.
const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync('.qc-cache/hireops-2026-10-01-round1/task/solution/app/public/js/hireops.js', 'utf8');
const conversion = source.match(/const cents = \(value\) => \{[\s\S]*?\n    \};/)[0];
const context = {};
vm.createContext(context);
vm.runInContext(conversion + ';this.cents=cents;', context);
const results = [9007199254740991, 9007199254740989, 7036874417766401].map(original => {
  const revisionDefault = String(original / 100);
  const result = context.cents(revisionDefault);
  return { original_cents: original, revision_default: revisionDefault, reparsed_cents: result, unchanged: result === original };
});
console.log(JSON.stringify({ command: 'node qc/runs/hireops-2026-10-01-round1/reviewer-3-numeric.cjs', input_sha256: '6d809f24074eabe762e198c60e43ca813f2c0b3791e7e56ea9c4b472b9be3d15', results }, null, 2));
