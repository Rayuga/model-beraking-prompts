// Independent capability probe. No HireOps process or database is touched.
const {spawn} = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const http = require('node:http');
const dir = __dirname;
const root = path.resolve(dir, '../../..');
const fixture = http.createServer((_req, res) => { res.setHeader('Content-Type','text/html'); res.end('<!doctype html><title>Capability fixture</title><p>Read-only capability fixture</p>'); });
const pending = new Map();
let sequence = 0;
const raw = [];
const cli = path.join(root,'.tools/hireops/node_modules/@playwright/mcp/cli.js');
const child = spawn(process.execPath,[cli,'--headless','--isolated','--no-sandbox','--executable-path','C:/Program Files/Google/Chrome/Application/chrome.exe'],{cwd:root,windowsHide:true,stdio:['pipe','pipe','pipe']});
let stderr = '';
child.stderr.on('data', c => {stderr += c;});
readline.createInterface({input:child.stdout}).on('line', line => {
  try {const msg=JSON.parse(line);raw.push(msg);if(pending.has(msg.id)){pending.get(msg.id)(msg);pending.delete(msg.id);}} catch {}
});
function rpc(method, params) {
  const id=++sequence;
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('RPC deadline '+method)),45000);
    pending.set(id,msg=>{clearTimeout(timer);resolve(msg);});
    child.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n');
  });
}
async function main(){
  await new Promise(resolve=>fixture.listen(0,'127.0.0.1',resolve));
  const base='http://127.0.0.1:'+fixture.address().port;
  await rpc('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'independent-reviewer-3',version:'1'}});
  child.stdin.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})+'\n');
  const list=await rpc('tools/list',{});
  const names=list.result.tools.map(t=>t.name);
  const nav=await rpc('tools/call',{name:'browser_navigate',arguments:{url:base}});
  const run=await rpc('tools/call',{name:'browser_run_code_unsafe',arguments:{code:`async(page)=>{
    await page.evaluate(()=>{localStorage.setItem('review-context','original');document.cookie='reviewcookie=original';});
    const ctx=await page.context().browser().newContext();
    const fresh=await ctx.newPage();await fresh.goto('${base}');
    const clean=await fresh.evaluate(()=>({storage:localStorage.getItem('review-context'),cookie:document.cookie}));
    await fresh.evaluate(()=>localStorage.setItem('review-context','second'));
    await page.reload();const original=await page.evaluate(()=>localStorage.getItem('review-context'));
    const concurrent=await Promise.all([ctx.request.get('${base}/a'),ctx.request.get('${base}/b')]);
    let intercepted=false;await fresh.route('**/delayed',async(route)=>{intercepted=true;await fresh.waitForTimeout(60);await route.continue();});
    await fresh.goto('${base}/delayed');await ctx.close();
    return {clean,original,concurrentStatuses:concurrent.map(r=>r.status()),responseDelaySupported:intercepted,originalPageAlive:!page.isClosed()};
  }`}});
  const result={command:'node qc/runs/hireops-2026-10-01-round1/reviewer-3-tools.cjs',scope:'Actual @playwright/mcp 0.0.79; Windows installed Chrome, not frozen Linux verifier Chromium; generic read-only HTTP fixture, no task app or database',input_sha256:'6d809f24074eabe762e198c60e43ca813f2c0b3791e7e56ea9c4b472b9be3d15',names,nav,run,stderr};
  fs.writeFileSync(path.join(dir,'reviewer-3-tools.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
}
main().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>{child.stdin.end();child.kill();fixture.close();});
