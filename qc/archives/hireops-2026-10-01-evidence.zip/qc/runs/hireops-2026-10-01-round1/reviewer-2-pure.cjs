const fs=require('fs'), vm=require('vm');
const dir='.qc-cache/hireops-2026-10-01-round1/task/solution/app';
const seed=JSON.parse(fs.readFileSync(dir+'/src/seed_data.json','utf8'));
const sandbox={module:{exports:{}},require:name=>{
  if(name==='./db') return {reference:{constants:seed.constants}};
  throw Error('unexpected dependency');
}};
vm.runInNewContext(fs.readFileSync(dir+'/src/rules.js','utf8'),sandbox);
const R=sandbox.module.exports, lines=[];
const out=(x)=>{const t=JSON.stringify(x);lines.push(t);console.log(t)};
const comp=(base,bonus,units,fair,strike)=>R.composition({base_salary_cents:base,signing_bonus_cents:bonus,relocation_cents:12345,equity_units:units,equity_fair_cents:fair,equity_strike_cents:strike});
for(const base of [19999997,19999998,34999997,34999998]) out({kind:'band',...comp(base,1,2,3,2)});
for(const [base,bonus,units,fair,strike] of [[10000000,1000001,7,102,1],[11000000,800003,11,203,2],[9000000,1200005,13,304,3]])out({kind:'lineage',...comp(base,bonus,units,fair,strike)});
for(const [start,end,want] of [
 ['2024-02-29T12:34:56.789Z','2025-02-28T12:34:56.788Z',11],
 ['2024-02-29T12:34:56.789Z','2025-02-28T12:34:56.789Z',12],
 ['2024-01-31T12:00:00Z','2025-03-30T12:00:00Z',13],
 ['2024-01-01T00:00:00Z','2026-01-01T00:00:00Z',24],
 ['2024-01-01T00:00:00Z','2026-09-01T00:00:00Z',32],
 ['2024-01-01T00:00:00Z','2023-01-01T00:00:00Z',0]]){
 const actual=R.completedMonths(start,end);if(actual!==want)throw Error('month mismatch');
 out({kind:'vesting',start,end,months:actual,signing:R.signingClawback({start_date:start,signing_bonus_cents:10001},end),equity:R.equityCancellation({grant_date:start,units:7},end)});
}
out({kind:'invalid_calendar',invalid:R.validDate('2025-02-30T00:00:00Z'),valid:R.validDate('2024-02-29T12:34:56.789Z')});
for(const start of ['2026-02-01T00:00:00Z','2026-02-01T00:00:00.001Z','2026-01-31T12:00:00Z'])out({kind:'referral',start,...R.referralVested({referred_hire_start:start,at_hire_cents:500000,contingent_cents:500000,total_cents:1000000},seed.reference_moment)});
const text=fs.readFileSync(dir+'/public/js/hireops.js','utf8');
const centsText=text.slice(text.indexOf('const cents ='),text.indexOf('const units ='));
const cents=vm.runInNewContext(centsText+' cents;');
const amount=Number.MAX_SAFE_INTEGER;
const revisionFieldValue=String(amount/100);
out({kind:'confirmed_revision_default_precision_loss',stored_cents:amount,revision_default:revisionFieldValue,round_trip_cents:cents(revisionFieldValue),delta:cents(revisionFieldValue)-amount,source:'public/js/hireops.js revise defaults divide cents by 100 before converting to text'});
try{comp(0,0,Number.MAX_SAFE_INTEGER,2,0);throw Error('overflow accepted');}catch(e){if(e.message==='overflow accepted')throw e;out({kind:'derived_overflow_refused',message:e.message});}
out({kind:'max_units_zero_spread',...comp(0,0,Number.MAX_SAFE_INTEGER,1,1)});
fs.writeFileSync('qc/runs/hireops-2026-10-01-round1/reviewer-2-pure.log',lines.join('\n')+'\n');
