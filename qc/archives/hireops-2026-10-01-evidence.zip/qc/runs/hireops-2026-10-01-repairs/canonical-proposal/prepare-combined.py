from pathlib import Path
import difflib
p=Path('qc/runs/hireops-2026-10-01-repairs/canonical-proposal')
base=Path('projects/webdev-task-template/tests/test.sh').read_text()
s=(p/'test.sh').read_text()
a=s.index('while IFS= read -r link; do')
b=s.index('\n\nchmod -R a+rX /app',a)
fix=(p/'symlink-guard.sh').read_text().split('\n',1)[1].split('\nprintf GUARD_PASSED')[0]
s=s[:a]+fix+s[b:]
s=s.replace('if ! run_suite scored 11100; then\n  exit 0','if ! run_suite scored 11100; then\n  write_zero_reward\n  exit 0')
(p/'test-combined.sh').write_text(s,encoding='utf-8',newline='\n')
(p/'combined.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='canonical/tests/test.sh',tofile='proposed/tests/test.sh')),encoding='utf-8',newline='\n')
n=(p/'check-normal.py').read_text().replace("'normal-runtime'","'normal-runtime-combined'").replace("name='hireops-proposed-normal'","name='hireops-proposed-normal-combined'").replace("'canonical-proposal'/'test.sh'","'canonical-proposal'/'test-combined.sh'")
(p/'check-normal-combined.py').write_text(n,encoding='utf-8',newline='\n')
n=(p/'check-proposal.py').read_text().replace("'resistant-tests'","'resistant-tests-combined'").replace("name='hireops-proposed-'","name='hireops-proposed-combined-'").replace("'canonical-proposal'/'test.sh'","'canonical-proposal'/'test-combined.sh'")
(p/'check-resistant-combined.py').write_text(n,encoding='utf-8',newline='\n')
n=(p.parent/'runtime/check-scored-failure.py').read_text().replace("'scored-failure-test'","'scored-failure-test-combined'").replace("'test-scored-failure.sh'","'test-combined.sh'").replace("name = 'hireops-scored-failure-probe'","name = 'hireops-scored-failure-probe-combined'")
(p/'check-scored-failure-combined.py').write_text(n,encoding='utf-8',newline='\n')
