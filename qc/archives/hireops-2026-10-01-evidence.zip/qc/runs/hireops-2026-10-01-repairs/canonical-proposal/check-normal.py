"""Offline real image/harness/MCP run, with explicitly synthetic RewardKit transport."""
from pathlib import Path
import argparse,hashlib,json,subprocess,time

ap=argparse.ArgumentParser();ap.add_argument('--label',default='preliminary');ap.add_argument('--image',default='hireops-verifier:20261001');args=ap.parse_args()
root=Path.cwd();scripts=root/'qc/runs/hireops-2026-10-01-repairs/runtime';out=scripts.parent/'canonical-proposal'/'normal-runtime';out.mkdir(parents=True,exist_ok=True)
task=root/'projects/hireops-recruiting-operations/hireops-recruiting-operations'
name='hireops-proposed-normal'
log=[]
def run(cmd,timeout=90,check=True):
    r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
    log.append({'cmd':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(out/'commands.json').write_text(json.dumps(log,indent=2))
    if check and r.returncode:raise RuntimeError(str(cmd)+'\n'+r.stdout+'\n'+r.stderr)
    return r
def hashes():return {str(p.relative_to(task)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in task.rglob('*') if p.is_file()}
before=hashes();(out/'source-before.json').write_text(json.dumps(before,indent=2))
run(['docker','image','inspect',args.image,'hireops-agent:20261001'])
run(['docker','run','--rm','--network','none','hireops-agent:20261001','sh','-c','find /app -maxdepth 2 -type f; test ! -e /tests && test ! -e /solution && test ! -e /app/server.js && echo AGENT_ISOLATION_OK'])
run(['docker','run','--name',name,'--network','none','--init','-d',args.image,'sleep','infinity'])
try:
    run(['docker','exec',name,'mkdir','-p','/evidence/bin'])
    run(['docker','cp',str(task/'solution'),name+':/solution'])
    run(['docker','cp',str(task/'tests')+'/.',name+':/tests'])
    run(['docker','cp',str(scripts.parent/'canonical-proposal'/'test.sh'),name+':/tests/test.sh'])
    run(['docker','cp',str(scripts/'rewardkit-fixture'),name+':/evidence/bin/rewardkit'])
    run(['docker','cp',str(scripts/'mcp-linux.cjs'),name+':/evidence/mcp-linux.cjs'])
    run(['docker','exec',name,'chmod','755','/evidence/bin/rewardkit'])
    run(['docker','exec',name,'bash','/solution/solve.sh'])
    run(['docker','exec',name,'sh','-c','test ! -e /assets && test ! -e /instructions && echo RUNTIME_HAS_NO_EXTERNAL_SEED_MOUNT; node --version; chromium --version; python3 -m pip show harbor-rewardkit'])
    # Only the disposable container uses the proposed lifecycle change; shipped task unchanged. Only command resolution of rewardkit is a synthetic offline fixture.
    run(['docker','exec','-d',name,'sh','-c','PATH=/evidence/bin:/usr/local/bin:/usr/bin:/bin REWARDKIT_JUDGE=claude-code REWARDKIT_MODEL=z-ai/glm-5.3-flashx bash /tests/test.sh > /evidence/harness.log 2>&1; echo $? > /evidence/harness.exit'])
    for _ in range(100):
        p=run(['docker','exec',name,'test','-e','/evidence/scored.entered'],check=False)
        if p.returncode==0:break
        time.sleep(.2)
    else:raise RuntimeError('Canonical harness did not reach scored phase')
    run(['docker','exec',name,'sh','-c','pid=$(cat /logs/verifier/app.pid); ps -o pid,ppid,pgid,user,args -p "$pid"; tr "\\0" "\\n" < /proc/"$pid"/environ'],check=False)
    run(['docker','exec',name,'timeout','180','node','/evidence/mcp-linux.cjs'],timeout=200)
    run(['docker','exec',name,'touch','/evidence/release'])
    for _ in range(50):
        p=run(['docker','exec',name,'test','-e','/evidence/harness.exit'],check=False)
        if p.returncode==0:break
        time.sleep(.2)
    run(['docker','exec',name,'sh','-c','cat /evidence/harness.exit; cat /logs/verifier/reward.json; pid=$(cat /logs/verifier/app.pid); if kill -0 "$pid" 2>/dev/null; then echo APP_PROCESS_STILL_EXISTS; else echo APP_STOPPED; fi'])
finally:
    run(['docker','cp',name+':/evidence/.',str(out)],check=False)
    run(['docker','cp',name+':/logs/verifier',str(out/'verifier-logs')],check=False)
    run(['docker','rm','-f',name],check=False)
    after=hashes();(out/'source-after.json').write_text(json.dumps(after,indent=2))
    (out/'evidence-classification.json').write_text(json.dumps({'real':'Linux Docker images, golden app, proposed test.sh launch/restart helper, pinned MCP Chromium, real UI and durable DB operations','synthetic':'rewardkit executable transport fixture supplies dummy gates/scored JSON solely to hold proposed harness; all reward numbers meaningless','provider_runs':False,'source_stable':before==after,'changed_during_run':[k for k in set(before)|set(after) if before.get(k)!=after.get(k)]},indent=2))
print('Runtime evidence:',out)
