import json,subprocess
requests=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2024-11-05','capabilities':{},'clientInfo':{'name':'resistant-process-fixture','version':'1'}}},{'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'restart_app','arguments':{}}}]
r=subprocess.run(['python3','/tests/tools/restart_mcp.py','/logs/verifier/app-restart.sh'],input=''.join(json.dumps(x)+'\n' for x in requests),text=True,capture_output=True,timeout=58)
print(r.stdout);print(r.stderr)
