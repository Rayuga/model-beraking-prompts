"""Offline harness failure provenance probe; synthetic transport, never a judge score."""
import hashlib
import argparse
import json
import subprocess
from pathlib import Path

root = Path.cwd()
ap=argparse.ArgumentParser();ap.add_argument('--proposed', action='store_true');args=ap.parse_args()
task = root / 'projects/hireops-recruiting-operations/hireops-recruiting-operations'
out = root / 'qc/runs/hireops-2026-10-01-repairs/runtime/scored-failure-configured'
if args.proposed:
    out = root / 'qc/runs/hireops-2026-10-01-repairs/canonical-proposal/scored-failure-test'
out.mkdir(parents=True, exist_ok=True)
fixture = out / 'rewardkit'
fixture.write_text('''#!/usr/local/bin/python3
import json,sys
from pathlib import Path
a=sys.argv[1:]
p=Path(a[a.index('--output')+1]); p.parent.mkdir(parents=True,exist_ok=True)
if Path(a[-1]).name=='gates':
    p.write_text(json.dumps({'render':1.0,'constraints':1.0}))
    print('SYNTHETIC transport gates; no provider or scoring evidence')
else:
    print('DELIBERATE synthetic scored evaluator failure',file=sys.stderr)
    sys.exit(73)
''', encoding='utf-8', newline='\n')
name = 'hireops-scored-failure-probe-combined'
commands = []
def run(cmd, check=True):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=90)
    commands.append(dict(command=cmd, exit=r.returncode, stdout=r.stdout, stderr=r.stderr))
    (out/'commands.json').write_text(json.dumps(commands, indent=2), encoding='utf-8')
    if check and r.returncode:
        raise RuntimeError(r.stderr or r.stdout)
    return r
run(['docker','run','--name',name,'--network','none','--init','-d','hireops-verifier:20261001-final','sleep','infinity'])
try:
    run(['docker','exec',name,'mkdir','-p','/evidence/bin'])
    run(['docker','cp',str(task/'solution'),name+':/solution'])
    run(['docker','cp',str(task/'tests')+'/.',name+':/tests'])
    if args.proposed:
        run(['docker','cp',str(out.parent/'test-combined.sh'),name+':/tests/test.sh'])
    run(['docker','cp',str(fixture),name+':/evidence/bin/rewardkit'])
    run(['docker','exec',name,'chmod','755','/evidence/bin/rewardkit'])
    run(['docker','exec',name,'bash','/solution/solve.sh'])
    run(['docker','exec',name,'sh','-c','PATH=/evidence/bin:/usr/local/bin:/usr/bin:/bin REWARDKIT_JUDGE=claude-code REWARDKIT_MODEL=z-ai/glm-5.3-flashx bash /tests/test.sh > /evidence/harness.log 2>&1; echo $? > /evidence/harness.exit'])
    run(['docker','cp',name+':/logs/verifier',str(out/'verifier-logs')])
    run(['docker','cp',name+':/evidence/harness.log',str(out/'harness.log')])
    reward=json.loads((out/'verifier-logs/reward.json').read_text())
    assert 'DELIBERATE synthetic scored evaluator failure' in (out/'verifier-logs/scored/rewardkit.log').read_text(), 'Probe never reached scored transport'
    finding={'classification':'Synthetic evaluator-failure handling only; no model score','real':'Unchanged test.sh and score.py with actual Node22 golden launch','fixture':'gate JSON injected; scored transport exits73 without score output','reward_metadata':reward,'falsely_marked_graded':reward.get('graded')==1 and reward.get('no_op')==0,'source_hashes':{p:hashlib.sha256((task/p).read_bytes()).hexdigest() for p in ['tests/test.sh','tests/tools/score.py']}}
    if args.proposed:
        finding['real']='Proposed test.sh only in disposable container; unchanged score.py; actual Node22 golden launch'
        finding['source_hashes']['tests/test.sh']=hashlib.sha256((out.parent/'test-combined.sh').read_bytes()).hexdigest()
    (out/'result.json').write_text(json.dumps(finding,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(finding,indent=2))
finally:
    run(['docker','rm','-f',name],check=False)
