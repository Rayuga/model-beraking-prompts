"""Isolated positive and negative controls for the proposed artifact-link guard."""
from pathlib import Path
import json,subprocess
root=Path.cwd();out=root/'qc/runs/hireops-2026-10-01-repairs/canonical-proposal'
cases={
    'ordinary_internal_asset': ('ln -s /app/public/base.css /app/public/theme.css',True),
    'internal_node_module': ('ln -s /app/public/base.css /app/node_modules/module.css',True),
    'internal_root': ('ln -s /app /app/public/root',True),
    'newline_name': ("ln -s /app/public/base.css /app/public/$'theme\\nname.css'",True),
    'external_path': ('ln -s /etc/passwd /app/public/escape.css',False),
    'external_node_module': ('ln -s /etc/passwd /app/node_modules/escape.css',False),
}
records=[]
for name,(setup,expected) in cases.items():
    command=['docker','run','--rm','--network','none','--mount',f'type=bind,src={out},dst=/proposal,readonly','hireops-verifier:20261001-final','bash','-c','mkdir -p /app/public /app/node_modules; touch /app/public/base.css; '+setup+'; bash /proposal/symlink-guard.sh']
    p=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',timeout=30)
    observed='GUARD_PASSED' in p.stdout
    records.append(dict(name=name,expected_pass=expected,observed_pass=observed,passed=p.returncode==0 and observed==expected,command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
(out/'symlink-results.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
assert all(r['passed'] for r in records), records
print('All six symlink guard controls passed; proposed patch remains outside canonical/task.')
