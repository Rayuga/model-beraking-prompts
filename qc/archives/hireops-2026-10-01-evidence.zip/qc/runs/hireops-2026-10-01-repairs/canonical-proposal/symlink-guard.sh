#!/bin/bash
while IFS= read -r -d '' link; do
  target="$(readlink -f "$link" 2>/dev/null || true)"
  case "$target" in
    /app|/app/*) ;;
    *) exit 0 ;;
  esac
done < <(find /app -type l -print0 2>/dev/null)
printf GUARD_PASSED
