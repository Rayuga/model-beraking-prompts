"""Prepare an unapplied shared-harness patch; no canonical or task mutation."""
from pathlib import Path
import difflib

root=Path.cwd()
out=root/'qc/runs/hireops-2026-10-01-repairs/canonical-proposal'
base=(root/'projects/webdev-task-template/tests/test.sh').read_text()
start=base.index('while IFS= read -r link; do')
end=base.index('\n\nchmod -R a+rX /app',start)
replacement='''while IFS= read -r -d '' link; do
  target="$(readlink -f "$link" 2>/dev/null || true)"
  case "$target" in
    /app|/app/*) ;;
    *) exit 0 ;;
  esac
done < <(find /app -type l -print0 2>/dev/null)'''
proposed=base[:start]+replacement+base[end:]
(out/'test-symlinks.sh').write_text(proposed,encoding='utf-8',newline='\n')
(out/'symlinks.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),proposed.splitlines(True),fromfile='canonical/tests/test.sh',tofile='proposed/tests/test.sh')),encoding='utf-8',newline='\n')
(out/'symlink-guard.sh').write_text('#!/bin/bash\n'+replacement+'\nprintf GUARD_PASSED\n',encoding='utf-8',newline='\n')
