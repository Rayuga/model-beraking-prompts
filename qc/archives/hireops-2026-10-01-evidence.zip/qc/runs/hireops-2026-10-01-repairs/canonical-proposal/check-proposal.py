from pathlib import Path
import subprocess,json,time
base=Path.cwd()/'qc/runs/hireops-2026-10-01-repairs/runtime';out=base.parent/'canonical-proposal'/'resistant-tests';out.mkdir(parents=True,exist_ok=True)
logs=[]
def run(cmd,check=True,timeout=70):
 r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout);logs.append({'cmd':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(out/'commands.json').write_text(json.dumps(logs,indent=2))
 if check and r.returncode:raise RuntimeError(r.stderr)
 return r
for mode in ['restart','cleanup']:
 name='hireops-proposed-'+mode
 run(['docker','run','--network','none','--init','--name',name,'-d','hireops-verifier:20261001','sleep','infinity'])
 try:
  run(['docker','exec',name,'mkdir','-p','/app','/evidence/bin'])
  run(['docker','cp',str(base.parent/'canonical-proposal'/'test.sh'),name+':/tests/test.sh'])
  run(['docker','cp',str(base/'resistant-server.cjs'),name+':/app/server.js'])
  run(['docker','cp',str(base/'rewardkit-fixture'),name+':/evidence/bin/rewardkit'])
  run(['docker','cp',str(base/'restart-probe.py'),name+':/evidence/restart-probe.py'])
  run(['docker','exec',name,'chmod','755','/evidence/bin/rewardkit'])
  run(['docker','exec','-d',name,'sh','-c','PATH=/evidence/bin:/usr/local/bin:/usr/bin:/bin REWARDKIT_JUDGE=claude-code REWARDKIT_MODEL=z-ai/glm-5.3-flashx timeout -k 2 90 bash /tests/test.sh > /evidence/harness.log 2>&1; echo $? > /evidence/harness.exit'])
  for _ in range(100):
   if run(['docker','exec',name,'test','-e','/evidence/scored.entered'],False).returncode==0:break
   time.sleep(.1)
  before=run(['docker','exec',name,'python3','-c','import urllib.request;print(urllib.request.urlopen("http://localhost:3000/api/health").read().decode())']).stdout.strip()
  if mode=='restart':
   run(['docker','exec',name,'python3','/evidence/restart-probe.py'])
   after=run(['docker','exec',name,'python3','-c','import urllib.request;print(urllib.request.urlopen("http://localhost:3000/api/health").read().decode())']).stdout.strip()
   run(['docker','exec',name,'sh','-c','cat /logs/verifier/app.pid; cat /logs/verifier/app-restart.log; ps -eo pid,ppid,pgid,user,args'])
   assert before != after, 'Replacement must use a new live PID'
   (out/'restart-result.json').write_text(json.dumps({'before':json.loads(before),'after':json.loads(after),'same_original_process':before==after,'meaning':'Proposed lifecycle helper tested against a SIGTERM-resistant application; compare actual PID evidence.'},indent=2))
  run(['docker','exec',name,'touch','/evidence/release'])
  time.sleep(6)
  run(['docker','exec',name,'sh','-c','if test -e /evidence/harness.exit; then cat /evidence/harness.exit; else echo HARNESS_NOT_EXITED_AFTER_SCORED_FINISHED; fi; cat /logs/verifier/reward.json; ps -eo pid,ppid,pgid,user,args'])
  exit_result=run(['docker','exec',name,'cat','/evidence/harness.exit'])
  assert exit_result.stdout.strip()=='0', 'Cleanup must finish preserving status'
  target=out/mode;target.mkdir(exist_ok=True)
  run(['docker','cp',name+':/evidence/.',str(target)])
  run(['docker','cp',name+':/logs/verifier',str(target/'verifier-logs')])
 finally:run(['docker','rm','-f',name],False)
print(out)
