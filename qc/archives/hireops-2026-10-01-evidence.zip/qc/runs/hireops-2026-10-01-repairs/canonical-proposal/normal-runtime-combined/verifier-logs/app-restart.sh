#!/bin/bash
set -euo pipefail

group_running() {
  [[ "$1" =~ ^[0-9]+$ && "$1" -gt 1 ]] || return 1
  ps -eo pgid=,stat= | awk -v group="$1" '$1 == group && $2 !~ /^Z/ { live=1 } END { exit !live }'
}
stop_group() {
  local group="$1"
  [[ "$group" =~ ^[0-9]+$ && "$group" -gt 1 ]] || return 0
  kill -- "-$group" 2>/dev/null || true
  for _ in $(seq 1 30); do
    group_running "$group" || return 0
    sleep 0.1
  done
  kill -KILL -- "-$group" 2>/dev/null || true
  for _ in $(seq 1 20); do
    group_running "$group" || return 0
    sleep 0.1
  done
  return 1
}
probe_ready() {
  python3 - <<'PY' >/dev/null 2>&1
import sys
import urllib.error
import urllib.request

for url in ("http://127.0.0.1:3000/api/health", "http://127.0.0.1:3000/"):
    try:
        urllib.request.urlopen(url, timeout=2).read()
    except urllib.error.HTTPError:
        sys.exit(0)
    except Exception:
        continue
    sys.exit(0)
sys.exit(1)
PY
}
LOG_DIR="/logs/verifier"
if [[ ! -f "$LOG_DIR/app.pid" ]]; then
  printf 'app-restart: no app.pid; cannot restart\n' >&2
  exit 1
fi
old_pid="$(cat "$LOG_DIR/app.pid")"
if ! stop_group "$old_pid"; then
  printf 'app-restart: prior process group did not stop\n' >&2
  exit 1
fi
python3 - <<'PYPORT'
import socket
with socket.socket() as listener:
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(('127.0.0.1', 3000))
PYPORT
setsid env -i \
  PATH="/usr/local/bin:/usr/bin:/bin" \
  NODE_PATH="/usr/local/lib/node_modules" \
  HOME="/tmp/submission" \
  PORT="3000" \
  DB_PATH="/app/app.db" \
  setpriv --reuid=65534 --regid=65534 --clear-groups \
  sh -c 'cd "$(dirname "$1")"; exec node "$1"' sh "/app/server.js" >>"$LOG_DIR/app-restart.log" 2>&1 &
new_pid=$!
printf '%s\n' "$new_pid" > "$LOG_DIR/app.pid"
ready=0
for _ in $(seq 1 120); do
  if ! kill -0 "$new_pid" 2>/dev/null; then
    printf 'app-restart: replacement exited\n' >&2
    exit 1
  fi
  if probe_ready && kill -0 "$new_pid" 2>/dev/null; then
    ready=1
    break
  fi
  sleep 0.25
done
printf 'app-restart pid=%s ready=%s at %s\n' "$new_pid" "$ready" "$(date -u +%FT%TZ)" >> "$LOG_DIR/app-restart.log"
if [[ "$ready" != "1" ]]; then
  printf 'app-restart: application did not answer HTTP within 30 seconds\n' >&2
  exit 1
fi
exit 0
