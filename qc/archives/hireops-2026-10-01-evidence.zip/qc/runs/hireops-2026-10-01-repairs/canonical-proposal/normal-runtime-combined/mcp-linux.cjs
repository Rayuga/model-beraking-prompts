'use strict';
// Real pinned Linux Playwright MCP + Chromium and real restart MCP. No judge/provider.
const fs=require('fs'),assert=require('assert/strict'),{spawn}=require('child_process'),readline=require('readline');
const out='/evidence/mcp';fs.mkdirSync(out,{recursive:true});
let serial=0;const children=[],results=[];
function client(command,args,name){
 const child=spawn(command,args,{stdio:['pipe','pipe','pipe'],env:{PATH:'/usr/local/bin:/usr/bin:/bin',HOME:'/root',PLAYWRIGHT_BROWSERS_PATH:'/opt/playwright-browsers',NODE_PATH:'/usr/local/lib/node_modules'}});children.push(child);
 const pending=new Map();child.stderr.pipe(fs.createWriteStream(out+'/'+name+'-stderr.log'));
 readline.createInterface({input:child.stdout}).on('line',line=>{
   fs.appendFileSync(out+'/'+name+'-responses.jsonl',line+'\n');
   try{const msg=JSON.parse(line);if(pending.has(msg.id)){const p=pending.get(msg.id);pending.delete(msg.id);clearTimeout(p.timer);p.resolve(msg)}}catch{}
 });
 return {child,rpc(method,params={}){return new Promise((resolve,reject)=>{
   const id=++serial,msg={jsonrpc:'2.0',id,method,params};
   const timer=setTimeout(()=>{pending.delete(id);reject(Error(name+' '+method+' timed out'))},58000);
   pending.set(id,{resolve,reject,timer});
   fs.appendFileSync(out+'/'+name+'-requests.jsonl',JSON.stringify(msg)+'\n');child.stdin.write(JSON.stringify(msg)+'\n');
 })}};
}
async function init(c){const r=await c.rpc('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'hireops-offline-runtime-probe',version:'1'}});assert(r.result);c.child.stdin.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})+'\n');return c.rpc('tools/list')}
async function tool(c,name,args={}){const reply=await c.rpc('tools/call',{name,arguments:args});if(reply.error||reply.result?.isError)throw Error(JSON.stringify(reply));return reply.result}
function result(name,data){results.push({name,passed:true,data});console.log('PASS',name);fs.writeFileSync(out+'/results.json',JSON.stringify({kind:'real Linux browser/restart tooling; no model judging',results},null,2));}
async function main(){
 const browser=client('playwright-mcp',['--headless','--isolated','--executable-path=/usr/local/bin/chromium','--no-sandbox','--output-dir',out],'browser');
 const listed=await init(browser);fs.writeFileSync(out+'/tools.json',JSON.stringify(listed,null,2));
 assert(listed.result.tools.some(x=>x.name==='browser_run_code_unsafe'));result('actual pinned browser tool listed',listed.result.tools.map(x=>x.name));
 await tool(browser,'browser_navigate',{url:'http://localhost:3000'});
 const run=async(name,code)=>result(name,await tool(browser,'browser_run_code_unsafe',{code}));
 await run('golden UI sign-in and new persisted requisition',`async(page)=>{
  await page.locator('#email').fill('rafael.costa@hireops.example');await page.locator('#password').fill('Hireops!2026');
  await page.getByRole('button',{name:'Sign in',exact:true}).click();await page.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();
  await page.getByRole('navigation').getByRole('button',{name:'Requisitions',exact:true}).click();
  await page.locator('#req-id').fill(' Linux MCP /?# ');await page.locator('#req-title').fill('Linux MCP durable requisition');await page.locator('#req-budget').fill('50000.01');
  await page.getByRole('button',{name:'Create requisition',exact:true}).click();await page.locator('article.entity').filter({hasText:'Linux MCP durable requisition'}).waitFor();
  return {text:await page.locator('article.entity').filter({hasText:'Linux MCP durable requisition'}).innerText()};
 }`);
 await run('new pending offer via UI and exact fields',`async(page)=>{
  await page.getByRole('navigation').getByRole('button',{name:'Offers',exact:true}).click();
  await page.locator('#off-id').fill(' Linux offer /?# ');await page.locator('#off-req').selectOption(' Linux MCP /?# ');await page.locator('#off-cand').fill('Linux durable candidate');await page.locator('#off-base').fill('100.01');await page.locator('#off-start').fill('2024-02-29T12:34:56.789Z');
  await page.getByRole('button',{name:'Create offer',exact:true}).click();await page.locator('article.entity').filter({hasText:'Linux durable candidate'}).waitFor();
  return {text:await page.locator('article.entity').filter({hasText:'Linux durable candidate'}).innerText()};
 }`);
 await run('newContext storage isolation and fresh Auditor readback',`async(page)=>{
   const ctx=await page.context().browser().newContext();try{const p=await ctx.newPage();await p.goto('http://localhost:3000');
   const before=await p.evaluate(async()=>({status:(await fetch('/api/bootstrap')).status}));if(before.status!==401)throw Error('Fresh context already authenticated');
   await p.locator('#email').fill('aud.halvorsen@hireops.example');await p.locator('#password').fill('Hireops!2026');await p.getByRole('button',{name:'Sign in',exact:true}).click();await p.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();
   const boot=await p.evaluate(async()=>await(await fetch('/api/bootstrap')).json());const req=boot.requisitions.find(x=>x.id===' Linux MCP /?# '),offer=boot.offers.find(x=>x.id===' Linux offer /?# ');
   if(req?.budget_cents!==5000001||offer?.composition.base_salary_cents!==10001||offer?.start_date!=='2024-02-29T12:34:56.789Z')throw Error('Saved details differ');
   await p.getByRole('navigation').getByRole('button',{name:'Offers',exact:true}).click();const visible=await p.locator('article.entity').filter({hasText:'Linux durable candidate'}).innerText();
   return {independent401:true,req,offer,visible,seedOfferCount:boot.offers.length};}finally{await ctx.close()}
 }`);
 const pre=await tool(browser,'browser_run_code_unsafe',{code:`async(page)=>{const b=await page.evaluate(async()=>await(await fetch('/api/bootstrap')).json());return {requisitions:b.requisitions,offers:b.offers,after_images:b.after_images,commitment_movements:b.commitment_movements,remittances:b.remittances,equity_grants:b.equity_grants,referral_accruals:b.referral_accruals}}`});
 fs.writeFileSync(out+'/before-restart.json',JSON.stringify(pre,null,2));
 const restart=client('/usr/local/bin/python3',['/tests/tools/restart_mcp.py','/logs/verifier/app-restart.sh'],'restart');
 const tools=await init(restart);assert(tools.result.tools.some(t=>t.name==='restart_app'));
 result('actual restart_app single successful invocation',await tool(restart,'restart_app'));
 const post=await tool(browser,'browser_run_code_unsafe',{code:`async(page)=>{await page.goto('http://localhost:3000');await page.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();const b=await page.evaluate(async()=>await(await fetch('/api/bootstrap')).json());return {requisitions:b.requisitions,offers:b.offers,after_images:b.after_images,commitment_movements:b.commitment_movements,remittances:b.remittances,equity_grants:b.equity_grants,referral_accruals:b.referral_accruals}}`});
 fs.writeFileSync(out+'/after-restart.json',JSON.stringify(post,null,2));
 // MCP wraps code result in markdown; extracting the Result section avoids unrelated browser reporting.
 const value=x=>x.content.filter(c=>c.type==='text').map(c=>c.text).join('\n').split('### Result\n')[1]?.split('\n###')[0]?.trim();
 assert(value(pre)&&value(post));assert.deepEqual(JSON.parse(value(post)),JSON.parse(value(pre)));result('all captured persisted records identical after restart', {same:true});
 await run('post-restart fresh Auditor UI sign-in sees new offer',`async(page)=>{const ctx=await page.context().browser().newContext();try{const p=await ctx.newPage();await p.goto('http://localhost:3000');await p.locator('#email').fill('aud.halvorsen@hireops.example');await p.locator('#password').fill('Hireops!2026');await p.getByRole('button',{name:'Sign in',exact:true}).click();await p.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();await p.getByRole('navigation').getByRole('button',{name:'Offers',exact:true}).click();return{visible:await p.locator('article.entity').filter({hasText:'Linux durable candidate'}).innerText()}}finally{await ctx.close()}}`);
}
main().then(()=>{fs.writeFileSync(out+'/completed','PASS\n')}).catch(e=>{fs.writeFileSync(out+'/failure.txt',e.stack);console.error(e);process.exitCode=1}).finally(()=>{for(const c of children)c.kill('SIGTERM');});
