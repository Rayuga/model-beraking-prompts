from pathlib import Path
import hashlib
import json
import re
import tomllib
from decimal import Decimal

root = Path(__file__).resolve().parents[4]
directory = root / 'projects/hireops-recruiting-operations/hireops-recruiting-operations/tests/scored/functional'
judge_path = directory / 'judge.toml'
prompt_path = directory / 'prompt.md'
before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [judge_path, prompt_path]}
judge = judge_path.read_text(encoding='utf-8')
prompt = prompt_path.read_text(encoding='utf-8')
old = tomllib.loads(judge)
assert len(old['criterion']) == 45, 'Repair applies once to the reviewed 45-row source.'
sections = re.split(r'(?=\[\[criterion\]\])', judge)
head, blocks = sections[0], sections[1:]
by_id = {tomllib.loads(s)['criterion'][0]['id']: s for s in blocks}

def criterion(identifier, name, weight, description):
    return f'[[criterion]]\nid = "{identifier}"\nname = "{name}"\ntype = "binary"\nweight = {weight}\ndescription = """\n{description.strip()}\n"""\n\n'

def replace_text(identifier, old_text, new_text):
    assert old_text in by_id[identifier], identifier
    by_id[identifier] = by_id[identifier].replace(old_text, new_text)

replace_text('hro_req_identity', 'belongs to hro_raise_roles.', 'belongs to hro_req_roles.')
by_id['hro_raise_roles'] = criterion('hro_raise_roles', 'Offer creation role boundary', '0.5', '''
P5: Recruiter, Comp partner, each seeded approver and Finance can raise distinct PENDING controls; reuse P1/P5 successful observed creations. Auditor is refused403 on a replay of an observed offer creation with a new ID, which never appears. Judge only offer-creation rights; hro_req_roles separately owns requisition-creation rights. If one role cannot create a requisition, use an existing suitable requisition for its offer control.
''') + criterion('hro_req_roles', 'Requisition creation role boundary', '0.5', '''
P1/P5: every seeded signed-in account, including Auditor and all three approver tiers, can open and freshly retrieve an ordinary valid requisition with its entered title, department and budget. Reuse already observed successful requisition creations rather than repeat them. This row owns requisition-creation permission only; do not withhold it for offer-creation, compensation or settlement failures. Basic caller-chosen ID handling is separately hro_req_identity.
''')

by_id['hro_numeric_validation'] = by_id['hro_numeric_validation'].replace('weight = 1.0', 'weight = 0.75', 1) + criterion('hro_money_precision', 'Exact valid money through the UI', '0.25', '''
P2 exact-money control: on an affordable ordinary requisition, raise through the UI a base100.00, bonus0, zero-unit offer with relocation90071992547409.91, fair70368744177664.01 and strike70368744177664.03 dollars. These are valid safe-integer cent values, and zero units keep intrinsic/run-rate small. Save and freshly read the exact values. Approve as a distinct sufficient-tier approver, then open revision through the UI, change only base to101.00 and submit without retyping the three large money fields. The saved revision and retained predecessor must preserve all three large amounts exactly. A normal small-money creation/revision establishes working controls; reuse prior controls. Observe rendered values or ordinary product responses, interpreting their public representation rather than demanding cents-valued keys. This row owns exact UI money round-tripping, not rejection of invalid inputs, general revision lineage or arithmetic formulas.
''')

by_id['hro_caps'] = criterion('hro_signing_cap', 'Signing full vesting cap', '0.5', '''
P7: at24 completed months a100.01 signing bonus is fully vested with zero clawback; at32 months it remains fully vested with zero clawback. Allow an omitted zero contra. First establish an actual partial signing rescission, e.g. P7's13-month case, so a handler that never settles cannot pass. Grade this signing cap independently of equity amounts/cancellation or a sibling's numerical-rounding failure: visibly reported signing rate100% and matching full retained amount establish the cap.
''') + criterion('hro_equity_cap', 'Equity full vesting cap', '0.5', '''
P7: at24 completed months the7-unit equity grant is only68% vested, retaining5 and cancelling2; at32 months the same-size independent grant is fully vested, retaining7 and cancelling0. Allow an omitted zero cancellation. Establish a successful partial equity rescission before crediting the absence of a32-month cancellation. Judge the equity schedule and cap independently of signing: if unrelated unit rounding obscures the rate, an otherwise equivalent100-unit control must retain68/cancel32 at24 months and retain100/cancel0 at32. Amount rounding for the odd-unit12/13-month witnesses belongs to hro_cancel.
''')

by_id['hro_referral_clock'] = by_id['hro_referral_clock'].replace('weight = 1.0', 'weight = 0.75', 1) + criterion('hro_referral_immediate', 'Approval immediately vests the referral first half', '0.25', '''
P8 future-start control: approve an otherwise ordinary affordable offer whose offer start is2026-09-01T00:00:00Z and separate referred-hire start is2026-09-15T00:00:00Z, both later than the stored2026-08-01 reference moment. Immediately after approval, the referral shows5000.00 vested at hire and5000.00 still contingent; it must not withhold the first half until either scheduled start. Reuse a prior ordinary successful referred approval as control. This row owns immediate vesting at the approval event; referral ownership/split is hro_referral_creation and the separate six-month cliff is hro_referral_clock.
''')

common_refusal = 'Compare fresh persisted state before/after: no new offer, movement, grant, payment, referral, successful settlement audit entry or after-image, and no changed active lineage/economic values. Generic access/security logs may grow. Reuse successful observed action controls, not sibling verdicts.'
common_race = 'Use Promise.all with two copies of the actual UI-observed successful request shape under an authorized session and an ample budget. Exactly one succeeds and the other is refused. Inspect fresh persisted results: only one transition\'s complete effects and one current lineage; no duplicate economic rows or settlement receipts. Do not require which request wins or its latency. The winner is the matching positive control; an independently successful ordinary action first establishes the request shape. Evaluate exclusivity relative to the observed successful action, not a sibling formula verdict. If the shared chain cannot reach this stage, prepare an independent eligible target; do not require the earlier concurrent stage to pass.'
by_id['hro_stale'] = criterion('hro_stale_approval', 'Approval refuses ineligible stored states', '0.125', f'''
P4/P5/P9 sequential approval: after an actual successful ordinary approval, replay its approval request and require refusal. Also refuse approval of seeded DRAFT OFF-301; inspect that DRAFT contributes no commitment. The successful pending approval is the positive control for the same approval mechanism. This row owns sequential approval eligibility only, not revision or rescission protections. {common_refusal}
''') + criterion('hro_stale_revision', 'Revision refuses noncurrent or uncommitted offers', '0.1875', f'''
P4/P5/P9 sequential revision: first perform a successful committed-offer revision. Attempt revision of its superseded ancestor, an ordinary PENDING offer and an already rescinded offer; all refuse. Use an independent ordinary successful rescission to prepare the last target if P4 failed. This row owns sequential revision eligibility only, not approval or rescission refusal. {common_refusal}
''') + criterion('hro_stale_rescission', 'Rescission refuses noncurrent or unsettled offers', '0.1875', f'''
P4/P5/P9 sequential rescission: first perform a successful Finance rescission of an ordinary committed target. Replay that rescission, then attempt Finance rescission of a superseded ancestor and an ordinary PENDING offer; all refuse. Independently prepare the superseded target with an ordinary successful revision if needed. This row owns sequential rescission eligibility only, not approval or revision refusal. {common_refusal}
''') + criterion('hro_concurrent_approval', 'Concurrent approvals of one offer settle once', '0.125', f'''
P9 same-target approval pair: target one affordable PENDING hire, raised by a person distinct from the authorized approver. {common_race} One offer becomes committed with one approval's movements/grant/payment/referral where applicable and one receipt. P6/hro_competing separately owns two different hires competing for insufficient combined budget.
''') + criterion('hro_concurrent_revision', 'Concurrent revisions of one offer settle once', '0.1875', f'''
P9 same-target revision pair: target one current COMMITTED hire and submit the same valid compensation change twice concurrently. {common_race} Exactly one successor is minted, its predecessor is superseded once, and only one reversal/replacement, signing adjustment and replacement grant where applicable is posted. Same-target approval success is not this row's prerequisite.
''') + criterion('hro_concurrent_rescission', 'Concurrent rescissions of one offer settle once', '0.1875', f'''
P9 same-target rescission pair: target one current COMMITTED hire as Finance with the same valid effective date in both requests. {common_race} The target becomes rescinded once, with only one release, contra/cancellation where applicable and receipt. Same-target revision success is not this row's prerequisite.
''')

by_id['hro_anon_read'] = criterion('hro_anon_read', 'Anonymous operational read boundary', '1.0', '''
P9: inventory every distinct operational read family actually used by the UI while opening Dashboard, Requisitions, Offers, Equity Table, Referrals and Audit Trail, including available detail/receipt reads. Deduplicate a genuinely shared bootstrap/read rather than require an endpoint per screen. First capture a populated successful authenticated response for each observed family. Replay each without every observed cookie/token/auth credential in a fresh empty context: each must401 and return no operational records. Public health and a login/static app shell may remain public. Do not guess routes or inspect implementation; report the observed inventory and bounded coverage. An empty response without its populated authenticated control proves nothing. If a listed screen lacks a separate request, inspect the shared observed read that supplied its data.
''')
by_id['hro_anon_write'] = criterion('hro_anon_write', 'Anonymous operational write boundary', '1.0', '''
P9: cover every required operational write family observed through successful UI actions: requisition creation, offer creation, approval, revision and rescission. For each, first capture a successful authenticated control, then replay its actual shape without every auth credential in a fresh empty context against a separate otherwise valid eligible target (fresh unused IDs for creations, current state and sufficient budget for settlements). Each must401. Fresh authenticated readback must show no created record or changed status, lineage, financial row, grant, payment, referral or successful settlement receipt; valid control records remain. Generic access logs may grow. Reuse P1/P4/P5/P6/P10 controls and small dedicated targets, never guess a route. A missing product operation lacks evidence for its corresponding family, but do not claim anonymous access was observed merely because a tool/setup failed. Login/logout are session operations, not operational writes in this row.
''')

new_judge = head + ''.join(by_id[tomllib.loads(b)['criterion'][0]['id']] for b in blocks)
parsed = tomllib.loads(new_judge)
weights = sum(Decimal(str(c['weight'])) for c in parsed['criterion'])
assert weights == Decimal(45), weights
assert len(parsed['criterion']) == 54
assert len({c['id'] for c in parsed['criterion']}) == 54
assert parsed['judge'] == old['judge'] and parsed['scoring'] == old['scoring']

old_text = 'If the owned outcome still cannot be observed, give that row no credit and describe the actual missing evidence. Do not infer other failures from it.'
new_text = 'If the owned outcome still cannot be observed, give that row no unearned credit and describe the actual missing evidence. For the binary result, return0 with reason "NOT EXERCISED — evaluator/tool limitation" when a tool, evaluator error or exhausted budget prevented observation; this is not an observed application failure. Use an application-failure reason only for behavior actually observed. Preserve every other completed row and never infer its failure from the missing evidence. The same distinction applies if tool failure prevents establishing the basic gate; do not describe an unobserved app as blank or broken.'
assert old_text in prompt
prompt = prompt.replace(old_text,new_text)
prompt = prompt.replace('Request replays are reserved for authorization, validation, body-claim and stale-operation tests.', 'Request replays are permitted only for the prescribed authorization, validation, body-claim, sequential stale-operation, concurrent-budget and same-target concurrent-operation protocols. Reuse successful UI-observed operation shapes; this permission does not turn ordinary UI creation requirements into API-only tests.')

old_text = 'On dedicated otherwise valid records capture successful create/revise requests.'
new_text = 'For the exact-money control, use an ordinary affordable offer with base100.00,bonus0,units0,relocation90071992547409.91,fair70368744177664.01,strike70368744177664.03 dollars. Create through the UI, approve as a distinct authorized actor, then open the revision UI and change only base to101.00 without retyping the large fields. Save and compare those exact amounts on both predecessor and successor; these large values fit safe integer cents and zero units keep the computed compensation affordable. Normal small-money creations/revisions remain successful controls. On dedicated otherwise valid records capture successful create/revise requests.'
assert old_text in prompt
prompt = prompt.replace(old_text,new_text)

old_text = 'Test create rights, approval forbidden roles, allowed/forbidden revisers and all non-Finance rescinders as the criterion specifies.'
new_text = 'Test offer-creation rights and all seven accounts\' requisition-creation rights separately, reusing P1/P5 successful creations. An ordinary suitable existing requisition can support offer-permission evidence if that actor\'s requisition creation is broken. Then test approval forbidden roles, allowed/forbidden revisers and all non-Finance rescinders as their separate criteria specify.'
assert old_text in prompt
prompt = prompt.replace(old_text,new_text)

old_text = 'Their vested totals at fixed reference are10000.00,5000.00,10000.00. Use different candidates, same valid referrer; no duplicate accrual expected. Read cliff dates and split, then optionally reuse one for a separate rescission-invariance witness.'
new_text = 'Their vested totals at fixed reference are10000.00,5000.00,10000.00. Add a fourth approved affordable offer with future offer start2026-09-01T00:00:00Z and separate future referred-hire start2026-09-15T00:00:00Z:5000.00 is vested immediately at approval, with5000.00 contingent, despite both starts being later than reference2026-08-01. Use different candidates, same valid referrer; no duplicate accrual expected. Score immediate future-start vesting separately from the six-month cliff. Read cliff dates and split, then optionally reuse one for a separate rescission-invariance witness.'
assert old_text in prompt
prompt = prompt.replace(old_text,new_text)

old_text = 'Test anonymous read/write in clean context; wrong-role/forged-actor and fake derived-value claims in current authenticated contexts; stale/repeated settlement operations from P4/P5.'
new_text = 'Inventory all distinct UI-observed operational read families across all six screens and available details/receipts; deduplicate a common bootstrap read. For every family capture populated authenticated success, then replay without all credentials in a clean context and require401 with no operational records. Separately cover the five required operational write families: requisition creation,offer creation,approval,revision,rescission. Reuse each family\'s actual successful UI request as control; attempt its anonymous counterpart on an otherwise valid dedicated target and compare fresh authenticated unchanged-state readback. Never send a stale or malformed request as the only anonymous refusal witness. Record which actual families were exercised and do not invent separate endpoints when one observed interface serves several screens/actions. Test wrong-role/forged-actor and fake derived-value claims in current authenticated contexts; sequential stale/repeated settlement operations from P4/P5 are scored separately by approval,revision and rescission.'
assert old_text in prompt
prompt = prompt.replace(old_text,new_text)

old_text = 'Exactly one action succeeds per pair; inspect all resulting financial and lineage records for single effects. This same-target check is separate from P6\'s two different offers competing for headroom.'
new_text = 'Exactly one action succeeds per pair; inspect all resulting financial and lineage records for single effects. Approval,revision and rescission pairs each receive their own verdict, independent of the sequential-state refusal rows. If a prior pair fails, prepare an ordinary eligible target for the next action using successful nonconcurrent operations; do not make later concurrency credit inherit the earlier pair\'s failure. This same-target check is separate from P6\'s two different offers competing for headroom. Use a small bonus,equity grant and referrer on these controls where supported so duplicate settlement can be distinguished across the relevant records; preserve credit for observed exclusivity independently of a sibling formula verdict.'
assert old_text in prompt
prompt = prompt.replace(old_text,new_text)

old_text = 'A screenshot or reload is not a process restart.'
new_text = 'A screenshot or reload is not a process restart. If restart_app returns an error or the tool is unavailable, hro_restart receives no credit with reason "NOT EXERCISED — evaluator/tool limitation"; do not report lost data unless actual post-restart behavior proves it. Preserve the independently observed fresh-context readback and earlier criteria.'
assert old_text in prompt
prompt = prompt.replace(old_text,new_text)

judge_path.write_text(new_judge,encoding='utf-8',newline='\n')
prompt_path.write_text(prompt,encoding='utf-8',newline='\n')
record = {
    'source':str(directory.relative_to(root)),
    'before_sha256':before,
    'after_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [judge_path,prompt_path]},
    'functional_count_before':45,'functional_count_after':54,
    'functional_weight_before':'45.0','functional_weight_after':str(weights),
    'shared_judge_and_scoring_configuration_unchanged':True,
    'weight_ownership': {
        'hro_raise_roles':{'hro_raise_roles':'0.5','hro_req_roles':'0.5'},
        'hro_numeric_validation':{'hro_numeric_validation':'0.75','hro_money_precision':'0.25'},
        'hro_caps':{'hro_signing_cap':'0.5','hro_equity_cap':'0.5'},
        'hro_referral_clock':{'hro_referral_clock':'0.75','hro_referral_immediate':'0.25'},
        'hro_stale':{'hro_stale_approval':'0.125','hro_stale_revision':'0.1875','hro_stale_rescission':'0.1875','hro_concurrent_approval':'0.125','hro_concurrent_revision':'0.1875','hro_concurrent_rescission':'0.1875'}
    },
    'execution_scope':'Parser/schema and exact weight checks only; no configured judge, paid evaluation, task app runtime or platform QC claimed.'
}
(Path(__file__).parent/'repair-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
