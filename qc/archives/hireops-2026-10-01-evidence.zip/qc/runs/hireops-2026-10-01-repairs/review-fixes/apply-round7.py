from pathlib import Path
import json,re,tomllib
root=Path.cwd();task=root/'projects/hireops-recruiting-operations/hireops-recruiting-operations'
proposal=json.loads((root/'qc/runs/hireops-2026-10-01-round6/reviewer-1-seed-proposal.json').read_text(encoding='utf-8'))
judge=task/'tests/scored/functional/judge.toml';s=judge.read_text(encoding='utf-8')
for cid in ['hro_accounts','hro_restart']:
 pattern=r'(id = "'+cid+r'"\nname = "'+cid+r'"\ntype = "binary"\nweight = )1.0'
 s,n=re.subn(pattern,lambda m:m[1]+'0.5',s);assert n==1,cid
rows=[]
for c in proposal['criteria']:
 rows.append(f'[[criterion]]\nid = "{c["id"]}"\nname = "{c["name"]}"\ntype = "binary"\nweight = {c["weight"]}\ndescription = """\n{c["description"]}\n"""\n\n')
s=s.replace('[[criterion]]\nid = "hro_req_identity"',''.join(rows)+'[[criterion]]\nid = "hro_req_identity"',1)
cs=tomllib.loads(s)['criterion'];assert len(cs)==68 and sum(c['weight'] for c in cs)==45
judge.write_text(s,encoding='utf-8',newline='\n')
p=task/'tests/scored/functional/prompt.md';s=p.read_text(encoding='utf-8')
anchor='P1 — Identity and creation.';assert s.count(anchor)==1
facts=json.dumps(proposal['expected_product_facts'],ensure_ascii=False,separators=(',',':'))
prefix=proposal['protocol']+'\n\nTrusted starting product facts, transcribed from the supplied public seed:\n```json\n'+facts+'\n```\n\n'
s=s.replace(anchor,prefix+anchor,1)
p.write_text(s,encoding='utf-8',newline='\n')
pack=root/'deliverables/package_staged_candidates.py'
s=pack.read_text(encoding='utf-8').replace("'hireops-recruiting-operations': (61, 45)","'hireops-recruiting-operations': (68, 45)")
pack.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'functional':len(cs),'weight':sum(c['weight'] for c in cs),'total_criteria':88,'trusted_fixture_chars':len(facts)}))
