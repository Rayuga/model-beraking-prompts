"""Apply the two independently prepared round5 task-local review proposals."""
from pathlib import Path
import re, tomllib, json

root=Path.cwd()
task=root/'projects/hireops-recruiting-operations/hireops-recruiting-operations'
reviews=root/'qc/runs/hireops-2026-10-01-round5'
p1=(reviews/'reviewer-1-fix-proposal.md').read_text(encoding='utf-8')
p2=(reviews/'reviewer-2-fix-proposal.md').read_text(encoding='utf-8')
def quote(text,heading):
    section=text.split(heading,1)[1].split('\n##',1)[0]
    return next(line[2:] for line in section.splitlines() if line.startswith('> '))
def criterion(cid,weight,description):
    return f'[[criterion]]\nid = "{cid}"\nname = "{cid}"\ntype = "binary"\nweight = {weight}\ndescription = """\n{description}\n"""\n\n'
def replace_criterion(text,cid,replacement):
    pattern=r'\[\[criterion\]\]\nid = "'+re.escape(cid)+r'"\n.*?(?=\[\[criterion\]\]|\Z)'
    result,n=re.subn(pattern,lambda m:replacement,text,flags=re.S)
    assert n==1,(cid,n)
    return result
def write(rel,text):
    (task/rel).write_text(text,encoding='utf-8',newline='\n')

functional=(task/'tests/scored/functional/judge.toml').read_text(encoding='utf-8')
for original,feedback,heading in [
 ('hro_tier','hro_tier_feedback','### `hro_tier`'),
 ('hro_approval_budget','hro_approval_budget_feedback','### `hro_approval_budget`')]:
    functional=replace_criterion(functional,original,criterion(original,.75,quote(p1,heading))+criterion(feedback,.25,quote(p1,'### `'+feedback+'`')))
relocation_block=re.findall(r'```toml\n(.*?)\n```',p2,re.S)[0]
new_rows=tomllib.loads(relocation_block)['criterion']
for old,new in zip(['hro_signing','hro_revision_signing','hro_claw'],new_rows):
    old_row=next(c for c in tomllib.loads(functional)['criterion'] if c['id']==old)
    functional=replace_criterion(functional,old,criterion(old,.75,old_row['description'].strip())+criterion(new['id'],.25,new['description'].strip()))
write('tests/scored/functional/judge.toml',functional)

polish=(task/'tests/scored/polish/judge.toml').read_text(encoding='utf-8')
rows=[]
for suffix,heading in [('req','### Requisition preservation'),('offer','### Offer preservation'),('revision','### Revision preservation'),('rescission','### Rescission preservation')]:
    description=quote(p1,heading)
    if suffix=='rescission':
        description+=' If the form has several editable fields, an ordinary genuinely invalid field plus another valid distinctive field may instead establish the same retention/correction observation. Never require extra fields or free-text dates, or force impossible text into a native date input. Compare equivalent date representations semantically.'
    rows.append(criterion('hro_pol_preserve_'+suffix,.25,description))
polish=replace_criterion(polish,'hro_pol_preserve',''.join(rows))
write('tests/scored/polish/judge.toml',polish)

prompt=(task/'tests/scored/polish/prompt.md').read_text(encoding='utf-8')
start=prompt.index('Assess interaction')
end=prompt.index('\n{criteria}',start)
prompt=prompt[:start]+'''Assess interaction and accessibility, not subjective visual craft. Use normal UI and accessibility-tree inspection, never implementation source. Use unique Polish-owned IDs and records. Never settle or alter seeded records, another judge's records or a record reserved by another protocol. For revision/rescission input recovery only, you may create simple own requisitions/offers, approve them as a distinct authorized approver to enable their forms, then perform the described correction/retry. Setup supplies eligibility, not a financial-formula grade. All other Polish criteria may reuse these own records. If a form/action fails, try an equivalent minimal valid dedicated setup for another outcome; never inherit a sibling verdict. Inspect all available relevant form types for accessibility and interaction.

Efficient shared recovery setup: requisition recovery creates a dedicated budget1000.00 requisition. Offer recovery creates A with base10.00, zero extras, valid start2024-01-01 and no referral. Create one more ordinary offer B. As a distinct approver, approve A/B. Revision recovery on A can change bonus to1.23 and base to1000.01, observe refusal and retained valid bonus, then correct only base to11.00 and save. As Finance, successfully rescind B with a valid date to observe its actual request family, then use current A for the bounded failure/retained-date/retry check. Reuse those observations for keyboard, semantics and feedback where appropriate. If revision fails, an ordinary committed A or a fresh eligible own target can still establish rescission recovery. Missing eligibility is missing observation, not proof of erased input. Keep every form's retention verdict independent.

For the rescission retention row only, after a successful normal UI control establishes the actual operation request family, interrupt exactly one matching outgoing UI request on another eligible own target before dispatch. Leave payload and entered values unchanged. Install interception immediately around the action and always remove it in a finally block before retrying or leaving the row. Do not abort unrelated auth, loads, assets or actions; do not fabricate a status, payload or server response. An unchanged valid-date retry must succeed. If multiple editable fields permit an ordinary invalid-field/valid-field retention observation, that is an alternative. Do not force invalid text into native date/number controls or remove browser validation. Compare semantic values allowing ordinary formatting; no password retention is required.

The separate loading observation may delay only an already-observed operational response and must release it unchanged. No guessed endpoints. If browser tools cannot safely perform a required observation, give no unearned credit and state the evaluator/tool limitation; do not describe unobserved app failure. Successful scripted setup does not establish configured-judge workload fit.

'''+prompt[end:]
write('tests/scored/polish/prompt.md',prompt)

gate=(task/'tests/gates/constraints/judge.toml').read_text(encoding='utf-8')
gate_description=tomllib.loads(re.findall(r'```toml\n(.*?)\n```',p2,re.S)[1])['description']
gate=replace_criterion(gate,'hro_gate_shared',criterion('hro_gate_shared',1.0,gate_description.strip()))
write('tests/gates/constraints/judge.toml',gate)
gate_prompt=(task/'tests/gates/constraints/prompt.md').read_text(encoding='utf-8')
gate_prompt=gate_prompt.replace('Judge only basic real saved storage. Use a unique normal requisition ID so no other suite needs its value. Do not touch seeded offers or settle any offer.',
'Judge the basic working offer and shared-storage prerequisite: create your own ordinary requisition and zero-extra offer, approve only that offer as a distinct authorized approver, then retrieve both in a fresh Auditor context. Use unique IDs with a session suffix. Do not touch seeded offers or another judge\'s records, and do not revise or rescind. Do not grade advanced compensation, budget or settlement calculations here. Leave both records in place.')
gate_prompt=gate_prompt.replace('Prefer ordinary browser tool calls for the initial UI creation.','Use ordinary UI interactions for requisition creation, offer creation and approval; do not substitute API-only writes. The independent Auditor context must navigate to the saved operational records through its UI; normal product responses may clarify exact values.')
write('tests/gates/constraints/prompt.md',gate_prompt)

fp=(task/'tests/scored/functional/prompt.md').read_text(encoding='utf-8')
fp=fp.replace('Use unique identifiers with','Earlier gates may have added a unique requisition and committed offer; treat both as existing shared state, never your own controls, and do not revise or rescind them. Use unique identifiers with',1)
anchor='Signing entries10000.01,-1999.98,+4000.02; all original dates/referral unchanged.'
assert anchor in fp
fp=fp.replace(anchor,anchor+'\nRecord payment/remittance rows before and after approval, each revision and rescission. Nonzero agreed relocation123.45/222.22/333.00 must not generate relocation payments, adjustments, repayments or reversals in HireOps; retained offer inputs/snapshots are allowed. Score this exclusion independently for approval,revision,rescission, using a successful operation with nonzero relocation as the control. If an unrelated chain outcome fails, use an ordinary eligible target as each relocation criterion permits. Inspect ordinary product records and observed response data without guessing endpoints or imposing a financial-row schema.')
fp=fp.replace('Request bodies never set authority.','Record each insufficient-tier refusal\'s held and required tier information separately from the enforcement observation. Request bodies never set authority.')
fp=fp.replace('Record the revision refusal message:', 'Record the approval refusal\'s.01 shortfall as a separate feedback observation; no available-amount display is required for approval. Record the revision refusal message:')
write('tests/scored/functional/prompt.md',fp)

pack=root/'deliverables/package_staged_candidates.py'
s=pack.read_text(encoding='utf-8').replace("'hireops-recruiting-operations': (56, 45)","'hireops-recruiting-operations': (61, 45)").replace("'hireops-recruiting-operations': 9","'hireops-recruiting-operations': 12")
pack.write_text(s,encoding='utf-8',newline='\n')
counts={}
for dim,expected_count,expected_weight in [('functional',61,45),('polish',12,9),('visual',6,6)]:
    cs=tomllib.loads((task/f'tests/scored/{dim}/judge.toml').read_text())['criterion']
    assert len(cs)==expected_count,(dim,len(cs))
    assert sum(c['weight'] for c in cs)==expected_weight
    counts[dim]={'count':len(cs),'weight':sum(c['weight'] for c in cs)}
print(json.dumps(counts))
