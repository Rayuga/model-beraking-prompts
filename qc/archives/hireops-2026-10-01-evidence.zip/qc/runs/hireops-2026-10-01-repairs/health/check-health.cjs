﻿'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {spawn,spawnSync}=require('node:child_process');
const Database=require('better-sqlite3');
const output='/evidence';
const solution='/solution-root';
const results=[];
const active=new Set();
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function child(entry,db,port,name){
 const p=spawn(process.execPath,[entry],{env:{...process.env,DB_PATH:db,PORT:String(port)},stdio:['ignore','pipe','pipe']});
 const log=fs.createWriteStream(path.join(output,name+'.log'));p.stdout.pipe(log,{end:false});p.stderr.pipe(log,{end:false});p.once('close',()=>log.end());active.add(p);p.once('exit',()=>active.delete(p));return p;
}
async function stop(p){if(p.exitCode!==null)return;const done=new Promise(r=>p.once('exit',r));p.kill('SIGTERM');await done;}
async function health(port){for(let i=0;i<100;i++){try{const r=await fetch(`http://127.0.0.1:${port}/api/health`,{signal:AbortSignal.timeout(1000)});if(r.ok)return await r.json();}catch{}await delay(30);}throw Error('health did not become available');}
async function request(port,url,method='GET',body,cookie){const r=await fetch(`http://127.0.0.1:${port}${url}`,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(cookie?{cookie}:{})},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(10000)});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
async function login(port){const r=await request(port,'/api/auth/login','POST',{email:'rafael.costa@hireops.example',password:'Hireops!2026'});assert.equal(r.status,200,JSON.stringify(r));return r.cookie;}
async function main(){
 const dbpath=path.join(output,'blocked.sqlite');
 const blocker=new Database(dbpath);blocker.exec('CREATE TABLE IF NOT EXISTS lock_witness(value INTEGER); BEGIN EXCLUSIVE');
 const p=child(solution+'/app/server.js',dbpath,3077,'blocked');
 assert.equal((await health(3077)).ok,true);
 let completed=false;
 const pending=login(3077).finally(()=>{completed=true;});
 await delay(300);
 assert.equal(completed,false,'operational login should wait for blocked SQLite startup');
 const started=performance.now();assert.equal((await health(3077)).ok,true);
 const healthMs=performance.now()-started;
 blocker.exec('ROLLBACK');blocker.close();
 const cookie=await pending;
 results.push({name:'real exclusive SQLite lock blocks worker startup while health responds and login waits',passed:true,healthMs});
 let r=await request(3077,'/api/requisitions','POST',{id:'health-restart-witness',title:'Persistent after bootstrap',dept:'Testing',budget_cents:10000},cookie);assert.equal(r.status,200);
 await stop(p);
 const restarted=child(solution+'/app/server.js',dbpath,3077,'restarted');await health(3077);const rc=await login(3077);
 r=await request(3077,'/api/bootstrap','GET',undefined,rc);assert.equal(r.data.requisitions.filter(x=>x.id==='health-restart-witness').length,1);assert.equal(r.data.users.length,7);
 results.push({name:'normal operational proxy preserves cookies,writes,readback,restart and seed idempotence',passed:true});await stop(restarted);
 const obstruction=path.join(output,'not-a-directory');fs.writeFileSync(obstruction,'file');
 const broken=child(solution+'/app/server.js',obstruction+'/app.db',3078,'failed-db');assert.equal((await health(3078)).ok,true);
 r=await request(3078,'/api/auth/login','POST',{email:'rafael.costa@hireops.example',password:'Hireops!2026'});assert.equal(r.status,503);assert.equal((await health(3078)).ok,true);assert.equal(broken.exitCode,null);
 results.push({name:'database init failure yields operational503 but health stays200 and process survives',passed:true});await stop(broken);
 const install=()=>spawnSync('/bin/bash',[solution+'/solve.sh'],{encoding:'utf8'});
 let installRun=install();assert.equal(installRun.status,0,installRun.stderr);
 const installed=child('/app/server.js','/app/app.db',3079,'installed');await health(3079);const ic=await login(3079);
 r=await request(3079,'/api/requisitions','POST',{id:'installer-active-witness',title:'Do not delete',dept:'Test',budget_cents:100},ic);assert.equal(r.status,200);
 installRun=install();assert.notEqual(installRun.status,0);assert.match(installRun.stderr,/database is in use/);
 fs.writeFileSync(path.join(output,'active-install-refusal.log'),installRun.stderr);
 r=await request(3079,'/api/bootstrap','GET',undefined,ic);assert.equal(r.data.requisitions.filter(x=>x.id==='installer-active-witness').length,1);
 results.push({name:'installer refuses idle active SQLite database before copying or reset',passed:true});await stop(installed);
 installRun=install();assert.equal(installRun.status,0,installRun.stderr);
 const fresh=child('/app/server.js','/app/app.db',3079,'reinstalled');await health(3079);const fc=await login(3079);
 r=await request(3079,'/api/bootstrap','GET',undefined,fc);assert.equal(r.data.requisitions.length,7);assert.equal(r.data.requisitions.some(x=>x.id==='installer-active-witness'),false);
 results.push({name:'installer resets stopped used workspace and seeds fresh baseline',passed:true});await stop(fresh);
 fs.writeFileSync(path.join(output,'results.json'),JSON.stringify({runtime:process.version,kind:'local Node22 Docker behavioral tests,not configured judge',results},null,2));console.log(JSON.stringify(results,null,2));
}
main().catch(error=>{console.error(error);fs.writeFileSync(path.join(output,'failure.log'),error.stack);process.exitCode=1;}).finally(async()=>{for(const p of active)await stop(p);});
