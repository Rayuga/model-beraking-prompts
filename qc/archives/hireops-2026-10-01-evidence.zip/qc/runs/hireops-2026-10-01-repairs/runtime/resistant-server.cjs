// Deliberately SIGTERM-resistant local harness probe. NOT the HireOps golden.
const http=require('http');
process.on('SIGTERM',()=>console.log('ignored SIGTERM',process.pid));
http.createServer((req,res)=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:true,pid:process.pid,kind:'deliberate-resistant-harness-fixture'}));}).listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('listening resistant fixture',process.pid));
