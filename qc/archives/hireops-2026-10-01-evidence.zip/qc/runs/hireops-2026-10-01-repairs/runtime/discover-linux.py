from pathlib import Path
import subprocess,json,hashlib,argparse
ap=argparse.ArgumentParser();ap.add_argument('--label',default='schema-before-fix');ap.add_argument('--image-tests',action='store_true');ap.add_argument('--image',default='hireops-verifier:20261001');a=ap.parse_args()
root=Path.cwd();base=root/'qc/runs/hireops-2026-10-01-repairs/runtime';out=base/a.label;out.mkdir(parents=True,exist_ok=True)
task=root/'projects/hireops-recruiting-operations/hireops-recruiting-operations'
name='hireops-schema-'+a.label
logs=[]
def run(cmd,check=True):
 r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60);logs.append({'cmd':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(out/'commands.json').write_text(json.dumps(logs,indent=2))
 if check and r.returncode:raise RuntimeError(r.stderr)
 return r
(out/'source-hashes.json').write_text(json.dumps({'source':'baked image original tests'} if a.image_tests else {str(p.relative_to(task)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (task/'tests').rglob('*') if p.is_file()},indent=2))
run(['docker','run','--network','none','--name',name,'-d',a.image,'sleep','infinity'])
try:
 if not a.image_tests:run(['docker','cp',str(task/'tests')+'/.',name+':/tests'])
 run(['docker','cp',str(base/'rewardkit-discover.py'),name+':/tmp/discover.py'])
 run(['docker','exec',name,'python3','/tmp/discover.py'],False)
 run(['docker','cp',name+':/evidence/.',str(out)])
finally:run(['docker','rm','-f',name],False)
print(out)
