from pathlib import Path
import hashlib,json,subprocess
base=Path('qc/runs/hireops-2026-10-01-repairs/runtime')
manifest=json.loads(Path('qc/runs/hireops-2026-10-01-round3/manifest.json').read_text())
probe="from pathlib import Path;import json,hashlib;print(json.dumps({str(p.relative_to('/tests')):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/tests').rglob('*') if p.is_file()}))"
cmd=['docker','run','--rm','--network','none','hireops-verifier:20261001-final','python3','-c',probe]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=30,check=True)
baked=json.loads(r.stdout)
expected={k.removeprefix('tests/'):v for k,v in manifest['inputs']['task'].items() if k.startswith('tests/')}
excluded={k:expected.pop(k) for k in ['Dockerfile','.dockerignore']}
assert baked==expected,(baked.keys()^expected.keys())
(base/'final-baked-tests-hashes.json').write_text(json.dumps({'command':cmd,'baked_test_hashes':baked,'matches_round3_manifest':True,'documented_dockerignore_exclusions':excluded},indent=2))
source=json.loads((base/'final-rebuilt/source-before.json').read_text())
assert source==manifest['inputs']['task']
result=json.loads((base/'final-rebuilt/mcp/results.json').read_text())
summary={
 'input_sha256':manifest['input_sha256'],
 'candidate':'round3 / commit82a023f5',
 'source_all_files_match_frozen_manifest':True,
 'source_unchanged_during_run':json.loads((base/'final-rebuilt/evidence-classification.json').read_text())['source_stable'],
 'verifier_image':'hireops-verifier:20261001-final',
 'agent_image':'hireops-agent:20261001',
 'baked_runtime_tests_exactly_match_candidate':True,
 'runtime_result':{'passed_checks':len(result['results']),'checks':[x['name'] for x in result['results']]},
 'agent_image_isolation':'Observed /app contains .git and .gitkeep, no /app/server.js,/tests,/solution',
 'runtime_launch':'Canonical unchanged test.sh launched actual golden as nobody using its env-i command; app copied by actual solve.sh with no /assets or /instructions mounts; real process restart helper called exactly once; normal golden cleanup reports APP_STOPPED.',
 'tooling':'Actual pinned Playwright MCP/Chromium in rebuilt Linux image, real independent newContext, fresh UI sign-in and same-data readback across real restart_mcp invocation.',
 'rewardkit':{'actual_loader_and_schema':'schema-final-rebuilt/discovery/results.json','criteria_counts':{'render':1,'constraints':1,'functional':54,'polish':9,'visual':6},'resolved_prompt_and_constructed_cli_arguments':True,'provider_execution':False,'original_P0':'schema-original-image-failure/discovery/results.json preserves invalid human-readable criterion-name ValidationError; schema-safe names fix it'},
 'synthetic_boundary':'External rewardkit-fixture substitutes ONLY RewardKit transport to hold canonical test.sh while browser/restart tests run. Synthetic gate/scored JSON and resulting reward values are not measurements; no full judge, Oracle/model score, reward discrimination, ranking or judge workload claim.',
 'canonical_blockers':[
 {'kind':'restart false success','evidence':'resistant-process/restart-result.json and restart/verifier-logs/app-restart.log','observation':'restart_app reports success; old SIGTERM-resistant PID44 still answers; replacement PID158 fails EADDRINUSE while helper records ready1'},
 {'kind':'cleanup survival after failed replacement','evidence':'resistant-process/commands.json','observation':'After synthetic scoring and canonical cleanup, old PID44 remains alive as nobody'},
 {'kind':'unbounded normal cleanup wait','evidence':'resistant-process/commands.json cleanup case','observation':'After scored fixture released and reward.json exists, canonical harness remains waiting on deliberately SIGTERM-resistant app; outer90-second timeout/container teardown bounds the probe'}],
 'task_edits':'None by runtime verifier; fixtures and reports outside task; canonical harness untouched',
 'network':'All runtime/parser/probe containers --network none; no provider credentials or paid calls',
}
(base/'runtime-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
