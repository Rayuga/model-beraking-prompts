'use strict';
// Pinned Linux browser MCP feasibility. No provider, configured judge, or meaningful reward.
const fs=require('node:fs'),assert=require('node:assert/strict'),{spawn}=require('node:child_process'),readline=require('node:readline');
const out='/evidence/mcp';fs.mkdirSync(out,{recursive:true});
const results=[],children=[];let serial=0;
function client(command,args,name){
 const child=spawn(command,args,{stdio:['pipe','pipe','pipe'],env:{PATH:'/usr/local/bin:/usr/bin:/bin',HOME:'/root',PLAYWRIGHT_BROWSERS_PATH:'/opt/playwright-browsers',NODE_PATH:'/usr/local/lib/node_modules'}});children.push(child);
 const pending=new Map();child.stderr.pipe(fs.createWriteStream(out+'/'+name+'-stderr.log'));
 readline.createInterface({input:child.stdout}).on('line',line=>{
  fs.appendFileSync(out+'/'+name+'-responses.jsonl',line+'\n');
  try{const msg=JSON.parse(line),p=pending.get(msg.id);if(p){pending.delete(msg.id);clearTimeout(p.timer);p.resolve(msg)}}catch{}
 });
 return {child,rpc(method,params={}){return new Promise((resolve,reject)=>{
  const id=++serial,msg={jsonrpc:'2.0',id,method,params};const timer=setTimeout(()=>{pending.delete(id);reject(Error(name+' '+method+' timed out'))},58000);
  pending.set(id,{resolve,reject,timer});fs.appendFileSync(out+'/'+name+'-requests.jsonl',JSON.stringify(msg)+'\n');child.stdin.write(JSON.stringify(msg)+'\n');
 })}};
}
async function tool(c,name,args={}){const r=await c.rpc('tools/call',{name,arguments:args});if(r.error||r.result?.isError)throw Error(JSON.stringify(r));return r.result}
function record(name,data){results.push({name,passed:true,data});fs.writeFileSync(out+'/results.json',JSON.stringify({classification:'Actual pinned Linux Playwright MCP product/tool evidence; synthetic external harness transport; no configured judge',results},null,2));console.log('PASS',name)}
const extract=r=>JSON.parse(r.content.filter(x=>x.type==='text').map(x=>x.text).join('\n').split('### Result\n')[1].split('\n###')[0].trim());
async function main(){
 const c=client('playwright-mcp',['--headless','--isolated','--executable-path=/usr/local/bin/chromium','--no-sandbox','--output-dir',out],'browser');
 assert((await c.rpc('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'hireops-recovery-feasibility',version:'1'}})).result);
 c.child.stdin.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})+'\n');
 const listed=await c.rpc('tools/list');fs.writeFileSync(out+'/tools.json',JSON.stringify(listed,null,2));assert(listed.result.tools.some(t=>t.name==='browser_run_code_unsafe'));
 record('actual pinned MCP exposes required browser tool',listed.result.tools.map(t=>t.name));
 await tool(c,'browser_navigate',{url:'http://localhost:3000'});
 const run=async(name,code)=>{const raw=await tool(c,'browser_run_code_unsafe',{code}),data=extract(raw);record(name,data);return data};
 const setup=await run('own UI requisition and two fresh pending offers',`async(page)=>{
  let observedReadUrl;const observe=async response=>{if(response.request().method()!=='GET')return;try{const b=await response.json();if(Array.isArray(b.requisitions)&&Array.isArray(b.offers))observedReadUrl=response.url()}catch{}};page.on('response',observe);
  try{
   await page.locator('#email').fill('rafael.costa@hireops.example');await page.locator('#password').fill('Hireops!2026');await page.getByRole('button',{name:'Sign in',exact:true}).click();await page.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();
   await page.getByRole('navigation').getByRole('button',{name:'Requisitions',exact:true}).click();
   await page.locator('#req-id').fill('RECOVERY-MCP-REQ');await page.locator('#req-title').fill('MCP recovery own budget');await page.locator('#req-budget').fill('1000.00');await page.getByRole('button',{name:'Create requisition',exact:true}).click();await page.locator('article.entity').filter({hasText:'MCP recovery own budget'}).waitFor();
   await page.getByRole('navigation').getByRole('button',{name:'Offers',exact:true}).click();
   for(const suffix of ['A','B']){await page.locator('#off-id').fill('RECOVERY-MCP-'+suffix);await page.locator('#off-req').selectOption('RECOVERY-MCP-REQ');await page.locator('#off-cand').fill('Recovery own candidate '+suffix);await page.locator('#off-base').fill('10.00');await page.locator('#off-start').fill('2024-01-01');await page.getByRole('button',{name:'Create offer',exact:true}).click();await page.locator('article.entity').filter({hasText:'Recovery own candidate '+suffix}).waitFor();}
   if(!observedReadUrl)throw Error('No ordinary populated UI read observed');
   const b=await page.evaluate(async url=>await(await fetch(url)).json(),observedReadUrl);const records=b.offers.filter(o=>['RECOVERY-MCP-A','RECOVERY-MCP-B'].includes(o.id));if(records.length!==2||records.some(o=>o.status!=='PENDING'))throw Error('Own pending creation missing');
   return {observedReadUrl,records:records.map(o=>({id:o.id,status:o.status,base:o.composition.base_salary_cents,start:o.start_date})),requisition:b.requisitions.find(r=>r.id==='RECOVERY-MCP-REQ')};
  }finally{page.off('response',observe)}
 }`);
 const readUrl=JSON.stringify(setup.observedReadUrl);
 await run('distinct approver UI transitions own pending records to committed',`async(page)=>{
  await page.locator('#logout').click();await page.locator('#email').fill('ingrid.sorensen@hireops.example');await page.locator('#password').fill('Hireops!2026');await page.getByRole('button',{name:'Sign in',exact:true}).click();await page.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();await page.getByRole('navigation').getByRole('button',{name:'Offers',exact:true}).click();
  for(const suffix of ['A','B']){await page.getByRole('button',{name:'Approve RECOVERY-MCP-'+suffix,exact:true}).click();await page.getByRole('button',{name:'Revise RECOVERY-MCP-'+suffix,exact:true}).waitFor();}
  const b=await page.evaluate(async url=>await(await fetch(url)).json(),${readUrl});const own=b.offers.filter(o=>['RECOVERY-MCP-A','RECOVERY-MCP-B'].includes(o.id));if(own.length!==2||own.some(o=>o.status!=='COMMITTED'||o.approved_by===o.raised_by))throw Error('Distinct-actor commitment missing');
  const movements=b.commitment_movements.filter(m=>own.some(o=>o.id===m.offer_id));if(movements.length!==2||movements.some(m=>m.movement_cents!==-1000))throw Error('Expected actual commitment movements absent');
  return {offers:own.map(o=>({id:o.id,status:o.status,creator:o.raised_by,approver:o.approved_by})),movements,headroom:b.requisitions.find(r=>r.id==='RECOVERY-MCP-REQ').headroom_cents};
 }`);
 await run('independent empty-context Auditor sees committed records and effects',`async(page)=>{
  const ctx=await page.context().browser().newContext();try{const fresh=await ctx.newPage();await fresh.goto('http://localhost:3000');const initial=await fresh.evaluate(async url=>({status:(await fetch(url)).status,localKeys:Object.keys(localStorage)}),${readUrl});if(initial.status!==401||initial.localKeys.some(k=>k!=='hireops-theme'))throw Error('Fresh context not independent');
   await fresh.locator('#email').fill('aud.halvorsen@hireops.example');await fresh.locator('#password').fill('Hireops!2026');await fresh.getByRole('button',{name:'Sign in',exact:true}).click();await fresh.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();await fresh.getByRole('navigation').getByRole('button',{name:'Offers',exact:true}).click();
   const text=await fresh.locator('article.entity').filter({hasText:'Recovery own candidate A'}).innerText();if(!text.includes('COMMITTED')||!text.includes('Ingrid Sorensen'))throw Error('Independent UI lacks committed record');
   const b=await fresh.evaluate(async url=>await(await fetch(url)).json(),${readUrl});const own=b.offers.filter(o=>['RECOVERY-MCP-A','RECOVERY-MCP-B'].includes(o.id));if(own.length!==2||own.some(o=>o.status!=='COMMITTED'))throw Error('Readback differs');const req=b.requisitions.find(r=>r.id==='RECOVERY-MCP-REQ');if(req.headroom_cents!==98000)throw Error('Independent ledger differs');return {initial,visible:text,headroom:req.headroom_cents,offers:own.map(o=>({id:o.id,status:o.status}))};
  }finally{await ctx.close()}
 }`);
 const control=await run('successful ordinary Finance rescission observes real request family',`async(page)=>{
  await page.locator('#logout').click();await page.locator('#email').fill('farah.nasser@hireops.example');await page.locator('#password').fill('Hireops!2026');await page.getByRole('button',{name:'Sign in',exact:true}).click();await page.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();await page.getByRole('navigation').getByRole('button',{name:'Offers',exact:true}).click();
  await page.getByRole('button',{name:'Rescind RECOVERY-MCP-B',exact:true}).click();await page.locator('input[name="effective_at"]').fill('2025-02-01');
  const observed=page.waitForRequest(r=>r.method()==='POST');await page.getByRole('button',{name:'Post rescission (Finance controller only)',exact:true}).click();const request=await observed;await page.locator('#detail-backdrop').waitFor({state:'hidden'});
  const b=await page.evaluate(async url=>await(await fetch(url)).json(),${readUrl});const o=b.offers.find(o=>o.id==='RECOVERY-MCP-B');if(o.status!=='RESCINDED'||o.rescission_effective_at!=='2025-02-01T00:00:00Z')throw Error('Normal rescission control failed');
  return {method:request.method(),url:request.url(),body:request.postDataJSON(),status:o.status,effective:o.rescission_effective_at};
 }`);
 // No source or endpoint guessing: the next request must match the actually observed
 // successful method and route family, substituting only the UI's own target ID.
 await run('one bounded pre-dispatch abort preserves valid date and saved books; unchanged retry succeeds',`async(page)=>{
  const control=${JSON.stringify(control)},readUrl=${readUrl};const expectedUrl=control.url.replace(encodeURIComponent('RECOVERY-MCP-B'),encodeURIComponent('RECOVERY-MCP-A'));if(expectedUrl===control.url)throw Error('Observed family has no target identity; cannot safely narrow fixture');
  const read=async()=>page.evaluate(async url=>await(await fetch(url)).json(),readUrl);
  const economics=b=>({requisitions:b.requisitions,offers:b.offers,movements:b.commitment_movements,grants:b.equity_grants,cancellations:b.equity_cancellations,remittances:b.remittances,referrals:b.referral_accruals,receipts:b.after_images,audit:b.audit.filter(a=>/^OFFER_(APPROVED|REVISED|RESCINDED)$/.test(a.action))});
  const before=economics(await read());await page.getByRole('button',{name:'Rescind RECOVERY-MCP-A',exact:true}).click();const date=page.locator('input[name="effective_at"]');await date.fill('2025-02-01');const entered=await date.inputValue();let aborted=0,captured=null,removed=false;
  const handler=async route=>{const request=route.request();if(request.method()!==control.method)return route.continue();if(aborted!==0)throw Error('Second matching operation before cleanup');captured={url:request.url(),method:request.method(),body:request.postDataJSON()};aborted++;await route.abort('connectionfailed')};
  await page.route(expectedUrl,handler);
  try{await page.getByRole('button',{name:'Post rescission (Finance controller only)',exact:true}).click();await page.locator('.drawer-form .error').filter({hasText:/server could not be reached/}).waitFor();if(aborted!==1)throw Error('Exact one outgoing operation was not aborted');if(await date.inputValue()!==entered||!(await date.isEditable()))throw Error('Valid effective date not retained editable');if(!(await page.locator('#detail-backdrop').isVisible()))throw Error('Editor closed on failed save');const after=economics(await read());if(JSON.stringify(after)!==JSON.stringify(before))throw Error('Aborted save changed stored business state');}
  finally{await page.unroute(expectedUrl,handler);removed=true}
  const visibleFailure=await page.locator('.drawer-form .error').innerText();const retryRequest=page.waitForRequest(r=>r.method()===control.method&&r.url()===expectedUrl);await page.getByRole('button',{name:'Post rescission (Finance controller only)',exact:true}).click();const sent=await retryRequest;await page.locator('#detail-backdrop').waitFor({state:'hidden'});
  const b=await read(),o=b.offers.find(o=>o.id==='RECOVERY-MCP-A');if(o.status!=='RESCINDED'||o.rescission_effective_at!=='2025-02-01T00:00:00Z')throw Error('Unchanged-date retry did not settle');if(JSON.stringify(sent.postDataJSON())!==JSON.stringify(captured.body))throw Error('Retry payload changed');if(aborted!==1||!removed)throw Error('Route interruption leaked into retry');
  const receipts=b.after_images.filter(a=>a.offer_id==='RECOVERY-MCP-A'&&a.action==='RESCIND'),releases=b.commitment_movements.filter(m=>m.offer_id==='RECOVERY-MCP-A'&&m.kind==='RELEASE');if(receipts.length!==1||releases.length!==1||releases[0].movement_cents!==1000)throw Error('Duplicate or missing settlement');
  return {control,abortedOutgoingRequest:captured,abortedExactlyOnce:aborted===1,routeRemovedBeforeRetry:removed,visibleFailure,enteredDate:entered,retainedDate:entered,storedEconomicsUnchangedAfterAbort:true,retryPayload:sent.postDataJSON(),finalStatus:o.status,finalEffective:o.rescission_effective_at,receiptCount:receipts.length,releaseCount:releases.length,finalHeadroom:b.requisitions.find(r=>r.id==='RECOVERY-MCP-REQ').headroom_cents};
 }`);
 await run('original MCP page remains usable after independent context cleanup and route removal',`async(page)=>{await page.getByRole('navigation').getByRole('button',{name:'Requisitions',exact:true}).click();const text=await page.locator('article.entity').filter({hasText:'MCP recovery own budget'}).innerText();if(!text.includes('$1,000.00'))throw Error('Original page no longer works');return {visible:text}}`);
 await tool(c,'browser_close');
}
main().then(()=>fs.writeFileSync(out+'/completed','PASS\n')).catch(e=>{fs.writeFileSync(out+'/failure.txt',e.stack);console.error(e);process.exitCode=1}).finally(()=>{for(const c of children)c.kill('SIGTERM')});
