"""Real pinned Linux MCP recovery feasibility; synthetic external judge transport only."""
from pathlib import Path
import hashlib,json,subprocess,time

root=Path.cwd()
out=Path(__file__).resolve().parent
frozen=root/'.qc-cache/hireops-2026-10-01-round5/task'
current=root/'projects/hireops-recruiting-operations/hireops-recruiting-operations'
image='hireops-verifier:20261001-final-qc'
name='hireops-recovery-mcp-reviewer1'
records=[]
def run(cmd,timeout=60,check=True):
    begin=time.monotonic()
    r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
    records.append(dict(command=cmd,exit=r.returncode,duration_seconds=round(time.monotonic()-begin,3),stdout=r.stdout,stderr=r.stderr))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    if check and r.returncode:raise RuntimeError(str(cmd)+'\n'+r.stdout+'\n'+r.stderr)
    return r
scoped=['tests/test.sh','tests/Dockerfile','tests/scoring.toml','tests/tools/score.py','tests/tools/restart_mcp.py']
scoped += [p.relative_to(frozen).as_posix() for p in (frozen/'solution').rglob('*') if p.is_file()]
def hashes(base):return {p:hashlib.sha256((base/p).read_bytes()).hexdigest() for p in scoped}
before=hashes(frozen)
assert before==hashes(current),'Golden or canonical runtime changed before run'
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
fixture=out/'rewardkit-fixture'
fixture.write_text('''#!/usr/local/bin/python3
"""SYNTHETIC OFFLINE TRANSPORT ONLY. Dummy rewards are not grading evidence."""
import sys,json,time
from pathlib import Path
a=sys.argv[1:];p=Path(a[a.index('--output')+1]);p.parent.mkdir(parents=True,exist_ok=True);suite=Path(a[-1]).name
Path('/evidence/'+suite+'.entered').write_text('Synthetic fixture only; no provider.\\n')
if suite=='gates':payload={'render':1.0,'constraints':1.0}
else:
 end=time.monotonic()+300
 while not Path('/evidence/release').exists():
  if time.monotonic()>end:sys.exit(124)
  time.sleep(.1)
 payload={'functional':0.0,'polish':0.0,'visual':0.0}
p.write_text(json.dumps(payload)+'\\n');print('SYNTHETIC NO-SCORE TRANSPORT:',suite)
''',encoding='utf-8',newline='\n')
started=time.monotonic();success=False
run(['docker','image','inspect',image])
run(['docker','run','--name',name,'--network','none','--init','-d',image,'sleep','infinity'])
try:
    run(['docker','exec',name,'mkdir','-p','/evidence/bin'])
    run(['docker','cp',str(frozen/'solution'),name+':/solution'])
    run(['docker','cp',str(frozen/'tests')+'/.',name+':/tests'])
    run(['docker','cp',str(fixture),name+':/evidence/bin/rewardkit'])
    run(['docker','cp',str(out/'recovery-linux.cjs'),name+':/evidence/recovery-linux.cjs'])
    run(['docker','exec',name,'chmod','755','/evidence/bin/rewardkit'])
    run(['docker','exec',name,'bash','/solution/solve.sh'])
    run(['docker','exec',name,'sh','-c','node --version; chromium --version; npm list -g --depth=0; python3 -m pip show harbor-rewardkit; test ! -e /assets && test ! -e /instructions'])
    # Actual unchanged canonical harness launches app. No provider executable is invoked.
    run(['docker','exec','-d',name,'sh','-c','PATH=/evidence/bin:/usr/local/bin:/usr/bin:/bin REWARDKIT_JUDGE=claude-code REWARDKIT_MODEL=z-ai/glm-5.3-flashx bash /tests/test.sh > /evidence/harness.log 2>&1; echo $? > /evidence/harness.exit'])
    for _ in range(100):
        if run(['docker','exec',name,'test','-e','/evidence/scored.entered'],check=False).returncode==0:break
        time.sleep(.2)
    else:raise RuntimeError('Harness did not reach synthetic scored transport')
    run(['docker','exec',name,'timeout','180','node','/evidence/recovery-linux.cjs'],timeout=195)
    run(['docker','exec',name,'test','-e','/evidence/mcp/completed'])
    success=True
finally:
    run(['docker','exec',name,'touch','/evidence/release'],check=False)
    for _ in range(50):
        if run(['docker','exec',name,'test','-e','/evidence/harness.exit'],check=False).returncode==0:break
        time.sleep(.2)
    run(['docker','cp',name+':/evidence/.',str(out)],check=False)
    run(['docker','cp',name+':/logs/verifier',str(out/'verifier-logs')],check=False)
    run(['docker','rm','-f',name],check=False)
    after=hashes(frozen);current_after=hashes(current)
    (out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
    meta={'classification':'Actual pinned Linux Playwright MCP/browser and unchanged canonical harness product/tool feasibility; no configured judge or reward evidence','image':image,'passed':success,'duration_seconds':round(time.monotonic()-started,3),'tested_snapshot':frozen.relative_to(root).as_posix(),'hash_scope':'All solution files and five shared runtime files; rubric/prompt edits by root excluded and not claimed tested','tested_source_unchanged':before==after,'current_scoped_source_matches':before==current_after,'source_hashes':before,'provider_runs':False,'synthetic':'External rewardkit transport supplies dummy gates/scores only to hold canonical launch; reward numbers have no grading meaning','scripts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),out/'recovery-linux.cjs',fixture]}}
    (out/'evidence-classification.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
print(json.dumps(meta,indent=2))
