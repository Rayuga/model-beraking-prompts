"""Bind exact baked instructions/assets/tests to the current candidate; no provider use."""
import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();task=root/'projects/hireops-recruiting-operations/hireops-recruiting-operations'
out=root/'qc/runs/hireops-2026-10-01-repairs/runtime/round6-images.json'
records=[]
def run(cmd):
    p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60)
    records.append(dict(command=cmd,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if p.returncode: raise RuntimeError(p.stderr)
    return p.stdout
image_info=json.loads(run(['docker','image','inspect','hireops-agent:20261001-final-qc','hireops-verifier:20261001-round6']))
node="const fs=require('fs'),c=require('crypto');let h={};function walk(p){for(const x of fs.readdirSync(p,{withFileTypes:true})){const f=p+'/'+x.name;if(x.isDirectory())walk(f);else h[f]=c.createHash('sha256').update(fs.readFileSync(f)).digest('hex')}}walk('/instructions');walk('/assets');console.log(JSON.stringify(h));"
actual=json.loads(run(['docker','run','--rm','--network','none','hireops-agent:20261001-final-qc','node','-e',node]))
expected={ '/'+str(p.relative_to(task/'environment')).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['instructions','assets'] for p in (task/'environment'/d).rglob('*') if p.is_file()}
assert actual==expected, 'Baked agent inputs differ'
python="from pathlib import Path;import hashlib,json;print(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/tests').rglob('*') if p.is_file()}))"
actual_tests=json.loads(run(['docker','run','--rm','--network','none','hireops-verifier:20261001-round6','python3','-c',python]))
expected_tests={'/tests/'+str(p.relative_to(task/'tests')).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in (task/'tests').rglob('*') if p.is_file() and p.name not in {'.dockerignore','Dockerfile'}}
# .dockerignore remains a legitimate Docker context control; COPY may retain it.
actual_tests.pop('/tests/.dockerignore',None)
assert actual_tests==expected_tests,'Baked verifier tests differ'
out.write_text(json.dumps({'scope':'Exact baked-file and image identity; not configured grading','passed':True,'images':image_info,'agent_hashes':actual,'verifier_hashes':actual_tests,'commands':records},indent=2)+'\n',encoding='utf-8')
print('Agent inputs and verifier tests exactly match current candidate.')
