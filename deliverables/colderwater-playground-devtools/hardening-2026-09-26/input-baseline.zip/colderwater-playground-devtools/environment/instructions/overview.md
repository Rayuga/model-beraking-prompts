Build a useful, polished playground with TypeScript, React and Vite, and SQLite for saved snippets.
No accounts or sign-in. When nothing is saved, open a runnable working example.
Let users create runnable JavaScript, complete HTML documents, and CSS from scratch; infer language from filename extension.
The first screen must be useful without any supplied implementation files and should provide a clear working starting state.
