Infer language from the filename extension: .js executes against the preview document, .html replaces the document, and .css styles it.
Every run starts in a fresh isolated frame, without leaked timers, globals or partially updated DOM from the prior run.
Starting another run cancels any run already in progress.
A run has a five-second budget; terminate work exceeding it, report the reason, and never hang the playground tab.
Report uncaught errors in the console with the message and line number in the user's code, not the wrapper.
A failed run retains the last successful rendered preview instead of losing it.
Capture console.log, warn, error and info in their original order; objects and arrays must be expandable.
Show run duration and provide a clear-console action. Follow new entries unless the user has scrolled up.
Debounce automatic runs while typing, with a switch that actually disables auto-run and permits manual runs.
