Provide three panes: editor, live preview and console, resizable by dragging dividers, with sizes remembered.
The editor has line numbers, a monospaced face, Tab and Shift+Tab indent/unindent for a selection, bracket matching, and JavaScript/HTML/CSS syntax colouring.
Light and dark themes apply to the whole interface, including editor syntax colours, preview frame surround and console.
Document and implement keyboard shortcuts for Run, Save and Clear console.
Provide legible responsive layouts, visible focus, labeled controls and usable navigation on narrow screens.
