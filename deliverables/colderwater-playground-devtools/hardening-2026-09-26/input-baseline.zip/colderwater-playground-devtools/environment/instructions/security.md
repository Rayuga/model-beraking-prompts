A snippet runs in an isolated frame and cannot reach the playground page, its storage, or parent document.
A snippet attempting forbidden access fails within its sandbox without breaking the surrounding app.
Application assets, editor components and examples are local; no CDN or external service is fetched.
Serve only intended application assets and APIs, never arbitrary host files, verifier files or secrets.
