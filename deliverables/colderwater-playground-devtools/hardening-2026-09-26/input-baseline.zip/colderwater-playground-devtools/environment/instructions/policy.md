Judge the observable workflows described in the six focused contracts.
Do not depend on supplied example implementations; users author their own snippets.
An error must produce useful feedback and leave the surrounding app usable.
Ordinary local persistence and source/build dependencies are permitted. Do not add accounts or sign-in.
