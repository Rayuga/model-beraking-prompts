# How the application runs

The application runs as one Node 22 process with Express and better-sqlite3
already available through NODE_PATH; use only those packages and Node
built-ins. The process starts from /app/server.js, listens on port 3000 on
0.0.0.0, and serves both the browser UI and the API. Keep the SQLite
database beside server.js (for example /app/playground.db), honoring
DB_PATH when it is set; accept SQLITE_PATH as a compatibility alias for the
same setting. Restarting the process over the same database file keeps all
data, and seeding never duplicates records. GET /api/health answers before
database work can block startup.

The product is served from the local server. It may load external fonts,
scripts or CDN assets, but it cannot depend on an external backend or data
service. How routes and files are laid out under /app is up to you.

/instructions and /assets are not there when the playground runs for real;
only /app is. /assets/artifacts/task_scope.json records that no starter
implementation is handed to the participant environment: the runnable
examples the playground opens and offers are part of the shipped
application itself, not a supplied fixture, and they ship inside /app (for
example /app/starters/) rather than under /assets.

Saved snippets are the only durable records this application keeps. They
must survive both a page reload and a full process restart on the same
database file.
