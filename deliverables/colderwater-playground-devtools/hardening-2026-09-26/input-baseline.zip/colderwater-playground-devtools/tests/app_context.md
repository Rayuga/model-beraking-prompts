## Application

Name: Colderwater Playground (offline in-browser code playground)
URL: http://localhost:3000

## Accounts

No sign-in: the playground opens straight to its workspace. There is one
shared library of saved snippets; no participant starter files are supplied.

## Key screens

The three-pane workspace (editor with its title and filename fields, live
preview, console), with the Example picker and the Run, Stop and Auto-run
controls above it; the saved-snippets library below the editor, with
Duplicate, Rename and Delete controls and its own Export/Import controls; the
light/dark theme toggle; and, at 375 pixels wide, the same workspace with its
panes stacked and still individually usable.
