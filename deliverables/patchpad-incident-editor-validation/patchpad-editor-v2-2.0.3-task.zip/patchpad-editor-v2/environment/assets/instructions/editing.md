# Editing

Support the normal things people expect from a text editor: typing, new lines,
Backspace, Delete, arrow keys, Home and End. Show line numbers and the current
cursor position.

Include familiar keyboard behavior for moving or selecting by words, using Tab
and Shift+Tab for indentation, and opening Find from the keyboard. Find results
should be reachable in both directions without going back to the mouse.
Escape from the editing area should focus the Find input so people can use
Tab and Shift+Tab to move through the surrounding controls again.

Support emoji and accented text as complete visible characters when moving,
selecting, or deleting.

Mouse and keyboard selection should work for words, lines, larger ranges, and
the whole document. Selection should continue naturally when it moves beyond
the visible part of a long report. Typing or pasting over a selection should
replace it.

Support copy, cut, and paste from PatchPad and from other applications, including
multiline and tabbed clipboard text. Provide visible Undo and Redo controls as
well as the usual keyboard shortcuts. Undo and Redo should behave like they do
in familiar document editors such as Google Docs or Word.

Allow multiple carets using Alt+Click or Ctrl/Cmd+Click. Typing, Backspace, and
Delete should affect every active caret.

Keep uninterrupted typing at one location together in Undo. Replacing a
selection is one action; moving to another location starts a new action, and
a new edit clears Redo.
