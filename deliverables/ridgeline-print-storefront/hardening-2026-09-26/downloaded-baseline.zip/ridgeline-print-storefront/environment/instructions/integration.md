# How the application runs

The application runs as one Node 22 process with Express and better-sqlite3
already available through NODE_PATH; use only those packages and Node
built-ins. The process starts from /app/server.js, listens on port 3000 on
0.0.0.0, and serves both the browser UI and the API. GET /api/health answers
before database work can block startup.

The catalogue's data files (variants.csv and postage.csv) and the print
photographs are under /assets. /assets is not there when the shop runs for
real; only /app is. So copy what is needed into /app (for example
/app/seed/, in whatever form is convenient) and load it from that copy on
first start, when the database is empty. Starting again must not load it a
second time or duplicate anything. Keep every SKU, title, paper size, price,
stock figure and trade-break number exactly as variants.csv and postage.csv
have them, and use the real photographs from /assets/prints — no placeholder
images.

Keep the SQLite database at /app/app.db, honoring DB_PATH when it is set.
Restarting the process over the same database file keeps all data: every
placed order and every stock change survives a restart, and seeding never
duplicates records.

The shop is public: there is no sign-in, and the basket belongs to whoever is
looking rather than to any account, held in the browser. The product is
served from the local server. It may load external fonts, scripts or CDN
assets, but nothing it needs in order to function may depend on the network
— every photograph and script the shop actually uses ships locally. How
routes and files are laid out under /app is up to you.
