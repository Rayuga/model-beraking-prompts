Can you build me the shop front for Ridgeline Press, a risograph print studio? React on SQLite — no accounts, no sign-in, it's public, and the basket lives in the browser for whoever is looking.

Everything the shop sells is under /instructions and /assets: a photo of every print, one buyable line per paper size in variants.csv, postage bands in postage.csv, and README.md and checkout-note.md writing up pricing, the trade break, postage, the basket and the order — follow both precisely; those numbers outrank a request body or the UI. Use the real images, not placeholders.

The grid needs to sell prints: filter by paper size and stock sheet, sort by price and title, search titles, and show a price and stock state unopened. Opening a print shows the image large with its sizes, papers and prices. Stock and price are per line, not per print — a sold-out A3 should still sell its A2. Show a line's trade break before and after it applies.

Then a checkout collecting a delivery address and a summary with the same figures — no payment, no card details — ending in a confirmation with a reference. Light and dark mode, keyboard-navigable and responsive to a phone; nothing should be fetched over the network.

Put the app in /app with Node.js and Express, and use SQLite for durable storage. It must start with node /app/server.js, listen on port 3000, expose a successful GET /api/health before any database work blocks startup, and serve the browser UI from /app/public/index.html.
