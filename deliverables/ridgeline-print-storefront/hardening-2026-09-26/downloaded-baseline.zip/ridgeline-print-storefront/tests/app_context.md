## Application

Name: Ridgeline Press (risograph print shop)
URL: http://localhost:3000

## Accounts

No sign-in: the shop is public and opens straight to its catalogue. The
basket belongs to whoever is looking and lives in the browser.

## Key screens

The print grid (filter by paper size and stock sheet, sort by price or
title, search titles, price and stock state on every card); a print's
detail view (its photograph large, every size it comes in, each size's own
price, stock and trade-break state); the basket panel (subtotal, trade-break
saving, postage and total, each shown separately); the checkout
delivery-address form; the order review step; the order confirmation
screen; and the "track an order" lookup by reference.
