import json
import math
import sys
import tomllib
from pathlib import Path


def number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"Missing or non-numeric {label}")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"Non-finite {label}")
    return value


def policy(root):
    config = tomllib.loads((root / "reward.toml").read_text())
    if set(config) != {"reward", "composition"} or config["reward"] != [{"name": "reward", "aggregation": "weighted_mean"}]:
        raise ValueError("RewardKit must declare the named intermediate weighted mean")
    composition = config["composition"]
    if set(composition) != {"gates", "weighted_dimensions"}:
        raise ValueError("Unknown composition fields")
    gates = composition["gates"]
    weighted = composition["weighted_dimensions"]
    dimensions = gates + weighted
    if len(dimensions) != 5 or set(dimensions) != {"render", "constraints", "functional", "polish", "visual"}:
        raise ValueError("Each dimension must have exactly one composition role")
    if set(gates) != {"render", "constraints"}:
        raise ValueError("Render and Constraints must be mandatory gates")
    weights = {}
    for dimension in dimensions:
        judge = tomllib.loads((root / dimension / "judge.toml").read_text())
        weight = number(judge["judge"]["weight"], f"{dimension} weight")
        if weight <= 0:
            raise ValueError(f"Non-positive {dimension} weight")
        expected = "all_pass" if dimension in gates else "weighted_mean"
        if judge["scoring"]["aggregation"] != expected:
            raise ValueError(f"Incorrect {dimension} aggregation")
        weights[dimension] = weight
    return gates, weighted, weights


def compose(data, root):
    gates, weighted, weights = policy(root)
    for dimension in gates + weighted:
        value = number(data.get(dimension), f"RewardKit dimension {dimension}")
        if not 0 <= value <= 1:
            raise ValueError(f"Out-of-range RewardKit dimension {dimension}")
        data[dimension] = value
    if any(data[dimension] <= 0 for dimension in gates):
        return 0.0
    return round(sum(data[dimension] * weights[dimension] for dimension in weighted) / sum(weights[dimension] for dimension in weighted), 4)


def write_outputs(json_path, text_path, ctrf_path, root):
    data = json.loads(json_path.read_text())
    data["reward"] = compose(data, root)
    data["graded"] = 1
    data["no_op"] = 0
    dimensions = policy(root)[0] + policy(root)[1]
    cases = [{"name": dimension, "status": "passed" if data[dimension] > (0.05 if dimension == "functional" else 0) else "failed"} for dimension in dimensions]
    passed = sum(case["status"] == "passed" for case in cases)
    json_path.write_text(json.dumps(data, indent=2) + "\n")
    text_path.write_text(f"{data['reward']:.4f}\n")
    ctrf_path.write_text(json.dumps({"tool": {"name": "rewardkit"}, "tests": cases, "summary": {"passed": passed, "failed": len(cases) - passed, "skipped": 0, "total": 5}}, indent=2) + "\n")


if __name__ == "__main__":
    write_outputs(*(Path(value) for value in sys.argv[1:4]), Path(__file__).resolve().parent)
