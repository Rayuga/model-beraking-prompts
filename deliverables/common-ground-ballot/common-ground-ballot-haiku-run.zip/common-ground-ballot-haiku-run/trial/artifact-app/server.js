const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const app = express();
const publicDir = path.join(__dirname, 'public');
const dbPath = process.env.DB_PATH || path.join(__dirname, 'commonground.db');
const seedPath = path.join(__dirname, 'common_ground_seed.json');

let db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

let seedApplied = false;

// ============================================================================
// DATABASE SCHEMA
// ============================================================================

function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('coordinator', 'observer', 'member')),
      password_hash TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      last_active_at INTEGER NOT NULL,
      ended_at INTEGER,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS memberships (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL UNIQUE,
      active INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS ballots (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      method TEXT NOT NULL CHECK (method IN ('single', 'approval')),
      max_selections INTEGER NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('draft', 'open', 'closed', 'published')),
      revision INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ballot_choices (
      id TEXT PRIMARY KEY,
      ballot_id TEXT NOT NULL,
      label TEXT NOT NULL,
      FOREIGN KEY (ballot_id) REFERENCES ballots(id)
    );

    CREATE TABLE IF NOT EXISTS ballot_eligibility (
      ballot_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      PRIMARY KEY (ballot_id, user_id),
      FOREIGN KEY (ballot_id) REFERENCES ballots(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS votes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ballot_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      UNIQUE (ballot_id, user_id),
      FOREIGN KEY (ballot_id) REFERENCES ballots(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS vote_choices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vote_id INTEGER NOT NULL,
      choice_id TEXT NOT NULL,
      FOREIGN KEY (vote_id) REFERENCES votes(id),
      FOREIGN KEY (choice_id) REFERENCES ballot_choices(id)
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      resource_type TEXT NOT NULL,
      resource_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS seed_applied (
      applied INTEGER NOT NULL DEFAULT 0
    );
  `);
}

// ============================================================================
// SEED DATABASE
// ============================================================================

function applySeed() {
  const checkSeed = db.prepare('SELECT applied FROM seed_applied LIMIT 1');
  const result = checkSeed.get();
  if (result && result.applied) {
    return;
  }

  const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
  const now = Math.floor(Date.now() / 1000);

  const insertUser = db.prepare(`
    INSERT OR IGNORE INTO users (id, name, email, role, password_hash)
    VALUES (?, ?, ?, ?, ?)
  `);

  const insertMembership = db.prepare(`
    INSERT OR IGNORE INTO memberships (user_id, active)
    VALUES (?, ?)
  `);

  const insertBallot = db.prepare(`
    INSERT OR IGNORE INTO ballots (id, title, description, method, max_selections, status, revision, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertChoice = db.prepare(`
    INSERT OR IGNORE INTO ballot_choices (id, ballot_id, label)
    VALUES (?, ?, ?)
  `);

  const insertEligibility = db.prepare(`
    INSERT OR IGNORE INTO ballot_eligibility (ballot_id, user_id)
    VALUES (?, ?)
  `);

  const insertVote = db.prepare(`
    INSERT OR IGNORE INTO votes (ballot_id, user_id, created_at)
    VALUES (?, ?, ?)
  `);

  const insertVoteChoice = db.prepare(`
    INSERT INTO vote_choices (vote_id, choice_id)
    VALUES (?, ?)
  `);

  const hashPassword = (pass) => {
    return crypto.pbkdf2Sync(pass, 'salt-ignored-for-demo', 10000, 64, 'sha256').toString('hex');
  };

  const transaction = db.transaction(() => {
    for (const user of seed.users) {
      insertUser.run(user.id, user.name, user.email, user.role, hashPassword('CommonGround!2026'));
    }

    for (const member of seed.memberships) {
      insertMembership.run(member.user_id, member.active ? 1 : 0);
    }

    for (const ballot of seed.ballots) {
      insertBallot.run(ballot.id, ballot.title, ballot.description, ballot.method, ballot.max_selections, ballot.status, ballot.revision, now, now);

      for (const choice of ballot.choices) {
        insertChoice.run(choice.id, ballot.id, choice.label);
      }

      if (ballot.eligible_user_ids) {
        for (const userId of ballot.eligible_user_ids) {
          insertEligibility.run(ballot.id, userId);
        }
      }

      if (ballot.status === 'closed' || ballot.status === 'published') {
        for (const userId of ballot.participant_user_ids || []) {
          const voteId = db.prepare('INSERT INTO votes (ballot_id, user_id, created_at) VALUES (?, ?, ?) RETURNING id').get(ballot.id, userId, now).id;
          for (const choiceId of ballot.anonymous_choice_ids || []) {
            insertVoteChoice.run(voteId, choiceId);
          }
        }
      }
    }

    db.prepare('INSERT INTO seed_applied (applied) VALUES (1)').run();
  });

  transaction();
}

// ============================================================================
// UTILITIES
// ============================================================================

function generateSessionId() {
  return crypto.randomBytes(32).toString('hex');
}

function getSessionUser(sessionId) {
  if (!sessionId) return null;
  const session = db.prepare(`
    SELECT u.id, u.name, u.email, u.role
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ? AND s.ended_at IS NULL
  `).get(sessionId);
  if (session) {
    db.prepare('UPDATE sessions SET last_active_at = ? WHERE id = ?').run(Math.floor(Date.now() / 1000), sessionId);
  }
  return session;
}

function logAudit(action, resourceType, resourceId, userId) {
  db.prepare(`
    INSERT INTO audit_logs (action, resource_type, resource_id, user_id, created_at)
    VALUES (?, ?, ?, ?, ?)
  `).run(action, resourceType, resourceId, userId, Math.floor(Date.now() / 1000));
}

// ============================================================================
// MIDDLEWARE
// ============================================================================

app.use(express.json());

app.use((req, res, next) => {
  const sessionId = req.headers['x-session-id'];
  req.user = getSessionUser(sessionId);
  req.sessionId = sessionId;
  next();
});

// ============================================================================
// AUTH ROUTES
// ============================================================================

app.post('/api/auth/sign-in', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const user = db.prepare('SELECT id, name, email, role FROM users WHERE email = ?').get(email);
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const sessionId = generateSessionId();
  const now = Math.floor(Date.now() / 1000);
  db.prepare(`
    INSERT INTO sessions (id, user_id, created_at, last_active_at)
    VALUES (?, ?, ?, ?)
  `).run(sessionId, user.id, now, now);

  res.json({ sessionId, user });
});

app.post('/api/auth/sign-out', (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not signed in' });
  }

  db.prepare('UPDATE sessions SET ended_at = ? WHERE id = ?').run(Math.floor(Date.now() / 1000), req.sessionId);
  res.json({ ok: true });
});

app.post('/api/auth/end-all-sessions', (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not signed in' });
  }

  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE sessions SET ended_at = ? WHERE user_id = ? AND ended_at IS NULL').run(now, req.user.id);
  res.json({ ok: true });
});

// ============================================================================
// BALLOT ROUTES
// ============================================================================

app.get('/api/ballots', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });

  let query = `
    SELECT b.id, b.title, b.description, b.method, b.max_selections, b.status, b.revision
    FROM ballots b
  `;

  const params = [];

  if (req.user.role === 'member') {
    query += ` WHERE b.id IN (
      SELECT ballot_id FROM ballot_eligibility WHERE user_id = ?
    ) OR b.status = 'published'`;
    params.push(req.user.id);
  }

  query += ` ORDER BY b.created_at DESC`;

  const ballots = db.prepare(query).all(...params);

  const result = ballots.map(b => {
    const choices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(b.id);
    const eligible = db.prepare('SELECT user_id FROM ballot_eligibility WHERE ballot_id = ?').all(b.id);
    const hasVoted = req.user.role === 'member' ? db.prepare('SELECT 1 FROM votes WHERE ballot_id = ? AND user_id = ?').get(b.id, req.user.id) : null;

    return {
      ...b,
      choices,
      eligible_count: eligible.length,
      has_voted: !!hasVoted,
    };
  });

  res.json(result);
});

app.get('/api/ballots/:id', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  const choices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(ballot.id);

  if (req.user.role === 'member' && ballot.status === 'draft') {
    return res.status(403).json({ error: 'Members cannot view draft ballots' });
  }

  res.json({ ...ballot, choices });
});

app.post('/api/ballots', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only coordinators can create ballots' });

  const { title, description, method, max_selections, choices } = req.body;

  if (!title || !method || !choices || choices.length < 2) {
    return res.status(400).json({ error: 'Invalid ballot data' });
  }

  if (method === 'single' && max_selections !== 1) {
    return res.status(400).json({ error: 'Single choice ballots must have max_selections = 1' });
  }

  if (method === 'approval' && (max_selections < 1 || max_selections > choices.length)) {
    return res.status(400).json({ error: 'Approval max_selections must be between 1 and number of choices' });
  }

  const now = Math.floor(Date.now() / 1000);
  const ballotId = 'ballot-' + crypto.randomBytes(8).toString('hex');

  const transaction = db.transaction(() => {
    db.prepare(`
      INSERT INTO ballots (id, title, description, method, max_selections, status, revision, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, 'draft', 1, ?, ?)
    `).run(ballotId, title, description || '', method, max_selections, now, now);

    for (const choice of choices) {
      const choiceId = 'choice-' + crypto.randomBytes(8).toString('hex');
      db.prepare('INSERT INTO ballot_choices (id, ballot_id, label) VALUES (?, ?, ?)').run(choiceId, ballotId, choice.label);
    }

    logAudit('create', 'ballot', ballotId, req.user.id);
  });

  transaction();
  res.status(201).json({ id: ballotId });
});

app.patch('/api/ballots/:id', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only coordinators can edit ballots' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (ballot.status !== 'draft') {
    return res.status(409).json({ error: 'Only draft ballots can be edited' });
  }

  const { title, description, method, max_selections, choices, revision } = req.body;

  if (revision !== ballot.revision) {
    return res.status(409).json({ error: 'Revision conflict' });
  }

  const now = Math.floor(Date.now() / 1000);

  const transaction = db.transaction(() => {
    db.prepare(`
      UPDATE ballots SET title = ?, description = ?, method = ?, max_selections = ?, revision = revision + 1, updated_at = ?
      WHERE id = ?
    `).run(title || ballot.title, description !== undefined ? description : ballot.description, method || ballot.method, max_selections !== undefined ? max_selections : ballot.max_selections, now, ballot.id);

    if (choices) {
      db.prepare('DELETE FROM ballot_choices WHERE ballot_id = ?').run(ballot.id);
      for (const choice of choices) {
        const choiceId = 'choice-' + crypto.randomBytes(8).toString('hex');
        db.prepare('INSERT INTO ballot_choices (id, ballot_id, label) VALUES (?, ?, ?)').run(choiceId, ballot.id, choice.label);
      }
    }

    logAudit('edit', 'ballot', ballot.id, req.user.id);
  });

  transaction();

  const updated = db.prepare('SELECT * FROM ballots WHERE id = ?').get(ballot.id);
  const updatedChoices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(ballot.id);

  res.json({ ...updated, choices: updatedChoices });
});

app.post('/api/ballots/:id/open', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only coordinators can open ballots' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (ballot.status !== 'draft') {
    return res.status(409).json({ error: 'Only draft ballots can be opened' });
  }

  const { revision } = req.body;
  if (revision !== ballot.revision) {
    return res.status(409).json({ error: 'Revision conflict' });
  }

  const now = Math.floor(Date.now() / 1000);

  const transaction = db.transaction(() => {
    const activeMembers = db.prepare(`
      SELECT user_id FROM memberships WHERE active = 1 AND user_id IN (SELECT id FROM users WHERE role = 'member')
    `).all();

    db.prepare('DELETE FROM ballot_eligibility WHERE ballot_id = ?').run(ballot.id);

    for (const member of activeMembers) {
      db.prepare('INSERT INTO ballot_eligibility (ballot_id, user_id) VALUES (?, ?)').run(ballot.id, member.user_id);
    }

    db.prepare(`
      UPDATE ballots SET status = 'open', revision = revision + 1, updated_at = ?
      WHERE id = ?
    `).run(now, ballot.id);

    logAudit('open', 'ballot', ballot.id, req.user.id);
  });

  transaction();

  const updated = db.prepare('SELECT * FROM ballots WHERE id = ?').get(ballot.id);
  const choices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(ballot.id);

  res.json({ ...updated, choices });
});

app.post('/api/ballots/:id/close', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only coordinators can close ballots' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (ballot.status !== 'open') {
    return res.status(409).json({ error: 'Only open ballots can be closed' });
  }

  const { revision } = req.body;
  if (revision !== ballot.revision) {
    return res.status(409).json({ error: 'Revision conflict' });
  }

  const now = Math.floor(Date.now() / 1000);
  db.prepare(`
    UPDATE ballots SET status = 'closed', revision = revision + 1, updated_at = ?
    WHERE id = ?
  `).run(now, ballot.id);

  logAudit('close', 'ballot', ballot.id, req.user.id);

  const updated = db.prepare('SELECT * FROM ballots WHERE id = ?').get(ballot.id);
  const choices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(ballot.id);

  res.json({ ...updated, choices });
});

app.post('/api/ballots/:id/publish', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only coordinators can publish ballots' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (ballot.status !== 'closed') {
    return res.status(409).json({ error: 'Only closed ballots can be published' });
  }

  const { revision } = req.body;
  if (revision !== ballot.revision) {
    return res.status(409).json({ error: 'Revision conflict' });
  }

  const now = Math.floor(Date.now() / 1000);
  db.prepare(`
    UPDATE ballots SET status = 'published', revision = revision + 1, updated_at = ?
    WHERE id = ?
  `).run(now, ballot.id);

  logAudit('publish', 'ballot', ballot.id, req.user.id);

  const updated = db.prepare('SELECT * FROM ballots WHERE id = ?').get(ballot.id);
  const choices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(ballot.id);

  res.json({ ...updated, choices });
});

// ============================================================================
// VOTING ROUTES
// ============================================================================

app.get('/api/ballots/:id/vote', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'member') return res.status(403).json({ error: 'Only members can vote' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (ballot.status !== 'open') {
    return res.status(409).json({ error: 'Ballot is not open' });
  }

  const eligible = db.prepare('SELECT 1 FROM ballot_eligibility WHERE ballot_id = ? AND user_id = ?').get(ballot.id, req.user.id);
  if (!eligible) {
    return res.status(403).json({ error: 'Not eligible for this ballot' });
  }

  const choices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(ballot.id);

  res.json({ id: ballot.id, title: ballot.title, description: ballot.description, method: ballot.method, max_selections: ballot.max_selections, choices });
});

app.post('/api/ballots/:id/vote', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'member') return res.status(403).json({ error: 'Only members can vote' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (ballot.status !== 'open') {
    return res.status(409).json({ error: 'Ballot is not open' });
  }

  const eligible = db.prepare('SELECT 1 FROM ballot_eligibility WHERE ballot_id = ? AND user_id = ?').get(ballot.id, req.user.id);
  if (!eligible) {
    return res.status(403).json({ error: 'Not eligible for this ballot' });
  }

  const existingVote = db.prepare('SELECT id FROM votes WHERE ballot_id = ? AND user_id = ?').get(ballot.id, req.user.id);
  if (existingVote) {
    return res.status(409).json({ error: 'Already voted on this ballot' });
  }

  const { choices } = req.body;
  if (!choices || !Array.isArray(choices) || choices.length === 0) {
    return res.status(400).json({ error: 'At least one choice required' });
  }

  if (ballot.method === 'single' && choices.length !== 1) {
    return res.status(400).json({ error: 'Single choice ballot requires exactly one choice' });
  }

  if (ballot.method === 'approval' && choices.length > ballot.max_selections) {
    return res.status(400).json({ error: `Approval ballot allows maximum ${ballot.max_selections} choices` });
  }

  const validChoices = db.prepare('SELECT id FROM ballot_choices WHERE ballot_id = ?').all(ballot.id);
  const validIds = new Set(validChoices.map(c => c.id));

  for (const choiceId of choices) {
    if (!validIds.has(choiceId)) {
      return res.status(400).json({ error: 'Invalid choice ID' });
    }
  }

  const now = Math.floor(Date.now() / 1000);

  const transaction = db.transaction(() => {
    const voteId = db.prepare(`
      INSERT INTO votes (ballot_id, user_id, created_at)
      VALUES (?, ?, ?)
      RETURNING id
    `).get(ballot.id, req.user.id, now).id;

    for (const choiceId of choices) {
      db.prepare('INSERT INTO vote_choices (vote_id, choice_id) VALUES (?, ?)').run(voteId, choiceId);
    }

    logAudit('vote', 'ballot', ballot.id, req.user.id);
  });

  transaction();

  res.json({ ok: true });
});

// ============================================================================
// TURNOUT & RESULTS ROUTES
// ============================================================================

app.get('/api/ballots/:id/turnout', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (req.user.role === 'member') {
    return res.status(403).json({ error: 'Members cannot view turnout' });
  }

  const eligible = db.prepare('SELECT user_id FROM ballot_eligibility WHERE ballot_id = ? ORDER BY user_id').all(req.params.id);
  const participated = db.prepare(`
    SELECT DISTINCT v.user_id FROM votes v WHERE v.ballot_id = ? ORDER BY v.user_id
  `).all(req.params.id);

  const participantSet = new Set(participated.map(p => p.user_id));
  const roster = eligible.map(e => {
    const user = db.prepare('SELECT name, email FROM users WHERE id = ?').get(e.user_id);
    return { user_id: e.user_id, name: user.name, has_voted: participantSet.has(e.user_id) };
  });

  res.json({ id: ballot.id, title: ballot.title, status: ballot.status, eligible_count: eligible.length, participated_count: participated.length, roster });
});

app.get('/api/ballots/:id/results', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });

  const ballot = db.prepare('SELECT * FROM ballots WHERE id = ?').get(req.params.id);
  if (!ballot) return res.status(404).json({ error: 'Ballot not found' });

  if (req.user.role === 'member') {
    if (ballot.status !== 'published') {
      return res.status(403).json({ error: 'Members can only view published results' });
    }
  } else if (ballot.status !== 'closed' && ballot.status !== 'published') {
    return res.status(403).json({ error: 'Results not available in this state' });
  }

  const choices = db.prepare('SELECT id, label FROM ballot_choices WHERE ballot_id = ? ORDER BY rowid').all(ballot.id);
  const participants = db.prepare('SELECT COUNT(DISTINCT user_id) as count FROM votes WHERE ballot_id = ?').get(ballot.id);
  const participantCount = participants.count;

  const results = choices.map(choice => {
    const voteCount = db.prepare(`
      SELECT COUNT(*) as count FROM vote_choices WHERE choice_id = ?
    `).get(choice.id).count;

    return { id: choice.id, label: choice.label, votes: voteCount, percentage: participantCount > 0 ? (voteCount / participantCount * 100).toFixed(1) : 0 };
  });

  if (ballot.method === 'single') {
    const maxVotes = Math.max(...results.map(r => r.votes), 0);
    const leaders = results.filter(r => r.votes === maxVotes);

    if (leaders.length > 1) {
      return res.json({ id: ballot.id, title: ballot.title, method: ballot.method, status: ballot.status, results, participant_count: participantCount, is_tie: true, leaders: leaders.map(l => l.label) });
    }
  }

  res.json({ id: ballot.id, title: ballot.title, method: ballot.method, status: ballot.status, results, participant_count: participantCount });
});

// ============================================================================
// MEMBERS ROUTES
// ============================================================================

app.get('/api/members', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role === 'member') return res.status(403).json({ error: 'Members cannot view member list' });

  const members = db.prepare(`
    SELECT u.id, u.name, u.email, m.active FROM users u
    LEFT JOIN memberships m ON u.id = m.user_id
    WHERE u.role = 'member'
    ORDER BY u.name
  `).all();

  res.json(members);
});

app.patch('/api/members/:id', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only coordinators can manage members' });

  const user = db.prepare('SELECT id, role FROM users WHERE id = ?').get(req.params.id);
  if (!user || user.role !== 'member') return res.status(404).json({ error: 'Member not found' });

  const { active } = req.body;
  if (typeof active !== 'boolean') {
    return res.status(400).json({ error: 'Active must be boolean' });
  }

  const now = Math.floor(Date.now() / 1000);

  db.prepare('INSERT OR REPLACE INTO memberships (user_id, active) VALUES (?, ?)').run(req.params.id, active ? 1 : 0);

  logAudit(active ? 'activate' : 'deactivate', 'member', req.params.id, req.user.id);

  const updated = db.prepare('SELECT u.id, u.name, u.email, m.active FROM users u LEFT JOIN memberships m ON u.id = m.user_id WHERE u.id = ?').get(req.params.id);

  res.json(updated);
});

// ============================================================================
// AUDIT ROUTES
// ============================================================================

app.get('/api/audit', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  if (req.user.role === 'member') return res.status(403).json({ error: 'Members cannot view audit log' });

  const logs = db.prepare(`
    SELECT a.action, a.resource_type, a.resource_id, u.name, u.email, a.created_at
    FROM audit_logs a
    JOIN users u ON a.user_id = u.id
    ORDER BY a.created_at DESC
    LIMIT 200
  `).all();

  res.json(logs);
});

// ============================================================================
// STATIC FILES
// ============================================================================

app.get('/api/health', (_request, response) => response.json({ ok: true }));
app.use(express.static(publicDir));
app.use((_request, response) => response.sendFile(path.join(publicDir, 'index.html')));

// ============================================================================
// START SERVER
// ============================================================================

initializeDatabase();
applySeed();

const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => {
  console.log(`Common Ground listening on ${port}`);
});
