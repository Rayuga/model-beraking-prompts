# Common Ground Ballot

A private ballot workspace for membership group decision-making with role-based access control, transparent participation tracking, and anonymous vote recording.

## Overview

Common Ground is a local web application designed for the Riverside Residents Association to manage private ballots. It provides distinct workspaces for different roles (Coordinator, Observer, Member) with appropriate access levels and maintains complete audit trails of administrative actions while keeping individual voting choices confidential.

## Key Features

- **Role-Based Access Control**: Three roles with distinct capabilities
  - **Coordinator** (Ruth): Creates ballots, manages eligibility, drives state transitions
  - **Observer** (Arun): Reviews setup, turnout, results, and audit activity
  - **Member** (Leila, Owen): Votes on eligible ballots and views participation status

- **Ballot Lifecycle**: Ballots progress through four distinct states
  - **Draft**: Coordinator can create and edit
  - **Open**: Members vote; eligible roster is captured at this moment
  - **Closed**: No further voting; results are hidden
  - **Published**: Results become visible; state is terminal

- **Voting Methods**:
  - **Single choice**: Exactly one selection per member
  - **Approval**: Multiple selections up to specified limit

- **Privacy & Security**:
  - Identified participation records (who voted) separate from anonymous choices
  - Staff can see turnout without seeing individual selections
  - Server-issued unpredictable sessions (not browser-controlled)
  - Session revocation: members can end all their sessions
  - Revision-based optimistic concurrency (prevents stale writes)

- **Audit Trail**: All administrative actions logged with timestamp and actor
  - Ballot create, edit, open, close, publish
  - Member activate, deactivate
  - Voting recorded anonymously (participation only, no choice)

- **Data Persistence**: All records survive server restarts
  - SQLite database
  - Seed data applied exactly once per database
  - Sessions do not persist (end on restart)

## Installation & Setup

### Prerequisites

- Node.js 22
- npm (comes with Node.js)

### Getting Started

```bash
cd /app
npm install
node server.js
```

The server listens on port 3000 (configurable via `PORT` env var).

Visit `http://localhost:3000` in your browser.

### Database

- **Location**: `/app/commonground.db` (configurable via `DB_PATH` env var)
- **Seed data**: Loaded from `/app/common_ground_seed.json` on first startup
- **Persistence**: All ballots, votes, participants, members, and audit records survive restart
- **Sessions**: Server-issued; not persisted (end on restart for security)

## Demo Accounts

All accounts use password: `CommonGround!2026`

| Name | Email | Role |
|------|-------|------|
| Ruth Adebayo | ruth.adebayo@commonground.example | Coordinator |
| Arun Das | arun.das@commonground.example | Observer |
| Leila Ward | leila.ward@commonground.example | Member (active) |
| Owen Park | owen.park@commonground.example | Member (inactive) |

## Workspaces

### Ballots
- **Coordinator**: Create new ballots, edit drafts, transition states
- **Observer**: View all ballots and their metadata
- **Member**: View eligible ballots, including those they've already voted on

### Vote
- **Member only**: Open ballots where member is eligible
- Shows ballot title, description, choices
- Privacy notice displayed before submission
- Vote is final and cannot be changed

### Turnout
- **Coordinator & Observer only**: See participation without revealing choices
- Shows roster with participation status for each eligible member
- Displays counts and percentages

### Results
- **Coordinator & Observer**: View results from closed or published ballots
- **Member**: View results only from published ballots
- For single-choice: Shows counts, percentages, and detects ties
- For approval: Shows approval counts and percentages (may exceed 100%)

### Members
- **Coordinator & Observer only**: View active member roster
- **Coordinator only**: Activate/deactivate members
- Active members are eligible for future ballots
- Already-open ballots preserve previous eligibility

### Audit
- **Coordinator & Observer only**: Review administrative activity log
- Shows action, resource type/ID, actor name, and timestamp
- Never includes member names or choices

## Architecture

### Frontend (`/app/public/`)

- **index.html**: Login form and workspace layout
- **styles.css**: Responsive design (390×844 mobile +), light/dark theme, accessibility features
- **app.js**: Client-side state management, API communication, view rendering

Features:
- Theme toggle (light/dark, persisted to localStorage)
- Session management via X-Session-Id header
- Role-based navigation (buttons hidden for unauthorized roles)
- Real-time error and success messages
- Idempotent operations (retrying same action is safe)
- Touch-friendly with 44px minimum hit targets

### Backend (`/app/server.js`)

Express.js server with SQLite database.

#### Database Schema

- **users**: Account records with role
- **sessions**: Active login sessions (server-issued, unpredictable)
- **memberships**: Active/inactive roster
- **ballots**: Ballot metadata
- **ballot_choices**: Choices for each ballot
- **ballot_eligibility**: Snapshot of active members at ballot open time
- **votes**: Participation records (user + ballot, no choice)
- **vote_choices**: Anonymous choice records (no user link)
- **audit_logs**: Administrative activity

#### API Routes

**Authentication**
- `POST /api/auth/sign-in`: Generate session
- `POST /api/auth/sign-out`: End session
- `POST /api/auth/end-all-sessions`: End all user's sessions

**Ballots**
- `GET /api/ballots`: List (filtered by role)
- `GET /api/ballots/:id`: Get ballot details
- `POST /api/ballots`: Create draft
- `PATCH /api/ballots/:id`: Edit draft
- `POST /api/ballots/:id/open`: Transition to open, capture eligibility
- `POST /api/ballots/:id/close`: Transition to closed
- `POST /api/ballots/:id/publish`: Transition to published

**Voting**
- `GET /api/ballots/:id/vote`: Check eligibility and get ballot details
- `POST /api/ballots/:id/vote`: Submit vote (idempotent)

**Reporting**
- `GET /api/ballots/:id/turnout`: Participation roster (no choices revealed)
- `GET /api/ballots/:id/results`: Vote counts and percentages

**Members**
- `GET /api/members`: List members
- `PATCH /api/members/:id`: Toggle active status

**Audit**
- `GET /api/audit`: Recent administrative actions

## Security

### Session Management
- Sessions are random 64-hex-character strings generated server-side
- Session IDs are never sent in response bodies to prevent XSS exposure
- Transmitted via `X-Session-Id` header (not in URL)
- Sessions end immediately when `POST /api/auth/sign-out` is called
- Old sessions don't reactivate (check `ended_at` on each request)

### Access Control
- Role determined from server-issued session, never from client data
- All endpoints verify role before returning data
- Members cannot access member list, audit, turnout, or results until published
- Coordinators cannot see individual choices in any view

### Vote Privacy
- Votes split into participation (identified) and choices (anonymous)
- `vote_choices` table has no foreign key to users
- Results show only aggregated counts
- Audit log records voting happened but not what was chosen

### Concurrency
- Ballot revisions prevent stale writes
- Last-write-wins on edits with revision check
- Opening a ballot captures eligible member list at that moment
- Member activation/deactivation only affects future ballots

## Testing

### Manual Testing

The seeded data includes:
- **ballot-draft-picnic**: Draft ballot (picnic dates)
- **ballot-open-courtyard**: Open ballot (courtyard closing time) with Leila + Owen eligible
- **ballot-closed-improvements**: Closed ballot (space improvements) with 2 votes recorded
- **ballot-published-garden**: Published ballot (garden location) with 2 votes recorded

### Recommended Workflow

1. **As Ruth (Coordinator)**:
   - View seeded ballots
   - Create a new ballot with 2-3 choices
   - Open it (captures Leila as eligible since Owen is inactive)
   - View Turnout tab

2. **As Leila (Member)**:
   - View Vote tab
   - Vote on the newly-opened ballot
   - Try to vote again (verify prevented)
   - Switch to Results tab (verify not visible until published)

3. **As Arun (Observer)**:
   - View Turnout tab for the ballot
   - Verify Leila is marked as having voted
   - View Audit log to see all actions

4. **Back as Ruth**:
   - Close and then publish the ballot

5. **All Users**:
   - Verify Results now show votes and percentages

6. **Restart Test** (optional):
   - Stop the server
   - Restart it
   - Verify all ballot data persists
   - Verify sessions are empty (requires re-sign-in)
   - Verify votes are preserved

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- Mobile-friendly responsive design (390px+)
- Keyboard navigation with visible focus indicators
- Respects `prefers-reduced-motion` for accessibility
- Light and dark theme support

## Configuration

Environment variables:

```bash
PORT=3000              # Server port (default: 3000)
DB_PATH=/path/to/db   # SQLite database location (default: /app/commonground.db)
```

## No External Dependencies in Browser

- CSS and HTML: Standard, no framework
- JavaScript: Vanilla ES6, no libraries
- Fonts: System defaults
- Icons: Unicode emoji and text
- No CDN required, no npm install needed for browser code

## Future Considerations (Out of Scope)

- User registration and password management
- Email notifications
- Public result sharing links
- Ballot templates
- Vote export/import
- Real-world election certification
- Ballot cancellation/archival
- Voter eligibility recalculation for in-progress ballots

## File Structure

```
/app/
├── server.js                    # Express server + SQLite
├── package.json                 # Dependencies
├── common_ground_seed.json      # Seed data
├── commonground.db              # SQLite database (created on first run)
├── public/
│   ├── index.html              # HTML shell
│   ├── app.js                  # Frontend logic
│   └── styles.css              # Styling
└── README.md                   # This file
```

## License

Private use for Riverside Residents Association.

## Questions?

Contact Ruth Adebayo (ruth.adebayo@commonground.example) for access and feature inquiries.
