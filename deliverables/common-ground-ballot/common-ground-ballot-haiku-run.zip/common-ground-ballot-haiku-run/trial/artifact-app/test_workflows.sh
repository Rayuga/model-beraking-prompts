#!/bin/bash

set -e

BASE_URL="http://localhost:3000"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}=== Common Ground Ballot Testing ===${NC}\n"

# ============================================================================
# Sign in as Ruth (Coordinator)
# ============================================================================
echo -e "${BLUE}1. Sign in as Ruth (Coordinator)${NC}"
RUTH_RESPONSE=$(curl -s -X POST "$BASE_URL/api/auth/sign-in" \
  -H "Content-Type: application/json" \
  -d '{"email":"ruth.adebayo@commonground.example","password":"CommonGround!2026"}')

RUTH_SESSION=$(echo $RUTH_RESPONSE | grep -o '"sessionId":"[^"]*' | cut -d'"' -f4)
echo -e "${GREEN}✓ Ruth signed in (session: ${RUTH_SESSION:0:16}...)${NC}\n"

# ============================================================================
# Create a new ballot
# ============================================================================
echo -e "${BLUE}2. Create a new ballot (Ruth)${NC}"
CREATE_RESPONSE=$(curl -s -X POST "$BASE_URL/api/ballots" \
  -H "Content-Type: application/json" \
  -H "X-Session-Id: $RUTH_SESSION" \
  -d '{
    "title":"Test Proposal",
    "description":"A test ballot for validation",
    "method":"single",
    "max_selections":1,
    "choices":[
      {"label":"Yes"},
      {"label":"No"}
    ]
  }')

TEST_BALLOT_ID=$(echo $CREATE_RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4)
echo -e "${GREEN}✓ Created ballot: $TEST_BALLOT_ID${NC}\n"

# ============================================================================
# View the ballot
# ============================================================================
echo -e "${BLUE}3. View the ballot${NC}"
curl -s -X GET "$BASE_URL/api/ballots/$TEST_BALLOT_ID" \
  -H "X-Session-Id: $RUTH_SESSION" | grep -o '"title":"[^"]*\|"status":"[^"]*\|"revision":[^,]*' | head -3
echo -e "${GREEN}✓ Ballot retrieved${NC}\n"

# ============================================================================
# Open the ballot
# ============================================================================
echo -e "${BLUE}4. Open the ballot (capture eligible members)${NC}"
curl -s -X POST "$BASE_URL/api/ballots/$TEST_BALLOT_ID/open" \
  -H "Content-Type: application/json" \
  -H "X-Session-Id: $RUTH_SESSION" \
  -d '{"revision":1}' | grep -o '"status":"[^"]*' 
echo -e "${GREEN}✓ Ballot opened${NC}\n"

# ============================================================================
# Sign in as Leila (Member)
# ============================================================================
echo -e "${BLUE}5. Sign in as Leila (Member)${NC}"
LEILA_RESPONSE=$(curl -s -X POST "$BASE_URL/api/auth/sign-in" \
  -H "Content-Type: application/json" \
  -d '{"email":"leila.ward@commonground.example","password":"CommonGround!2026"}')

LEILA_SESSION=$(echo $LEILA_RESPONSE | grep -o '"sessionId":"[^"]*' | cut -d'"' -f4)
echo -e "${GREEN}✓ Leila signed in${NC}\n"

# ============================================================================
# Leila views eligible ballots
# ============================================================================
echo -e "${BLUE}6. Leila views available ballots${NC}"
curl -s -X GET "$BASE_URL/api/ballots" \
  -H "X-Session-Id: $LEILA_SESSION" | grep -o '"title":"[^"]*' | head -5
echo -e "${GREEN}✓ Ballots retrieved${NC}\n"

# ============================================================================
# Leila votes on the test ballot
# ============================================================================
echo -e "${BLUE}7. Leila votes on test ballot${NC}"
curl -s -X POST "$BASE_URL/api/ballots/$TEST_BALLOT_ID/vote" \
  -H "Content-Type: application/json" \
  -H "X-Session-Id: $LEILA_SESSION" \
  -d '{"choices":["choice-yes"]}' | grep -o '"error":"[^"]*\|"ok":true'

echo -e "${YELLOW}(Voting with invalid choice ID, expect error)${NC}"

# Get the valid choice ID first
CHOICES=$(curl -s -X GET "$BASE_URL/api/ballots/$TEST_BALLOT_ID/vote" \
  -H "X-Session-Id: $LEILA_SESSION")

CHOICE_ID=$(echo $CHOICES | grep -o '"id":"choice-[^"]*' | head -1 | cut -d'"' -f4)

echo -e "${BLUE}Voting with valid choice: $CHOICE_ID${NC}"
curl -s -X POST "$BASE_URL/api/ballots/$TEST_BALLOT_ID/vote" \
  -H "Content-Type: application/json" \
  -H "X-Session-Id: $LEILA_SESSION" \
  -d "{\"choices\":[\"$CHOICE_ID\"]}" | grep -o '"ok":true'
echo -e "${GREEN}✓ Leila voted${NC}\n"

# ============================================================================
# Sign in as Arun (Observer)
# ============================================================================
echo -e "${BLUE}8. Sign in as Arun (Observer)${NC}"
ARUN_RESPONSE=$(curl -s -X POST "$BASE_URL/api/auth/sign-in" \
  -H "Content-Type: application/json" \
  -d '{"email":"arun.das@commonground.example","password":"CommonGround!2026"}')

ARUN_SESSION=$(echo $ARUN_RESPONSE | grep -o '"sessionId":"[^"]*' | cut -d'"' -f4)
echo -e "${GREEN}✓ Arun signed in${NC}\n"

# ============================================================================
# Arun views turnout
# ============================================================================
echo -e "${BLUE}9. Arun views turnout${NC}"
curl -s -X GET "$BASE_URL/api/ballots/$TEST_BALLOT_ID/turnout" \
  -H "X-Session-Id: $ARUN_SESSION" | grep -o '"eligible_count":[^,]*\|"participated_count":[^,]*'
echo -e "${GREEN}✓ Turnout retrieved${NC}\n"

# ============================================================================
# Close and publish ballot
# ============================================================================
echo -e "${BLUE}10. Close and publish ballot (Ruth)${NC}"
curl -s -X POST "$BASE_URL/api/ballots/$TEST_BALLOT_ID/close" \
  -H "Content-Type: application/json" \
  -H "X-Session-Id: $RUTH_SESSION" \
  -d '{"revision":2}' | grep -o '"status":"[^"]*'
echo -e "${GREEN}✓ Ballot closed${NC}"

curl -s -X POST "$BASE_URL/api/ballots/$TEST_BALLOT_ID/publish" \
  -H "Content-Type: application/json" \
  -H "X-Session-Id: $RUTH_SESSION" \
  -d '{"revision":3}' | grep -o '"status":"[^"]*'
echo -e "${GREEN}✓ Ballot published${NC}\n"

# ============================================================================
# View results
# ============================================================================
echo -e "${BLUE}11. View published results${NC}"
RESULTS=$(curl -s -X GET "$BASE_URL/api/ballots/$TEST_BALLOT_ID/results" \
  -H "X-Session-Id: $LEILA_SESSION")

echo $RESULTS | grep -o '"votes":[^,]*\|"participant_count":[^,}]*'
echo -e "${GREEN}✓ Results retrieved${NC}\n"

# ============================================================================
# Check audit log
# ============================================================================
echo -e "${BLUE}12. Check audit log (Arun)${NC}"
AUDIT=$(curl -s -X GET "$BASE_URL/api/audit" \
  -H "X-Session-Id: $ARUN_SESSION")

echo "Recent audit entries:"
echo $AUDIT | grep -o '"action":"[^"]*' | tail -5
echo -e "${GREEN}✓ Audit log retrieved${NC}\n"

# ============================================================================
# Sign out and verify session is ended
# ============================================================================
echo -e "${BLUE}13. Sign out and verify session is ended${NC}"
curl -s -X POST "$BASE_URL/api/auth/sign-out" \
  -H "X-Session-Id: $RUTH_SESSION" | grep -o '"ok":true'
echo -e "${GREEN}✓ Ruth signed out${NC}"

# Try to use Ruth's session - should fail
RESULT=$(curl -s -X GET "$BASE_URL/api/ballots" \
  -H "X-Session-Id: $RUTH_SESSION")
if echo $RESULT | grep -q '"error"'; then
  echo -e "${GREEN}✓ Old session correctly rejected${NC}\n"
else
  echo -e "${RED}✗ Old session still active!${NC}\n"
fi

# ============================================================================
# Verify persistence - restart test
# ============================================================================
echo -e "${BLUE}14. Testing persistence after restart${NC}"
echo "Stopping server..."
pkill -f "node server.js" || true
sleep 2

echo "Restarting server..."
cd /app && node server.js > /tmp/server.log 2>&1 &
sleep 3

echo "Server restarted, checking data persistence..."

# Try with Leila's old session (should be invalid)
RESULT=$(curl -s -X GET "$BASE_URL/api/ballots" \
  -H "X-Session-Id: $LEILA_SESSION")
if echo $RESULT | grep -q '"error"'; then
  echo -e "${GREEN}✓ Session correctly cleared after restart${NC}"
fi

# Re-sign in as Leila
LEILA_RESPONSE=$(curl -s -X POST "$BASE_URL/api/auth/sign-in" \
  -H "Content-Type: application/json" \
  -d '{"email":"leila.ward@commonground.example","password":"CommonGround!2026"}')

NEW_LEILA_SESSION=$(echo $LEILA_RESPONSE | grep -o '"sessionId":"[^"]*' | cut -d'"' -f4)

# Check that test ballot still exists with published status
BALLOT=$(curl -s -X GET "$BASE_URL/api/ballots/$TEST_BALLOT_ID" \
  -H "X-Session-Id: $NEW_LEILA_SESSION")

echo $BALLOT | grep -o '"status":"[^"]*\|"title":"[^"]*'
echo -e "${GREEN}✓ Ballot data persisted${NC}\n"

# Verify vote was recorded
RESULTS=$(curl -s -X GET "$BASE_URL/api/ballots/$TEST_BALLOT_ID/results" \
  -H "X-Session-Id: $NEW_LEILA_SESSION")

echo $RESULTS | grep -o '"votes":[^,}]*'
echo -e "${GREEN}✓ Vote data persisted${NC}\n"

echo -e "${GREEN}=== All tests passed! ===${NC}"
