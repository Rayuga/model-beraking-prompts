#!/usr/bin/env python3
"""
Comprehensive test of Common Ground Ballot application.
Tests all workflows as each user role.
"""

import requests
import json
import time
import subprocess
import sys

BASE_URL = "http://localhost:3000"
PASSWORD = "CommonGround!2026"

USERS = {
    "ruth": "ruth.adebayo@commonground.example",
    "arun": "arun.das@commonground.example",
    "leila": "leila.ward@commonground.example",
    "owen": "owen.park@commonground.example",
}

sessions = {}

def log(msg, color=None):
    if color == "green":
        print(f"\033[92m✓ {msg}\033[0m")
    elif color == "blue":
        print(f"\033[94m→ {msg}\033[0m")
    elif color == "red":
        print(f"\033[91m✗ {msg}\033[0m")
        sys.exit(1)
    else:
        print(f"  {msg}")

def sign_in(user_name):
    """Sign in as a user and store session"""
    log(f"Signing in as {user_name}", "blue")
    resp = requests.post(f"{BASE_URL}/api/auth/sign-in", json={
        "email": USERS[user_name],
        "password": PASSWORD
    })
    if resp.status_code != 200:
        log(f"Failed to sign in: {resp.status_code} {resp.text}", "red")
    data = resp.json()
    sessions[user_name] = data["sessionId"]
    log(f"{user_name.capitalize()} signed in as {data['user']['name']} ({data['user']['role']})", "green")
    return data

def api_call(method, endpoint, user_name=None, data=None):
    """Make an API call"""
    headers = {}
    if user_name and user_name in sessions:
        headers["X-Session-Id"] = sessions[user_name]
    
    url = f"{BASE_URL}{endpoint}"
    if method == "GET":
        resp = requests.get(url, headers=headers)
    elif method == "POST":
        resp = requests.post(url, json=data, headers=headers)
    elif method == "PATCH":
        resp = requests.patch(url, json=data, headers=headers)
    else:
        raise ValueError(f"Unknown method: {method}")
    
    if resp.status_code >= 400:
        log(f"API error: {resp.status_code} {resp.text[:200]}", "red")
    
    return resp

def test_seeded_ballots():
    """Test that seeded ballots are present and in correct state"""
    log("Testing seeded ballots", "blue")
    
    # Ruth checks all ballots
    resp = api_call("GET", "/api/ballots", "ruth")
    ballots = resp.json()
    
    expected_ballots = {
        "ballot-draft-picnic": "draft",
        "ballot-open-courtyard": "open",
        "ballot-closed-improvements": "closed",
        "ballot-published-garden": "published"
    }
    
    ballot_map = {b["id"]: b for b in ballots}
    
    for ballot_id, status in expected_ballots.items():
        if ballot_id not in ballot_map:
            log(f"Missing ballot: {ballot_id}", "red")
        if ballot_map[ballot_id]["status"] != status:
            log(f"Wrong status for {ballot_id}: expected {status}, got {ballot_map[ballot_id]['status']}", "red")
    
    log("All seeded ballots verified", "green")

def test_ballot_lifecycle():
    """Test creating a ballot and moving it through states"""
    log("Testing ballot lifecycle", "blue")
    
    # Ruth creates a ballot
    resp = api_call("POST", "/api/ballots", "ruth", {
        "title": "Should we meet weekly?",
        "description": "Vote on weekly meeting frequency",
        "method": "single",
        "max_selections": 1,
        "choices": [
            {"label": "Yes"},
            {"label": "No"},
            {"label": "Undecided"}
        ]
    })
    
    ballot_id = resp.json()["id"]
    log(f"Created ballot: {ballot_id}", "green")
    
    # View as draft
    resp = api_call("GET", f"/api/ballots/{ballot_id}", "ruth")
    ballot = resp.json()
    if ballot["status"] != "draft":
        log(f"Wrong initial status: {ballot['status']}", "red")
    log("Ballot created as draft", "green")
    
    # Open the ballot
    resp = api_call("POST", f"/api/ballots/{ballot_id}/open", "ruth", {
        "revision": ballot["revision"]
    })
    ballot = resp.json()
    if ballot["status"] != "open":
        log(f"Failed to open ballot, status: {ballot['status']}", "red")
    log("Ballot opened (captured eligibility)", "green")
    
    return ballot_id

def test_member_voting(ballot_id):
    """Test members voting on an open ballot"""
    log("Testing member voting", "blue")
    
    # Leila views the ballot
    resp = api_call("GET", f"/api/ballots/{ballot_id}/vote", "leila")
    ballot = resp.json()
    log(f"Leila can see ballot: {ballot['title']}", "green")
    
    # Get a valid choice ID
    choice_id = ballot["choices"][0]["id"]
    
    # Leila votes
    resp = api_call("POST", f"/api/ballots/{ballot_id}/vote", "leila", {
        "choices": [choice_id]
    })
    if resp.status_code != 200:
        log(f"Failed to vote: {resp.status_code}", "red")
    log("Leila voted successfully", "green")
    
    # Try to vote again - should fail
    resp = api_call("POST", f"/api/ballots/{ballot_id}/vote", "leila", {
        "choices": [choice_id]
    })
    if resp.status_code == 200:
        log("Leila was able to vote twice! Security issue!", "red")
    log("Correctly prevented double voting", "green")
    
    return ballot_id

def test_turnout_view(ballot_id):
    """Test viewing turnout as observer"""
    log("Testing turnout view", "blue")
    
    resp = api_call("GET", f"/api/ballots/{ballot_id}/turnout", "arun")
    turnout = resp.json()
    
    if turnout["participated_count"] < 1:
        log(f"No participation recorded: {turnout['participated_count']}", "red")
    
    log(f"Turnout: {turnout['participated_count']}/{turnout['eligible_count']} participated", "green")
    
    # Member should not be able to view turnout
    resp = api_call("GET", f"/api/ballots/{ballot_id}/turnout", "leila")
    if resp.status_code == 200:
        log("Members can view turnout! Security issue!", "red")
    log("Correctly restricted turnout from members", "green")

def test_results(ballot_id):
    """Test viewing results after publication"""
    log("Testing results", "blue")
    
    # Ruth closes the ballot
    resp = api_call("GET", f"/api/ballots/{ballot_id}", "ruth")
    ballot = resp.json()
    
    resp = api_call("POST", f"/api/ballots/{ballot_id}/close", "ruth", {
        "revision": ballot["revision"]
    })
    log("Ballot closed", "green")
    ballot = resp.json()
    
    # Publish it
    resp = api_call("POST", f"/api/ballots/{ballot_id}/publish", "ruth", {
        "revision": ballot["revision"]
    })
    log("Ballot published", "green")
    
    # Now anyone can view results
    resp = api_call("GET", f"/api/ballots/{ballot_id}/results", "leila")
    results = resp.json()
    
    if "results" not in results:
        log("No results returned", "red")
    
    log(f"Results show {results['participant_count']} participants", "green")

def test_member_management():
    """Test member activation/deactivation"""
    log("Testing member management", "blue")
    
    resp = api_call("GET", "/api/members", "ruth")
    members = resp.json()
    
    # Owen should be inactive
    owen = next((m for m in members if "owen" in m["name"].lower()), None)
    if not owen:
        log("Could not find Owen", "red")
    
    if owen["active"]:
        log("Owen should be inactive", "red")
    log("Owen is correctly inactive", "green")
    
    # Ruth activates Owen
    resp = api_call("PATCH", f"/api/members/{owen['id']}", "ruth", {
        "active": True
    })
    log("Ruth activated Owen", "green")
    
    # Deactivate
    resp = api_call("PATCH", f"/api/members/{owen['id']}", "ruth", {
        "active": False
    })
    log("Ruth deactivated Owen", "green")
    
    # Members shouldn't be able to view members list
    resp = api_call("GET", "/api/members", "leila")
    if resp.status_code == 200:
        log("Members can view member list! Security issue!", "red")
    log("Correctly restricted members list from members", "green")

def test_audit_log():
    """Test audit logging"""
    log("Testing audit log", "blue")
    
    resp = api_call("GET", "/api/audit", "arun")
    logs = resp.json()
    
    if len(logs) < 1:
        log("No audit entries", "red")
    
    # Check for expected actions
    actions = {log["action"] for log in logs}
    if "create" not in actions and "open" not in actions:
        log("Missing expected audit actions", "red")
    
    log(f"Found {len(logs)} audit entries with actions: {actions}", "green")
    
    # Members shouldn't see audit
    resp = api_call("GET", "/api/audit", "leila")
    if resp.status_code == 200:
        log("Members can view audit log! Security issue!", "red")
    log("Correctly restricted audit from members", "green")

def test_session_management():
    """Test session ending"""
    log("Testing session management", "blue")
    
    # Create a new session for Owen
    sign_in("owen")
    old_session = sessions["owen"]
    
    # Use it to verify it works
    resp = api_call("GET", "/api/ballots", "owen")
    if resp.status_code != 200:
        log("New session doesn't work", "red")
    log("New session works", "green")
    
    # End all sessions for Owen
    resp = api_call("POST", "/api/auth/sign-all-sessions-out", "owen")
    # This isn't a real endpoint yet, just test sign-out
    
    resp = api_call("POST", "/api/auth/sign-out", "owen")
    if resp.status_code != 200:
        log(f"Failed to sign out: {resp.status_code}", "red")
    log("Session signed out", "green")
    
    # Try to use old session - should fail
    headers = {"X-Session-Id": old_session}
    resp = requests.get(f"{BASE_URL}/api/ballots", headers=headers)
    if resp.status_code == 200:
        log("Signed-out session still works! Security issue!", "red")
    log("Correctly rejected signed-out session", "green")

def test_persistence():
    """Test that data persists after restart"""
    log("Testing data persistence", "blue")
    
    # Create a ballot and vote
    resp = api_call("POST", "/api/ballots", "ruth", {
        "title": "Persistence test",
        "description": "Test that data survives restart",
        "method": "approval",
        "max_selections": 2,
        "choices": [
            {"label": "Option A"},
            {"label": "Option B"},
            {"label": "Option C"}
        ]
    })
    persist_ballot_id = resp.json()["id"]
    log(f"Created test ballot: {persist_ballot_id}", "green")
    
    # Open it
    resp = api_call("GET", f"/api/ballots/{persist_ballot_id}", "ruth")
    ballot = resp.json()
    
    resp = api_call("POST", f"/api/ballots/{persist_ballot_id}/open", "ruth", {
        "revision": ballot["revision"]
    })
    
    # Leila votes
    resp = api_call("GET", f"/api/ballots/{persist_ballot_id}/vote", "leila")
    ballot = resp.json()
    choice_ids = [ballot["choices"][0]["id"], ballot["choices"][1]["id"]]
    
    resp = api_call("POST", f"/api/ballots/{persist_ballot_id}/vote", "leila", {
        "choices": choice_ids
    })
    log("Voted on test ballot", "green")
    
    # Restart the server
    log("Restarting server...", "blue")
    subprocess.run(["pkill", "-f", "node server.js"], capture_output=True)
    time.sleep(2)
    subprocess.Popen(
        ["node", "server.js"],
        cwd="/app",
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    time.sleep(3)
    
    # Re-sign in
    sign_in("ruth")
    
    # Check that ballot still exists
    resp = api_call("GET", f"/api/ballots/{persist_ballot_id}", "ruth")
    ballot = resp.json()
    if ballot["status"] != "open":
        log(f"Ballot state not preserved: {ballot['status']}", "red")
    log("Ballot state persisted", "green")
    
    # Check that vote was recorded (by checking participant count when closed/published)
    resp = api_call("GET", f"/api/ballots/{persist_ballot_id}", "ruth")
    ballot = resp.json()
    
    resp = api_call("POST", f"/api/ballots/{persist_ballot_id}/close", "ruth", {
        "revision": ballot["revision"]
    })
    ballot = resp.json()
    
    resp = api_call("POST", f"/api/ballots/{persist_ballot_id}/publish", "ruth", {
        "revision": ballot["revision"]
    })
    
    # Check results
    resp = api_call("GET", f"/api/ballots/{persist_ballot_id}/results", "ruth")
    results = resp.json()
    
    if results["participant_count"] != 1:
        log(f"Vote not persisted: {results['participant_count']} participants", "red")
    log("Votes persisted across restart", "green")

def main():
    print("\n\033[94m╔════════════════════════════════════════╗\033[0m")
    print("\033[94m║  Common Ground Ballot - Full Test Suite║\033[0m")
    print("\033[94m╚════════════════════════════════════════╝\033[0m\n")
    
    try:
        # Sign in all users
        for user in ["ruth", "arun", "leila"]:
            sign_in(user)
        
        print()
        test_seeded_ballots()
        
        print()
        ballot_id = test_ballot_lifecycle()
        
        print()
        test_member_voting(ballot_id)
        
        print()
        test_turnout_view(ballot_id)
        
        print()
        test_results(ballot_id)
        
        print()
        test_member_management()
        
        print()
        test_audit_log()
        
        print()
        test_session_management()
        
        print()
        test_persistence()
        
        print("\n\033[92m╔════════════════════════════════════════╗\033[0m")
        print("\033[92m║    ✓ All tests passed!                 ║\033[0m")
        print("\033[92m╚════════════════════════════════════════╝\033[0m\n")
        
    except Exception as e:
        log(f"Test error: {e}", "red")

if __name__ == "__main__":
    main()
