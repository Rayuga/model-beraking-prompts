// ============================================================================
// STATE
// ============================================================================

let state = {
  sessionId: localStorage.getItem('sessionId'),
  user: null,
  currentView: 'ballots',
};

// ============================================================================
// API HELPERS
// ============================================================================

async function apiCall(endpoint, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.sessionId) {
    headers['X-Session-Id'] = state.sessionId;
  }

  const response = await fetch(endpoint, { ...options, headers: { ...headers, ...options.headers } });
  const data = await response.json();

  if (!response.ok) {
    throw { status: response.status, error: data.error };
  }

  return data;
}

// ============================================================================
// AUTHENTICATION
// ============================================================================

async function signIn(email, password) {
  try {
    const result = await apiCall('/api/auth/sign-in', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    state.sessionId = result.sessionId;
    state.user = result.user;
    localStorage.setItem('sessionId', state.sessionId);
    return true;
  } catch (err) {
    return false;
  }
}

async function signOut() {
  try {
    await apiCall('/api/auth/sign-out', { method: 'POST' });
  } catch (err) {
    console.error('Sign out error:', err);
  }
  state.sessionId = null;
  state.user = null;
  localStorage.removeItem('sessionId');
}

async function endAllSessions() {
  try {
    await apiCall('/api/auth/end-all-sessions', { method: 'POST' });
    await signOut();
  } catch (err) {
    console.error('End all sessions error:', err);
  }
}

// ============================================================================
// UI HELPERS
// ============================================================================

function showError(message) {
  const errorEl = document.querySelector('#view-error');
  errorEl.textContent = message;
  errorEl.classList.remove('hidden');
}

function clearError() {
  const errorEl = document.querySelector('#view-error');
  errorEl.textContent = '';
  errorEl.classList.add('hidden');
}

function showMessage(message) {
  const msgEl = document.querySelector('#view-message');
  msgEl.textContent = message;
}

function clearMessage() {
  const msgEl = document.querySelector('#view-message');
  msgEl.textContent = '';
}

function formatDate(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp * 1000);
  return date.toLocaleString();
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ============================================================================
// RENDER FUNCTIONS
// ============================================================================

function renderBallotsView(ballots) {
  const roleHierarchy = { member: 1, observer: 2, coordinator: 3 };
  const canCreate = roleHierarchy[state.user.role] >= roleHierarchy.coordinator;

  let html = '';

  if (canCreate) {
    html += `
      <button onclick="showCreateBallotForm()">Create new ballot</button>
    `;
  }

  if (ballots.length === 0) {
    html += '<p>No ballots available.</p>';
  } else {
    html += '<div class="ballot-list">';
    for (const ballot of ballots) {
      const statusClass = `status-${ballot.status}`;
      html += `
        <div class="ballot-card">
          <h2>${escapeHtml(ballot.title)}</h2>
          <div class="ballot-meta">
            <span class="status-badge ${statusClass}">${ballot.status}</span>
            ${ballot.has_voted ? '<span style="font-size: 0.85rem;">✓ You have voted</span>' : ''}
            ${ballot.method === 'approval' ? `<span>Up to ${ballot.max_selections} choices</span>` : ''}
            <span>${ballot.eligible_count} eligible</span>
          </div>
          ${ballot.description ? `<p>${escapeHtml(ballot.description)}</p>` : ''}
          <div class="ballot-actions">
            <button onclick="viewBallot('${ballot.id}')">View</button>
            ${state.user.role === 'coordinator' && ballot.status === 'draft' ? `<button onclick="editBallot('${ballot.id}')">Edit</button>` : ''}
          </div>
        </div>
      `;
    }
    html += '</div>';
  }

  document.querySelector('#view-content').innerHTML = html;
}

function renderVoteView(ballots) {
  const openBallots = ballots.filter(b => b.status === 'open');

  let html = '';

  if (openBallots.length === 0) {
    html += '<p>No open ballots available for voting.</p>';
  } else {
    html += '<div class="ballot-list">';
    for (const ballot of openBallots) {
      const votedIndicator = ballot.has_voted ? '✓ Voted' : 'Ready to vote';
      html += `
        <div class="ballot-card">
          <h2>${escapeHtml(ballot.title)}</h2>
          <div class="ballot-meta">
            <span>${votedIndicator}</span>
            ${ballot.method === 'approval' ? `<span>Select up to ${ballot.max_selections}</span>` : ''}
          </div>
          ${ballot.description ? `<p>${escapeHtml(ballot.description)}</p>` : ''}
          <button onclick="openVoteForm('${ballot.id}')" ${ballot.has_voted ? 'disabled' : ''}>
            ${ballot.has_voted ? 'Already voted' : 'Vote'}
          </button>
        </div>
      `;
    }
    html += '</div>';
  }

  document.querySelector('#view-content').innerHTML = html;
}

async function renderTurnoutView() {
  try {
    const ballots = await apiCall('/api/ballots');

    let html = '<div class="ballot-list">';

    for (const ballot of ballots) {
      if (ballot.status === 'draft') continue;

      try {
        const turnout = await apiCall(`/api/ballots/${ballot.id}/turnout`);
        const percentage = turnout.eligible_count > 0 ? Math.round((turnout.participated_count / turnout.eligible_count) * 100) : 0;

        html += `
          <div class="ballot-card">
            <h2>${escapeHtml(turnout.title)}</h2>
            <div class="ballot-meta">
              <span class="status-badge status-${turnout.status}">${turnout.status}</span>
              <span>${turnout.participated_count}/${turnout.eligible_count} participated (${percentage}%)</span>
            </div>
            <details>
              <summary>Show roster</summary>
              <div style="margin-top: 1rem; font-size: 0.9rem;">
                ${turnout.roster.map(m => `
                  <div style="padding: 0.5rem 0; border-bottom: 1px solid #82928855;">
                    <span>${m.has_voted ? '✓' : '·'}</span> ${escapeHtml(m.name)}
                  </div>
                `).join('')}
              </div>
            </details>
          </div>
        `;
      } catch (err) {
        // Ballot may not be accessible to this user
      }
    }

    html += '</div>';
    document.querySelector('#view-content').innerHTML = html;
  } catch (err) {
    showError('Failed to load turnout data');
  }
}

async function renderResultsView() {
  try {
    const ballots = await apiCall('/api/ballots');

    let html = '<div class="ballot-list">';

    for (const ballot of ballots) {
      if (ballot.status === 'draft' || ballot.status === 'open') continue;

      try {
        const results = await apiCall(`/api/ballots/${ballot.id}/results`);

        let resultsHtml = '';

        if (results.is_tie) {
          resultsHtml += `
            <div class="tie-notice">
              <strong>Tied vote:</strong> ${results.leaders.join(' and ')}
            </div>
          `;
        }

        resultsHtml += '<div style="display: grid; gap: 1rem;">';
        for (const result of results.results) {
          const percentage = result.percentage;
          const width = ballot.method === 'single' ? Math.round((result.votes / results.participant_count) * 100) : Math.round((result.votes / results.participant_count) * 100);
          resultsHtml += `
            <div class="result-item">
              <h3>${escapeHtml(result.label)}</h3>
              <div style="font-size: 0.9rem; margin-bottom: 0.5rem;">
                ${result.votes} ${result.votes === 1 ? 'vote' : 'votes'} (${percentage}%)
              </div>
              <div style="background: color-mix(in srgb, currentColor 10%, transparent); border-radius: 0.3rem; overflow: hidden; height: 1.5rem;">
                <div class="result-bar" style="width: ${width}%; min-width: 2px;">
                  ${width > 15 ? percentage + '%' : ''}
                </div>
              </div>
            </div>
          `;
        }
        resultsHtml += '</div>';

        html += `
          <div class="ballot-card">
            <h2>${escapeHtml(results.title)}</h2>
            <div class="ballot-meta">
              <span class="status-badge status-${results.status}">${results.status}</span>
              <span>${results.participant_count} ${results.participant_count === 1 ? 'participant' : 'participants'}</span>
            </div>
            ${resultsHtml}
          </div>
        `;
      } catch (err) {
        // May not be accessible
      }
    }

    html += '</div>';
    document.querySelector('#view-content').innerHTML = html;
  } catch (err) {
    showError('Failed to load results');
  }
}

async function renderMembersView() {
  try {
    const members = await apiCall('/api/members');

    let html = '<div class="member-list">';

    for (const member of members) {
      const status = member.active ? 'Active' : 'Inactive';
      const statusClass = member.active ? 'status-open' : 'status-closed';

      html += `
        <div class="member-card">
          <div style="display: flex; justify-content: space-between; align-items: start; gap: 1rem;">
            <div>
              <h3 style="margin: 0 0 0.25rem 0;">${escapeHtml(member.name)}</h3>
              <p style="margin: 0; font-size: 0.85rem; opacity: 0.75;">${escapeHtml(member.email)}</p>
            </div>
            <span class="status-badge ${statusClass}">${status}</span>
          </div>
          ${state.user.role === 'coordinator' ? `
            <button class="secondary" onclick="toggleMemberStatus('${member.id}', ${member.active ? 'false' : 'true'})" style="margin-top: 1rem; width: 100%;">
              ${member.active ? 'Deactivate' : 'Activate'}
            </button>
          ` : ''}
        </div>
      `;
    }

    html += '</div>';
    document.querySelector('#view-content').innerHTML = html;
  } catch (err) {
    showError('Failed to load members');
  }
}

async function renderAuditView() {
  try {
    const logs = await apiCall('/api/audit');

    let html = '';

    if (logs.length === 0) {
      html = '<p>No audit entries yet.</p>';
    } else {
      html = '<div class="audit-list">';
      for (const log of logs) {
        html += `
          <div class="audit-entry">
            <div style="font-weight: 600; font-size: 0.95rem;">${escapeHtml(log.action)}</div>
            <div style="font-size: 0.85rem; opacity: 0.75;">
              ${escapeHtml(log.name)} · ${log.resource_type} ${escapeHtml(log.resource_id)}
            </div>
            <div style="font-size: 0.8rem; opacity: 0.6; margin-top: 0.5rem;">
              ${formatDate(log.created_at)}
            </div>
          </div>
        `;
      }
      html += '</div>';
    }

    document.querySelector('#view-content').innerHTML = html;
  } catch (err) {
    showError('Failed to load audit log');
  }
}

// ============================================================================
// BALLOT MANAGEMENT
// ============================================================================

function showCreateBallotForm() {
  const html = `
    <div style="max-width: 32rem;">
      <h2>Create new ballot</h2>
      <form id="create-ballot-form" style="display: grid; gap: 1rem;">
        <div>
          <label for="ballot-title">Title</label>
          <input id="ballot-title" type="text" required />
        </div>
        <div>
          <label for="ballot-description">Description (optional)</label>
          <textarea id="ballot-description" rows="3"></textarea>
        </div>
        <div>
          <label for="ballot-method">Voting method</label>
          <select id="ballot-method" required onchange="updateBallotMethodUI()">
            <option value="single">Single choice</option>
            <option value="approval">Approval (multiple choices)</option>
          </select>
        </div>
        <div id="max-selections-container" style="display: none;">
          <label for="ballot-max-selections">Maximum selections</label>
          <input id="ballot-max-selections" type="number" min="1" />
        </div>
        <div>
          <label>Choices</label>
          <div id="choices-container" class="choices-list">
            <div class="choice-input-row">
              <input type="text" class="choice-input" placeholder="Choice 1" />
              <button type="button" onclick="addChoiceInput()">+</button>
            </div>
            <div class="choice-input-row">
              <input type="text" class="choice-input" placeholder="Choice 2" />
              <button type="button" onclick="removeChoiceInput(this)">−</button>
            </div>
          </div>
        </div>
        <div class="form-actions">
          <button type="submit">Create</button>
          <button type="button" class="secondary" onclick="clearCreateBallotForm()">Cancel</button>
        </div>
      </form>
      <div id="create-ballot-error" class="error hidden"></div>
    </div>
  `;

  document.querySelector('#view-content').innerHTML = html;

  document.querySelector('#create-ballot-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = document.querySelector('#create-ballot-error');

    const title = document.querySelector('#ballot-title').value.trim();
    const description = document.querySelector('#ballot-description').value.trim();
    const method = document.querySelector('#ballot-method').value;

    const choiceInputs = document.querySelectorAll('.choice-input');
    const choices = [];
    for (const input of choiceInputs) {
      const label = input.value.trim();
      if (label) choices.push({ label });
    }

    if (!title || choices.length < 2) {
      errorEl.textContent = 'Title and at least two choices are required';
      errorEl.classList.remove('hidden');
      return;
    }

    let max_selections = 1;
    if (method === 'approval') {
      max_selections = parseInt(document.querySelector('#ballot-max-selections').value);
      if (!max_selections || max_selections < 1 || max_selections > choices.length) {
        errorEl.textContent = 'Invalid max selections';
        errorEl.classList.remove('hidden');
        return;
      }
    }

    try {
      await apiCall('/api/ballots', {
        method: 'POST',
        body: JSON.stringify({ title, description, method, max_selections, choices }),
      });

      showMessage('Ballot created successfully');
      clearError();
      setTimeout(() => loadView('ballots'), 1000);
    } catch (err) {
      errorEl.textContent = err.error || 'Failed to create ballot';
      errorEl.classList.remove('hidden');
    }
  });
}

function updateBallotMethodUI() {
  const method = document.querySelector('#ballot-method').value;
  const container = document.querySelector('#max-selections-container');
  const input = document.querySelector('#ballot-max-selections');

  if (method === 'approval') {
    container.style.display = 'block';
    const choiceCount = document.querySelectorAll('.choice-input').length;
    input.max = choiceCount;
    input.value = Math.min(2, choiceCount);
  } else {
    container.style.display = 'none';
  }
}

function addChoiceInput() {
  const container = document.querySelector('#choices-container');
  const count = container.querySelectorAll('.choice-input').length + 1;

  const row = document.createElement('div');
  row.className = 'choice-input-row';
  row.innerHTML = `
    <input type="text" class="choice-input" placeholder="Choice ${count}" />
    <button type="button" onclick="removeChoiceInput(this)">−</button>
  `;

  container.appendChild(row);
  updateBallotMethodUI();
}

function removeChoiceInput(button) {
  const container = document.querySelector('#choices-container');
  if (container.querySelectorAll('.choice-input-row').length > 2) {
    button.closest('.choice-input-row').remove();
    updateBallotMethodUI();
  }
}

function clearCreateBallotForm() {
  loadView('ballots');
}

async function viewBallot(ballotId) {
  try {
    const ballot = await apiCall(`/api/ballots/${ballotId}`);

    let html = `
      <div style="max-width: 48rem;">
        <h2>${escapeHtml(ballot.title)}</h2>
        <div class="ballot-meta">
          <span class="status-badge status-${ballot.status}">${ballot.status}</span>
          <span>Revision ${ballot.revision}</span>
          ${ballot.method === 'approval' ? `<span>Up to ${ballot.max_selections} choices</span>` : ''}
        </div>
        ${ballot.description ? `<p>${escapeHtml(ballot.description)}</p>` : ''}
        <div style="margin: 1.5rem 0;">
          <h3>Choices:</h3>
          <ul style="margin: 0.5rem 0; padding-left: 1.5rem;">
            ${ballot.choices.map(c => `<li>${escapeHtml(c.label)}</li>`).join('')}
          </ul>
        </div>
        <div class="ballot-actions">
          <button onclick="loadView('ballots')" class="secondary">Back</button>
          ${state.user.role === 'coordinator' ? `
            ${ballot.status === 'draft' ? `<button onclick="editBallot('${ballotId}')">Edit</button>` : ''}
            ${ballot.status === 'draft' ? `<button onclick="openBallot('${ballotId}', ${ballot.revision})">Open</button>` : ''}
            ${ballot.status === 'open' ? `<button onclick="closeBallot('${ballotId}', ${ballot.revision})">Close</button>` : ''}
            ${ballot.status === 'closed' ? `<button onclick="publishBallot('${ballotId}', ${ballot.revision})">Publish</button>` : ''}
          ` : ''}
        </div>
      </div>
    `;

    document.querySelector('#view-content').innerHTML = html;
  } catch (err) {
    showError(err.error || 'Failed to load ballot');
  }
}

async function editBallot(ballotId) {
  try {
    const ballot = await apiCall(`/api/ballots/${ballotId}`);

    let html = `
      <div style="max-width: 32rem;">
        <h2>Edit ballot</h2>
        <form id="edit-ballot-form" style="display: grid; gap: 1rem;">
          <div>
            <label for="edit-ballot-title">Title</label>
            <input id="edit-ballot-title" type="text" value="${escapeHtml(ballot.title)}" required />
          </div>
          <div>
            <label for="edit-ballot-description">Description</label>
            <textarea id="edit-ballot-description" rows="3">${escapeHtml(ballot.description || '')}</textarea>
          </div>
          <div>
            <label for="edit-ballot-method">Voting method</label>
            <select id="edit-ballot-method" required onchange="updateEditBallotMethodUI()">
              <option value="single" ${ballot.method === 'single' ? 'selected' : ''}>Single choice</option>
              <option value="approval" ${ballot.method === 'approval' ? 'selected' : ''}>Approval (multiple choices)</option>
            </select>
          </div>
          <div id="edit-max-selections-container" ${ballot.method === 'approval' ? '' : 'style="display: none;"'}>
            <label for="edit-ballot-max-selections">Maximum selections</label>
            <input id="edit-ballot-max-selections" type="number" min="1" value="${ballot.max_selections}" />
          </div>
          <div>
            <label>Choices</label>
            <div id="edit-choices-container" class="choices-list">
              ${ballot.choices.map((c, i) => `
                <div class="choice-input-row">
                  <input type="text" class="choice-input" value="${escapeHtml(c.label)}" />
                  <button type="button" onclick="removeEditChoiceInput(this)" ${ballot.choices.length === 2 ? 'disabled' : ''}>−</button>
                </div>
              `).join('')}
            </div>
            <button type="button" onclick="addEditChoiceInput()">Add choice</button>
          </div>
          <div class="form-actions">
            <button type="submit">Save</button>
            <button type="button" class="secondary" onclick="viewBallot('${ballotId}')">Cancel</button>
          </div>
        </form>
        <div id="edit-ballot-error" class="error hidden"></div>
      </div>
    `;

    document.querySelector('#view-content').innerHTML = html;

    document.querySelector('#edit-ballot-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const errorEl = document.querySelector('#edit-ballot-error');

      const title = document.querySelector('#edit-ballot-title').value.trim();
      const description = document.querySelector('#edit-ballot-description').value.trim();
      const method = document.querySelector('#edit-ballot-method').value;

      const choiceInputs = document.querySelectorAll('#edit-choices-container .choice-input');
      const choices = [];
      for (const input of choiceInputs) {
        const label = input.value.trim();
        if (label) choices.push({ label });
      }

      if (!title || choices.length < 2) {
        errorEl.textContent = 'Title and at least two choices are required';
        errorEl.classList.remove('hidden');
        return;
      }

      let max_selections = 1;
      if (method === 'approval') {
        max_selections = parseInt(document.querySelector('#edit-ballot-max-selections').value);
        if (!max_selections || max_selections < 1 || max_selections > choices.length) {
          errorEl.textContent = 'Invalid max selections';
          errorEl.classList.remove('hidden');
          return;
        }
      }

      try {
        await apiCall(`/api/ballots/${ballotId}`, {
          method: 'PATCH',
          body: JSON.stringify({ title, description, method, max_selections, choices, revision: ballot.revision }),
        });

        showMessage('Ballot updated successfully');
        setTimeout(() => viewBallot(ballotId), 500);
      } catch (err) {
        errorEl.textContent = err.error || 'Failed to update ballot';
        errorEl.classList.remove('hidden');
      }
    });
  } catch (err) {
    showError(err.error || 'Failed to load ballot for editing');
  }
}

function updateEditBallotMethodUI() {
  const method = document.querySelector('#edit-ballot-method').value;
  const container = document.querySelector('#edit-max-selections-container');
  const input = document.querySelector('#edit-ballot-max-selections');

  if (method === 'approval') {
    container.style.display = 'block';
    const choiceCount = document.querySelectorAll('#edit-choices-container .choice-input').length;
    input.max = choiceCount;
  } else {
    container.style.display = 'none';
  }
}

function addEditChoiceInput() {
  const container = document.querySelector('#edit-choices-container');
  const count = container.querySelectorAll('.choice-input').length + 1;

  const row = document.createElement('div');
  row.className = 'choice-input-row';
  row.innerHTML = `
    <input type="text" class="choice-input" placeholder="Choice ${count}" />
    <button type="button" onclick="removeEditChoiceInput(this)">−</button>
  `;

  container.appendChild(row);
  updateEditBallotMethodUI();
}

function removeEditChoiceInput(button) {
  const container = document.querySelector('#edit-choices-container');
  if (container.querySelectorAll('.choice-input-row').length > 2) {
    button.closest('.choice-input-row').remove();
    updateEditBallotMethodUI();
  }
}

async function openBallot(ballotId, revision) {
  try {
    await apiCall(`/api/ballots/${ballotId}/open`, {
      method: 'POST',
      body: JSON.stringify({ revision }),
    });
    showMessage('Ballot opened');
    setTimeout(() => viewBallot(ballotId), 500);
  } catch (err) {
    showError(err.error || 'Failed to open ballot');
  }
}

async function closeBallot(ballotId, revision) {
  try {
    await apiCall(`/api/ballots/${ballotId}/close`, {
      method: 'POST',
      body: JSON.stringify({ revision }),
    });
    showMessage('Ballot closed');
    setTimeout(() => viewBallot(ballotId), 500);
  } catch (err) {
    showError(err.error || 'Failed to close ballot');
  }
}

async function publishBallot(ballotId, revision) {
  try {
    await apiCall(`/api/ballots/${ballotId}/publish`, {
      method: 'POST',
      body: JSON.stringify({ revision }),
    });
    showMessage('Ballot published');
    setTimeout(() => viewBallot(ballotId), 500);
  } catch (err) {
    showError(err.error || 'Failed to publish ballot');
  }
}

// ============================================================================
// VOTING
// ============================================================================

async function openVoteForm(ballotId) {
  try {
    clearError();
    const ballot = await apiCall(`/api/ballots/${ballotId}/vote`);

    let html = `
      <div style="max-width: 32rem;">
        <h2>${escapeHtml(ballot.title)}</h2>
        ${ballot.description ? `<p>${escapeHtml(ballot.description)}</p>` : ''}

        <div style="background: #fff3cd; color: #856404; padding: 1rem; border-radius: 0.6rem; margin: 1.5rem 0;">
          <strong>Privacy notice:</strong> Your choice will be kept confidential. Only participation records are retained.
        </div>

        <form id="vote-form" style="display: grid; gap: 1rem;">
          <fieldset style="border: none; padding: 0; margin: 0;">
            <legend style="font-weight: 600; margin-bottom: 1rem;">
              ${ballot.method === 'single' ? 'Select one' : `Select up to ${ballot.max_selections}`}
            </legend>
            <div style="display: grid; gap: 0.75rem;">
              ${ballot.choices.map((choice, i) => {
        const inputType = ballot.method === 'single' ? 'radio' : 'checkbox';
        const groupName = ballot.method === 'single' ? `vote-${ballotId}` : `vote-${ballotId}-${i}`;

        return `
                <label class="vote-choice">
                  <input type="${inputType}" name="${groupName}" value="${choice.id}" ${ballot.method === 'single' ? 'required' : ''} />
                  <span>${escapeHtml(choice.label)}</span>
                </label>
              `;
      }).join('')}
            </div>
          </fieldset>
          <div class="form-actions">
            <button type="submit">Submit vote</button>
            <button type="button" class="secondary" onclick="loadView('vote')">Cancel</button>
          </div>
        </form>
        <div id="vote-error" class="error hidden"></div>
      </div>
    `;

    document.querySelector('#view-content').innerHTML = html;

    document.querySelector('#vote-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const errorEl = document.querySelector('#vote-error');

      const choices = ballot.method === 'single'
        ? [document.querySelector(`input[name="vote-${ballotId}"]:checked`).value]
        : Array.from(document.querySelectorAll(`input[type="checkbox"][name^="vote-${ballotId}"]:checked`)).map(el => el.value);

      if (choices.length === 0) {
        errorEl.textContent = 'Please select at least one choice';
        errorEl.classList.remove('hidden');
        return;
      }

      try {
        await apiCall(`/api/ballots/${ballotId}/vote`, {
          method: 'POST',
          body: JSON.stringify({ choices }),
        });

        showMessage('Vote recorded successfully');
        setTimeout(() => loadView('vote'), 1000);
      } catch (err) {
        errorEl.textContent = err.error || 'Failed to record vote';
        errorEl.classList.remove('hidden');
      }
    });
  } catch (err) {
    showError(err.error || 'Failed to load ballot');
  }
}

// ============================================================================
// MEMBERS
// ============================================================================

async function toggleMemberStatus(memberId, active) {
  try {
    await apiCall(`/api/members/${memberId}`, {
      method: 'PATCH',
      body: JSON.stringify({ active }),
    });

    showMessage(active ? 'Member activated' : 'Member deactivated');
    setTimeout(() => renderMembersView(), 500);
  } catch (err) {
    showError(err.error || 'Failed to update member');
  }
}

// ============================================================================
// VIEW MANAGEMENT
// ============================================================================

async function loadView(viewName) {
  state.currentView = viewName;
  clearError();
  clearMessage();

  document.querySelectorAll('nav button').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === viewName);
  });

  document.querySelector('#view-title').textContent = document.querySelector(`[data-view="${viewName}"]`).textContent;
  document.querySelector('#view-content').innerHTML = '';

  try {
    if (viewName === 'ballots') {
      const ballots = await apiCall('/api/ballots');
      renderBallotsView(ballots);
    } else if (viewName === 'vote') {
      const ballots = await apiCall('/api/ballots');
      renderVoteView(ballots);
    } else if (viewName === 'turnout') {
      await renderTurnoutView();
    } else if (viewName === 'results') {
      await renderResultsView();
    } else if (viewName === 'members') {
      await renderMembersView();
    } else if (viewName === 'audit') {
      await renderAuditView();
    }
  } catch (err) {
    showError(err.error || 'Failed to load view');
  }
}

// ============================================================================
// THEME
// ============================================================================

function toggleTheme() {
  const root = document.documentElement;
  const newTheme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  root.dataset.theme = newTheme;
  localStorage.setItem('theme', newTheme);
  document.querySelector('#theme').textContent = newTheme === 'dark' ? '☀️' : '🌙';
}

// ============================================================================
// INITIALIZATION
// ============================================================================

async function initApp() {
  const themeButton = document.querySelector('#theme');
  const savedTheme = localStorage.getItem('theme');
  const theme = savedTheme || 'light';
  document.documentElement.dataset.theme = theme;
  themeButton.textContent = theme === 'dark' ? '☀️' : '🌙';
  themeButton.addEventListener('click', toggleTheme);

  if (!state.sessionId) {
    document.querySelector('#sign-in').classList.remove('hidden');
    document.querySelector('#workspace').classList.add('hidden');
    setupLoginForm();
  } else {
    try {
      const userCheckResponse = await fetch('/api/ballots', {
        headers: { 'X-Session-Id': state.sessionId },
      });

      if (userCheckResponse.ok) {
        // Re-fetch user info by attempting a call
        try {
          const ballots = await apiCall('/api/ballots');
          // Session is still valid
          document.querySelector('#sign-in').classList.add('hidden');
          document.querySelector('#workspace').classList.remove('hidden');
          setupWorkspace();
        } catch {
          // Session expired
          state.sessionId = null;
          localStorage.removeItem('sessionId');
          location.reload();
        }
      } else {
        // Session invalid
        state.sessionId = null;
        localStorage.removeItem('sessionId');
        location.reload();
      }
    } catch {
      // Network error - show login
      state.sessionId = null;
      localStorage.removeItem('sessionId');
      location.reload();
    }
  }
}

function setupLoginForm() {
  const demoButtons = document.querySelectorAll('[data-email]');
  demoButtons.forEach(button => {
    button.addEventListener('click', () => {
      document.querySelector('#email').value = button.dataset.email;
      document.querySelector('#password').value = 'CommonGround!2026';
    });
  });

  document.querySelector('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = document.querySelector('#login-error');
    errorEl.textContent = '';

    const email = document.querySelector('#email').value;
    const password = document.querySelector('#password').value;

    if (await signIn(email, password)) {
      document.querySelector('#sign-in').classList.add('hidden');
      document.querySelector('#workspace').classList.remove('hidden');
      setupWorkspace();
    } else {
      errorEl.textContent = 'Invalid email or password';
      errorEl.classList.remove('hidden');
    }
  });
}

function setupWorkspace() {
  // Set user info in header
  document.querySelector('#user-info').textContent = `${state.user.name} · ${state.user.role}`;

  // Sign out button
  document.querySelector('#sign-out').addEventListener('click', async () => {
    await signOut();
    location.reload();
  });

  // Navigation filtering
  const roleHierarchy = { member: 1, observer: 2, coordinator: 3 };
  document.querySelectorAll('nav button').forEach(btn => {
    const minRole = btn.dataset.minRole;
    const minRoleLevel = roleHierarchy[minRole] || 0;
    const userRoleLevel = roleHierarchy[state.user.role] || 0;

    if (userRoleLevel < minRoleLevel) {
      btn.style.display = 'none';
    } else {
      btn.addEventListener('click', () => loadView(btn.dataset.view));
    }
  });

  // Load default view
  loadView('ballots');
}

// ============================================================================
// START
// ============================================================================

document.addEventListener('DOMContentLoaded', initApp);
