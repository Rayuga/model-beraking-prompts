# Task List

1. 🔄 Inspect starter app, seed data, and rules
Understand seeded ballots, privacy constraints, and required workflows before coding.
2. ⏳ Build SQLite-backed server with auth, ballots, voting, membership, and audit APIs
Persist sessions, receipts, roster, ballot lifecycle, revision checks, and seed-once initialization.
3. ⏳ Create polished responsive UI for six workspaces and role-based access
Support sign-in, theme toggle, clear states, validation, and privacy-safe displays.
4. ⏳ Run demo workflows for all users and confirm persistence after restart
Exercise draft-to-publication flow and re-sign-in checks using the supplied seed.
