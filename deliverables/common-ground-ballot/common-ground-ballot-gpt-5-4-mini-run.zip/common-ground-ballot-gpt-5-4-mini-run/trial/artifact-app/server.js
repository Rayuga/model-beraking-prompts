const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const app = express();
const publicDir = path.join(__dirname, 'public');
const dbPath = process.env.DB_PATH || path.join(__dirname, 'commonground.db');
const seedPath = path.join(__dirname, 'common_ground_seed.json');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
const actionable = new Set(['draft_created', 'draft_updated', 'opened', 'closed', 'published', 'memberships_updated']);
function now() { return new Date().toISOString(); }
function token() { return crypto.randomBytes(24).toString('hex'); }
function json(value) { return JSON.stringify(value); }
function parse(value, fallback) { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } }
function seedDb() {
  db.exec(`CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, role TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS memberships (user_id TEXT PRIMARY KEY, active INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS ballots (id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL, method TEXT NOT NULL, max_selections INTEGER NOT NULL, status TEXT NOT NULL, revision INTEGER NOT NULL, eligible_snapshot TEXT NOT NULL, opened_at TEXT, closed_at TEXT, published_at TEXT);
    CREATE TABLE IF NOT EXISTS ballot_choices (ballot_id TEXT NOT NULL, choice_id TEXT NOT NULL, label TEXT NOT NULL, position INTEGER NOT NULL, PRIMARY KEY(ballot_id, choice_id));
    CREATE TABLE IF NOT EXISTS ballot_participants (ballot_id TEXT NOT NULL, user_id TEXT NOT NULL, PRIMARY KEY(ballot_id, user_id));
    CREATE TABLE IF NOT EXISTS ballot_votes (ballot_id TEXT NOT NULL, user_id TEXT NOT NULL, op_key TEXT NOT NULL, response_json TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(ballot_id, user_id));
    CREATE TABLE IF NOT EXISTS ballot_vote_choices (ballot_id TEXT NOT NULL, op_key TEXT NOT NULL, choice_id TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, record_type TEXT NOT NULL, record_id TEXT NOT NULL, actor_user_id TEXT, actor_name TEXT, created_at TEXT NOT NULL, details TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at TEXT NOT NULL, revoked_at TEXT);
    CREATE TABLE IF NOT EXISTS receipts (op_key TEXT PRIMARY KEY, ballot_id TEXT NOT NULL, user_id TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS operations (op_key TEXT PRIMARY KEY, route TEXT NOT NULL, user_id TEXT NOT NULL, request_hash TEXT NOT NULL, response_json TEXT NOT NULL, created_at TEXT NOT NULL);`);
  if (!db.prepare('SELECT 1 FROM meta WHERE key=?').get('seeded')) {
    const insUser = db.prepare('INSERT INTO users VALUES (?,?,?,?)');
    const insMem = db.prepare('INSERT INTO memberships VALUES (?,?)');
    const insBallot = db.prepare('INSERT INTO ballots VALUES (?,?,?,?,?,?,?,?,?, ?,?)');
    const insChoice = db.prepare('INSERT INTO ballot_choices VALUES (?,?,?,?)');
    seed.users.forEach((u) => insUser.run(u.id, u.name, u.email, u.role));
    seed.memberships.forEach((m) => insMem.run(m.user_id, m.active ? 1 : 0));
    seed.ballots.forEach((b) => {
      insBallot.run(b.id, b.title, b.description || '', b.method, b.max_selections, b.status, b.revision, json(b.eligible_user_ids || []), null, null, null);
      b.choices.forEach((c, i) => insChoice.run(b.id, c.id, c.label, i));
      if (b.participant_user_ids) b.participant_user_ids.forEach((u) => db.prepare('INSERT INTO ballot_participants VALUES (?,?)').run(b.id, u));
      if (b.anonymous_choice_ids) b.anonymous_choice_ids.forEach((choice_id, i) => db.prepare('INSERT INTO ballot_vote_choices VALUES (?,?,?)').run(b.id, `seed-${b.id}-${i}`, choice_id));
    });
    db.prepare('INSERT INTO meta VALUES (?,?)').run('seeded', '1');
  }
}
seedDb();
app.use(express.json());
app.use(express.static(publicDir));
function auth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const t = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : req.header('x-session-token');
  if (!t) return res.status(401).json({ error: 'Sign in required' });
  const s = db.prepare('SELECT * FROM sessions WHERE token=?').get(t);
  if (!s || s.revoked_at) return res.status(401).json({ error: 'Session ended' });
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(s.user_id);
  req.sessionToken = t; req.user = user; next();
}
function role(req, ...allowed) { return allowed.includes(req.user.role); }
function loadBallot(id) { const b = db.prepare('SELECT * FROM ballots WHERE id=?').get(id); if (!b) return null; b.choices = db.prepare('SELECT choice_id id, label FROM ballot_choices WHERE ballot_id=? ORDER BY position').all(id); b.eligible_user_ids = parse(b.eligible_snapshot, []); b.participant_user_ids = db.prepare('SELECT user_id FROM ballot_participants WHERE ballot_id=? ORDER BY user_id').all(id).map(r => r.user_id); return b; }
function audit(action, type, id, actor, details = {}) { db.prepare('INSERT INTO audit(action,record_type,record_id,actor_user_id,actor_name,created_at,details) VALUES (?,?,?,?,?,?,?)').run(action, type, id, actor?.id || null, actor?.name || null, now(), json(details)); }
function currentState() { const ballots = db.prepare('SELECT * FROM ballots ORDER BY CASE status WHEN "draft" THEN 0 WHEN "open" THEN 1 WHEN "closed" THEN 2 ELSE 3 END, title').all().map((b) => loadBallot(b.id)); return { group: seed.group, users: db.prepare('SELECT id,name,email,role FROM users ORDER BY name').all(), memberships: db.prepare('SELECT user_id, active FROM memberships').all().map(m => ({ ...m, active: !!m.active })), ballots, audit: db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 100').all(), me: null }; }
app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.post('/api/login', (req, res) => { const user = db.prepare('SELECT id,name,email,role FROM users WHERE email=?').get(req.body.email); if (!user || req.body.password !== 'CommonGround!2026') return res.status(401).json({ error: 'Invalid credentials' }); const t = token(); db.prepare('INSERT INTO sessions VALUES (?,?,?,NULL)').run(t, user.id, now()); res.json({ token: t, user }); });
app.post('/api/logout', auth, (req, res) => { db.prepare('UPDATE sessions SET revoked_at=? WHERE token=?').run(now(), req.sessionToken); res.json({ ok: true }); });
app.post('/api/logout-all', auth, (req, res) => { db.prepare('UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(now(), req.user.id); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => { res.json({ user: req.user, state: { ...currentState(), me: req.user } }); });
app.get('/api/state', auth, (req, res) => res.json({ ...currentState(), me: req.user }));
app.post('/api/ballots', auth, (req, res) => { if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only Ruth can create drafts' }); const { title, description = '', method, maxSelections, choices } = req.body; if (!title || !Array.isArray(choices) || choices.length < 2) return res.status(400).json({ error: 'Draft needs a title and at least two choices' }); const cleanChoices = choices.map(c => String(c || '').trim()).filter(Boolean); if (cleanChoices.length < 2) return res.status(400).json({ error: 'Choices must be non-empty and different' }); if (new Set(cleanChoices).size !== cleanChoices.length) return res.status(400).json({ error: 'Choices must be different' }); const ballotId = `ballot-${crypto.randomUUID()}`; db.prepare('INSERT INTO ballots VALUES (?,?,?,?,?,?,?,?,?,?,?)').run(ballotId, title.trim(), description.trim(), method, Number(maxSelections), 'draft', 1, json([]), null, null, null); cleanChoices.forEach((label, i) => db.prepare('INSERT INTO ballot_choices VALUES (?,?,?,?)').run(ballotId, `choice-${i}-${crypto.randomBytes(4).toString('hex')}`, label, i)); audit('draft_created', 'ballot', ballotId, req.user, { title }); res.status(201).json(loadBallot(ballotId)); });
app.patch('/api/ballots/:id', auth, (req, res) => { if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only Ruth can edit ballots' }); const ballot = loadBallot(req.params.id); if (!ballot) return res.status(404).json({ error: 'Ballot not found' }); if (Number(req.body.revision) !== ballot.revision) return res.status(409).json({ error: 'Revision is out of date' }); if (ballot.status !== 'draft') return res.status(400).json({ error: 'Only drafts can be edited' }); db.prepare('UPDATE ballots SET title=?, description=?, method=?, max_selections=?, revision=revision+1 WHERE id=?').run(req.body.title, req.body.description || '', req.body.method, req.body.maxSelections, ballot.id); db.prepare('DELETE FROM ballot_choices WHERE ballot_id=?').run(ballot.id); (req.body.choices || []).forEach((label, i) => db.prepare('INSERT INTO ballot_choices VALUES (?,?,?,?)').run(ballot.id, `choice-${i}-${crypto.randomBytes(4).toString('hex')}`, label.trim(), i)); audit('draft_updated', 'ballot', ballot.id, req.user, {}); res.json(loadBallot(ballot.id)); });
app.post('/api/ballots/:id/open', auth, (req, res) => { if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only Ruth can open ballots' }); const ballot = loadBallot(req.params.id); if (!ballot) return res.status(404).json({ error: 'Ballot not found' }); if (ballot.status !== 'draft') return res.status(400).json({ error: 'Only drafts can open' }); const active = db.prepare('SELECT user_id FROM memberships WHERE active=1').all().map(r => r.user_id); db.prepare('UPDATE ballots SET status="open", revision=revision+1, opened_at=?, eligible_snapshot=? WHERE id=?').run(now(), json(active), ballot.id); audit('opened', 'ballot', ballot.id, req.user, { eligible: active.length }); res.json(loadBallot(ballot.id)); });
app.post('/api/ballots/:id/close', auth, (req, res) => { if (!role(req, 'coordinator')) return res.status(403).json({ error: 'Only staff can close ballots' }); const ballot = loadBallot(req.params.id); if (!ballot) return res.status(404).json({ error: 'Ballot not found' }); if (ballot.status !== 'open') return res.status(400).json({ error: 'Only open ballots can close' }); db.prepare('UPDATE ballots SET status="closed", revision=revision+1, closed_at=? WHERE id=?').run(now(), ballot.id); audit('closed', 'ballot', ballot.id, req.user, {}); res.json(loadBallot(ballot.id)); });
app.post('/api/ballots/:id/publish', auth, (req, res) => { if (!role(req, 'coordinator')) return res.status(403).json({ error: 'Only staff can publish ballots' }); const ballot = loadBallot(req.params.id); if (!ballot) return res.status(404).json({ error: 'Ballot not found' }); if (ballot.status !== 'closed') return res.status(400).json({ error: 'Only closed ballots can publish' }); db.prepare('UPDATE ballots SET status="published", revision=revision+1, published_at=? WHERE id=?').run(now(), ballot.id); audit('published', 'ballot', ballot.id, req.user, {}); res.json(loadBallot(ballot.id)); });
app.patch('/api/memberships', auth, (req, res) => { if (req.user.role !== 'coordinator') return res.status(403).json({ error: 'Only Ruth can change membership' }); const updates = req.body.memberships || []; const stmt = db.prepare('INSERT INTO memberships(user_id,active) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET active=excluded.active'); const tx = db.transaction((rows) => rows.forEach((r) => stmt.run(r.user_id, r.active ? 1 : 0))); tx(updates); audit('memberships_updated', 'memberships', 'group-riverside', req.user, { count: updates.length }); res.json({ ok: true }); });
app.post('/api/ballots/:id/vote', auth, (req, res) => { const ballot = loadBallot(req.params.id); if (!ballot) return res.status(404).json({ error: 'Ballot not found' }); if (ballot.status !== 'open') return res.status(400).json({ error: 'Ballot is not open' }); if (!ballot.eligible_user_ids.includes(req.user.id)) return res.status(403).json({ error: 'You are not eligible for this ballot' }); const choices = Array.from(new Set((req.body.choiceIds || []).filter(Boolean))); if (!choices.length) return res.status(400).json({ error: 'Choose at least one option' }); if (ballot.method === 'single' && choices.length !== 1) return res.status(400).json({ error: 'Single-choice ballots need exactly one choice' }); if (ballot.method === 'approval' && (choices.length < 1 || choices.length > ballot.max_selections)) return res.status(400).json({ error: 'Approval choices exceed the limit' }); const ballotChoiceIds = new Set(ballot.choices.map(c => c.id)); if (!choices.every((c) => ballotChoiceIds.has(c))) return res.status(400).json({ error: 'Invalid choice for this ballot' }); const opKey = String(req.body.operationKey || ''); if (!opKey) return res.status(400).json({ error: 'Missing operation key' }); const requestHash = crypto.createHash('sha256').update(json({ ballotId: ballot.id, choiceIds: choices, opKey })).digest('hex'); const existingOp = db.prepare('SELECT * FROM operations WHERE op_key=? AND route=? AND user_id=?').get(opKey, 'vote', req.user.id); if (existingOp) { if (existingOp.request_hash !== requestHash) return res.status(409).json({ error: 'Operation key already used for different input' }); return res.json(parse(existingOp.response_json, {})); }
  const prior = db.prepare('SELECT * FROM ballot_votes WHERE ballot_id=? AND user_id=?').get(ballot.id, req.user.id);
  if (prior) { const response = parse(prior.response_json, {}); db.prepare('INSERT INTO operations VALUES (?,?,?,?,?,?)').run(opKey, 'vote', req.user.id, requestHash, json(response), now()); return res.json(response); }
  const response = { ok: true, ballotId: ballot.id, message: 'Participation recorded' }; const tx = db.transaction(() => { db.prepare('INSERT INTO ballot_votes VALUES (?,?,?,?,?)').run(ballot.id, req.user.id, opKey, json(response), now()); choices.forEach((choice_id) => db.prepare('INSERT INTO ballot_vote_choices VALUES (?,?,?)').run(ballot.id, opKey, choice_id)); db.prepare('INSERT INTO receipts VALUES (?,?,?,?)').run(opKey, ballot.id, req.user.id, now()); db.prepare('INSERT INTO operations VALUES (?,?,?,?,?,?)').run(opKey, 'vote', req.user.id, requestHash, json(response), now()); db.prepare('INSERT INTO ballot_participants VALUES (?,?) ON CONFLICT DO NOTHING').run(ballot.id, req.user.id); }); tx(); res.json(response); });
app.get('/api/ballots/:id/results', auth, (req, res) => { const ballot = loadBallot(req.params.id); if (!ballot) return res.status(404).json({ error: 'Ballot not found' }); if (ballot.status !== 'published' && req.user.role !== 'coordinator' && req.user.role !== 'observer') return res.status(403).json({ error: 'Results are hidden until publication' }); const rows = db.prepare('SELECT choice_id, COUNT(*) count FROM ballot_vote_choices WHERE ballot_id=? GROUP BY choice_id').all(ballot.id); const totals = Object.fromEntries(rows.map(r => [r.choice_id, r.count])); const participating = db.prepare('SELECT COUNT(*) c FROM ballot_participants WHERE ballot_id=?').get(ballot.id).c; res.json({ ballotId: ballot.id, status: ballot.status, totalBallots: participating, choices: ballot.choices.map(c => ({ id: c.id, label: c.label, count: totals[c.id] || 0 })) }); });
app.get('/api/state', auth, (req, res) => res.json({ ...currentState(), me: req.user }));
app.use((_req, res) => res.sendFile(path.join(publicDir, 'index.html')));
const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`Common Ground listening on ${port}`));
