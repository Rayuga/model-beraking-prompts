const API_BASE = '/api';
let currentUser = null;

const alerts = document.getElementById('alerts');
const workspaceEl = document.getElementById('workspace');
const signInEl = document.getElementById('sign-in');

function showAlert(message, type = 'info') {
  const alertEl = document.createElement('div');
  alertEl.className = `alert alert-${type}`;
  alertEl.setAttribute('role', 'alert');
  alertEl.innerHTML = `<p>${escapeHtml(message)}</p>
    <button type="button" class="close-alert" aria-label="Close alert">×</button>`;
  alerts.appendChild(alertEl);
  
  const closeBtn = alertEl.querySelector('.close-alert');
  closeBtn.addEventListener('click', () => alertEl.remove());
  
  if (type !== 'error') {
    setTimeout(() => alertEl.remove(), 5000);
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

const api = async (url, body) => {
  const response = await fetch(url, body === undefined ? {} : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed.');
  return result;
};

// Pending Actions in localStorage
class PendingActions {
  constructor() {
    this.loadFromStorage();
  }

  loadFromStorage() {
    const stored = localStorage.getItem('cg_pending_actions');
    this.actions = stored ? JSON.parse(stored) : [];
  }

  saveToStorage() {
    localStorage.setItem('cg_pending_actions', JSON.stringify(this.actions));
  }

  add(action, target, inputs, operationId) {
    const existing = this.actions.find(a => a.operationId === operationId);
    if (existing) return;
    
    this.actions.push({
      operationId,
      action,
      target,
      inputs,
      timestamp: new Date().toISOString()
    });
    this.saveToStorage();
  }

  get(operationId) {
    return this.actions.find(a => a.operationId === operationId);
  }

  remove(operationId) {
    this.actions = this.actions.filter(a => a.operationId !== operationId);
    this.saveToStorage();
  }

  clear(operationId) {
    this.remove(operationId);
    updatePendingPanel();
  }

  list() {
    return [...this.actions];
  }
}

const pendingActions = new PendingActions();

function makeOperationId() {
  return 'op-' + Math.random().toString(36).substr(2, 9) + '-' + Date.now();
}

function showUser(user) {
  currentUser = user;
  if (user) {
    document.getElementById('identity').textContent = `${user.name} · ${user.role}`;
    signInEl.classList.add('hidden');
    workspaceEl.classList.remove('hidden');
    loadView('ballots');
    updatePendingPanel();
  } else {
    signInEl.classList.remove('hidden');
    workspaceEl.classList.add('hidden');
  }
}

document.querySelectorAll('[data-email]').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelector('#email').value = button.dataset.email;
    document.querySelector('#password').value = 'CommonGround!2026';
  });
});

document.getElementById('login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button');
  button.disabled = true;
  try {
    const { user } = await api('/api/auth/login', {
      email: document.querySelector('#email').value,
      password: document.querySelector('#password').value
    });
    showUser(user);
    showAlert('Signed in.');
  } catch (error) {
    showAlert(error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

document.getElementById('logout').addEventListener('click', async () => {
  try {
    await api('/api/auth/logout', {});
    showUser(null);
    showAlert('Signed out.');
  } catch (error) {
    showAlert(error.message, 'error');
  }
});

document.getElementById('logout-all').addEventListener('click', async () => {
  try {
    await api('/api/auth/logout-all', {});
    showUser(null);
    showAlert('All Common Ground sessions ended.');
  } catch (error) {
    showAlert(error.message, 'error');
  }
});

api('/api/me').then(({ user }) => {
  showUser(user);
  if (!user) showAlert('You are not signed in.');
}).catch(error => {
  showAlert(error.message, 'error');
});

document.getElementById('theme').addEventListener('click', () => {
  const root = document.documentElement;
  root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('cg_theme', root.dataset.theme);
  updateThemeButton();
});

function updateThemeButton() {
  const root = document.documentElement;
  const btn = document.getElementById('theme');
  btn.textContent = root.dataset.theme === 'dark' ? '☀️' : '🌙';
}

// Load saved theme
const savedTheme = localStorage.getItem('cg_theme');
if (savedTheme) {
  document.documentElement.dataset.theme = savedTheme;
}
updateThemeButton();

// View management
function loadView(viewName) {
  document.querySelectorAll('[data-view]').forEach(btn => btn.classList.remove('active'));
  document.querySelector(`[data-view="${viewName}"]`).classList.add('active');
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  document.getElementById(`${viewName}-view`).classList.remove('hidden');
  
  switch (viewName) {
    case 'ballots': renderBallots(); break;
    case 'vote': renderVote(); break;
    case 'turnout': renderTurnout(); break;
    case 'results': renderResults(); break;
    case 'members': renderMembers(); break;
    case 'audit': renderAudit(); break;
  }
}

document.querySelectorAll('[data-view]').forEach(btn => {
  btn.addEventListener('click', () => loadView(btn.dataset.view));
});

// Pending Actions Panel
function updatePendingPanel() {
  const actions = pendingActions.list();
  const panel = document.getElementById('pending-actions');
  const list = document.getElementById('pending-list');
  
  if (actions.length === 0) {
    panel.classList.add('hidden');
    return;
  }
  
  panel.classList.remove('hidden');
  list.innerHTML = actions.map(action => `
    <div class="pending-item">
      <div>
        <strong>${action.action}</strong>
        <p>${action.target}</p>
        <small>${new Date(action.timestamp).toLocaleString()}</small>
      </div>
      <div class="pending-buttons">
        <button type="button" class="retry-btn" data-op-id="${action.operationId}">Retry</button>
        <button type="button" class="dismiss-btn" data-op-id="${action.operationId}">Dismiss</button>
      </div>
    </div>
  `).join('');
  
  list.querySelectorAll('.retry-btn').forEach(btn => {
    btn.addEventListener('click', () => retryAction(btn.dataset.opId));
  });
  
  list.querySelectorAll('.dismiss-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      pendingActions.remove(btn.dataset.opId);
      updatePendingPanel();
    });
  });
}

function retryAction(operationId) {
  const action = pendingActions.get(operationId);
  if (!action) return;
  showAlert(`Retrying ${action.action}...`);
}

// ========== BALLOTS VIEW ==========
async function renderBallots() {
  const container = document.getElementById('ballots-content');
  container.innerHTML = '<p>Loading ballots...</p>';
  
  try {
    const { ballots } = await api(`${API_BASE}/ballots`);
    
    if (ballots.length === 0) {
      container.innerHTML = '<p>No ballots yet.</p>';
      if (currentUser.role === 'coordinator') {
        container.innerHTML += '<button class="create-ballot-btn">+ Create ballot</button>';
      }
      return;
    }
    
    let html = '';
    
    if (currentUser.role === 'coordinator') {
      html += '<div class="button-group"><button class="create-ballot-btn">+ Create ballot</button></div>';
    }
    
    html += '<div class="ballot-list">';
    for (const ballot of ballots) {
      const statusClass = `status-${ballot.status}`;
      let participationText = '';
      if (currentUser.role !== 'member' && ballot.participation_count !== undefined) {
        participationText = `<p class="participation-info">
          <strong>${ballot.participation_count}</strong> of <strong>${ballot.eligible_count}</strong> voted
        </p>`;
      }
      
      let userStatus = '';
      if (currentUser.role === 'member') {
        if (ballot.user_eligible === false) {
          userStatus = '<p class="not-eligible">You are not eligible for this ballot</p>';
        } else if (ballot.user_participated) {
          userStatus = '<p class="participated">✓ You participated</p>';
        } else if (ballot.status === 'open') {
          userStatus = '<p class="can-vote">You can vote on this</p>';
        }
      }
      
      html += `
        <div class="ballot-card ${statusClass}">
          <div class="ballot-header">
            <h2>${escapeHtml(ballot.title)}</h2>
            <span class="status-badge">${ballot.status}</span>
          </div>
          <p>${escapeHtml(ballot.description)}</p>
          <p class="method-info">${ballot.method === 'single' ? 'Single choice' : `Approval (up to ${ballot.max_selections})`}</p>
          ${participationText}
          ${userStatus}
          <div class="ballot-choices">
            ${ballot.choices.map(c => `<span class="choice-item">${escapeHtml(c.label)}</span>`).join('')}
          </div>
          <div class="ballot-actions">
      `;
      
      if (currentUser.role === 'coordinator') {
        if (ballot.status === 'draft') {
          html += `
            <button class="edit-ballot-btn" data-ballot-id="${ballot.id}" data-revision="${ballot.revision}">Edit</button>
            <button class="open-ballot-btn" data-ballot-id="${ballot.id}" data-revision="${ballot.revision}">Open</button>
          `;
        } else if (ballot.status === 'open') {
          html += `<button class="close-ballot-btn" data-ballot-id="${ballot.id}" data-revision="${ballot.revision}">Close</button>`;
        } else if (ballot.status === 'closed') {
          html += `<button class="publish-ballot-btn" data-ballot-id="${ballot.id}" data-revision="${ballot.revision}">Publish</button>`;
        }
      }
      
      html += '</div></div>';
    }
    html += '</div>';
    
    container.innerHTML = html;
    
    // Add event listeners
    const createBtn = container.querySelector('.create-ballot-btn');
    if (createBtn) createBtn.addEventListener('click', showCreateBallotForm);
    
    container.querySelectorAll('.edit-ballot-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        editBallot(btn.dataset.ballotId, parseInt(btn.dataset.revision));
      });
    });
    
    container.querySelectorAll('.open-ballot-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        openBallot(btn.dataset.ballotId, parseInt(btn.dataset.revision));
      });
    });
    
    container.querySelectorAll('.close-ballot-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        closeBallot(btn.dataset.ballotId, parseInt(btn.dataset.revision));
      });
    });
    
    container.querySelectorAll('.publish-ballot-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        publishBallot(btn.dataset.ballotId, parseInt(btn.dataset.revision));
      });
    });
  } catch (error) {
    container.innerHTML = `<p class="error">Error loading ballots: ${escapeHtml(error.message)}</p>`;
  }
}

function showCreateBallotForm() {
  const container = document.getElementById('ballots-content');
  container.innerHTML = `
    <div class="form-card">
      <h2>Create Ballot</h2>
      <form id="create-ballot-form">
        <label>Title *</label>
        <input type="text" name="title" required maxlength="200" />
        
        <label>Description</label>
        <textarea name="description" maxlength="2000"></textarea>
        
        <label>Voting Method *</label>
        <select name="method" required>
          <option value="">Choose...</option>
          <option value="single">Single choice (pick exactly one)</option>
          <option value="approval">Approval (pick multiple, up to a limit)</option>
        </select>
        
        <div id="approval-settings" class="hidden">
          <label>Maximum selections *</label>
          <input type="number" name="max_selections" min="1" required />
        </div>
        
        <label>Choices *</label>
        <div id="choices-container">
          <div class="choice-input"><input type="text" class="choice-label" placeholder="Choice 1" required maxlength="200" /></div>
          <div class="choice-input"><input type="text" class="choice-label" placeholder="Choice 2" required maxlength="200" /></div>
        </div>
        <button type="button" id="add-choice-btn" class="secondary">+ Add choice</button>
        
        <div class="form-actions">
          <button type="submit">Create</button>
          <button type="button" class="secondary cancel-btn">Cancel</button>
        </div>
      </form>
    </div>
  `;
  
  const form = document.getElementById('create-ballot-form');
  const methodSelect = form.querySelector('select[name="method"]');
  const approvalSettings = document.getElementById('approval-settings');
  const addChoiceBtn = document.getElementById('add-choice-btn');
  const cancelBtn = form.querySelector('.cancel-btn');
  
  methodSelect.addEventListener('change', () => {
    if (methodSelect.value === 'approval') {
      approvalSettings.classList.remove('hidden');
      form.querySelector('input[name="max_selections"]').required = true;
    } else {
      approvalSettings.classList.add('hidden');
      form.querySelector('input[name="max_selections"]').required = false;
      form.querySelector('input[name="max_selections"]').value = '';
    }
  });
  
  addChoiceBtn.addEventListener('click', () => {
    const container = document.getElementById('choices-container');
    const div = document.createElement('div');
    div.className = 'choice-input';
    div.innerHTML = `<input type="text" class="choice-label" placeholder="Choice ${container.children.length + 1}" required maxlength="200" />
      <button type="button" class="remove-choice-btn secondary" aria-label="Remove choice">×</button>`;
    container.appendChild(div);
    div.querySelector('.remove-choice-btn').addEventListener('click', (e) => {
      e.preventDefault();
      div.remove();
    });
  });
  
  cancelBtn.addEventListener('click', () => renderBallots());
  
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const choices = Array.from(form.querySelectorAll('.choice-label'))
      .map(input => ({ label: input.value.trim() }))
      .filter(c => c.label);
    
    if (choices.length < 2) {
      showAlert('At least two choices required', 'error');
      return;
    }
    
    const maxSelections = methodSelect.value === 'approval' ? parseInt(form.querySelector('input[name="max_selections"]').value) : 1;
    
    const operationId = makeOperationId();
    const payload = {
      title: form.querySelector('input[name="title"]').value,
      description: form.querySelector('textarea[name="description"]').value || '',
      method: methodSelect.value,
      max_selections: maxSelections,
      choices,
      operation_id: operationId
    };
    
    pendingActions.add('Create ballot', payload.title, payload, operationId);
    updatePendingPanel();
    
    try {
      await api(`${API_BASE}/ballots`, payload);
      pendingActions.remove(operationId);
      updatePendingPanel();
      showAlert('Ballot created.');
      renderBallots();
    } catch (error) {
      showAlert(`Error: ${error.message}`, 'error');
    }
  });
}

async function editBallot(ballotId, currentRevision) {
  try {
    const { ballots } = await api(`${API_BASE}/ballots`);
    const ballot = ballots.find(b => b.id === ballotId);
    if (!ballot) throw new Error('Ballot not found');
    
    const container = document.getElementById('ballots-content');
    container.innerHTML = `
      <div class="form-card">
        <h2>Edit Ballot: ${escapeHtml(ballot.title)}</h2>
        <form id="edit-ballot-form">
          <label>Title *</label>
          <input type="text" name="title" value="${escapeHtml(ballot.title)}" required maxlength="200" />
          
          <label>Description</label>
          <textarea name="description" maxlength="2000">${escapeHtml(ballot.description)}</textarea>
          
          <label>Voting Method *</label>
          <select name="method" required>
            <option value="single" ${ballot.method === 'single' ? 'selected' : ''}>Single choice</option>
            <option value="approval" ${ballot.method === 'approval' ? 'selected' : ''}>Approval</option>
          </select>
          
          ${ballot.method === 'approval' ? `
            <label>Maximum selections *</label>
            <input type="number" name="max_selections" value="${ballot.max_selections}" min="1" required />
          ` : ''}
          
          <label>Choices *</label>
          <div id="choices-container">
            ${ballot.choices.map((choice, i) => `
              <div class="choice-input">
                <input type="text" class="choice-label" value="${escapeHtml(choice.label)}" required maxlength="200" />
              </div>
            `).join('')}
          </div>
          <button type="button" id="add-choice-btn" class="secondary">+ Add choice</button>
          
          <div class="form-actions">
            <button type="submit">Save</button>
            <button type="button" class="secondary cancel-btn">Cancel</button>
          </div>
        </form>
      </div>
    `;
    
    const form = document.getElementById('edit-ballot-form');
    const addChoiceBtn = document.getElementById('add-choice-btn');
    
    addChoiceBtn.addEventListener('click', () => {
      const container = document.getElementById('choices-container');
      const div = document.createElement('div');
      div.className = 'choice-input';
      div.innerHTML = `<input type="text" class="choice-label" placeholder="Choice" required maxlength="200" />
        <button type="button" class="remove-choice-btn secondary" aria-label="Remove choice">×</button>`;
      container.appendChild(div);
      div.querySelector('.remove-choice-btn').addEventListener('click', (e) => {
        e.preventDefault();
        div.remove();
      });
    });
    
    form.querySelector('.cancel-btn').addEventListener('click', () => renderBallots());
    
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const choices = Array.from(form.querySelectorAll('.choice-label'))
        .map(input => ({ label: input.value.trim() }))
        .filter(c => c.label);
      
      if (choices.length < 2) {
        showAlert('At least two choices required', 'error');
        return;
      }
      
      const operationId = makeOperationId();
      const payload = {
        title: form.querySelector('input[name="title"]').value,
        description: form.querySelector('textarea[name="description"]').value || '',
        method: form.querySelector('select[name="method"]').value,
        max_selections: parseInt(form.querySelector('input[name="max_selections"]')?.value || '1'),
        choices,
        viewed_revision: currentRevision,
        operation_id: operationId
      };
      
      pendingActions.add('Edit ballot', escapeHtml(ballot.title), payload, operationId);
      updatePendingPanel();
      
      try {
        await api(`${API_BASE}/ballots/${ballotId}/edit`, payload);
        pendingActions.remove(operationId);
        updatePendingPanel();
        showAlert('Ballot saved.');
        renderBallots();
      } catch (error) {
        showAlert(`Error: ${error.message}`, 'error');
      }
    });
  } catch (error) {
    showAlert(`Error: ${error.message}`, 'error');
  }
}

async function openBallot(ballotId, revision) {
  const operationId = makeOperationId();
  const payload = {
    viewed_revision: revision,
    operation_id: operationId
  };
  
  pendingActions.add('Open ballot', 'Opening...', payload, operationId);
  updatePendingPanel();
  
  try {
    await api(`${API_BASE}/ballots/${ballotId}/open`, payload);
    pendingActions.remove(operationId);
    updatePendingPanel();
    showAlert('Ballot opened.');
    renderBallots();
  } catch (error) {
    showAlert(`Error: ${error.message}`, 'error');
  }
}

async function closeBallot(ballotId, revision) {
  const operationId = makeOperationId();
  const payload = {
    viewed_revision: revision,
    operation_id: operationId
  };
  
  pendingActions.add('Close ballot', 'Closing...', payload, operationId);
  updatePendingPanel();
  
  try {
    await api(`${API_BASE}/ballots/${ballotId}/close`, payload);
    pendingActions.remove(operationId);
    updatePendingPanel();
    showAlert('Ballot closed.');
    renderBallots();
  } catch (error) {
    showAlert(`Error: ${error.message}`, 'error');
  }
}

async function publishBallot(ballotId, revision) {
  const operationId = makeOperationId();
  const payload = {
    viewed_revision: revision,
    operation_id: operationId
  };
  
  pendingActions.add('Publish ballot', 'Publishing...', payload, operationId);
  updatePendingPanel();
  
  try {
    await api(`${API_BASE}/ballots/${ballotId}/publish`, payload);
    pendingActions.remove(operationId);
    updatePendingPanel();
    showAlert('Ballot published.');
    renderBallots();
  } catch (error) {
    showAlert(`Error: ${error.message}`, 'error');
  }
}

// ========== VOTE VIEW ==========
async function renderVote() {
  const container = document.getElementById('vote-content');
  container.innerHTML = '<p>Loading ballots...</p>';
  
  try {
    const { ballots } = await api(`${API_BASE}/ballots`);
    const openBallots = ballots.filter(b => b.status === 'open' && b.user_eligible && !b.user_participated);
    
    if (openBallots.length === 0) {
      container.innerHTML = '<p>No open ballots available for you.</p>';
      return;
    }
    
    let html = '<div class="ballot-list">';
    for (const ballot of openBallots) {
      html += `
        <div class="ballot-card status-open">
          <h2>${escapeHtml(ballot.title)}</h2>
          <p>${escapeHtml(ballot.description)}</p>
          <button class="vote-ballot-btn" data-ballot-id="${ballot.id}">Vote on this ballot</button>
        </div>
      `;
    }
    html += '</div>';
    
    container.innerHTML = html;
    
    container.querySelectorAll('.vote-ballot-btn').forEach(btn => {
      btn.addEventListener('click', () => showVoteForm(btn.dataset.ballotId));
    });
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}

async function showVoteForm(ballotId) {
  const container = document.getElementById('vote-content');
  container.innerHTML = '<p>Loading ballot...</p>';
  
  try {
    const voteState = await api(`${API_BASE}/ballots/${ballotId}/vote-state`);
    const ballot = voteState.ballot;
    
    let choicesHtml = '';
    if (ballot.method === 'single') {
      choicesHtml = ballot.choices.map(choice => `
        <label class="choice-label">
          <input type="radio" name="choices" value="${choice.id}" required />
          ${escapeHtml(choice.label)}
        </label>
      `).join('');
    } else {
      const maxText = ballot.max_selections === 1 ? '1 choice' : `up to ${ballot.max_selections} choices`;
      choicesHtml = `<p class="choice-limit">You can select ${maxText}.</p>` +
        ballot.choices.map(choice => `
          <label class="choice-label">
            <input type="checkbox" name="choices" value="${choice.id}" />
            ${escapeHtml(choice.label)}
          </label>
        `).join('');
    }
    
    container.innerHTML = `
      <div class="form-card">
        <h2>${escapeHtml(ballot.title)}</h2>
        <p>${escapeHtml(ballot.description)}</p>
        <div class="privacy-notice">
          <strong>Privacy:</strong> Your selection is completely separate from your name. 
          Only the total votes are counted, never connected to you individually.
        </div>
        <form id="vote-form">
          <fieldset>
            <legend>Make your final selection</legend>
            ${choicesHtml}
          </fieldset>
          <div class="form-actions">
            <button type="submit">Submit vote</button>
            <button type="button" class="secondary cancel-btn">Cancel</button>
          </div>
        </form>
      </div>
    `;
    
    const form = document.getElementById('vote-form');
    
    form.querySelector('.cancel-btn').addEventListener('click', () => renderVote());
    
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      let choiceIds;
      if (ballot.method === 'single') {
        const selected = form.querySelector('input[name="choices"]:checked');
        choiceIds = selected ? [selected.value] : [];
      } else {
        choiceIds = Array.from(form.querySelectorAll('input[name="choices"]:checked')).map(input => input.value);
      }
      
      if (choiceIds.length === 0) {
        showAlert('Please make a selection', 'error');
        return;
      }
      
      const operationId = makeOperationId();
      const payload = {
        choice_ids: choiceIds,
        operation_id: operationId
      };
      
      pendingActions.add('Vote', escapeHtml(ballot.title), payload, operationId);
      updatePendingPanel();
      
      try {
        await api(`${API_BASE}/ballots/${ballotId}/vote`, payload);
        pendingActions.remove(operationId);
        updatePendingPanel();
        showAlert('Your vote has been recorded.');
        renderVote();
      } catch (error) {
        showAlert(`Error: ${error.message}`, 'error');
      }
    });
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}

// ========== TURNOUT VIEW ==========
async function renderTurnout() {
  const container = document.getElementById('turnout-content');
  
  if (currentUser.role === 'member') {
    container.innerHTML = '<p>You cannot view turnout.</p>';
    return;
  }
  
  container.innerHTML = '<p>Select a ballot to view turnout.</p>';
  
  try {
    const { ballots } = await api(`${API_BASE}/ballots`);
    const viewableBallots = ballots.filter(b => !['draft'].includes(b.status));
    
    if (viewableBallots.length === 0) {
      container.innerHTML = '<p>No ballots with turnout available.</p>';
      return;
    }
    
    let html = '<div class="ballot-select">';
    for (const ballot of viewableBallots) {
      html += `<button class="turnout-btn" data-ballot-id="${ballot.id}">${escapeHtml(ballot.title)}</button>`;
    }
    html += '</div>';
    
    container.innerHTML = html;
    
    container.querySelectorAll('.turnout-btn').forEach(btn => {
      btn.addEventListener('click', () => showTurnout(btn.dataset.ballotId));
    });
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}

async function showTurnout(ballotId) {
  const container = document.getElementById('turnout-content');
  
  try {
    const result = await api(`${API_BASE}/ballots/${ballotId}/turnout`);
    const ballot = result.ballot;
    const turnout = result.turnout;
    
    let html = `
      <div class="ballot-summary">
        <h2>${escapeHtml(ballot.title)}</h2>
        <p class="summary-stats">
          <strong>${ballot.participation_count}</strong> of <strong>${ballot.eligible_count}</strong> members participated
        </p>
      </div>
      <table class="turnout-table">
        <thead>
          <tr>
            <th>Member</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
    `;
    
    for (const member of turnout) {
      const status = member.participated ? '✓ Voted' : 'Not voted';
      html += `
        <tr>
          <td>${escapeHtml(member.user_name)}</td>
          <td>${status}</td>
        </tr>
      `;
    }
    
    html += `
        </tbody>
      </table>
      <button class="secondary" onclick="renderTurnout()">Back</button>
    `;
    
    container.innerHTML = html;
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}

// ========== RESULTS VIEW ==========
async function renderResults() {
  const container = document.getElementById('results-content');
  
  container.innerHTML = '<p>Select a ballot to view results.</p>';
  
  try {
    const { ballots } = await api(`${API_BASE}/ballots`);
    const publishedBallots = ballots.filter(b => b.status === 'published');
    
    if (publishedBallots.length === 0) {
      container.innerHTML = '<p>No published results yet.</p>';
      return;
    }
    
    let html = '<div class="ballot-select">';
    for (const ballot of publishedBallots) {
      html += `<button class="results-btn" data-ballot-id="${ballot.id}">${escapeHtml(ballot.title)}</button>`;
    }
    html += '</div>';
    
    container.innerHTML = html;
    
    container.querySelectorAll('.results-btn').forEach(btn => {
      btn.addEventListener('click', () => showResults(btn.dataset.ballotId));
    });
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}

async function showResults(ballotId) {
  const container = document.getElementById('results-content');
  
  try {
    const result = await api(`${API_BASE}/ballots/${ballotId}/results`);
    const ballot = result.ballot;
    const results = result.results;
    
    let html = `
      <div class="ballot-summary">
        <h2>${escapeHtml(ballot.title)}</h2>
      </div>
    `;
    
    if (results.method === 'single') {
      html += `
        <div class="results-summary">
          <p>Total ballots: <strong>${results.total_ballots}</strong></p>
        </div>
        <div class="choices-results">
      `;
      
      if (results.leader) {
        html += `<div class="result-card leader"><strong>${escapeHtml(results.leader.choice_label)}</strong> wins with ${results.leader.count} vote${results.leader.count !== 1 ? 's' : ''}</div>`;
      } else if (results.tied_leaders) {
        const leaders = results.tied_leaders.map(l => escapeHtml(l.choice_label)).join(' and ');
        html += `<div class="result-card tied"><strong>Tied:</strong> ${leaders} each with ${results.tied_leaders[0].count} votes</div>`;
      }
      
      for (const choice of results.choices) {
        html += `<div class="result-item"><span>${escapeHtml(choice.choice_label)}</span><strong>${choice.count}</strong></div>`;
      }
      html += '</div>';
    } else {
      html += `
        <div class="results-summary">
          <p>Participating members: <strong>${results.participating_members}</strong></p>
        </div>
        <div class="choices-results">
      `;
      
      for (const choice of results.choices) {
        html += `
          <div class="result-item">
            <span>${escapeHtml(choice.choice_label)}</span>
            <div class="result-bar">
              <div class="bar-fill" style="width: ${Math.min(choice.percentage, 100)}%"></div>
            </div>
            <strong>${choice.approvals} approvals (${choice.percentage}%)</strong>
          </div>
        `;
      }
      html += '</div>';
    }
    
    html += '<button class="secondary" onclick="renderResults()">Back</button>';
    
    container.innerHTML = html;
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}

// ========== MEMBERS VIEW ==========
async function renderMembers() {
  const container = document.getElementById('members-content');
  
  if (currentUser.role === 'member') {
    container.innerHTML = '<p>You cannot manage members.</p>';
    return;
  }
  
  container.innerHTML = '<p>Loading members...</p>';
  
  try {
    const { members } = await api(`${API_BASE}/members`);
    
    let html = '<table class="members-table"><thead><tr><th>Member</th><th>Status</th><th>Action</th></tr></thead><tbody>';
    
    for (const member of members) {
      const status = member.active ? 'Active' : 'Paused';
      const actionBtn = member.active 
        ? `<button class="pause-member-btn secondary" data-member-id="${member.user_id}" data-revision="${member.revision}">Pause</button>`
        : `<button class="activate-member-btn secondary" data-member-id="${member.user_id}" data-revision="${member.revision}">Activate</button>`;
      
      html += `
        <tr>
          <td>${escapeHtml(member.user_name)}</td>
          <td>${status}</td>
          <td>${actionBtn}</td>
        </tr>
      `;
    }
    
    html += '</tbody></table>';
    container.innerHTML = html;
    
    if (currentUser.role === 'coordinator') {
      container.querySelectorAll('.pause-member-btn').forEach(btn => {
        btn.addEventListener('click', () => pauseMember(btn.dataset.memberId, parseInt(btn.dataset.revision)));
      });
      
      container.querySelectorAll('.activate-member-btn').forEach(btn => {
        btn.addEventListener('click', () => activateMember(btn.dataset.memberId, parseInt(btn.dataset.revision)));
      });
    }
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}

async function pauseMember(memberId, revision) {
  const operationId = makeOperationId();
  const payload = {
    viewed_revision: revision,
    operation_id: operationId
  };
  
  pendingActions.add('Pause member', 'Pausing...', payload, operationId);
  updatePendingPanel();
  
  try {
    await api(`${API_BASE}/members/${memberId}/pause`, payload);
    pendingActions.remove(operationId);
    updatePendingPanel();
    showAlert('Member paused.');
    renderMembers();
  } catch (error) {
    showAlert(`Error: ${error.message}`, 'error');
  }
}

async function activateMember(memberId, revision) {
  const operationId = makeOperationId();
  const payload = {
    viewed_revision: revision,
    operation_id: operationId
  };
  
  pendingActions.add('Activate member', 'Activating...', payload, operationId);
  updatePendingPanel();
  
  try {
    await api(`${API_BASE}/members/${memberId}/activate`, payload);
    pendingActions.remove(operationId);
    updatePendingPanel();
    showAlert('Member activated.');
    renderMembers();
  } catch (error) {
    showAlert(`Error: ${error.message}`, 'error');
  }
}

// ========== AUDIT VIEW ==========
async function renderAudit() {
  const container = document.getElementById('audit-content');
  
  if (currentUser.role === 'member') {
    container.innerHTML = '<p>You cannot view the audit log.</p>';
    return;
  }
  
  container.innerHTML = '<p>Loading audit log...</p>';
  
  try {
    const { audit } = await api(`${API_BASE}/audit`);
    
    if (audit.length === 0) {
      container.innerHTML = '<p>No audit entries.</p>';
      return;
    }
    
    let html = '<div class="audit-list">';
    
    for (const entry of audit) {
      const date = new Date(entry.created_at).toLocaleString();
      html += `
        <div class="audit-entry">
          <div class="audit-header">
            <strong>${escapeHtml(entry.action)}</strong>
            <span class="audit-actor">${escapeHtml(entry.actor_label)}</span>
            <small>${date}</small>
          </div>
          <p>${escapeHtml(entry.details)}</p>
        </div>
      `;
    }
    
    html += '</div>';
    container.innerHTML = html;
  } catch (error) {
    container.innerHTML = `<p class="error">Error: ${escapeHtml(error.message)}</p>`;
  }
}
