// Foundation: persistence, seed import, authentication, and HTTP shell.
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const express = require("express");
const Database = require("better-sqlite3");

const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DB_PATH || "/app/commonground.db";
const SEED_PATH = process.env.SEED_PATH || "/app/common_ground_seed.json";
const PASSWORD = "CommonGround!2026";
const SESSION_SECONDS = 8 * 60 * 60;

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "128kb", strict: true }));
app.use((request, response, next) => {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("Referrer-Policy", "same-origin");
  if (request.path.startsWith("/api/")) response.setHeader("Cache-Control", "no-store");
  next();
});

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS seed_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK (role IN ('coordinator', 'observer', 'member')),
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS groups (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS memberships (
    group_id TEXT NOT NULL REFERENCES groups(id),
    user_id TEXT NOT NULL REFERENCES users(id),
    active INTEGER NOT NULL CHECK (active IN (0, 1)),
    revision INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (group_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS ballots (
    id TEXT PRIMARY KEY,
    group_id TEXT NOT NULL REFERENCES groups(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    method TEXT NOT NULL CHECK (method IN ('single', 'approval')),
    max_selections INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft', 'open', 'closed', 'published')),
    revision INTEGER NOT NULL,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    opened_at TEXT,
    closed_at TEXT,
    published_at TEXT
  );
  CREATE TABLE IF NOT EXISTS choices (
    id TEXT PRIMARY KEY,
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    position INTEGER NOT NULL,
    UNIQUE (ballot_id, position)
  );
  CREATE TABLE IF NOT EXISTS eligibility (
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id),
    PRIMARY KEY (ballot_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS participation (
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id),
    submitted_at TEXT NOT NULL,
    receipt_id TEXT NOT NULL UNIQUE,
    PRIMARY KEY (ballot_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS anonymous_votes (
    id TEXT PRIMARY KEY,
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    choice_id TEXT NOT NULL REFERENCES choices(id) ON DELETE CASCADE,
    cast_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS operation_receipts (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    operation_id TEXT NOT NULL,
    action TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    status_code INTEGER NOT NULL,
    response_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, operation_id)
  );
  CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    actor_id TEXT REFERENCES users(id),
    actor_label TEXT NOT NULL,
    details TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ballots_status ON ballots(status);
  CREATE INDEX IF NOT EXISTS idx_choices_ballot ON choices(ballot_id, position);
  CREATE INDEX IF NOT EXISTS idx_votes_ballot ON anonymous_votes(ballot_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
  CREATE INDEX IF NOT EXISTS idx_audit_created ON audit(id DESC);
`);

class ApiError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.body = { error: message, ...extra };
  }
}

const now = () => new Date().toISOString();
const makeId = (prefix) => `${prefix}-${crypto.randomUUID()}`;
const tokenHash = (token) => crypto.createHash("sha256").update(token).digest("hex");
const fingerprint = (value) =>
  crypto.createHash("sha256").update(JSON.stringify(value)).digest("hex");

function passwordRecord(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  return { salt, hash: crypto.scryptSync(password, salt, 64).toString("hex") };
}

function passwordMatches(password, salt, expected) {
  const actual = crypto.scryptSync(password, salt, 64);
  const stored = Buffer.from(expected, "hex");
  return stored.length === actual.length && crypto.timingSafeEqual(actual, stored);
}

function seedApplication() {
  if (db.prepare("SELECT 1 FROM seed_state WHERE key = 'bootstrap-v1'").get()) return;
  const seed = JSON.parse(fs.readFileSync(SEED_PATH, "utf8"));
  const fixed = {
    draft: "2026-08-04T09:00:00.000Z",
    open: "2026-08-05T10:00:00.000Z",
    closed: "2026-08-06T11:00:00.000Z",
    published: "2026-08-07T12:00:00.000Z",
    member: "2026-08-08T13:00:00.000Z",
  };
  db.transaction(() => {
    db.prepare("INSERT INTO groups (id, name) VALUES (?, ?)").run(seed.group.id, seed.group.name);
    const insertUser = db.prepare(
      "INSERT INTO users (id, name, email, role, password_hash, password_salt) VALUES (?, ?, ?, ?, ?, ?)"
    );
    for (const user of seed.users) {
      const password = passwordRecord(PASSWORD);
      insertUser.run(user.id, user.name, user.email, user.role, password.hash, password.salt);
    }
    const insertMembership = db.prepare(
      "INSERT INTO memberships (group_id, user_id, active, revision, updated_at) VALUES (?, ?, ?, 1, ?)"
    );
    for (const member of seed.memberships) {
      insertMembership.run(seed.group.id, member.user_id, member.active ? 1 : 0, fixed.member);
    }
    const insertBallot = db.prepare(`
      INSERT INTO ballots
        (id, group_id, title, description, method, max_selections, status, revision,
         created_by, created_at, opened_at, closed_at, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'user-ruth', ?, ?, ?, ?)
    `);
    const insertChoice = db.prepare(
      "INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)"
    );
    const insertEligible = db.prepare(
      "INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)"
    );
    const insertParticipant = db.prepare(
      "INSERT INTO participation (ballot_id, user_id, submitted_at, receipt_id) VALUES (?, ?, ?, ?)"
    );
    const insertVote = db.prepare(
      "INSERT INTO anonymous_votes (id, ballot_id, choice_id, cast_at) VALUES (?, ?, ?, ?)"
    );
    for (const ballot of seed.ballots) {
      const opened = ballot.status === "draft" ? null : fixed.open;
      const closed = ["closed", "published"].includes(ballot.status) ? fixed.closed : null;
      const published = ballot.status === "published" ? fixed.published : null;
      insertBallot.run(
        ballot.id,
        seed.group.id,
        ballot.title,
        ballot.description,
        ballot.method,
        ballot.max_selections,
        ballot.status,
        ballot.revision,
        fixed.draft,
        opened,
        closed,
        published
      );
      ballot.choices.forEach((choice, index) =>
        insertChoice.run(choice.id, ballot.id, choice.label, index)
      );
      for (const userId of ballot.eligible_user_ids || []) {
        insertEligible.run(ballot.id, userId);
      }
      (ballot.participant_user_ids || []).forEach((userId, index) => {
        insertParticipant.run(
          ballot.id,
          userId,
          fixed.closed,
          `seed-receipt-${ballot.id}-${index + 1}`
        );
      });
      (ballot.anonymous_choice_ids || []).forEach((choiceId, index) => {
        insertVote.run(`seed-vote-${ballot.id}-${index + 1}`, ballot.id, choiceId, fixed.closed);
      });
    }
    const insertAudit = db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES (?, 'ballot', ?, 'user-ruth', 'Ruth Adebayo', ?, ?)
    `);
    insertAudit.run("created", "ballot-draft-picnic", "Created draft Annual picnic date", fixed.draft);
    insertAudit.run("opened", "ballot-open-courtyard", "Opened Courtyard closing time with 2 eligible Members", fixed.open);
    insertAudit.run("closed", "ballot-closed-improvements", "Closed Shared-space improvements", fixed.closed);
    insertAudit.run("published", "ballot-published-garden", "Published anonymous results for Garden location", fixed.published);
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('membership_paused', 'member', 'user-owen', 'user-ruth', 'Ruth Adebayo',
              'Paused Owen Park for future eligibility snapshots', ?)
    `).run(fixed.member);
    db.prepare("INSERT INTO seed_state (key, value) VALUES ('bootstrap-v1', ?)").run(
      String(seed.schema_version)
    );
  })();
}

seedApplication();

function cleanExpiredSessions() {
  db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(now());
}

function parseCookies(request) {
  const values = {};
  for (const part of (request.headers.cookie || "").split(";")) {
    const separator = part.indexOf("=");
    if (separator < 0) continue;
    values[part.slice(0, separator).trim()] = decodeURIComponent(part.slice(separator + 1).trim());
  }
  return values;
}

function currentUser(request) {
  cleanExpiredSessions();
  const token = parseCookies(request).cg_session;
  if (!token) return null;
  return db.prepare(`
    SELECT u.id, u.name, u.email, u.role, s.token_hash
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > ?
  `).get(tokenHash(token), now()) || null;
}

function requireUser(request, _response, next) {
  const user = currentUser(request);
  if (!user) return next(new ApiError(401, "Please sign in to continue."));
  request.user = user;
  next();
}

function requireRole(...roles) {
  return (request, _response, next) => {
    if (!roles.includes(request.user.role)) {
      return next(new ApiError(403, "Your role cannot perform this action."));
    }
    next();
  };
}

function requireObject(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ApiError(400, "A valid request body is required.");
  }
}

function exactKeys(value, allowed) {
  requireObject(value);
  const extras = Object.keys(value).filter((key) => !allowed.includes(key));
  if (extras.length) throw new ApiError(400, `Unexpected field: ${extras[0]}.`);
}

function text(value, label, max, required = true) {
  if (typeof value !== "string") throw new ApiError(400, `${label} must be text.`);
  const cleaned = value.trim();
  if (required && !cleaned) throw new ApiError(400, `${label} is required.`);
  if (cleaned.length > max) throw new ApiError(400, `${label} is too long.`);
  return cleaned;
}

app.get("/api/health", (_request, response) => {
  response.json({ ok: true, service: "common-ground-ballot" });
});

app.post("/api/auth/login", (request, response, next) => {
  try {
    exactKeys(request.body, ["email", "password"]);
    const email = text(request.body.email, "Email", 240).toLowerCase();
    const password = typeof request.body.password === "string" ? request.body.password : "";
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user || !passwordMatches(password, user.password_salt, user.password_hash)) {
      throw new ApiError(401, "Email or password is incorrect.");
    }
    const token = crypto.randomBytes(32).toString("base64url");
    const createdAt = now();
    const expiresAt = new Date(Date.now() + SESSION_SECONDS * 1000).toISOString();
    db.prepare(
      "INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)"
    ).run(tokenHash(token), user.id, createdAt, expiresAt);
    response.setHeader(
      "Set-Cookie",
      `cg_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_SECONDS}`
    );
    response.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/logout", requireUser, (request, response) => {
  db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(request.user.token_hash);
  response.setHeader("Set-Cookie", "cg_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0");
  response.json({ ok: true });
});

app.post("/api/auth/logout-all", requireUser, (request, response) => {
  db.prepare("DELETE FROM sessions WHERE user_id = ?").run(request.user.id);
  response.setHeader("Set-Cookie", "cg_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0");
  response.json({ ok: true, message: "All Common Ground sessions were ended." });
});

app.get("/api/me", (request, response) => {
  const user = currentUser(request);
  response.json({
    user: user ? { id: user.id, name: user.name, email: user.email, role: user.role } : null,
  });
});

const getGroup = () => db.prepare("SELECT id FROM groups LIMIT 1").get();

function getActiveMemberships(groupId) {
  return db.prepare(`
    SELECT u.id, u.name, m.active, m.revision
    FROM memberships m
    JOIN users u ON u.id = m.user_id
    WHERE m.group_id = ?
    ORDER BY u.name
  `).all(groupId);
}

function getEligibleMembers(ballotId) {
  return db.prepare(`
    SELECT u.id, u.name FROM eligibility e
    JOIN users u ON u.id = e.user_id
    WHERE e.ballot_id = ? ORDER BY u.name
  `).all(ballotId);
}

function participationByBallot(ballotId) {
  return db.prepare(`
    SELECT user_id FROM participation WHERE ballot_id = ?
  `).all(ballotId).map(r => r.user_id);
}

function countVotesByChoice(ballotId) {
  return db.prepare(`
    SELECT choice_id, COUNT(*) as count FROM anonymous_votes
    WHERE ballot_id = ? GROUP BY choice_id
  `).all(ballotId);
}

function choiceById(choiceId) {
  return db.prepare("SELECT * FROM choices WHERE id = ?").get(choiceId);
}

function ballotById(id) {
  return db.prepare("SELECT * FROM ballots WHERE id = ?").get(id);
}

function choicesByBallot(ballotId) {
  return db.prepare(`
    SELECT id, label, position FROM choices WHERE ballot_id = ?
    ORDER BY position
  `).all(ballotId);
}

function userById(id) {
  return db.prepare("SELECT id, name, email, role FROM users WHERE id = ?").get(id);
}

function hasUserVoted(ballotId, userId) {
  return !!db.prepare("SELECT 1 FROM participation WHERE ballot_id = ? AND user_id = ?").get(ballotId, userId);
}

function getReceipt(userId, operationId) {
  return db.prepare(`
    SELECT status_code, response_json FROM operation_receipts
    WHERE user_id = ? AND operation_id = ? LIMIT 1
  `).get(userId, operationId);
}

function saveReceipt(userId, operationId, action, inputFingerprint, statusCode, responseBody) {
  db.prepare(`
    INSERT OR REPLACE INTO operation_receipts
    (user_id, operation_id, action, fingerprint, status_code, response_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(userId, operationId, action, inputFingerprint, statusCode, JSON.stringify(responseBody), now());
}

function createAuditEntry(action, entityType, entityId, actor, details) {
  db.prepare(`
    INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(action, entityType, entityId, actor.id, actor.name, details, now());
}

function validatePositiveInteger(value, label) {
  const num = Number(value);
  if (!Number.isInteger(num) || num < 1) {
    throw new ApiError(400, `${label} must be a positive whole number.`);
  }
  return num;
}

function validateRevision(ballot, providedRevision, label = "Ballot") {
  const rev = validatePositiveInteger(providedRevision, "Revision");
  if (ballot.revision !== rev) {
    throw new ApiError(409, `${label} has been updated. Please refresh and try again.`);
  }
  return rev;
}

function validateMembershipRevision(membership, providedRevision) {
  const rev = validatePositiveInteger(providedRevision, "Member");
  if (membership.revision !== rev) {
    throw new ApiError(409, "Member list has been updated. Please refresh and try again.");
  }
  return rev;
}

app.post("/api/ballots", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    exactKeys(request.body, ["title", "description", "method", "max_selections", "choices", "operation_id"]);
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const title = text(request.body.title, "Title", 200);
    const description = text(request.body.description, "Description", 2000, false);
    const method = request.body.method;
    if (!["single", "approval"].includes(method)) throw new ApiError(400, "Method must be single or approval.");
    const maxSelections = validatePositiveInteger(request.body.max_selections, "Max selections");
    
    requireObject(request.body.choices);
    const choices = request.body.choices;
    if (!Array.isArray(choices)) throw new ApiError(400, "Choices must be an array.");
    if (choices.length < 2) throw new ApiError(400, "At least two choices are required.");
    
    const uniqueLabels = new Set();
    for (const choice of choices) {
      requireObject(choice);
      const label = text(choice.label, "Choice label", 200);
      if (label.length === 0) throw new ApiError(400, "Choice labels cannot be empty.");
      if (uniqueLabels.has(label)) throw new ApiError(400, "Choice labels must be unique.");
      uniqueLabels.add(label);
    }
    
    if (method === "approval" && maxSelections > choices.length) {
      throw new ApiError(400, "Max selections cannot exceed number of choices.");
    }

    const group = getGroup();
    const fingerprint = fingerprint({title, description, method, max_selections: maxSelections, choices});
    const receipt = getReceipt(request.user.id, operationId);
    
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    const ballotId = makeId("ballot");
    const createdAt = now();
    db.transaction(() => {
      db.prepare(`
        INSERT INTO ballots
        (id, group_id, title, description, method, max_selections, status, revision, created_by, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'draft', 1, ?, ?)
      `).run(ballotId, group.id, title, description, method, maxSelections, request.user.id, createdAt);
      
      choices.forEach((choice, index) => {
        db.prepare(
          "INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)"
        ).run(makeId("choice"), ballotId, choice.label, index);
      });
      
      createAuditEntry("created", "ballot", ballotId, request.user, `Created draft ${title}`);
    })();
    
    const responseBody = { ballot: { id: ballotId, status: "draft", revision: 1 } };
    saveReceipt(request.user.id, operationId, "create_ballot", fingerprint, 201, responseBody);
    response.status(201).json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.post("/api/ballots/:id/edit", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    if (ballot.status !== "draft") throw new ApiError(409, "Only draft ballots can be edited.");
    
    validateRevision(ballot, request.body.viewed_revision, "Ballot");
    
    exactKeys(request.body, ["title", "description", "method", "max_selections", "choices", "operation_id", "viewed_revision"]);
    const title = text(request.body.title, "Title", 200);
    const description = text(request.body.description, "Description", 2000, false);
    const method = request.body.method;
    if (!["single", "approval"].includes(method)) throw new ApiError(400, "Method must be single or approval.");
    const maxSelections = validatePositiveInteger(request.body.max_selections, "Max selections");
    
    if (!Array.isArray(request.body.choices)) throw new ApiError(400, "Choices must be an array.");
    if (request.body.choices.length < 2) throw new ApiError(400, "At least two choices are required.");
    
    const uniqueLabels = new Set();
    for (const choice of request.body.choices) {
      requireObject(choice);
      const label = text(choice.label, "Choice label", 200);
      if (label.length === 0) throw new ApiError(400, "Choice labels cannot be empty.");
      if (uniqueLabels.has(label)) throw new ApiError(400, "Choice labels must be unique.");
      uniqueLabels.add(label);
    }
    
    if (method === "approval" && maxSelections > request.body.choices.length) {
      throw new ApiError(400, "Max selections cannot exceed number of choices.");
    }

    const fingerprint = fingerprint({title, description, method, max_selections: maxSelections, choices: request.body.choices});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const newRevision = ballot.revision + 1;
      db.prepare(`
        UPDATE ballots SET title = ?, description = ?, method = ?, max_selections = ?, revision = ?
        WHERE id = ?
      `).run(title, description, method, maxSelections, newRevision, ballotId);
      
      db.prepare("DELETE FROM choices WHERE ballot_id = ?").run(ballotId);
      request.body.choices.forEach((choice, index) => {
        db.prepare(
          "INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)"
        ).run(makeId("choice"), ballotId, choice.label, index);
      });
      
      createAuditEntry("edited", "ballot", ballotId, request.user, `Edited draft ${title}`);
    })();
    
    const responseBody = { ballot: { id: ballotId, status: "draft", revision: ballot.revision + 1 } };
    saveReceipt(request.user.id, operationId, "edit_ballot", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.post("/api/ballots/:id/open", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    if (ballot.status !== "draft") throw new ApiError(409, "Only draft ballots can be opened.");
    
    validateRevision(ballot, request.body.viewed_revision, "Ballot");
    
    const group = getGroup();
    const members = getActiveMemberships(group.id);
    const activeMembers = members.filter(m => m.active);
    if (activeMembers.length === 0) throw new ApiError(409, "Cannot open ballot without active members.");
    
    const fingerprint = fingerprint({ballotId, viewedRevision: ballot.revision, activeMembers});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const newRevision = ballot.revision + 1;
      const openedAt = now();
      db.prepare(`
        UPDATE ballots SET status = 'open', revision = ?, opened_at = ?
        WHERE id = ?
      `).run(newRevision, openedAt, ballotId);
      
      db.prepare("DELETE FROM eligibility WHERE ballot_id = ?").run(ballotId);
      for (const member of activeMembers) {
        db.prepare("INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)").run(ballotId, member.id);
      }
      
      createAuditEntry("opened", "ballot", ballotId, request.user, `Opened ${ballot.title} with ${activeMembers.length} eligible members`);
    })();
    
    const responseBody = { ballot: { id: ballotId, status: "open", revision: ballot.revision + 1 } };
    saveReceipt(request.user.id, operationId, "open_ballot", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.post("/api/ballots/round/open", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    exactKeys(request.body, ["ballot_ids", "viewed_revisions", "viewed_memberships", "operation_id"]);
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    
    if (!Array.isArray(request.body.ballot_ids)) throw new ApiError(400, "Ballot IDs must be an array.");
    const ballotIds = request.body.ballot_ids;
    if (ballotIds.length < 2) throw new ApiError(400, "At least two ballots are required.");
    if (new Set(ballotIds).size !== ballotIds.length) throw new ApiError(400, "Duplicate ballots in round.");
    
    if (!Array.isArray(request.body.viewed_revisions)) throw new ApiError(400, "Viewed revisions must be an array.");
    if (request.body.viewed_revisions.length !== ballotIds.length) throw new ApiError(400, "Revisions must match ballot count.");
    
    if (!Array.isArray(request.body.viewed_memberships)) throw new ApiError(400, "Viewed memberships must be an array.");
    
    const group = getGroup();
    const ballots = [];
    const revisionMap = {};
    
    for (let i = 0; i < ballotIds.length; i++) {
      const ballot = ballotById(ballotIds[i]);
      if (!ballot) throw new ApiError(400, `Ballot ${ballotIds[i]} not found.`);
      if (ballot.status !== "draft") throw new ApiError(409, `Ballot ${ballot.title} is not a draft.`);
      if (ballot.group_id !== group.id) throw new ApiError(400, "Ballot from different group.");
      validateRevision(ballot, request.body.viewed_revisions[i], "Ballot");
      revisionMap[ballot.id] = ballot.revision;
      ballots.push(ballot);
    }
    
    const currentMembers = getActiveMemberships(group.id);
    const membershipFingerprint = fingerprint(request.body.viewed_memberships);
    const currentFingerprint = fingerprint(currentMembers);
    if (membershipFingerprint !== currentFingerprint) {
      throw new ApiError(409, "Member list has changed. Please review again before confirming.");
    }
    
    const activeMembers = currentMembers.filter(m => m.active);
    if (activeMembers.length === 0) throw new ApiError(409, "Cannot open round without active members.");
    
    const fingerprint = fingerprint({ballotIds, viewedRevisions: request.body.viewed_revisions, viewedMemberships: request.body.viewed_memberships});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const openedAt = now();
      for (const ballot of ballots) {
        const newRevision = revisionMap[ballot.id] + 1;
        db.prepare(`
          UPDATE ballots SET status = 'open', revision = ?, opened_at = ?
          WHERE id = ?
        `).run(newRevision, openedAt, ballot.id);
        
        db.prepare("DELETE FROM eligibility WHERE ballot_id = ?").run(ballot.id);
        for (const member of activeMembers) {
          db.prepare("INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)").run(ballot.id, member.id);
        }
        
        createAuditEntry("opened", "ballot", ballot.id, request.user, `Opened ${ballot.title} with ${activeMembers.length} eligible members`);
      }
    })();
    
    const responseBody = {
      round: {
        ballot_ids: ballotIds,
        status: "opened",
        count: ballots.length
      }
    };
    saveReceipt(request.user.id, operationId, "open_round", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.post("/api/ballots/:id/close", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    if (ballot.status !== "open") throw new ApiError(409, "Only open ballots can be closed.");
    
    validateRevision(ballot, request.body.viewed_revision, "Ballot");
    
    const fingerprint = fingerprint({ballotId, viewedRevision: ballot.revision});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const newRevision = ballot.revision + 1;
      const closedAt = now();
      db.prepare(`
        UPDATE ballots SET status = 'closed', revision = ?, closed_at = ?
        WHERE id = ?
      `).run(newRevision, closedAt, ballotId);
      
      createAuditEntry("closed", "ballot", ballotId, request.user, `Closed ${ballot.title}`);
    })();
    
    const responseBody = { ballot: { id: ballotId, status: "closed", revision: ballot.revision + 1 } };
    saveReceipt(request.user.id, operationId, "close_ballot", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.post("/api/ballots/:id/publish", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    if (ballot.status !== "closed") throw new ApiError(409, "Only closed ballots can be published.");
    
    validateRevision(ballot, request.body.viewed_revision, "Ballot");
    
    const fingerprint = fingerprint({ballotId, viewedRevision: ballot.revision});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const newRevision = ballot.revision + 1;
      const publishedAt = now();
      db.prepare(`
        UPDATE ballots SET status = 'published', revision = ?, published_at = ?
        WHERE id = ?
      `).run(newRevision, publishedAt, ballotId);
      
      createAuditEntry("published", "ballot", ballotId, request.user, `Published anonymous results for ${ballot.title}`);
    })();
    
    const responseBody = { ballot: { id: ballotId, status: "published", revision: ballot.revision + 1 } };
    saveReceipt(request.user.id, operationId, "publish_ballot", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.get("/api/ballots", requireUser, (request, response, next) => {
  try {
    const group = getGroup();
    const allBallots = db.prepare(`
      SELECT id, title, description, method, max_selections, status, revision, created_at
      FROM ballots WHERE group_id = ? ORDER BY created_at DESC
    `).all(group.id);
    
    const ballots = allBallots.map(ballot => {
      const choices = choicesByBallot(ballot.id);
      const eligible = getEligibleMembers(ballot.id);
      const participation = participationByBallot(ballot.id);
      let userParticipation = null;
      
      if (request.user.role === "member") {
        userParticipation = participation.includes(request.user.id);
      }
      
      const result = {
        id: ballot.id,
        title: ballot.title,
        description: ballot.description,
        method: ballot.method,
        max_selections: ballot.max_selections,
        status: ballot.status,
        revision: ballot.revision,
        choices: choices,
        eligible_count: request.user.role !== "member" ? eligible.length : undefined,
        user_eligible: request.user.role === "member" ? eligible.map(e => e.id).includes(request.user.id) : undefined,
        user_participated: request.user.role === "member" ? userParticipation : undefined,
      };
      
      if (request.user.role !== "member") {
        result.participation_count = participation.length;
      }
      
      return result;
    });
    
    response.json({ ballots });
  } catch (error) {
    next(error);
  }
});

app.get("/api/ballots/:id/vote-state", requireUser, requireRole("member"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    if (ballot.status !== "open") throw new ApiError(409, "This ballot is not open for voting.");
    
    const eligible = db.prepare("SELECT 1 FROM eligibility WHERE ballot_id = ? AND user_id = ? LIMIT 1").get(ballotId, request.user.id);
    if (!eligible) throw new ApiError(403, "You are not eligible for this ballot.");
    
    const hasVoted = hasUserVoted(ballotId, request.user.id);
    if (hasVoted) throw new ApiError(409, "You have already voted on this ballot.");
    
    const choices = choicesByBallot(ballotId);
    response.json({
      ballot: {
        id: ballotId,
        title: ballot.title,
        description: ballot.description,
        method: ballot.method,
        max_selections: ballot.max_selections,
        choices: choices
      }
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/ballots/:id/vote", requireUser, requireRole("member"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    if (ballot.status !== "open") throw new ApiError(409, "This ballot is not open for voting.");
    
    const eligible = db.prepare("SELECT 1 FROM eligibility WHERE ballot_id = ? AND user_id = ? LIMIT 1").get(ballotId, request.user.id);
    if (!eligible) throw new ApiError(403, "You are not eligible for this ballot.");
    
    if (hasUserVoted(ballotId, request.user.id)) throw new ApiError(409, "You have already voted on this ballot.");
    
    if (!Array.isArray(request.body.choice_ids)) throw new ApiError(400, "Choice IDs must be an array.");
    const choiceIds = request.body.choice_ids;
    
    if (ballot.method === "single" && choiceIds.length !== 1) {
      throw new ApiError(400, "Single-choice ballot requires exactly one selection.");
    }
    
    if (ballot.method === "approval") {
      if (choiceIds.length === 0) throw new ApiError(400, "At least one choice required.");
      if (choiceIds.length > ballot.max_selections) throw new ApiError(400, `Maximum ${ballot.max_selections} selections allowed.`);
    }
    
    if (new Set(choiceIds).size !== choiceIds.length) throw new ApiError(400, "Duplicate choices in vote.");
    
    const choices = choicesByBallot(ballotId);
    const validChoiceIds = new Set(choices.map(c => c.id));
    for (const choiceId of choiceIds) {
      if (!validChoiceIds.has(choiceId)) throw new ApiError(400, "Invalid choice for this ballot.");
    }
    
    const fingerprint = fingerprint({ballotId, choiceIds});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const receiptId = makeId("vote-receipt");
      const submittedAt = now();
      db.prepare(
        "INSERT INTO participation (ballot_id, user_id, submitted_at, receipt_id) VALUES (?, ?, ?, ?)"
      ).run(ballotId, request.user.id, submittedAt, receiptId);
      
      for (const choiceId of choiceIds) {
        db.prepare(
          "INSERT INTO anonymous_votes (id, ballot_id, choice_id, cast_at) VALUES (?, ?, ?, ?)"
        ).run(makeId("vote"), ballotId, choiceId, submittedAt);
      }
    })();
    
    const responseBody = { participated: true };
    saveReceipt(request.user.id, operationId, "vote", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.get("/api/ballots/:id/turnout", requireUser, (request, response, next) => {
  try {
    if (!["coordinator", "observer"].includes(request.user.role)) {
      throw new ApiError(403, "You cannot view turnout.");
    }
    
    const ballotId = request.params.id;
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    
    if (["draft"].includes(ballot.status)) {
      throw new ApiError(409, "Turnout is not available for draft ballots.");
    }
    
    const eligible = getEligibleMembers(ballotId);
    const participants = participationByBallot(ballotId);
    const participated = new Set(participants);
    
    const turnout = eligible.map(member => ({
      user_id: member.id,
      user_name: member.name,
      participated: participated.has(member.id)
    }));
    
    response.json({
      ballot: {
        id: ballotId,
        title: ballot.title,
        status: ballot.status,
        eligible_count: eligible.length,
        participation_count: participants.length
      },
      turnout: turnout
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/ballots/:id/results", requireUser, (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const ballot = ballotById(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    
    if (ballot.status !== "published") {
      if (request.user.role === "member") {
        throw new ApiError(403, "Results are not yet published.");
      }
      throw new ApiError(409, "Results are only available after publication.");
    }
    
    const choices = choicesByBallot(ballotId);
    const participants = participationByBallot(ballotId);
    const votesByChoice = countVotesByChoice(ballotId);
    const voteMap = new Map(votesByChoice.map(v => [v.choice_id, v.count]));
    
    let results;
    if (ballot.method === "single") {
      const choiceResults = choices.map(choice => ({
        choice_id: choice.id,
        choice_label: choice.label,
        count: voteMap.get(choice.id) || 0
      }));
      
      const maxCount = Math.max(...choiceResults.map(c => c.count), 0);
      const leaders = choiceResults.filter(c => c.count === maxCount && c.count > 0);
      
      results = {
        method: "single",
        total_ballots: participants.length,
        choices: choiceResults,
        leader: leaders.length === 1 ? leaders[0] : null,
        tied_leaders: leaders.length > 1 ? leaders : null
      };
    } else {
      const choiceResults = choices.map(choice => {
        const count = voteMap.get(choice.id) || 0;
        const percentage = participants.length > 0 ? ((count / participants.length) * 100).toFixed(1) : "0.0";
        return {
          choice_id: choice.id,
          choice_label: choice.label,
          approvals: count,
          percentage: parseFloat(percentage)
        };
      });
      
      results = {
        method: "approval",
        participating_members: participants.length,
        choices: choiceResults
      };
    }
    
    response.json({
      ballot: {
        id: ballotId,
        title: ballot.title,
        status: ballot.status
      },
      results
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/members", requireUser, (request, response, next) => {
  try {
    if (!["coordinator", "observer"].includes(request.user.role)) {
      throw new ApiError(403, "You cannot view the member list.");
    }
    
    const group = getGroup();
    const members = getActiveMemberships(group.id);
    
    const memberList = members.map(m => ({
      user_id: m.id,
      user_name: m.name,
      active: m.active === 1,
      revision: m.revision
    }));
    
    response.json({
      members: memberList,
      roster_fingerprint: fingerprint(memberList)
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/members/:id/activate", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const userId = request.params.id;
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const user = userById(userId);
    if (!user) throw new ApiError(404, "User not found.");
    if (user.role === "coordinator" || user.role === "observer") {
      throw new ApiError(400, "Can only manage member memberships.");
    }
    
    const group = getGroup();
    const membership = db.prepare(
      "SELECT * FROM memberships WHERE group_id = ? AND user_id = ?"
    ).get(group.id, userId);
    if (!membership) throw new ApiError(404, "Membership not found.");
    
    if (membership.active === 1) throw new ApiError(409, "Member is already active.");
    
    validateMembershipRevision(membership, request.body.viewed_revision);
    
    const fingerprint = fingerprint({userId, viewedRevision: membership.revision, action: "activate"});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const newRevision = membership.revision + 1;
      db.prepare(
        "UPDATE memberships SET active = 1, revision = ?, updated_at = ? WHERE group_id = ? AND user_id = ?"
      ).run(newRevision, now(), group.id, userId);
      
      createAuditEntry("membership_activated", "member", userId, request.user, `Activated ${user.name} for future eligibility snapshots`);
    })();
    
    const responseBody = { user: { id: userId, active: true, revision: membership.revision + 1 } };
    saveReceipt(request.user.id, operationId, "activate_member", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.post("/api/members/:id/pause", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const userId = request.params.id;
    const operationId = text(request.body.operation_id, "Operation ID", 100);
    const user = userById(userId);
    if (!user) throw new ApiError(404, "User not found.");
    if (user.role === "coordinator" || user.role === "observer") {
      throw new ApiError(400, "Can only manage member memberships.");
    }
    
    const group = getGroup();
    const membership = db.prepare(
      "SELECT * FROM memberships WHERE group_id = ? AND user_id = ?"
    ).get(group.id, userId);
    if (!membership) throw new ApiError(404, "Membership not found.");
    
    if (membership.active === 0) throw new ApiError(409, "Member is already paused.");
    
    validateMembershipRevision(membership, request.body.viewed_revision);
    
    const fingerprint = fingerprint({userId, viewedRevision: membership.revision, action: "pause"});
    const receipt = getReceipt(request.user.id, operationId);
    if (receipt) {
      return response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
    }

    db.transaction(() => {
      const newRevision = membership.revision + 1;
      db.prepare(
        "UPDATE memberships SET active = 0, revision = ?, updated_at = ? WHERE group_id = ? AND user_id = ?"
      ).run(newRevision, now(), group.id, userId);
      
      createAuditEntry("membership_paused", "member", userId, request.user, `Paused ${user.name} for future eligibility snapshots`);
    })();
    
    const responseBody = { user: { id: userId, active: false, revision: membership.revision + 1 } };
    saveReceipt(request.user.id, operationId, "pause_member", fingerprint, 200, responseBody);
    response.json(responseBody);
  } catch (error) {
    next(error);
  }
});

app.get("/api/audit", requireUser, (request, response, next) => {
  try {
    if (!["coordinator", "observer"].includes(request.user.role)) {
      throw new ApiError(403, "You cannot view the audit log.");
    }
    
    const entries = db.prepare(`
      SELECT id, action, entity_type, entity_id, actor_label, details, created_at
      FROM audit ORDER BY id DESC LIMIT 100
    `).all();
    
    response.json({ audit: entries });
  } catch (error) {
    next(error);
  }
});

app.use('/api', (_request, response) => response.status(404).json({error: 'Not found'}));

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.get(/.*/, (_request, response) => response.sendFile(path.join(__dirname, "public", "index.html")));

app.use((error, _request, response, _next) => {
  if (error instanceof SyntaxError && "body" in error) {
    return response.status(400).json({ error: "Request body must be valid JSON." });
  }
  if (error instanceof ApiError) return response.status(error.status).json(error.body);
  console.error(error);
  response.status(500).json({ error: "Something went wrong on the server." });
});

const server = app.listen(PORT, "0.0.0.0", () => {
  console.log(`Common Ground listening on ${PORT}`);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
