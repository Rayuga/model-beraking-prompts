# Common Ground notes

- Node.js 22 + Express + better-sqlite3.
- SQLite database defaults to `/app/commonground.db`; `DB_PATH` overrides it.
- Seed data defaults to `/app/common_ground_seed.json`; `SEED_PATH` overrides it.
- Seed import is one-time via `seed_state` and must not duplicate on restart.
- Sessions are cookie-backed (`cg_session`) and stored hashed in SQLite.
- Operation receipts are keyed by user and operation id; exact retries return the original body.
- Ballot rounds use reviewed ballot revisions plus a roster fingerprint so stale confirmations fail safely.
- Keep turnout, results, members, and audit projections role-aware and privacy-preserving.
- UI state is a single-page app with pending actions stored per user in localStorage.
