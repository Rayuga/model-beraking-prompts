const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const Database = require('better-sqlite3');

const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DB_PATH || '/app/commonground.db';
const SEED_PATH = process.env.SEED_PATH || '/app/common_ground_seed.json';
const PASSWORD = 'CommonGround!2026';
const SESSION_SECONDS = 8 * 60 * 60;
const GROUP_ID = 'group-riverside';
const GROUP_NAME = 'Riverside Residents Association';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '256kb', strict: true }));
app.use((request, response, next) => {
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Referrer-Policy', 'same-origin');
  if (request.path.startsWith('/api/')) response.setHeader('Cache-Control', 'no-store');
  next();
});

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS seed_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK (role IN ('coordinator', 'observer', 'member')),
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS groups (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS memberships (
    group_id TEXT NOT NULL REFERENCES groups(id),
    user_id TEXT NOT NULL REFERENCES users(id),
    active INTEGER NOT NULL CHECK (active IN (0, 1)),
    revision INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (group_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS ballots (
    id TEXT PRIMARY KEY,
    group_id TEXT NOT NULL REFERENCES groups(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    method TEXT NOT NULL CHECK (method IN ('single', 'approval')),
    max_selections INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft', 'open', 'closed', 'published')),
    revision INTEGER NOT NULL,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    opened_at TEXT,
    closed_at TEXT,
    published_at TEXT
  );
  CREATE TABLE IF NOT EXISTS choices (
    id TEXT PRIMARY KEY,
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    position INTEGER NOT NULL,
    UNIQUE (ballot_id, position)
  );
  CREATE TABLE IF NOT EXISTS eligibility (
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id),
    PRIMARY KEY (ballot_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS participation (
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id),
    submitted_at TEXT NOT NULL,
    receipt_id TEXT NOT NULL UNIQUE,
    PRIMARY KEY (ballot_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS anonymous_votes (
    id TEXT PRIMARY KEY,
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    choice_id TEXT NOT NULL REFERENCES choices(id) ON DELETE CASCADE,
    cast_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS operation_receipts (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    operation_id TEXT NOT NULL,
    action TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    status_code INTEGER NOT NULL,
    response_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, operation_id)
  );
  CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    actor_id TEXT REFERENCES users(id),
    actor_label TEXT NOT NULL,
    details TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ballots_status ON ballots(status);
  CREATE INDEX IF NOT EXISTS idx_choices_ballot ON choices(ballot_id, position);
  CREATE INDEX IF NOT EXISTS idx_votes_ballot ON anonymous_votes(ballot_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
  CREATE INDEX IF NOT EXISTS idx_audit_created ON audit(id DESC);
`);

class ApiError extends Error {
  constructor(status, message, extra = {}, persistReceipt = false) {
    super(message);
    this.status = status;
    this.body = { error: message, ...extra };
    this.persistReceipt = persistReceipt;
  }
}

const now = () => new Date().toISOString();
const makeId = (prefix) => `${prefix}-${crypto.randomUUID()}`;
const tokenHash = (token) => crypto.createHash('sha256').update(token).digest('hex');
const fingerprint = (value) => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');

function passwordRecord(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return { salt, hash: crypto.scryptSync(password, salt, 64).toString('hex') };
}

function passwordMatches(password, salt, expected) {
  const actual = crypto.scryptSync(password, salt, 64);
  const stored = Buffer.from(expected, 'hex');
  return stored.length === actual.length && crypto.timingSafeEqual(actual, stored);
}

function seedApplication() {
  if (db.prepare("SELECT 1 FROM seed_state WHERE key = 'bootstrap-v1'").get()) return;
  const seed = JSON.parse(fs.readFileSync(SEED_PATH, 'utf8'));
  const fixed = {
    draft: '2026-08-04T09:00:00.000Z',
    open: '2026-08-05T10:00:00.000Z',
    closed: '2026-08-06T11:00:00.000Z',
    published: '2026-08-07T12:00:00.000Z',
    member: '2026-08-08T13:00:00.000Z',
  };
  db.transaction(() => {
    db.prepare('INSERT INTO groups (id, name) VALUES (?, ?)').run(seed.group.id, seed.group.name);
    const insertUser = db.prepare(
      'INSERT INTO users (id, name, email, role, password_hash, password_salt) VALUES (?, ?, ?, ?, ?, ?)'
    );
    for (const user of seed.users) {
      const password = passwordRecord(PASSWORD);
      insertUser.run(user.id, user.name, user.email, user.role, password.hash, password.salt);
    }
    const insertMembership = db.prepare(
      'INSERT INTO memberships (group_id, user_id, active, revision, updated_at) VALUES (?, ?, ?, 1, ?)'
    );
    for (const member of seed.memberships) {
      insertMembership.run(seed.group.id, member.user_id, member.active ? 1 : 0, fixed.member);
    }
    const insertBallot = db.prepare(`
      INSERT INTO ballots
        (id, group_id, title, description, method, max_selections, status, revision,
         created_by, created_at, opened_at, closed_at, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'user-ruth', ?, ?, ?, ?)
    `);
    const insertChoice = db.prepare(
      'INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)'
    );
    const insertEligible = db.prepare('INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)');
    const insertParticipant = db.prepare(
      'INSERT INTO participation (ballot_id, user_id, submitted_at, receipt_id) VALUES (?, ?, ?, ?)'
    );
    const insertVote = db.prepare(
      'INSERT INTO anonymous_votes (id, ballot_id, choice_id, cast_at) VALUES (?, ?, ?, ?)'
    );
    for (const ballot of seed.ballots) {
      const opened = ballot.status === 'draft' ? null : fixed.open;
      const closed = ['closed', 'published'].includes(ballot.status) ? fixed.closed : null;
      const published = ballot.status === 'published' ? fixed.published : null;
      insertBallot.run(
        ballot.id,
        seed.group.id,
        ballot.title,
        ballot.description,
        ballot.method,
        ballot.max_selections,
        ballot.status,
        ballot.revision,
        fixed.draft,
        opened,
        closed,
        published
      );
      ballot.choices.forEach((choice, index) => insertChoice.run(choice.id, ballot.id, choice.label, index));
      for (const userId of ballot.eligible_user_ids || []) insertEligible.run(ballot.id, userId);
      (ballot.participant_user_ids || []).forEach((userId, index) => {
        insertParticipant.run(ballot.id, userId, fixed.closed, `seed-receipt-${ballot.id}-${index + 1}`);
      });
      (ballot.anonymous_choice_ids || []).forEach((choiceId, index) => {
        insertVote.run(`seed-vote-${ballot.id}-${index + 1}`, ballot.id, choiceId, fixed.closed);
      });
    }
    const insertAudit = db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES (?, 'ballot', ?, 'user-ruth', 'Ruth Adebayo', ?, ?)
    `);
    insertAudit.run('created', 'ballot-draft-picnic', 'Created draft Annual picnic date', fixed.draft);
    insertAudit.run('opened', 'ballot-open-courtyard', 'Opened Courtyard closing time with 2 eligible Members', fixed.open);
    insertAudit.run('closed', 'ballot-closed-improvements', 'Closed Shared-space improvements', fixed.closed);
    insertAudit.run('published', 'ballot-published-garden', 'Published anonymous results for Garden location', fixed.published);
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('membership_paused', 'member', 'user-owen', 'user-ruth', 'Ruth Adebayo',
              'Paused Owen Park for future eligibility snapshots', ?)
    `).run(fixed.member);
    db.prepare("INSERT INTO seed_state (key, value) VALUES ('bootstrap-v1', ?)").run(
      String(seed.schema_version)
    );
  })();
}

seedApplication();

function cleanExpiredSessions() {
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(now());
}

function parseCookies(request) {
  const values = {};
  for (const part of (request.headers.cookie || '').split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0) continue;
    values[part.slice(0, separator).trim()] = decodeURIComponent(part.slice(separator + 1).trim());
  }
  return values;
}

function currentUser(request) {
  cleanExpiredSessions();
  const token = parseCookies(request).cg_session;
  if (!token) return null;
  return (
    db.prepare(`
      SELECT u.id, u.name, u.email, u.role, s.token_hash
      FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ? AND s.expires_at > ?
    `).get(tokenHash(token), now()) || null
  );
}

function requireUser(request, _response, next) {
  const user = currentUser(request);
  if (!user) return next(new ApiError(401, 'Please sign in to continue.'));
  request.user = user;
  next();
}

function requireRole(...roles) {
  return (request, _response, next) => {
    if (!roles.includes(request.user.role)) {
      return next(new ApiError(403, 'Your role cannot perform this action.'));
    }
    next();
  };
}

function requireObject(value, message = 'A valid request body is required.') {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new ApiError(400, message);
  }
}

function exactKeys(value, allowed) {
  requireObject(value);
  const extras = Object.keys(value).filter((key) => !allowed.includes(key));
  if (extras.length) throw new ApiError(400, `Unexpected field: ${extras[0]}.`);
}

function text(value, label, max, required = true) {
  if (typeof value !== 'string') throw new ApiError(400, `${label} must be text.`);
  const cleaned = value.trim();
  if (required && !cleaned) throw new ApiError(400, `${label} is required.`);
  if (cleaned.length > max) throw new ApiError(400, `${label} is too long.`);
  return cleaned;
}

function optionalText(value, label, max) {
  if (value === undefined || value === null) return '';
  return text(value, label, max, false);
}

function positiveInteger(value, label) {
  if (typeof value === 'number' && Number.isInteger(value) && value > 0) return value;
  if (typeof value === 'string' && /^(0|[1-9]\d*)$/.test(value.trim())) {
    const parsed = Number(value.trim());
    if (parsed > 0) return parsed;
  }
  throw new ApiError(400, `${label} must be a positive whole number.`);
}

function nonNegativeInteger(value, label) {
  if (typeof value === 'number' && Number.isInteger(value) && value >= 0) return value;
  if (typeof value === 'string' && /^(0|[1-9]\d*)$/.test(value.trim())) return Number(value.trim());
  throw new ApiError(400, `${label} must be a whole number.`);
}

function parseStatus(value) {
  const status = text(value, 'Membership status', 16).toLowerCase();
  if (status !== 'active' && status !== 'paused') {
    throw new ApiError(400, 'Membership status must be active or paused.');
  }
  return status;
}

function parseMethod(value) {
  const method = text(value, 'Voting method', 16).toLowerCase();
  if (method !== 'single' && method !== 'approval') {
    throw new ApiError(400, 'Voting method must be single or approval.');
  }
  return method;
}

function uniqueStrings(values, label) {
  if (!Array.isArray(values)) throw new ApiError(400, `${label} must be an array.`);
  const items = values.map((value, index) => {
    if (typeof value !== 'string') throw new ApiError(400, `${label} item ${index + 1} must be text.`);
    const cleaned = value.trim();
    if (!cleaned) throw new ApiError(400, `${label} item ${index + 1} is required.`);
    return cleaned;
  });
  if (new Set(items).size !== items.length) throw new ApiError(400, `${label} cannot repeat values.`);
  return items;
}

function arrayOfIds(values, label) {
  if (!Array.isArray(values)) throw new ApiError(400, `${label} must be an array.`);
  const ids = values.map((value, index) => {
    if (typeof value !== 'string') throw new ApiError(400, `${label} item ${index + 1} must be text.`);
    const cleaned = value.trim();
    if (!cleaned) throw new ApiError(400, `${label} item ${index + 1} is required.`);
    return cleaned;
  });
  return ids;
}

function requestOperationId(value) {
  const operationId = text(value, 'Operation identifier', 128);
  return operationId;
}

function canonicalReceiptPayload(action, payload) {
  return { action, payload };
}

function savedReceipt(userId, operationId) {
  return db.prepare('SELECT * FROM operation_receipts WHERE user_id = ? AND operation_id = ?').get(userId, operationId) || null;
}

function sendStoredReceipt(response, receipt) {
  response.status(receipt.status_code).json(JSON.parse(receipt.response_json));
}

function writeReceipt(userId, operationId, action, receiptPayload, statusCode, body) {
  db.prepare(`
    INSERT OR REPLACE INTO operation_receipts
      (user_id, operation_id, action, fingerprint, status_code, response_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(userId, operationId, action, fingerprint(receiptPayload), statusCode, JSON.stringify(body), now());
}

function persistBusinessRefusal(request, response, action, payloadBuilder, error) {
  if (!(error instanceof ApiError) || !error.persistReceipt) return false;
  try {
    const operationId = requestOperationId(request.body.operation_id);
    const receiptPayload = canonicalReceiptPayload(action, payloadBuilder());
    writeReceipt(request.user.id, operationId, action, receiptPayload, error.status, error.body);
    response.status(error.status).json(error.body);
    return true;
  } catch {
    return false;
  }
}

function runOperation(request, response, action, payload, handler) {
  const operationId = requestOperationId(request.body.operation_id);
  const receipt = savedReceipt(request.user.id, operationId);
  const receiptFingerprint = fingerprint(canonicalReceiptPayload(action, payload));
  if (receipt) {
    if (receipt.action !== action || receipt.fingerprint !== receiptFingerprint) {
      throw new ApiError(409, 'That operation identifier was already used for different input.');
    }
    return sendStoredReceipt(response, receipt);
  }
  try {
    const result = handler();
    const statusCode = result.statusCode || 200;
    const body = result.body || {};
    writeReceipt(request.user.id, operationId, action, payload, statusCode, body);
    return response.status(statusCode).json(body);
  } catch (error) {
    if (error instanceof ApiError && error.persistReceipt) {
      writeReceipt(request.user.id, operationId, action, payload, error.status, error.body);
      return response.status(error.status).json(error.body);
    }
    throw error;
  }
}

function actorLabel(user) {
  return user ? user.name : 'Common Ground';
}

function isCoordinator(user) {
  return user && user.role === 'coordinator';
}

function isObserver(user) {
  return user && user.role === 'observer';
}

function isMember(user) {
  return user && user.role === 'member';
}

function groupRow() {
  return db.prepare('SELECT id, name FROM groups WHERE id = ?').get(GROUP_ID);
}

function getUsersMap() {
  const rows = db.prepare('SELECT id, name, email, role FROM users ORDER BY name').all();
  const map = new Map();
  for (const row of rows) map.set(row.id, row);
  return map;
}

function getMembershipRows() {
  const users = getUsersMap();
  return db.prepare(`
    SELECT m.group_id, m.user_id, m.active, m.revision, m.updated_at
    FROM memberships m
    WHERE m.group_id = ?
    ORDER BY (SELECT name FROM users u WHERE u.id = m.user_id)
  `).all(GROUP_ID).map((row) => ({
    user_id: row.user_id,
    name: users.get(row.user_id)?.name || row.user_id,
    email: users.get(row.user_id)?.email || '',
    role: users.get(row.user_id)?.role || 'member',
    active: Boolean(row.active),
    revision: row.revision,
    updated_at: row.updated_at,
  }));
}

function rosterVersion(rows = getMembershipRows()) {
  return fingerprint(rows.map((row) => ({ user_id: row.user_id, active: row.active, revision: row.revision })));
}

function getBallotRows() {
  return db.prepare(`
    SELECT b.*,
      (SELECT COUNT(*) FROM choices c WHERE c.ballot_id = b.id) AS choice_count,
      (SELECT COUNT(*) FROM participation p WHERE p.ballot_id = b.id) AS participant_count
    FROM ballots b
    WHERE b.group_id = ?
    ORDER BY CASE b.status WHEN 'draft' THEN 0 WHEN 'open' THEN 1 WHEN 'closed' THEN 2 ELSE 3 END,
             b.created_at DESC, b.title COLLATE NOCASE ASC
  `).all(GROUP_ID);
}

function getChoices(ballotId) {
  return db.prepare('SELECT id, ballot_id, label, position FROM choices WHERE ballot_id = ? ORDER BY position').all(ballotId)
    .map((row) => ({ id: row.id, ballotId: row.ballot_id, label: row.label, position: row.position }));
}

function getEligibility(ballotId) {
  const rows = db.prepare(`
    SELECT e.ballot_id, e.user_id, u.name, u.email, u.role, m.active, m.revision, m.updated_at
    FROM eligibility e
    JOIN users u ON u.id = e.user_id
    JOIN memberships m ON m.group_id = ? AND m.user_id = e.user_id
    WHERE e.ballot_id = ?
    ORDER BY u.name COLLATE NOCASE ASC
  `).all(GROUP_ID, ballotId);
  return rows.map((row) => ({
    user_id: row.user_id,
    name: row.name,
    email: row.email,
    role: row.role,
    active: Boolean(row.active),
    revision: row.revision,
    updated_at: row.updated_at,
  }));
}

function getParticipationRows(ballotId) {
  return db.prepare(`
    SELECT p.ballot_id, p.user_id, p.submitted_at, p.receipt_id, u.name, u.email, u.role
    FROM participation p
    JOIN users u ON u.id = p.user_id
    WHERE p.ballot_id = ?
    ORDER BY p.submitted_at ASC, u.name COLLATE NOCASE ASC
  `).all(ballotId).map((row) => ({
    user_id: row.user_id,
    name: row.name,
    email: row.email,
    role: row.role,
    submitted_at: row.submitted_at,
    receipt_id: row.receipt_id,
  }));
}

function choiceTallies(ballotId) {
  const rows = db.prepare(`
    SELECT c.id, c.label, c.position, COUNT(v.id) AS votes
    FROM choices c
    LEFT JOIN anonymous_votes v ON v.choice_id = c.id
    WHERE c.ballot_id = ?
    GROUP BY c.id
    ORDER BY c.position ASC
  `).all(ballotId);
  return rows.map((row) => ({
    id: row.id,
    label: row.label,
    position: row.position,
    votes: row.votes,
  }));
}

function participationCount(ballotId) {
  return db.prepare('SELECT COUNT(*) AS count FROM participation WHERE ballot_id = ?').get(ballotId).count;
}

function eligibleCount(ballotId) {
  return db.prepare('SELECT COUNT(*) AS count FROM eligibility WHERE ballot_id = ?').get(ballotId).count;
}

function userParticipation(ballotId, userId) {
  return db.prepare('SELECT submitted_at, receipt_id FROM participation WHERE ballot_id = ? AND user_id = ?').get(ballotId, userId) || null;
}

function currentMembership(userId) {
  return db.prepare(`
    SELECT m.group_id, m.user_id, m.active, m.revision, m.updated_at, u.name, u.email, u.role
    FROM memberships m JOIN users u ON u.id = m.user_id
    WHERE m.group_id = ? AND m.user_id = ?
  `).get(GROUP_ID, userId) || null;
}

function fetchBallot(ballotId) {
  return db.prepare('SELECT * FROM ballots WHERE group_id = ? AND id = ?').get(GROUP_ID, ballotId) || null;
}

function assertBallot(ballotId) {
  const ballot = fetchBallot(ballotId);
  if (!ballot) throw new ApiError(404, 'That ballot was not found.');
  return ballot;
}

function assertMembership(userId) {
  const membership = currentMembership(userId);
  if (!membership) throw new ApiError(404, 'That member was not found.');
  return membership;
}

function validDraftBallot(ballot) {
  return ballot && ballot.status === 'draft';
}

function buildBallotCore(ballot, user, options = {}) {
  const choices = options.includeChoices === false ? [] : getChoices(ballot.id);
  const participant = user ? userParticipation(ballot.id, user.id) : null;
  const eligibility = options.includeEligibility ? getEligibility(ballot.id) : [];
  const resultSummary = ballot.status === 'published' ? summarizeResults(ballot, user) : null;
  return {
    id: ballot.id,
    title: ballot.title,
    description: ballot.description,
    method: ballot.method,
    max_selections: ballot.max_selections,
    status: ballot.status,
    status_label: ballot.status.charAt(0).toUpperCase() + ballot.status.slice(1),
    revision: ballot.revision,
    created_at: ballot.created_at,
    opened_at: ballot.opened_at,
    closed_at: ballot.closed_at,
    published_at: ballot.published_at,
    choice_count: choices.length,
    choices,
    eligible_count: eligibleCount(ballot.id),
    participant_count: participationCount(ballot.id),
    participated: Boolean(participant),
    my_participation: participant ? { submitted_at: participant.submitted_at } : null,
    eligibility,
    result_summary: resultSummary,
  };
}

function summarizeResults(ballot) {
  const participantTotal = participationCount(ballot.id);
  const tallies = choiceTallies(ballot.id);
  if (ballot.method === 'single') {
    const best = tallies.length ? Math.max(...tallies.map((row) => row.votes)) : 0;
    const leaders = best > 0 ? tallies.filter((row) => row.votes === best).map((row) => row.label) : [];
    return {
      total_ballots: participantTotal,
      choices: tallies.map((row) => ({
        id: row.id,
        label: row.label,
        count: row.votes,
        percentage: participantTotal ? Number(((row.votes / participantTotal) * 100).toFixed(1)) : 0,
      })),
      leader: leaders.length === 1 ? { type: 'choice', label: leaders[0], count: best } : leaders.length > 1 ? { type: 'tie', labels: leaders, count: best } : { type: 'none' },
    };
  }
  return {
    participating_members: participantTotal,
    choices: tallies.map((row) => ({
      id: row.id,
      label: row.label,
      approvals: row.votes,
      percentage: participantTotal ? Number(((row.votes / participantTotal) * 100).toFixed(1)) : 0,
    })),
  };
}

function visibleBallotsForUser(user) {
  const ballots = getBallotRows();
  return ballots
    .filter((ballot) => {
      if (isCoordinator(user) || isObserver(user)) return true;
      if (ballot.status === 'published') return true;
      if (ballot.status === 'open') {
        return Boolean(userParticipation(ballot.id, user.id) || db.prepare('SELECT 1 FROM eligibility WHERE ballot_id = ? AND user_id = ?').get(ballot.id, user.id));
      }
      return false;
    })
    .map((ballot) => {
      const includeChoices = isCoordinator(user) || isObserver(user) || ballot.status === 'open' || ballot.status === 'published';
      return buildBallotCore(ballot, user, { includeChoices, includeEligibility: false });
    });
}

function ballotsWorkspace(user) {
  return visibleBallotsForUser(user).map((ballot) => ({
    id: ballot.id,
    title: ballot.title,
    description: ballot.description,
    method: ballot.method,
    max_selections: ballot.max_selections,
    status: ballot.status,
    status_label: ballot.status_label,
    revision: ballot.revision,
    choice_count: ballot.choice_count,
    choices: ballot.choices,
    can_edit: isCoordinator(user) && ballot.status === 'draft',
    can_open: isCoordinator(user) && ballot.status === 'draft',
    can_close: isCoordinator(user) && ballot.status === 'open',
    can_publish: isCoordinator(user) && ballot.status === 'closed',
    participated: ballot.participated,
    my_participation: ballot.my_participation,
    result_summary: ballot.result_summary,
  }));
}

function ballotDetailsForUser(ballotId, user) {
  const ballot = assertBallot(ballotId);
  if (isMember(user) && ballot.status === 'draft') throw new ApiError(403, 'That ballot is not visible to members yet.');
  const includeChoices = isCoordinator(user) || isObserver(user) || ballot.status !== 'draft';
  const includeEligibility = isCoordinator(user) || isObserver(user);
  return buildBallotCore(ballot, user, { includeChoices, includeEligibility });
}

function ballotListForState(user) {
  return ballotsWorkspace(user);
}

function turnoutWorkspace(user) {
  const ballots = getBallotRows();
  return ballots
    .filter((ballot) => isCoordinator(user) || isObserver(user) || ballot.status !== 'draft')
    .map((ballot) => {
      const eligibility = getEligibility(ballot.id);
      const participants = getParticipationRows(ballot.id);
      const participantSet = new Set(participants.map((row) => row.user_id));
      if (isMember(user)) {
        return {
          id: ballot.id,
          title: ballot.title,
          status: ballot.status,
          status_label: ballot.status_label,
          revision: ballot.revision,
          eligible_count: ballot.status === 'open' || ballot.status === 'closed' || ballot.status === 'published' ? eligibility.length : 0,
          participant_count: participantSet.size,
          my_participation: userParticipation(ballot.id, user.id)
            ? { submitted_at: userParticipation(ballot.id, user.id).submitted_at }
            : null,
        };
      }
      return {
        id: ballot.id,
        title: ballot.title,
        status: ballot.status,
        status_label: ballot.status_label,
        revision: ballot.revision,
        eligible_count: eligibility.length,
        participant_count: participantSet.size,
        eligible_members: eligibility.map((row) => ({
          user_id: row.user_id,
          name: row.name,
          email: row.email,
          role: row.role,
          active: row.active,
          revision: row.revision,
          updated_at: row.updated_at,
          participated: participantSet.has(row.user_id),
          submitted_at: participantSet.has(row.user_id) ? participants.find((p) => p.user_id === row.user_id)?.submitted_at || null : null,
        })),
      };
    });
}

function resultsWorkspace(user) {
  const ballots = getBallotRows();
  return ballots
    .filter((ballot) => ballot.status === 'published' || isCoordinator(user) || isObserver(user) || isMember(user))
    .map((ballot) => {
      const base = {
        id: ballot.id,
        title: ballot.title,
        status: ballot.status,
        status_label: ballot.status_label,
        revision: ballot.revision,
        published_at: ballot.published_at,
      };
      if (ballot.status !== 'published') {
        return { ...base, published: false, message: 'Results stay hidden until the ballot is Published.' };
      }
      return { ...base, published: true, result_summary: summarizeResults(ballot) };
    });
}

function memberWorkspace(user) {
  if (isCoordinator(user) || isObserver(user)) {
    return getMembershipRows();
  }
  const membership = currentMembership(user.id);
  return membership ? [{
    user_id: membership.user_id,
    name: membership.name,
    email: membership.email,
    role: membership.role,
    active: Boolean(membership.active),
    revision: membership.revision,
    updated_at: membership.updated_at,
    self: true,
  }] : [];
}

function auditWorkspace(user) {
  const rows = db.prepare(`
    SELECT id, action, entity_type, entity_id, actor_id, actor_label, details, created_at
    FROM audit
    ORDER BY id DESC
    LIMIT 200
  `).all();
  return rows.map((row) => ({
    id: row.id,
    action: row.action,
    entity_type: row.entity_type,
    entity_id: row.entity_id,
    actor_id: row.actor_id,
    actor_label: row.actor_label,
    details: row.details,
    created_at: row.created_at,
    visible_to: isMember(user) ? 'member' : 'staff',
  }));
}

function stateForUser(user) {
  const group = groupRow();
  return {
    group,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
    ballots: ballotsWorkspace(user),
    turnout: turnoutWorkspace(user),
    results: resultsWorkspace(user),
    members: memberWorkspace(user),
    audit: auditWorkspace(user),
    roster_version: rosterVersion(),
  };
}

function selectionSnapshot(selection) {
  return selection.slice().sort((a, b) => a.id.localeCompare(b.id)).map((item) => ({ id: item.id, revision: item.revision }));
}

function normalizeRoundPayload(ballotIds, reviewedBallots, rosterSnapshot) {
  return {
    ballot_ids: [...new Set(ballotIds)].slice().sort(),
    ballots: selectionSnapshot(reviewedBallots),
    roster_version: rosterSnapshot,
  };
}

function roundReviewPayload(ballotIds) {
  const ballots = ballotIds.map((id) => assertBallot(id));
  for (const ballot of ballots) {
    if (ballot.status !== 'draft') throw new ApiError(409, `Ballot ${ballot.title} is no longer Draft.`, { ballot_id: ballot.id }, true);
  }
  const roster = getMembershipRows();
  return {
    selection: ballots.map((ballot) => ({
      id: ballot.id,
      title: ballot.title,
      description: ballot.description,
      method: ballot.method,
      max_selections: ballot.max_selections,
      revision: ballot.revision,
      choices: getChoices(ballot.id),
    })),
    roster: {
      version: rosterVersion(roster),
      members: roster,
      active_members: roster.filter((row) => row.active),
    },
  };
}

function openBallots(user, ballotIds, reviewedBallots, reviewedRosterVersion) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  const normalizedIds = [...new Set(ballotIds)].sort();
  if (normalizedIds.length < 2) throw new ApiError(400, 'Select at least two different drafts for a round.');
  if (reviewedBallots.length !== normalizedIds.length) throw new ApiError(400, 'Review the same set of drafts before confirming the round.');
  const currentRoster = getMembershipRows();
  const currentRosterVersion = rosterVersion(currentRoster);
  if (currentRosterVersion !== reviewedRosterVersion) {
    throw new ApiError(409, 'The roster changed after your review. Please review the members again.', { roster: { version: currentRosterVersion, members: currentRoster } }, true);
  }
  const activeMembers = currentRoster.filter((row) => row.active);
  if (!activeMembers.length) {
    throw new ApiError(409, 'A round with no active Members cannot open.', { roster: { version: currentRosterVersion, members: currentRoster } }, true);
  }
  const reviewedMap = new Map(reviewedBallots.map((ballot) => [ballot.id, ballot]));
  const currentBallots = normalizedIds.map((id) => assertBallot(id));
  for (const ballot of currentBallots) {
    const reviewed = reviewedMap.get(ballot.id);
    if (!reviewed) throw new ApiError(400, `Ballot ${ballot.id} was not part of the reviewed round.`);
    if (ballot.status !== 'draft') {
      throw new ApiError(409, `Ballot ${ballot.title} is no longer Draft.`, { ballot_id: ballot.id, ballot: buildBallotCore(ballot, user) }, true);
    }
    if (ballot.revision !== reviewed.revision) {
      throw new ApiError(409, `Ballot ${ballot.title} changed after your review. Please review again.`, { ballot_id: ballot.id, ballot: buildBallotCore(ballot, user) }, true);
    }
  }
  const response = db.transaction(() => {
    const openedAt = now();
    const snapshotChoiceIds = [];
    const opened = [];
    for (const ballot of currentBallots) {
      const eligibleIds = activeMembers.map((row) => row.user_id);
      db.prepare('DELETE FROM eligibility WHERE ballot_id = ?').run(ballot.id);
      const insertEligibility = db.prepare('INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)');
      eligibleIds.forEach((userId) => insertEligibility.run(ballot.id, userId));
      db.prepare(`
        UPDATE ballots
        SET status = 'open', revision = revision + 1, opened_at = ?, closed_at = NULL, published_at = NULL
        WHERE id = ? AND status = 'draft'
      `).run(openedAt, ballot.id);
      const updated = assertBallot(ballot.id);
      if (updated.status !== 'open') throw new ApiError(409, `Ballot ${ballot.title} could not be opened.`, {}, true);
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES ('opened', 'ballot', ?, ?, ?, ?, ?)
      `).run(ballot.id, user.id, user.name, `Opened ${ballot.title} with ${eligibleIds.length} eligible Members`, openedAt);
      opened.push({
        id: ballot.id,
        title: ballot.title,
        revision: updated.revision,
        status: updated.status,
        eligible_count: eligibleIds.length,
      });
      snapshotChoiceIds.push(...getChoices(ballot.id).map((choice) => choice.id));
    }
    return {
      statusCode: 200,
      body: {
        ok: true,
        round: true,
        opened,
        roster: { version: currentRosterVersion, members: currentRoster, active_members: activeMembers },
      },
    };
  })();
  return response;
}

function draftPayloadFromBody(body) {
  exactKeys(body, ['operation_id', 'expected_revision', 'title', 'description', 'method', 'max_selections', 'choices']);
  const title = text(body.title, 'Title', 120);
  const description = optionalText(body.description, 'Context', 1000);
  const method = parseMethod(body.method);
  const choices = uniqueStrings(body.choices, 'Choices');
  if (choices.length < 2) throw new ApiError(400, 'At least two different choices are required.');
  const maxSelections = positiveInteger(body.max_selections, 'Approval maximum');
  if (method === 'single' && maxSelections !== 1) {
    throw new ApiError(400, 'Single choice ballots must allow exactly one selection.');
  }
  if (method === 'approval' && (maxSelections < 1 || maxSelections > choices.length)) {
    throw new ApiError(400, 'Approval maximum must be between 1 and the number of choices.');
  }
  return { title, description, method, max_selections: maxSelections, choices };
}

function ballotDraftPayload(ballot, body) {
  exactKeys(body, ['operation_id', 'expected_revision', 'title', 'description', 'method', 'max_selections', 'choices']);
  const expectedRevision = positiveInteger(body.expected_revision, 'Revision');
  const title = text(body.title, 'Title', 120);
  const description = optionalText(body.description, 'Context', 1000);
  const method = parseMethod(body.method);
  const choices = uniqueStrings(body.choices, 'Choices');
  if (choices.length < 2) throw new ApiError(400, 'At least two different choices are required.');
  const maxSelections = positiveInteger(body.max_selections, 'Approval maximum');
  if (method === 'single' && maxSelections !== 1) {
    throw new ApiError(400, 'Single choice ballots must allow exactly one selection.');
  }
  if (method === 'approval' && (maxSelections < 1 || maxSelections > choices.length)) {
    throw new ApiError(400, 'Approval maximum must be between 1 and the number of choices.');
  }
  return { expected_revision: expectedRevision, title, description, method, max_selections: maxSelections, choices };
}

function newChoicesForBallot(ballotId, labels) {
  const rows = [];
  labels.forEach((label, position) => rows.push({ id: makeId('choice'), ballot_id: ballotId, label, position }));
  return rows;
}

function createBallotDraft(user, body) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  const payload = draftPayloadFromBody(body);
  const ballotId = makeId('ballot');
  db.transaction(() => {
    db.prepare(`
      INSERT INTO ballots
        (id, group_id, title, description, method, max_selections, status, revision, created_by, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 'draft', 1, ?, ?)
    `).run(ballotId, GROUP_ID, payload.title, payload.description, payload.method, payload.max_selections, user.id, now());
    const insertChoice = db.prepare('INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)');
    newChoicesForBallot(ballotId, payload.choices).forEach((choice) => insertChoice.run(choice.id, ballotId, choice.label, choice.position));
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('created', 'ballot', ?, ?, ?, ?, ?)
    `).run(ballotId, user.id, user.name, `Created draft ${payload.title}`, now());
  })();
  return {
    statusCode: 201,
    body: { ok: true, ballot: ballotDetailsForUser(ballotId, user) },
  };
}

function saveDraftBallot(user, ballotId, body) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  const ballot = assertBallot(ballotId);
  const payload = ballotDraftPayload(ballot, body);
  const receiptPayload = { ballot_id: ballotId, expected_revision: payload.expected_revision, title: payload.title, description: payload.description, method: payload.method, max_selections: payload.max_selections, choices: payload.choices };
  if (ballot.status !== 'draft') {
    throw new ApiError(409, 'This ballot definition is locked because it is no longer Draft.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  if (ballot.revision !== payload.expected_revision) {
    throw new ApiError(409, 'This draft changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  const currentChoices = getChoices(ballotId).map((choice) => choice.label);
  const changed = ballot.title !== payload.title || ballot.description !== payload.description || ballot.method !== payload.method || ballot.max_selections !== payload.max_selections || JSON.stringify(currentChoices) !== JSON.stringify(payload.choices);
  if (!changed) {
    throw new ApiError(409, 'Nothing changed, so there is nothing to save.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  const updatedAt = now();
  db.transaction(() => {
    db.prepare(`
      UPDATE ballots
      SET title = ?, description = ?, method = ?, max_selections = ?, revision = revision + 1
      WHERE id = ? AND status = 'draft' AND revision = ?
    `).run(payload.title, payload.description, payload.method, payload.max_selections, ballotId, payload.expected_revision);
    const updated = assertBallot(ballotId);
    if (updated.revision !== payload.expected_revision + 1) {
      throw new ApiError(409, 'This draft changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(updated, user) }, true);
    }
    db.prepare('DELETE FROM choices WHERE ballot_id = ?').run(ballotId);
    const insertChoice = db.prepare('INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)');
    newChoicesForBallot(ballotId, payload.choices).forEach((choice) => insertChoice.run(choice.id, ballotId, choice.label, choice.position));
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('edited', 'ballot', ?, ?, ?, ?, ?)
    `).run(ballotId, user.id, user.name, `Edited draft ${payload.title}`, updatedAt);
  })();
  return {
    statusCode: 200,
    body: { ok: true, ballot: ballotDetailsForUser(ballotId, user) },
  };
}

function openSingleBallot(user, ballotId, body) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  exactKeys(body, ['operation_id', 'expected_revision']);
  const expectedRevision = positiveInteger(body.expected_revision, 'Revision');
  const ballot = assertBallot(ballotId);
  if (ballot.status !== 'draft') {
    throw new ApiError(409, 'This ballot is no longer Draft.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  if (ballot.revision !== expectedRevision) {
    throw new ApiError(409, 'This draft changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  const roster = getMembershipRows();
  const activeMembers = roster.filter((row) => row.active);
  if (!activeMembers.length) {
    throw new ApiError(409, 'A ballot cannot open when no Members are active.', { roster: { version: rosterVersion(roster), members: roster } }, true);
  }
  const openedAt = now();
  db.transaction(() => {
    db.prepare('DELETE FROM eligibility WHERE ballot_id = ?').run(ballotId);
    const insertEligibility = db.prepare('INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)');
    activeMembers.forEach((member) => insertEligibility.run(ballotId, member.user_id));
    db.prepare(`
      UPDATE ballots
      SET status = 'open', revision = revision + 1, opened_at = ?, closed_at = NULL, published_at = NULL
      WHERE id = ? AND status = 'draft' AND revision = ?
    `).run(openedAt, ballotId, expectedRevision);
    const opened = assertBallot(ballotId);
    if (opened.status !== 'open') throw new ApiError(409, 'This ballot could not be opened.', {}, true);
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('opened', 'ballot', ?, ?, ?, ?, ?)
    `).run(ballotId, user.id, user.name, `Opened ${opened.title} with ${activeMembers.length} eligible Members`, openedAt);
  })();
  const refreshed = assertBallot(ballotId);
  return { statusCode: 200, body: { ok: true, ballot: ballotDetailsForUser(ballotId, user), eligible_members: activeMembers, roster: { version: rosterVersion(roster), members: roster } } };
}

function closeBallot(user, ballotId, body) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  exactKeys(body, ['operation_id', 'expected_revision']);
  const expectedRevision = positiveInteger(body.expected_revision, 'Revision');
  const ballot = assertBallot(ballotId);
  if (ballot.status !== 'open') {
    throw new ApiError(409, 'Only Open ballots can be Closed.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  if (ballot.revision !== expectedRevision) {
    throw new ApiError(409, 'This ballot changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  const closedAt = now();
  db.transaction(() => {
    db.prepare(`
      UPDATE ballots
      SET status = 'closed', revision = revision + 1, closed_at = ?
      WHERE id = ? AND status = 'open' AND revision = ?
    `).run(closedAt, ballotId, expectedRevision);
    const closed = assertBallot(ballotId);
    if (closed.status !== 'closed') throw new ApiError(409, 'This ballot could not be Closed.', {}, true);
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('closed', 'ballot', ?, ?, ?, ?, ?)
    `).run(ballotId, user.id, user.name, `Closed ${closed.title}`, closedAt);
  })();
  return { statusCode: 200, body: { ok: true, ballot: ballotDetailsForUser(ballotId, user) } };
}

function publishBallot(user, ballotId, body) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  exactKeys(body, ['operation_id', 'expected_revision']);
  const expectedRevision = positiveInteger(body.expected_revision, 'Revision');
  const ballot = assertBallot(ballotId);
  if (ballot.status !== 'closed') {
    throw new ApiError(409, 'Only Closed ballots can be Published.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  if (ballot.revision !== expectedRevision) {
    throw new ApiError(409, 'This ballot changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  const publishedAt = now();
  db.transaction(() => {
    db.prepare(`
      UPDATE ballots
      SET status = 'published', revision = revision + 1, published_at = ?
      WHERE id = ? AND status = 'closed' AND revision = ?
    `).run(publishedAt, ballotId, expectedRevision);
    const published = assertBallot(ballotId);
    if (published.status !== 'published') throw new ApiError(409, 'This ballot could not be Published.', {}, true);
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('published', 'ballot', ?, ?, ?, ?, ?)
    `).run(ballotId, user.id, user.name, `Published ${published.title}`, publishedAt);
  })();
  return { statusCode: 200, body: { ok: true, ballot: ballotDetailsForUser(ballotId, user), results: summarizeResults(assertBallot(ballotId)) } };
}

function validateVoteChoices(ballot, choiceIds) {
  if (!Array.isArray(choiceIds)) throw new ApiError(400, 'Selections must be an array.');
  const selections = choiceIds.map((value, index) => {
    if (typeof value !== 'string') throw new ApiError(400, `Selection ${index + 1} must be text.`);
    const cleaned = value.trim();
    if (!cleaned) throw new ApiError(400, `Selection ${index + 1} is required.`);
    return cleaned;
  });
  if (new Set(selections).size !== selections.length) throw new ApiError(400, 'Selections cannot repeat a choice.');
  const choices = getChoices(ballot.id);
  const validChoiceIds = new Set(choices.map((choice) => choice.id));
  for (const choiceId of selections) {
    if (!validChoiceIds.has(choiceId)) {
      throw new ApiError(400, 'A selection belongs to a different ballot.', {}, false);
    }
  }
  if (ballot.method === 'single' && selections.length !== 1) {
    throw new ApiError(400, 'Single choice ballots require exactly one selection.');
  }
  if (ballot.method === 'approval') {
    if (selections.length < 1) throw new ApiError(400, 'Approval ballots require at least one selection.');
    if (selections.length > ballot.max_selections) throw new ApiError(400, 'Too many selections were made for this approval ballot.');
  }
  return selections;
}

function voteOnBallot(user, ballotId, body) {
  if (!isMember(user)) throw new ApiError(403, 'Only Members can submit a vote.');
  exactKeys(body, ['operation_id', 'choice_ids']);
  const ballot = assertBallot(ballotId);
  const selections = validateVoteChoices(ballot, body.choice_ids);
  const eligibility = db.prepare('SELECT 1 FROM eligibility WHERE ballot_id = ? AND user_id = ?').get(ballotId, user.id);
  if (!eligibility) {
    throw new ApiError(409, 'You are not eligible for this ballot.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  const participation = userParticipation(ballotId, user.id);
  if (participation) {
    throw new ApiError(409, 'Your vote has already been submitted for this ballot.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  if (ballot.status !== 'open') {
    throw new ApiError(409, 'Votes can only be submitted while a ballot is Open.', { ballot: buildBallotCore(ballot, user) }, true);
  }
  const submittedAt = now();
  db.transaction(() => {
    db.prepare('INSERT INTO participation (ballot_id, user_id, submitted_at, receipt_id) VALUES (?, ?, ?, ?)')
      .run(ballotId, user.id, submittedAt, makeId('receipt'));
    const insertVote = db.prepare('INSERT INTO anonymous_votes (id, ballot_id, choice_id, cast_at) VALUES (?, ?, ?, ?)');
    selections.forEach((choiceId) => insertVote.run(makeId('vote'), ballotId, choiceId, submittedAt));
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('vote_received', 'ballot', ?, NULL, 'Anonymous member', ?, ?)
    `).run(ballotId, `Anonymous participation recorded for ${ballot.title}`, submittedAt);
  })();
  return {
    statusCode: 200,
    body: {
      ok: true,
      ballot: {
        id: ballot.id,
        title: ballot.title,
        status: ballot.status,
        status_label: ballot.status_label,
      },
      participation: { submitted_at: submittedAt },
      message: 'Your participation was recorded anonymously.',
    },
  };
}

function updateMembership(user, memberId, body) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  exactKeys(body, ['operation_id', 'expected_revision', 'status']);
  const expectedRevision = positiveInteger(body.expected_revision, 'Revision');
  const status = parseStatus(body.status);
  const member = assertMembership(memberId);
  if (member.revision !== expectedRevision) {
    throw new ApiError(409, 'That membership changed after you loaded it. Please refresh the roster.', { member, roster: { version: rosterVersion(), members: getMembershipRows() } }, true);
  }
  if ((status === 'active' && member.active) || (status === 'paused' && !member.active)) {
    throw new ApiError(409, 'That membership already has this status.', { member }, true);
  }
  const updatedAt = now();
  db.transaction(() => {
    db.prepare(`
      UPDATE memberships
      SET active = ?, revision = revision + 1, updated_at = ?
      WHERE group_id = ? AND user_id = ? AND revision = ?
    `).run(status === 'active' ? 1 : 0, updatedAt, GROUP_ID, memberId, expectedRevision);
    const refreshed = assertMembership(memberId);
    if (refreshed.revision !== expectedRevision + 1) {
      throw new ApiError(409, 'That membership changed after you loaded it. Please refresh the roster.', { member: refreshed, roster: { version: rosterVersion(), members: getMembershipRows() } }, true);
    }
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES (?, 'member', ?, ?, ?, ?, ?)
    `).run(status === 'active' ? 'membership_activated' : 'membership_paused', memberId, user.id, user.name, `${status === 'active' ? 'Activated' : 'Paused'} ${refreshed.name}`, updatedAt);
  })();
  return { statusCode: 200, body: { ok: true, member: currentMembership(memberId), roster: { version: rosterVersion(), members: getMembershipRows() } } };
}

function reviewRound(user, ballotIds) {
  if (!isCoordinator(user)) throw new ApiError(403, 'Your role cannot perform this action.');
  const ids = arrayOfIds(ballotIds, 'Ballot selection');
  if (ids.length < 2) throw new ApiError(400, 'Select at least two different drafts for review.');
  if (new Set(ids).size !== ids.length) throw new ApiError(400, 'A round cannot include the same ballot more than once.');
  const ballots = ids.map((id) => assertBallot(id));
  for (const ballot of ballots) {
    if (ballot.status !== 'draft') throw new ApiError(409, `Ballot ${ballot.title} is no longer Draft.`, { ballot: buildBallotCore(ballot, user) }, true);
  }
  const roster = getMembershipRows();
  return {
    statusCode: 200,
    body: {
      ok: true,
      selection: ballots.map((ballot) => ({
        id: ballot.id,
        title: ballot.title,
        description: ballot.description,
        method: ballot.method,
        max_selections: ballot.max_selections,
        revision: ballot.revision,
        choices: getChoices(ballot.id),
      })),
      roster: {
        version: rosterVersion(roster),
        members: roster,
        active_members: roster.filter((member) => member.active),
      },
    },
  };
}

app.get('/api/health', (_request, response) => {
  response.json({ ok: true, service: 'common-ground-ballot' });
});

app.post('/api/auth/login', (request, response, next) => {
  try {
    exactKeys(request.body, ['email', 'password']);
    const email = text(request.body.email, 'Email', 240).toLowerCase();
    const password = typeof request.body.password === 'string' ? request.body.password : '';
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user || !passwordMatches(password, user.password_salt, user.password_hash)) {
      throw new ApiError(401, 'Email or password is incorrect.');
    }
    const token = crypto.randomBytes(32).toString('base64url');
    const createdAt = now();
    const expiresAt = new Date(Date.now() + SESSION_SECONDS * 1000).toISOString();
    db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)').run(tokenHash(token), user.id, createdAt, expiresAt);
    response.setHeader('Set-Cookie', `cg_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_SECONDS}`);
    response.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    next(error);
  }
});

app.post('/api/auth/logout', requireUser, (request, response) => {
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(request.user.token_hash);
  response.setHeader('Set-Cookie', 'cg_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0');
  response.json({ ok: true });
});

app.post('/api/auth/logout-all', requireUser, (request, response) => {
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(request.user.id);
  response.setHeader('Set-Cookie', 'cg_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0');
  response.json({ ok: true, message: 'All Common Ground sessions were ended.' });
});

app.get('/api/me', (request, response) => {
  const user = currentUser(request);
  response.json({
    user: user ? { id: user.id, name: user.name, email: user.email, role: user.role } : null,
  });
});

app.get('/api/state', requireUser, (request, response) => {
  response.json(stateForUser(request.user));
});

app.get('/api/ballots', requireUser, (request, response) => {
  response.json({ ballots: ballotsWorkspace(request.user) });
});

app.get('/api/ballots/:ballotId', requireUser, (request, response, next) => {
  try {
    response.json({ ballot: ballotDetailsForUser(request.params.ballotId, request.user) });
  } catch (error) {
    next(error);
  }
});

app.get('/api/round-review', requireUser, (request, response, next) => {
  try {
    const ids = (typeof request.query.ballot_ids === 'string' ? request.query.ballot_ids.split(',') : []).map((item) => item.trim()).filter(Boolean);
    response.json(reviewRound(request.user, ids).body);
  } catch (error) {
    next(error);
  }
});

app.post('/api/ballots', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    exactKeys(request.body, ['operation_id', 'title', 'description', 'method', 'max_selections', 'choices']);
    const payload = {
      title: text(request.body.title, 'Title', 120),
      description: optionalText(request.body.description, 'Context', 1000),
      method: parseMethod(request.body.method),
      max_selections: positiveInteger(request.body.max_selections, 'Approval maximum'),
      choices: uniqueStrings(request.body.choices, 'Choices'),
    };
    if (payload.choices.length < 2) throw new ApiError(400, 'At least two different choices are required.');
    if (payload.method === 'single' && payload.max_selections !== 1) throw new ApiError(400, 'Single choice ballots must allow exactly one selection.');
    if (payload.method === 'approval' && (payload.max_selections < 1 || payload.max_selections > payload.choices.length)) throw new ApiError(400, 'Approval maximum must be between 1 and the number of choices.');
    const operationId = requestOperationId(request.body.operation_id);
    const existing = savedReceipt(request.user.id, operationId);
    const receiptPayload = canonicalReceiptPayload('create-ballot', payload);
    if (existing) {
      if (existing.action !== 'create-ballot' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    const ballotId = makeId('ballot');
    const createdAt = now();
    db.transaction(() => {
      db.prepare(`
        INSERT INTO ballots
          (id, group_id, title, description, method, max_selections, status, revision, created_by, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'draft', 1, ?, ?)
      `).run(ballotId, GROUP_ID, payload.title, payload.description, payload.method, payload.max_selections, request.user.id, createdAt);
      const insertChoice = db.prepare('INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)');
      newChoicesForBallot(ballotId, payload.choices).forEach((choice) => insertChoice.run(choice.id, ballotId, choice.label, choice.position));
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES ('created', 'ballot', ?, ?, ?, ?, ?)
      `).run(ballotId, request.user.id, request.user.name, `Created draft ${payload.title}`, createdAt);
    })();
    const body = { ok: true, ballot: ballotDetailsForUser(ballotId, request.user) };
    writeReceipt(request.user.id, operationId, 'create-ballot', receiptPayload, 201, body);
    response.status(201).json(body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'create-ballot', () => draftPayloadFromBody(request.body), error)) return;
    next(error);
  }
});

app.patch('/api/ballots/:ballotId/draft', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    const ballot = assertBallot(request.params.ballotId);
    exactKeys(request.body, ['operation_id', 'expected_revision', 'title', 'description', 'method', 'max_selections', 'choices']);
    const payload = {
      expected_revision: positiveInteger(request.body.expected_revision, 'Revision'),
      title: text(request.body.title, 'Title', 120),
      description: optionalText(request.body.description, 'Context', 1000),
      method: parseMethod(request.body.method),
      max_selections: positiveInteger(request.body.max_selections, 'Approval maximum'),
      choices: uniqueStrings(request.body.choices, 'Choices'),
    };
    if (payload.choices.length < 2) throw new ApiError(400, 'At least two different choices are required.');
    if (payload.method === 'single' && payload.max_selections !== 1) throw new ApiError(400, 'Single choice ballots must allow exactly one selection.');
    if (payload.method === 'approval' && (payload.max_selections < 1 || payload.max_selections > payload.choices.length)) throw new ApiError(400, 'Approval maximum must be between 1 and the number of choices.');
    const operationId = requestOperationId(request.body.operation_id);
    const receiptPayload = canonicalReceiptPayload('edit-draft', { ballot_id: ballot.id, ...payload });
    const existing = savedReceipt(request.user.id, operationId);
    if (existing) {
      if (existing.action !== 'edit-draft' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    if (ballot.status !== 'draft') {
      throw new ApiError(409, 'This ballot definition is locked because it is no longer Draft.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    if (ballot.revision !== payload.expected_revision) {
      throw new ApiError(409, 'This draft changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    const currentChoices = getChoices(ballot.id).map((choice) => choice.label);
    const changed = ballot.title !== payload.title || ballot.description !== payload.description || ballot.method !== payload.method || ballot.max_selections !== payload.max_selections || JSON.stringify(currentChoices) !== JSON.stringify(payload.choices);
    if (!changed) {
      throw new ApiError(409, 'Nothing changed, so there is nothing to save.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    const updatedAt = now();
    db.transaction(() => {
      db.prepare(`
        UPDATE ballots
        SET title = ?, description = ?, method = ?, max_selections = ?, revision = revision + 1
        WHERE id = ? AND status = 'draft' AND revision = ?
      `).run(payload.title, payload.description, payload.method, payload.max_selections, ballot.id, payload.expected_revision);
      const refreshed = assertBallot(ballot.id);
      if (refreshed.revision !== payload.expected_revision + 1) {
        throw new ApiError(409, 'This draft changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(refreshed, request.user) }, true);
      }
      db.prepare('DELETE FROM choices WHERE ballot_id = ?').run(ballot.id);
      const insertChoice = db.prepare('INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)');
      newChoicesForBallot(ballot.id, payload.choices).forEach((choice) => insertChoice.run(choice.id, ballot.id, choice.label, choice.position));
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES ('edited', 'ballot', ?, ?, ?, ?, ?)
      `).run(ballot.id, request.user.id, request.user.name, `Edited draft ${payload.title}`, updatedAt);
    })();
    const body = { ok: true, ballot: ballotDetailsForUser(ballot.id, request.user) };
    writeReceipt(request.user.id, operationId, 'edit-draft', receiptPayload, 200, body);
    response.json(body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'edit-draft', () => ({ ballot_id: request.params.ballotId, ...ballotDraftPayload(assertBallot(request.params.ballotId), request.body) }), error)) return;
    next(error);
  }
});

app.post('/api/ballots/:ballotId/open', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    const ballot = assertBallot(request.params.ballotId);
    exactKeys(request.body, ['operation_id', 'expected_revision']);
    const payload = { ballot_id: ballot.id, expected_revision: positiveInteger(request.body.expected_revision, 'Revision') };
    const operationId = requestOperationId(request.body.operation_id);
    const receiptPayload = canonicalReceiptPayload('open-ballot', payload);
    const existing = savedReceipt(request.user.id, operationId);
    if (existing) {
      if (existing.action !== 'open-ballot' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    if (ballot.status !== 'draft') {
      throw new ApiError(409, 'This ballot is no longer Draft.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    if (ballot.revision !== payload.expected_revision) {
      throw new ApiError(409, 'This draft changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    const roster = getMembershipRows();
    const activeMembers = roster.filter((row) => row.active);
    if (!activeMembers.length) {
      throw new ApiError(409, 'A ballot cannot open when no Members are active.', { roster: { version: rosterVersion(roster), members: roster } }, true);
    }
    const openedAt = now();
    db.transaction(() => {
      db.prepare('DELETE FROM eligibility WHERE ballot_id = ?').run(ballot.id);
      const insertEligibility = db.prepare('INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)');
      activeMembers.forEach((member) => insertEligibility.run(ballot.id, member.user_id));
      db.prepare(`
        UPDATE ballots
        SET status = 'open', revision = revision + 1, opened_at = ?, closed_at = NULL, published_at = NULL
        WHERE id = ? AND status = 'draft' AND revision = ?
      `).run(openedAt, ballot.id, payload.expected_revision);
      const opened = assertBallot(ballot.id);
      if (opened.status !== 'open') throw new ApiError(409, 'This ballot could not be opened.', {}, true);
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES ('opened', 'ballot', ?, ?, ?, ?, ?)
      `).run(ballot.id, request.user.id, request.user.name, `Opened ${opened.title} with ${activeMembers.length} eligible Members`, openedAt);
    })();
    const body = { ok: true, ballot: ballotDetailsForUser(ballot.id, request.user), eligible_members: activeMembers, roster: { version: rosterVersion(roster), members: roster } };
    writeReceipt(request.user.id, operationId, 'open-ballot', receiptPayload, 200, body);
    response.json(body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'open-ballot', () => ({ ballot_id: request.params.ballotId, expected_revision: positiveInteger(request.body.expected_revision, 'Revision') }), error)) return;
    next(error);
  }
});

app.post('/api/ballots/:ballotId/close', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    const ballot = assertBallot(request.params.ballotId);
    exactKeys(request.body, ['operation_id', 'expected_revision']);
    const payload = { ballot_id: ballot.id, expected_revision: positiveInteger(request.body.expected_revision, 'Revision') };
    const operationId = requestOperationId(request.body.operation_id);
    const receiptPayload = canonicalReceiptPayload('close-ballot', payload);
    const existing = savedReceipt(request.user.id, operationId);
    if (existing) {
      if (existing.action !== 'close-ballot' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    if (ballot.status !== 'open') {
      throw new ApiError(409, 'Only Open ballots can be Closed.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    if (ballot.revision !== payload.expected_revision) {
      throw new ApiError(409, 'This ballot changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    const closedAt = now();
    db.transaction(() => {
      db.prepare(`
        UPDATE ballots
        SET status = 'closed', revision = revision + 1, closed_at = ?
        WHERE id = ? AND status = 'open' AND revision = ?
      `).run(closedAt, ballot.id, payload.expected_revision);
      const closed = assertBallot(ballot.id);
      if (closed.status !== 'closed') throw new ApiError(409, 'This ballot could not be Closed.', {}, true);
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES ('closed', 'ballot', ?, ?, ?, ?, ?)
      `).run(ballot.id, request.user.id, request.user.name, `Closed ${closed.title}`, closedAt);
    })();
    const body = { ok: true, ballot: ballotDetailsForUser(ballot.id, request.user) };
    writeReceipt(request.user.id, operationId, 'close-ballot', receiptPayload, 200, body);
    response.json(body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'close-ballot', () => ({ ballot_id: request.params.ballotId, expected_revision: positiveInteger(request.body.expected_revision, 'Revision') }), error)) return;
    next(error);
  }
});

app.post('/api/ballots/:ballotId/publish', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    const ballot = assertBallot(request.params.ballotId);
    exactKeys(request.body, ['operation_id', 'expected_revision']);
    const payload = { ballot_id: ballot.id, expected_revision: positiveInteger(request.body.expected_revision, 'Revision') };
    const operationId = requestOperationId(request.body.operation_id);
    const receiptPayload = canonicalReceiptPayload('publish-ballot', payload);
    const existing = savedReceipt(request.user.id, operationId);
    if (existing) {
      if (existing.action !== 'publish-ballot' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    if (ballot.status !== 'closed') {
      throw new ApiError(409, 'Only Closed ballots can be Published.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    if (ballot.revision !== payload.expected_revision) {
      throw new ApiError(409, 'This ballot changed after you loaded it. Please review the latest version again.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    const publishedAt = now();
    db.transaction(() => {
      db.prepare(`
        UPDATE ballots
        SET status = 'published', revision = revision + 1, published_at = ?
        WHERE id = ? AND status = 'closed' AND revision = ?
      `).run(publishedAt, ballot.id, payload.expected_revision);
      const published = assertBallot(ballot.id);
      if (published.status !== 'published') throw new ApiError(409, 'This ballot could not be Published.', {}, true);
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES ('published', 'ballot', ?, ?, ?, ?, ?)
      `).run(ballot.id, request.user.id, request.user.name, `Published ${published.title}`, publishedAt);
    })();
    const updated = assertBallot(ballot.id);
    const body = { ok: true, ballot: ballotDetailsForUser(ballot.id, request.user), results: summarizeResults(updated) };
    writeReceipt(request.user.id, operationId, 'publish-ballot', receiptPayload, 200, body);
    response.json(body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'publish-ballot', () => ({ ballot_id: request.params.ballotId, expected_revision: positiveInteger(request.body.expected_revision, 'Revision') }), error)) return;
    next(error);
  }
});

app.post('/api/ballots/:ballotId/vote', requireUser, requireRole('member'), (request, response, next) => {
  try {
    const ballot = assertBallot(request.params.ballotId);
    exactKeys(request.body, ['operation_id', 'choice_ids']);
    const selections = validateVoteChoices(ballot, request.body.choice_ids);
    const payload = { ballot_id: ballot.id, choice_ids: [...selections].sort() };
    const operationId = requestOperationId(request.body.operation_id);
    const receiptPayload = canonicalReceiptPayload('vote-ballot', payload);
    const existing = savedReceipt(request.user.id, operationId);
    if (existing) {
      if (existing.action !== 'vote-ballot' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    const eligibility = db.prepare('SELECT 1 FROM eligibility WHERE ballot_id = ? AND user_id = ?').get(ballot.id, request.user.id);
    if (!eligibility) {
      throw new ApiError(409, 'You are not eligible for this ballot.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    if (ballot.status !== 'open') {
      throw new ApiError(409, 'Votes can only be submitted while a ballot is Open.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    if (userParticipation(ballot.id, request.user.id)) {
      throw new ApiError(409, 'Your vote has already been submitted for this ballot.', { ballot: buildBallotCore(ballot, request.user) }, true);
    }
    const submittedAt = now();
    db.transaction(() => {
      db.prepare('INSERT INTO participation (ballot_id, user_id, submitted_at, receipt_id) VALUES (?, ?, ?, ?)')
        .run(ballot.id, request.user.id, submittedAt, makeId('receipt'));
      const insertVote = db.prepare('INSERT INTO anonymous_votes (id, ballot_id, choice_id, cast_at) VALUES (?, ?, ?, ?)');
      selections.forEach((choiceId) => insertVote.run(makeId('vote'), ballot.id, choiceId, submittedAt));
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES ('vote_received', 'ballot', ?, NULL, 'Anonymous member', ?, ?)
      `).run(ballot.id, `Anonymous participation recorded for ${ballot.title}`, submittedAt);
    })();
    const body = {
      ok: true,
      ballot: { id: ballot.id, title: ballot.title, status: ballot.status, status_label: ballot.status_label },
      participation: { submitted_at: submittedAt },
      message: 'Your participation was recorded anonymously.',
    };
    writeReceipt(request.user.id, operationId, 'vote-ballot', receiptPayload, 200, body);
    response.json(body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'vote-ballot', () => ({ ballot_id: request.params.ballotId, choice_ids: [...validateVoteChoices(assertBallot(request.params.ballotId), request.body.choice_ids)].sort() }), error)) return;
    next(error);
  }
});

app.post('/api/memberships/:userId', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    const member = assertMembership(request.params.userId);
    exactKeys(request.body, ['operation_id', 'expected_revision', 'status']);
    const status = parseStatus(request.body.status);
    const payload = { member_id: member.user_id, expected_revision: positiveInteger(request.body.expected_revision, 'Revision'), status };
    const operationId = requestOperationId(request.body.operation_id);
    const receiptPayload = canonicalReceiptPayload('update-membership', payload);
    const existing = savedReceipt(request.user.id, operationId);
    if (existing) {
      if (existing.action !== 'update-membership' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    if (member.revision !== payload.expected_revision) {
      throw new ApiError(409, 'That membership changed after you loaded it. Please refresh the roster.', { member, roster: { version: rosterVersion(), members: getMembershipRows() } }, true);
    }
    if ((status === 'active' && member.active) || (status === 'paused' && !member.active)) {
      throw new ApiError(409, 'That membership already has this status.', { member }, true);
    }
    const updatedAt = now();
    db.transaction(() => {
      db.prepare(`
        UPDATE memberships
        SET active = ?, revision = revision + 1, updated_at = ?
        WHERE group_id = ? AND user_id = ? AND revision = ?
      `).run(status === 'active' ? 1 : 0, updatedAt, GROUP_ID, member.user_id, payload.expected_revision);
      const refreshed = assertMembership(member.user_id);
      if (refreshed.revision !== payload.expected_revision + 1) {
        throw new ApiError(409, 'That membership changed after you loaded it. Please refresh the roster.', { member: refreshed, roster: { version: rosterVersion(), members: getMembershipRows() } }, true);
      }
      db.prepare(`
        INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
        VALUES (?, 'member', ?, ?, ?, ?, ?)
      `).run(status === 'active' ? 'membership_activated' : 'membership_paused', member.user_id, request.user.id, request.user.name, `${status === 'active' ? 'Activated' : 'Paused'} ${refreshed.name}`, updatedAt);
    })();
    const body = { ok: true, member: currentMembership(member.user_id), roster: { version: rosterVersion(), members: getMembershipRows() } };
    writeReceipt(request.user.id, operationId, 'update-membership', receiptPayload, 200, body);
    response.json(body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'update-membership', () => ({ member_id: request.params.userId, expected_revision: positiveInteger(request.body.expected_revision, 'Revision'), status: parseStatus(request.body.status) }), error)) return;
    next(error);
  }
});

app.post('/api/ballots/open-review', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    exactKeys(request.body, ['ballot_ids']);
    response.json(reviewRound(request.user, request.body.ballot_ids).body);
  } catch (error) {
    next(error);
  }
});

app.post('/api/ballots/open-round', requireUser, requireRole('coordinator'), (request, response, next) => {
  try {
    exactKeys(request.body, ['operation_id', 'ballot_ids', 'reviewed_ballots', 'roster_version']);
    const ballotIds = arrayOfIds(request.body.ballot_ids, 'Ballot selection');
    if (ballotIds.length < 2) throw new ApiError(400, 'Select at least two different drafts for a round.');
    if (new Set(ballotIds).size !== ballotIds.length) throw new ApiError(400, 'A round cannot include the same ballot more than once.');
    if (!Array.isArray(request.body.reviewed_ballots) || request.body.reviewed_ballots.length !== ballotIds.length) {
      throw new ApiError(400, 'Review the same set of drafts before confirming the round.');
    }
    const reviewedBallots = request.body.reviewed_ballots.map((item, index) => {
      requireObject(item, `Reviewed ballot ${index + 1} must be an object.`);
      exactKeys(item, ['id', 'revision']);
      return { id: text(item.id, 'Ballot id', 128), revision: positiveInteger(item.revision, 'Revision') };
    });
    const reviewedRosterVersion = typeof request.body.roster_version === 'string' ? request.body.roster_version.trim() : '';
    if (!reviewedRosterVersion) throw new ApiError(400, 'The reviewed roster is required.');
    const payload = normalizeRoundPayload(ballotIds, reviewedBallots, reviewedRosterVersion);
    const operationId = requestOperationId(request.body.operation_id);
    const existing = savedReceipt(request.user.id, operationId);
    const receiptPayload = canonicalReceiptPayload('open-round', payload);
    if (existing) {
      if (existing.action !== 'open-round' || existing.fingerprint !== fingerprint(receiptPayload)) {
        throw new ApiError(409, 'That operation identifier was already used for different input.');
      }
      return sendStoredReceipt(response, existing);
    }
    const result = openBallots(request.user, ballotIds, reviewedBallots, reviewedRosterVersion);
    writeReceipt(request.user.id, operationId, 'open-round', receiptPayload, result.statusCode, result.body);
    response.status(result.statusCode).json(result.body);
  } catch (error) {
    if (persistBusinessRefusal(request, response, 'open-round', () => {
      const ids = arrayOfIds(request.body.ballot_ids, 'Ballot selection');
      const reviewed = request.body.reviewed_ballots.map((item) => ({ id: text(item.id, 'Ballot id', 128), revision: positiveInteger(item.revision, 'Revision') }));
      const rosterVersionValue = typeof request.body.roster_version === 'string' ? request.body.roster_version.trim() : '';
      return normalizeRoundPayload(ids, reviewed, rosterVersionValue);
    }, error)) return;
    next(error);
  }
});

app.get('/api/turnout', requireUser, (request, response) => {
  response.json({ turnout: turnoutWorkspace(request.user) });
});

app.get('/api/results', requireUser, (request, response) => {
  response.json({ results: resultsWorkspace(request.user) });
});

app.get('/api/members', requireUser, (request, response) => {
  response.json({ members: memberWorkspace(request.user), roster_version: rosterVersion() });
});

app.get('/api/audit', requireUser, (request, response) => {
  response.json({ audit: auditWorkspace(request.user) });
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get(/.*/, (_request, response) => response.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((error, _request, response, _next) => {
  if (error instanceof SyntaxError && 'body' in error) {
    return response.status(400).json({ error: 'Request body must be valid JSON.' });
  }
  if (error instanceof ApiError) return response.status(error.status).json(error.body);
  console.error(error);
  response.status(500).json({ error: 'Something went wrong on the server.' });
});

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`Common Ground listening on ${PORT}`);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
