const views = {
  ballots: 'Prepare drafts, open rounds, and track live ballot stages.',
  vote: 'Cast one anonymous final submission on an eligible open ballot.',
  turnout: 'Review participation without exposing any private selections.',
  results: 'Read published outcomes after a ballot is finished.',
  members: 'Review and adjust the roster that future openings will use.',
  audit: 'Review administrative activity and anonymous vote receipts.'
};

const els = {
  status: document.querySelector('#status'),
  signIn: document.querySelector('#sign-in'),
  workspace: document.querySelector('#workspace'),
  identity: document.querySelector('#identity'),
  groupName: document.querySelector('#group-name'),
  nav: document.querySelector('#nav'),
  viewTitle: document.querySelector('#view-title'),
  viewCopy: document.querySelector('#view-copy'),
  viewEyebrow: document.querySelector('#view-eyebrow'),
  view: document.querySelector('#view'),
  pendingList: document.querySelector('#pending-list'),
  modalRoot: document.querySelector('#modal-root'),
};

const STORAGE = {
  theme: 'cg-theme',
  view: 'cg-view',
  pending: 'cg-pending-actions',
};

const app = {
  user: null,
  data: null,
  view: localStorage.getItem(STORAGE.view) || 'ballots',
  pending: [],
  draftConflict: null,
  roundReview: null,
};

const dateFormatter = new Intl.DateTimeFormat(undefined, {
  dateStyle: 'medium',
  timeStyle: 'short',
});

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function formatDate(value) {
  if (!value) return '—';
  try {
    return dateFormatter.format(new Date(value));
  } catch {
    return value;
  }
}

function statusLabel(status) {
  return String(status || '').replace(/_/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase());
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function currentTheme() {
  return localStorage.getItem(STORAGE.theme) || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem(STORAGE.theme, theme);
}

function setStatus(message = '') {
  els.status.textContent = message;
}

function pendingKey(userId) {
  return `${STORAGE.pending}:${userId}`;
}

function loadPending(userId) {
  if (!userId) return [];
  const raw = localStorage.getItem(pendingKey(userId));
  if (!raw) return [];
  let entries = [];
  try {
    entries = JSON.parse(raw);
  } catch {
    return [];
  }
  const now = Date.now();
  return entries
    .filter((entry) => entry && entry.userId === userId)
    .map((entry) => {
      if (entry.inFlight && now - Number(entry.inFlightAt || 0) > 15000) {
        return { ...entry, inFlight: false, status: 'unknown', lastError: 'The previous attempt may still be pending on the server.' };
      }
      return entry;
    });
}

function savePending(userId, entries) {
  if (!userId) return;
  localStorage.setItem(pendingKey(userId), JSON.stringify(entries));
}

function refreshPendingFromStorage() {
  if (!app.user) {
    app.pending = [];
    return;
  }
  app.pending = loadPending(app.user.id);
}

function updatePendingEntry(operationId, updates) {
  if (!app.user) return;
  app.pending = loadPending(app.user.id).map((entry) => (entry.operationId === operationId ? { ...entry, ...updates } : entry));
  savePending(app.user.id, app.pending);
  renderPending();
}

function removePendingEntry(operationId) {
  if (!app.user) return;
  app.pending = loadPending(app.user.id).filter((entry) => entry.operationId !== operationId);
  savePending(app.user.id, app.pending);
  renderPending();
}

function addPendingEntry(entry) {
  if (!app.user) return;
  app.pending = loadPending(app.user.id).filter((item) => item.operationId !== entry.operationId).concat(entry);
  savePending(app.user.id, app.pending);
  renderPending();
}

function makeOperationId() {
  return window.crypto?.randomUUID ? window.crypto.randomUUID() : `op-${Math.random().toString(36).slice(2)}-${Date.now()}`;
}

async function request(url, options = {}) {
  const headers = { ...(options.headers || {}) };
  let body = options.body;
  if (body && typeof body !== 'string' && !(body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
    body = JSON.stringify(body);
  }
  const response = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers,
    body,
  });
  let data = null;
  const raw = await response.text();
  if (raw) {
    try {
      data = JSON.parse(raw);
    } catch {
      throw Object.assign(new Error('The server reply could not be read.'), { status: response.status, unreadable: true });
    }
  }
  if (!response.ok) {
    throw Object.assign(new Error(data?.error || response.statusText || 'Request failed.'), {
      status: response.status,
      body: data,
    });
  }
  return data;
}

function setView(view) {
  app.view = view;
  localStorage.setItem(STORAGE.view, view);
  render();
}

function loadLoginHints() {
  document.querySelectorAll('[data-email]').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelector('#email').value = button.dataset.email;
      document.querySelector('#password').value = 'CommonGround!2026';
      document.querySelector('#email').focus();
    });
  });
}

function ballotStageLabel(ballot) {
  return statusLabel(ballot.status_label || ballot.status);
}

function groupToString(group) {
  return group ? `${group.name}` : 'Riverside Residents Association';
}

function optionRows(values, prefix) {
  const rows = values.map((value, index) => `
    <div class="row choice-row" data-choice-row>
      <input type="text" name="${prefix}-${index}" value="${escapeHtml(value)}" placeholder="Choice ${index + 1}" data-choice-input />
      <button type="button" class="secondary" data-action="remove-choice">Remove</button>
    </div>
  `).join('');
  return `${rows}`;
}

function collectChoiceValues(form) {
  return Array.from(form.querySelectorAll('[data-choice-input]'))
    .map((input) => input.value.trim())
    .filter(Boolean);
}

function collectFormValues(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function renderChoiceSummary(choice, percentField = 'percentage', countField = 'count') {
  const count = Number(choice[countField] || 0);
  const percent = Number(choice[percentField] || 0);
  return `
    <div class="result-item">
      <div class="row">
        <strong>${escapeHtml(choice.label)}</strong>
        <span class="badge">${count} ${count === 1 ? 'ballot' : 'ballots'}</span>
      </div>
      <div class="progress" aria-hidden="true"><span style="width:${Math.min(100, percent)}%"></span></div>
      <p class="small">${percent.toFixed(1)}%</p>
    </div>
  `;
}

function renderBallotCard(ballot) {
  const statusTone = ballot.status === 'open' ? 'accent' : ballot.status === 'published' ? 'success' : ballot.status === 'closed' ? 'muted' : 'muted';
  const choiceLines = (ballot.choices || []).map((choice) => `<li>${escapeHtml(choice.label)}</li>`).join('');
  const resultSummary = ballot.result_summary;
  const actions = [];
  if (app.user.role === 'coordinator') {
    if (ballot.status === 'draft') {
      actions.push(`<button type="button" class="primary" data-action="toggle-edit" data-ballot-id="${escapeHtml(ballot.id)}">Edit draft</button>`);
      actions.push(`<button type="button" data-action="open-ballot" data-ballot-id="${escapeHtml(ballot.id)}" data-revision="${ballot.revision}">Open</button>`);
    }
    if (ballot.status === 'open') actions.push(`<button type="button" data-action="close-ballot" data-ballot-id="${escapeHtml(ballot.id)}" data-revision="${ballot.revision}">Close</button>`);
    if (ballot.status === 'closed') actions.push(`<button type="button" data-action="publish-ballot" data-ballot-id="${escapeHtml(ballot.id)}" data-revision="${ballot.revision}">Publish</button>`);
  }
  const editForm = app.editingBallotId === ballot.id ? renderDraftEditor(ballot) : '';
  return `
    <article class="item" data-ballot-card data-ballot-id="${escapeHtml(ballot.id)}">
      <header>
        <div>
          <h3>${escapeHtml(ballot.title)}</h3>
          <p class="mini">${escapeHtml(ballot.description || 'No context provided yet.')}</p>
        </div>
        <span class="badge" data-status="${escapeHtml(ballot.status)}">${ballotStageLabel(ballot)}</span>
      </header>
      <div class="details-grid">
        <div><strong>Revision</strong><dd>${ballot.revision}</dd></div>
        <div><strong>Method</strong><dd>${escapeHtml(ballot.method === 'single' ? 'Single choice' : `Approval up to ${ballot.max_selections}`)}</dd></div>
        <div><strong>Choices</strong><dd>${ballot.choice_count || (ballot.choices || []).length}</dd></div>
        <div><strong>Participation</strong><dd>${ballot.participated ? 'You have participated' : 'No participation yet'}</dd></div>
      </div>
      <details>
        <summary>Choice wording</summary>
        <ul class="choice-list">${choiceLines || '<li>No choices loaded.</li>'}</ul>
      </details>
      ${ballot.status === 'published' && resultSummary ? renderPublishedResults(resultSummary) : ballot.status === 'closed' ? '<p class="mini">Results stay hidden until the ballot is Published.</p>' : ''}
      ${app.user.role === 'coordinator' ? `<div class="inline-actions">${actions.join('')}</div>` : ''}
      ${editForm}
    </article>
  `;
}

function renderPublishedResults(resultSummary) {
  if (resultSummary.total_ballots !== undefined) {
    const leader = resultSummary.leader;
    return `
      <section class="summary">
        <header>
          <h4>Published results</h4>
          <span class="badge">${resultSummary.total_ballots} ballots</span>
        </header>
        <div class="result-list">
          ${resultSummary.choices.map((choice) => `
            <div class="result-item">
              <div class="row">
                <strong>${escapeHtml(choice.label)}</strong>
                <span class="badge">${choice.count}</span>
              </div>
              <div class="progress"><span style="width:${Math.min(100, choice.percentage)}%"></span></div>
              <p class="small">${choice.percentage.toFixed(1)}%</p>
            </div>
          `).join('')}
        </div>
        <p class="mini">${leader.type === 'tie' ? `It is a tie between ${leader.labels.map(escapeHtml).join(', ')}.` : leader.type === 'choice' ? `${leader.label} leads.` : 'No ballots were cast.'}</p>
      </section>
    `;
  }
  return `
    <section class="summary">
      <header>
        <h4>Published results</h4>
        <span class="badge">${resultSummary.participating_members} participating members</span>
      </header>
      <div class="result-list">
        ${resultSummary.choices.map((choice) => `
          <div class="result-item">
            <div class="row">
              <strong>${escapeHtml(choice.label)}</strong>
              <span class="badge">${choice.approvals}</span>
            </div>
            <div class="progress"><span style="width:${Math.min(100, choice.percentage)}%"></span></div>
            <p class="small">${choice.percentage.toFixed(1)}%</p>
          </div>
        `).join('')}
      </div>
    </section>
  `;
}

function renderCreateForm() {
  return `
    <section class="note">
      <header>
        <h3>Create a new draft</h3>
        <span class="badge">Coordinator only</span>
      </header>
      <form id="create-ballot-form" class="inline-form" data-form-type="create-ballot">
        <div class="row">
          <div><label for="new-title">Title</label><input id="new-title" name="title" type="text" maxlength="120" required /></div>
          <div><label for="new-method">Voting method</label><select id="new-method" name="method"><option value="single">Single choice</option><option value="approval">Approval</option></select></div>
          <div><label for="new-max">Approval maximum</label><input id="new-max" name="max_selections" type="number" min="1" value="1" required /></div>
        </div>
        <div>
          <label for="new-description">Context</label>
          <textarea id="new-description" name="description" maxlength="1000" placeholder="Optional context for members"></textarea>
        </div>
        <div class="choice-group" data-choice-group>
          <label>Choices</label>
          ${optionRows(['', ''], 'new-choice')}
          <div class="row"><button type="button" class="secondary" data-action="add-choice">Add another choice</button></div>
        </div>
        <div class="inline-actions">
          <button type="submit" class="primary">Create draft</button>
        </div>
      </form>
      <p class="mini">Drafts need a title, optional context, a method, and at least two distinct choices.</p>
    </section>
  `;
}

function renderRoundBuilder() {
  const drafts = (app.data.ballots || []).filter((ballot) => ballot.status === 'draft');
  if (!drafts.length) return '';
  return `
    <section class="summary">
      <header>
        <div>
          <h3>Open a meeting round</h3>
          <p class="mini">Select two or more drafts, review the wording and eligible Members, then confirm one round.</p>
        </div>
        <span class="badge">Round action</span>
      </header>
      <div class="stack-gap">
        ${drafts.map((ballot) => `
          <label class="choice-item">
            <input type="checkbox" data-round-select value="${escapeHtml(ballot.id)}" />
            <strong>${escapeHtml(ballot.title)}</strong>
            <span class="mini">Revision ${ballot.revision} · ${escapeHtml(ballot.method === 'single' ? 'Single choice' : `Approval up to ${ballot.max_selections}`)}</span>
          </label>
        `).join('')}
      </div>
      <div class="inline-actions">
        <button type="button" class="primary" data-action="review-round">Review round</button>
      </div>
    </section>
  `;
}

function renderDraftEditor(ballot) {
  const original = escapeHtml(JSON.stringify(ballot));
  const values = [
    ballot.choices?.[0]?.label || '',
    ballot.choices?.[1]?.label || '',
    ballot.choices?.[2]?.label || '',
  ];
  while (values.length < 3) values.push('');
  return `
    <section class="note" data-editor-for="${escapeHtml(ballot.id)}">
      <header>
        <h4>Edit draft</h4>
        <div class="inline-actions">
          <button type="button" class="secondary" data-action="cancel-edit" data-ballot-id="${escapeHtml(ballot.id)}">Discard</button>
        </div>
      </header>
      <form class="inline-form" data-form-type="edit-ballot" data-ballot-id="${escapeHtml(ballot.id)}" data-original='${original}'>
        <input type="hidden" name="expected_revision" value="${ballot.revision}" />
        <div class="row">
          <div><label>Title</label><input name="title" type="text" maxlength="120" value="${escapeHtml(ballot.title)}" required /></div>
          <div><label>Voting method</label><select name="method"><option value="single" ${ballot.method === 'single' ? 'selected' : ''}>Single choice</option><option value="approval" ${ballot.method === 'approval' ? 'selected' : ''}>Approval</option></select></div>
          <div><label>Approval maximum</label><input name="max_selections" type="number" min="1" value="${ballot.max_selections}" required /></div>
        </div>
        <div>
          <label>Context</label>
          <textarea name="description" maxlength="1000">${escapeHtml(ballot.description || '')}</textarea>
        </div>
        <div class="choice-group" data-choice-group>
          <label>Choices</label>
          ${optionRows(values, `edit-${ballot.id}-choice`)}
          <div class="row"><button type="button" class="secondary" data-action="add-choice">Add another choice</button></div>
        </div>
        <div class="inline-actions">
          <button type="submit" class="primary">Save reviewed draft</button>
        </div>
      </form>
      <p class="mini">If another tab changed the draft, the save will stop and show both versions for review.</p>
    </section>
  `;
}

function mergeDefinition(source, target) {
  return source.method === target.method && String(source.max_selections) === String(target.max_selections) && JSON.stringify(source.choices || []) === JSON.stringify(target.choices || []);
}

function draftConflictAnalysis(conflict) {
  const { original, attempted, latest } = conflict;
  const titleConflict = attempted.title !== original.title && latest.title !== original.title && attempted.title !== latest.title;
  const descriptionConflict = attempted.description !== original.description && latest.description !== original.description && attempted.description !== latest.description;
  const definitionConflict = !mergeDefinition(attempted, original) && !mergeDefinition(latest, original) && !mergeDefinition(attempted, latest);
  const titleValue = attempted.title !== original.title ? attempted.title : latest.title;
  const descriptionValue = attempted.description !== original.description ? attempted.description : latest.description;
  const definitionValue = mergeDefinition(attempted, original) ? latest : attempted;
  return { titleConflict, descriptionConflict, definitionConflict, titleValue, descriptionValue, definitionValue };
}

function renderDraftConflictModal() {
  const conflict = app.draftConflict;
  if (!conflict) return '';
  const analysis = draftConflictAnalysis(conflict);
  const titleOptions = analysis.titleConflict ? `
    <label><input type="radio" name="title-choice" value="latest" required /> Keep latest saved title: <strong>${escapeHtml(conflict.latest.title)}</strong></label>
    <label><input type="radio" name="title-choice" value="mine" /> Keep my title: <strong>${escapeHtml(conflict.attempted.title)}</strong></label>
  ` : `<input type="hidden" name="title-value" value="${escapeHtml(analysis.titleValue)}" />`;
  const descriptionOptions = analysis.descriptionConflict ? `
    <label><input type="radio" name="description-choice" value="latest" required /> Keep latest saved context: <strong>${escapeHtml(conflict.latest.description || 'No context')}</strong></label>
    <label><input type="radio" name="description-choice" value="mine" /> Keep my context: <strong>${escapeHtml(conflict.attempted.description || 'No context')}</strong></label>
  ` : `<input type="hidden" name="description-value" value="${escapeHtml(analysis.descriptionValue)}" />`;
  const definitionOptions = analysis.definitionConflict ? `
    <label><input type="radio" name="definition-choice" value="latest" required /> Keep latest saved voting definition</label>
    <label><input type="radio" name="definition-choice" value="mine" /> Keep my voting definition</label>
  ` : `<input type="hidden" name="definition-value" value='${escapeHtml(JSON.stringify(analysis.definitionValue))}' />`;
  return `
    <div class="overlay">
      <section class="modal conflict" aria-labelledby="conflict-title">
        <header>
          <div>
            <p class="eyebrow">Review your changes</p>
            <h3 id="conflict-title">The draft changed while you were editing</h3>
          </div>
          <button type="button" class="secondary" data-action="close-conflict">Close</button>
        </header>
        <p class="muted">Disjoint changes were kept. Choose which version to keep for each field that changed differently.</p>
        <form class="stack" data-form-type="resolve-conflict" data-ballot-id="${escapeHtml(conflict.ballotId)}" data-original='${escapeHtml(JSON.stringify(conflict.original))}' data-attempted='${escapeHtml(JSON.stringify(conflict.attempted))}' data-latest='${escapeHtml(JSON.stringify(conflict.latest))}'>
          <fieldset>
            <legend>Title</legend>
            ${titleOptions}
          </fieldset>
          <fieldset>
            <legend>Context</legend>
            ${descriptionOptions}
          </fieldset>
          <fieldset>
            <legend>Voting definition</legend>
            ${definitionOptions}
          </fieldset>
          <div class="inline-actions">
            <button type="submit" class="primary">Save reviewed draft</button>
            <button type="button" class="secondary" data-action="discard-conflict">Discard changes</button>
          </div>
        </form>
      </section>
    </div>
  `;
}

function renderRoundReviewModal() {
  const review = app.roundReview;
  if (!review) return '';
  const activeMembers = review.roster.active_members || [];
  return `
    <div class="overlay">
      <section class="modal" aria-labelledby="round-review-title">
        <header>
          <div>
            <p class="eyebrow">Round review</p>
            <h3 id="round-review-title">Confirm these drafts as one opening round</h3>
          </div>
          <button type="button" class="secondary" data-action="cancel-round-review">Cancel</button>
        </header>
        <div class="stack-gap">
          ${review.selection.map((ballot) => `
            <article class="summary">
              <header>
                <h4>${escapeHtml(ballot.title)}</h4>
                <span class="badge">Revision ${ballot.revision}</span>
              </header>
              <p class="mini">${escapeHtml(ballot.description || 'No context provided.')}</p>
              <p class="small">${escapeHtml(ballot.method === 'single' ? 'Single choice' : `Approval up to ${ballot.max_selections}`)}</p>
              <ul class="choice-list">${ballot.choices.map((choice) => `<li>${escapeHtml(choice.label)}</li>`).join('')}</ul>
            </article>
          `).join('')}
          <section class="summary">
            <header>
              <h4>Eligible Members</h4>
              <span class="badge">Roster version ${review.roster.version.slice(0, 8)}</span>
            </header>
            <p class="mini">Only active Members at this moment will be eligible.</p>
            <div class="roster-list">
              ${activeMembers.map((member) => `<div class="roster-item"><strong>${escapeHtml(member.name)}</strong><p class="small">${escapeHtml(member.email)} · ${member.active ? 'Active' : 'Paused'}</p></div>`).join('')}
            </div>
          </section>
        </div>
        <div class="inline-actions">
          <button type="button" class="primary" data-action="confirm-round">Open round</button>
          <button type="button" class="secondary" data-action="cancel-round-review">Back</button>
        </div>
      </section>
    </div>
  `;
}

function renderRoundPanel() {
  if (app.user.role !== 'coordinator') return '';
  return renderRoundBuilder();
}

function renderBallotsView() {
  const ballots = app.data.ballots || [];
  const isCoordinator = app.user.role === 'coordinator';
  return `
    <div class="stack-gap">
      ${isCoordinator ? renderCreateForm() : '<section class="note"><h3>Ballots you can see</h3><p class="mini">Open ballots you are eligible for and published outcomes are shown here.</p></section>'}
      ${isCoordinator ? renderRoundPanel() : ''}
      <div class="list">
        ${ballots.length ? ballots.map(renderBallotCard).join('') : '<p class="note">There are no visible ballots yet.</p>'}
      </div>
    </div>
  `;
}

function renderVoteView() {
  const ballots = (app.data.ballots || []).filter((ballot) => ballot.status === 'open');
  if (app.user.role !== 'member') {
    return `<section class="note"><h3>Vote</h3><p class="mini">Only Members can submit ballots.</p></section>`;
  }
  const openBallots = ballots;
  return `
    <div class="stack-gap">
      <section class="note">
        <header>
          <h3>Before you submit</h3>
          <span class="badge">Anonymous vote</span>
        </header>
        <p class="mini">Staff can see turnout, but not your choices. After submission, you will only receive a participation confirmation.</p>
      </section>
      <div class="list">
        ${openBallots.length ? openBallots.map((ballot) => renderVoteCard(ballot)).join('') : '<p class="note">No open ballot is currently available to you.</p>'}
      </div>
    </div>
  `;
}

function renderVoteCard(ballot) {
  if (ballot.participated) {
    return `
      <article class="item">
        <header>
          <div>
            <h3>${escapeHtml(ballot.title)}</h3>
            <p class="mini">You submitted this ballot at ${formatDate(ballot.my_participation?.submitted_at)}</p>
          </div>
          <span class="badge" data-status="open">Already submitted</span>
        </header>
      </article>
    `;
  }
  const choices = ballot.choices || [];
  const isSingle = ballot.method === 'single';
  return `
    <article class="item">
      <header>
        <div>
          <h3>${escapeHtml(ballot.title)}</h3>
          <p class="mini">${escapeHtml(ballot.description || 'No context provided.')}</p>
        </div>
        <span class="badge" data-status="open">Open</span>
      </header>
      <form class="stack" data-form-type="vote-ballot" data-ballot-id="${escapeHtml(ballot.id)}">
        <p class="mini">${isSingle ? 'Pick exactly one option.' : `Pick up to ${ballot.max_selections} different options.`}</p>
        <div class="choice-list">
          ${choices.map((choice, index) => `
            <label class="choice-item">
              <input type="${isSingle ? 'radio' : 'checkbox'}" name="choice_ids" value="${escapeHtml(choice.id)}" ${isSingle ? '' : ''} />
              ${escapeHtml(choice.label)}
            </label>
          `).join('')}
        </div>
        <p class="note">
          Your final submission is private. The browser confirms only that participation was recorded.
        </p>
        <div class="inline-actions">
          <button type="submit" class="primary">Submit anonymous vote</button>
        </div>
      </form>
    </article>
  `;
}

function renderTurnoutView() {
  const rows = app.data.turnout || [];
  if (app.user.role === 'member') {
    const myRows = rows.map((row) => `
      <article class="summary">
        <header>
          <h3>${escapeHtml(row.title)}</h3>
          <span class="badge" data-status="${escapeHtml(row.status)}">${statusLabel(row.status_label)}</span>
        </header>
        <div class="details-grid">
          <div><strong>Participation</strong><dd>${row.my_participation ? `Submitted at ${formatDate(row.my_participation.submitted_at)}` : 'Not yet submitted'}</dd></div>
          <div><strong>Participant count</strong><dd>${row.participant_count}</dd></div>
        </div>
      </article>
    `).join('');
    return myRows || '<p class="note">No turnout details are available yet.</p>';
  }
  return `
    <div class="list">
      ${rows.map((row) => `
        <article class="summary">
          <header>
            <div>
              <h3>${escapeHtml(row.title)}</h3>
              <p class="mini">Revision ${row.revision}</p>
            </div>
            <span class="badge" data-status="${escapeHtml(row.status)}">${statusLabel(row.status_label)}</span>
          </header>
          <div class="details-grid">
            <div><strong>Eligible</strong><dd>${row.eligible_count}</dd></div>
            <div><strong>Participated</strong><dd>${row.participant_count}</dd></div>
          </div>
          <details>
            <summary>Eligible Members</summary>
            <div class="roster-list">
              ${(row.eligible_members || []).map((member) => `
                <div class="roster-item">
                  <div class="row">
                    <strong>${escapeHtml(member.name)}</strong>
                    <span class="badge" data-tone="${member.participated ? 'danger' : 'muted'}">${member.participated ? 'Participated' : 'Not yet participated'}</span>
                  </div>
                  <p class="small">${escapeHtml(member.email)} · ${member.active ? 'Active' : 'Paused'} · ${member.submitted_at ? `Submitted ${formatDate(member.submitted_at)}` : 'No submission'}</p>
                </div>
              `).join('')}
            </div>
          </details>
        </article>
      `).join('')}
    </div>
  `;
}

function renderResultsView() {
  const rows = app.data.results || [];
  return `
    <div class="list">
      ${rows.map((row) => `
        <article class="summary">
          <header>
            <div>
              <h3>${escapeHtml(row.title)}</h3>
              <p class="mini">${row.published ? `Published ${formatDate(row.published_at)}` : row.message}</p>
            </div>
            <span class="badge" data-status="${escapeHtml(row.status)}">${statusLabel(row.status_label)}</span>
          </header>
          ${row.published ? renderResultBody(row.result_summary) : `<p class="note">${escapeHtml(row.message)}</p>`}
        </article>
      `).join('')}
    </div>
  `;
}

function renderResultBody(summary) {
  if (summary.total_ballots !== undefined) {
    return `
      <div class="stack-gap">
        <p class="mini">${summary.total_ballots} total ballots</p>
        <div class="result-list">
          ${summary.choices.map((choice) => renderChoiceSummary(choice, 'percentage', 'count')).join('')}
        </div>
      </div>
    `;
  }
  return `
    <div class="stack-gap">
      <p class="mini">${summary.participating_members} participating members</p>
      <div class="result-list">
        ${summary.choices.map((choice) => renderChoiceSummary(choice, 'percentage', 'approvals')).join('')}
      </div>
    </div>
  `;
}

function renderMembersView() {
  const rows = app.data.members || [];
  if (!rows.length) return '<p class="note">No membership data is available yet.</p>';
  return `
    <div class="list">
      ${rows.map((member) => `
        <article class="summary">
          <header>
            <div>
              <h3>${escapeHtml(member.name)}</h3>
              <p class="mini">${escapeHtml(member.email)} · ${escapeHtml(member.role)}</p>
            </div>
            <span class="badge" data-status="${member.active ? 'active' : 'paused'}">${member.active ? 'Active' : 'Paused'}</span>
          </header>
          <div class="details-grid">
            <div><strong>Revision</strong><dd>${member.revision}</dd></div>
            <div><strong>Updated</strong><dd>${formatDate(member.updated_at)}</dd></div>
          </div>
          ${app.user.role === 'coordinator' ? renderMembershipControls(member) : ''}
        </article>
      `).join('')}
    </div>
  `;
}

function renderMembershipControls(member) {
  return `
    <form class="row" data-form-type="membership" data-member-id="${escapeHtml(member.user_id)}">
      <input type="hidden" name="expected_revision" value="${member.revision}" />
      <div>
        <label>Status</label>
        <select name="status">
          <option value="active" ${member.active ? 'selected' : ''}>Active</option>
          <option value="paused" ${!member.active ? 'selected' : ''}>Paused</option>
        </select>
      </div>
      <button type="submit" class="primary">Save status</button>
    </form>
  `;
}

function renderAuditView() {
  const rows = app.data.audit || [];
  return `
    <div class="audit-list">
      ${rows.map((row) => `
        <article class="audit-item">
          <header>
            <strong>${escapeHtml(statusLabel(row.action))}</strong>
            <span class="badge">${escapeHtml(row.entity_type)} · ${escapeHtml(row.entity_id)}</span>
          </header>
          <p class="mini">${escapeHtml(row.details)}</p>
          <p class="small">${escapeHtml(row.actor_label)} · ${formatDate(row.created_at)}</p>
        </article>
      `).join('')}
    </div>
  `;
}

function renderPending() {
  if (!app.user) {
    els.pendingList.innerHTML = '';
    return;
  }
  if (!app.pending.length) {
    els.pendingList.innerHTML = '<p class="note">No pending actions right now.</p>';
    return;
  }
  els.pendingList.innerHTML = app.pending.map((entry) => `
    <article class="pending-card ${entry.inFlight ? 'busy' : ''}" data-pending-id="${escapeHtml(entry.operationId)}">
      <header>
        <div>
          <h3>${escapeHtml(entry.label)}</h3>
          <p class="mini">${escapeHtml(entry.action)} · ${formatDate(entry.createdAt)}</p>
        </div>
        <span class="badge" data-tone="${entry.inFlight ? 'muted' : entry.status === 'unknown' ? 'danger' : 'muted'}">${entry.inFlight ? 'Working' : entry.status === 'unknown' ? 'Outcome unknown' : entry.status === 'needs_signin' ? 'Needs sign-in' : 'Pending'}</span>
      </header>
      <p class="statusline">${entry.inFlight ? 'Waiting for the current attempt to finish.' : entry.status === 'unknown' ? 'The outcome is unknown. Retry when you are ready.' : 'This reminder is waiting for confirmation.'}</p>
      ${entry.lastError ? `<p class="errorline">${escapeHtml(entry.lastError)}</p>` : ''}
      <div class="inline-actions">
        <button type="button" class="primary" data-action="retry-pending" data-pending-id="${escapeHtml(entry.operationId)}" ${entry.inFlight ? 'disabled' : ''}>Retry</button>
        <button type="button" class="secondary" data-action="dismiss-pending" data-pending-id="${escapeHtml(entry.operationId)}">Dismiss</button>
      </div>
    </article>
  `).join('');
}

function updateShell() {
  const loggedIn = Boolean(app.user);
  els.signIn.classList.toggle('hidden', loggedIn);
  els.workspace.classList.toggle('hidden', !loggedIn);
  if (!loggedIn) return;
  els.identity.textContent = `${app.user.name} · ${statusLabel(app.user.role)}`;
  els.groupName.textContent = groupToString(app.data?.group);
  els.nav.querySelectorAll('button[data-view]').forEach((button) => {
    button.setAttribute('aria-current', button.dataset.view === app.view ? 'page' : 'false');
  });
  els.viewTitle.textContent = statusLabel(app.view);
  els.viewCopy.textContent = views[app.view] || '';
  els.viewEyebrow.textContent = 'Workspace';
}

function renderView() {
  if (!app.user || !app.data) {
    els.view.innerHTML = '<p class="note">Signing in…</p>';
    renderPending();
    return;
  }
  updateShell();
  switch (app.view) {
    case 'ballots':
      els.view.innerHTML = renderBallotsView();
      break;
    case 'vote':
      els.view.innerHTML = renderVoteView();
      break;
    case 'turnout':
      els.view.innerHTML = renderTurnoutView();
      break;
    case 'results':
      els.view.innerHTML = renderResultsView();
      break;
    case 'members':
      els.view.innerHTML = renderMembersView();
      break;
    case 'audit':
      els.view.innerHTML = renderAuditView();
      break;
    default:
      els.view.innerHTML = '<p class="note">Choose a workspace above.</p>';
  }
  renderPending();
  renderModals();
}

function renderModals() {
  if (app.draftConflict) {
    els.modalRoot.innerHTML = renderDraftConflictModal();
    return;
  }
  if (app.roundReview) {
    els.modalRoot.innerHTML = renderRoundReviewModal();
    return;
  }
  els.modalRoot.innerHTML = '';
}

function render() {
  updateShell();
  if (app.user && app.data) {
    renderView();
  } else {
    els.view.innerHTML = '';
    els.pendingList.innerHTML = '';
    els.modalRoot.innerHTML = '';
  }
}

function setUserFromState(data) {
  app.user = data?.user || null;
  app.data = data || null;
  app.pending = app.user ? loadPending(app.user.id) : [];
  if (app.user && !app.data) {
    app.data = null;
  }
  if (app.user && !localStorage.getItem(STORAGE.view)) {
    app.view = 'ballots';
  }
}

async function loadState() {
  try {
    const data = await request('/api/state');
    setUserFromState(data);
    render();
    return data;
  } catch (error) {
    if (error.status === 401) {
      app.user = null;
      app.data = null;
      app.pending = [];
      app.draftConflict = null;
      app.roundReview = null;
      render();
      return null;
    }
    throw error;
  }
}

async function refreshAfterSuccess(message) {
  try {
    await loadState();
    if (message) setStatus(message);
  } catch (error) {
    setStatus(message ? `${message} Refresh problem: ${error.message}` : `Refresh problem: ${error.message}`);
  }
}

function payloadFromDraftForm(form) {
  const values = collectFormValues(form);
  const choices = collectChoiceValues(form);
  return {
    title: values.title?.trim() || '',
    description: values.description?.trim() || '',
    method: values.method,
    max_selections: values.max_selections,
    choices,
  };
}

function mergedDraftPayload(conflict, selection) {
  const { original, attempted, latest } = conflict;
  const title = selection.title === 'mine'
    ? attempted.title
    : selection.title === 'latest'
      ? latest.title
      : attempted.title !== original.title
        ? attempted.title
        : latest.title;
  const description = selection.description === 'mine'
    ? attempted.description
    : selection.description === 'latest'
      ? latest.description
      : attempted.description !== original.description
        ? attempted.description
        : latest.description;
  const definition = selection.definition === 'mine'
    ? attempted
    : selection.definition === 'latest'
      ? latest
      : diffDefinition(attempted, original) && !diffDefinition(latest, original)
        ? attempted
        : latest;
  return {
    expected_revision: latest.revision,
    title,
    description,
    method: definition.method,
    max_selections: definition.max_selections,
    choices: definition.choices,
  };
}

async function submitWithPending({ action, label, endpoint, payload, successMessage, onKnownFailureKeep = false }) {
  const operationId = payload.operation_id || makeOperationId();
  const requestPayload = { ...payload, operation_id: operationId };
  addPendingEntry({
    operationId,
    userId: app.user.id,
    action,
    label,
    payload: requestPayload,
    createdAt: new Date().toISOString(),
    status: 'pending',
    inFlight: true,
    inFlightAt: Date.now(),
    lastError: '',
  });
  try {
    const result = await request(endpoint, { method: 'POST', body: requestPayload });
    removePendingEntry(operationId);
    await refreshAfterSuccess(successMessage || `${label} saved.`);
    return result;
  } catch (error) {
    if (error.status === 401 || error.status === 403) {
      updatePendingEntry(operationId, {
        inFlight: false,
        status: 'needs_signin',
        lastError: error.message,
      });
      setStatus(error.message);
      return null;
    }
    if (error.status && error.status < 500) {
      removePendingEntry(operationId);
      setStatus(error.message);
      await refreshAfterSuccess('The workspace was refreshed after the refusal.');
      return null;
    }
    updatePendingEntry(operationId, {
      inFlight: false,
      status: 'unknown',
      lastError: error.message || 'The outcome is unknown.',
    });
    setStatus('The outcome is unknown. You can retry from Pending actions.');
    return null;
  }
}

function clearEditorState() {
  app.editingBallotId = null;
}

function openEditForm(ballotId) {
  app.editingBallotId = ballotId;
  renderView();
}

function closeConflict() {
  app.draftConflict = null;
  renderModals();
}

function closeRoundReview() {
  app.roundReview = null;
  renderModals();
}

function selectedRoundIds() {
  return Array.from(document.querySelectorAll('[data-round-select]:checked')).map((input) => input.value);
}

function addChoiceRow(target) {
  const group = target.closest('.choice-group');
  if (!group) return;
  const count = group.querySelectorAll('[data-choice-row]').length + 1;
  const prefix = group.closest('form')?.dataset.formType === 'create-ballot' ? 'new-choice' : 'edit-choice';
  const row = document.createElement('div');
  row.className = 'row choice-row';
  row.dataset.choiceRow = 'true';
  row.innerHTML = `<input type="text" name="${prefix}-${count}" placeholder="Choice ${count}" data-choice-input /> <button type="button" class="secondary" data-action="remove-choice">Remove</button>`;
  group.insertBefore(row, target.closest('.row'));
}

function removeChoiceRow(button) {
  const row = button.closest('[data-choice-row]');
  const group = button.closest('.choice-group');
  if (!row || !group) return;
  if (group.querySelectorAll('[data-choice-row]').length <= 2) {
    setStatus('A ballot needs at least two choices.');
    return;
  }
  row.remove();
}

function collectChoicesForForm(form) {
  return Array.from(form.querySelectorAll('[data-choice-input]'))
    .map((input) => input.value.trim())
    .filter(Boolean);
}

function resolveRadioValue(form, name, fallback = 'latest') {
  const checked = form.querySelector(`input[name="${name}"]:checked`);
  return checked ? checked.value : fallback;
}

function currentEditorBallot() {
  if (!app.editingBallotId) return null;
  return (app.data.ballots || []).find((ballot) => ballot.id === app.editingBallotId) || null;
}

function normalizeDraftPayload(payload) {
  return {
    title: payload.title.trim(),
    description: payload.description.trim(),
    method: payload.method,
    max_selections: Number(payload.max_selections),
    choices: payload.choices,
  };
}

function diffDefinition(a, b) {
  return a.method !== b.method || Number(a.max_selections) !== Number(b.max_selections) || JSON.stringify(a.choices || []) !== JSON.stringify(b.choices || []);
}

function buildConflictFromForm(form, ballotId) {
  const original = JSON.parse(form.dataset.original);
  const attempted = normalizeDraftPayload(payloadFromDraftForm(form));
  attempted.max_selections = Number(attempted.max_selections);
  attempted.choices = collectChoicesForForm(form);
  const latest = currentEditorBallot();
  return {
    ballotId,
    original,
    attempted,
    latest,
  };
}

function installNavigation() {
  els.nav.addEventListener('click', (event) => {
    const button = event.target.closest('[data-view]');
    if (!button) return;
    setView(button.dataset.view);
  });
}

function installLogin() {
  document.querySelector('#login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = event.currentTarget.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      await request('/api/auth/login', {
        method: 'POST',
        body: {
          email: document.querySelector('#email').value,
          password: document.querySelector('#password').value,
        },
      });
      setStatus('Signed in.');
      await loadState();
    } catch (error) {
      setStatus(error.message);
    } finally {
      button.disabled = false;
    }
  });
}

function installHeaderActions() {
  document.querySelector('#logout').addEventListener('click', async () => {
    try {
      await request('/api/auth/logout', { method: 'POST', body: {} });
      app.user = null;
      app.data = null;
      app.pending = [];
      app.draftConflict = null;
      app.roundReview = null;
      setStatus('Signed out.');
      render();
    } catch (error) {
      setStatus(error.message);
    }
  });
  document.querySelector('#logout-all').addEventListener('click', async () => {
    try {
      await request('/api/auth/logout-all', { method: 'POST', body: {} });
      app.user = null;
      app.data = null;
      app.pending = [];
      app.draftConflict = null;
      app.roundReview = null;
      setStatus('All sessions ended.');
      render();
    } catch (error) {
      setStatus(error.message);
    }
  });
  document.querySelector('#theme').addEventListener('click', () => {
    applyTheme(currentTheme() === 'dark' ? 'light' : 'dark');
  });
}

function installStorageSync() {
  window.addEventListener('storage', (event) => {
    if (event.key === STORAGE.theme) {
      applyTheme(event.newValue || 'light');
      return;
    }
    if (event.key === pendingKey(app.user?.id)) {
      refreshPendingFromStorage();
      renderPending();
    }
  });
}

async function handleFormSubmit(form) {
  const type = form.dataset.formType;
  if (type === 'create-ballot') {
    const payload = payloadFromDraftForm(form);
    payload.max_selections = Number(payload.max_selections);
    payload.choices = collectChoicesForForm(form);
    if (payload.choices.length < 2) {
      setStatus('Please enter at least two distinct choices.');
      return;
    }
    if (payload.method === 'single') payload.max_selections = 1;
    if (payload.method === 'approval' && (payload.max_selections < 1 || payload.max_selections > payload.choices.length)) {
      setStatus('Approval maximum must be between 1 and the number of choices.');
      return;
    }
    await submitWithPending({
      action: 'create-ballot',
      label: `Create draft ${payload.title || 'ballot'}`,
      endpoint: '/api/ballots',
      payload,
      successMessage: `Draft ${payload.title} created.`,
    });
    form.reset();
    return;
  }
  if (type === 'edit-ballot') {
    const ballotId = form.dataset.ballotId;
    const payload = payloadFromDraftForm(form);
    payload.max_selections = Number(payload.max_selections);
    payload.choices = collectChoicesForForm(form);
    if (payload.choices.length < 2) {
      setStatus('Please enter at least two distinct choices.');
      return;
    }
    const expectedRevision = Number(form.querySelector('[name="expected_revision"]').value);
    if (payload.method === 'single') payload.max_selections = 1;
    if (payload.method === 'approval' && (payload.max_selections < 1 || payload.max_selections > payload.choices.length)) {
      setStatus('Approval maximum must be between 1 and the number of choices.');
      return;
    }
    const original = JSON.parse(form.dataset.original);
    const attempted = normalizeDraftPayload(payload);
    attempted.max_selections = Number(attempted.max_selections);
    attempted.choices = collectChoicesForForm(form);
    const result = await submitWithPending({
      action: 'edit-draft',
      label: `Edit draft ${payload.title || ballotId}`,
      endpoint: `/api/ballots/${ballotId}/draft`,
      payload: { expected_revision: expectedRevision, ...payload },
      successMessage: `Draft ${payload.title} saved.`,
    });
    if (result) {
      app.editingBallotId = null;
      return;
    }
    if (app.data && app.data.ballots) {
      const refreshed = app.data.ballots.find((ballot) => ballot.id === ballotId);
      if (refreshed && refreshed.revision !== expectedRevision) {
        app.draftConflict = { ballotId, original, attempted, latest: refreshed };
        renderModals();
      }
    }
    return;
  }
  if (type === 'resolve-conflict') {
    const ballotId = form.dataset.ballotId;
    const conflict = app.draftConflict;
    if (!conflict) return;
    const original = JSON.parse(form.dataset.original);
    const attempted = JSON.parse(form.dataset.attempted);
    const latest = JSON.parse(form.dataset.latest);
    const titleChoice = form.querySelector('input[name="title-choice"]') ? resolveRadioValue(form, 'title-choice') : null;
    const descriptionChoice = form.querySelector('input[name="description-choice"]') ? resolveRadioValue(form, 'description-choice') : null;
    const definitionChoice = form.querySelector('input[name="definition-choice"]') ? resolveRadioValue(form, 'definition-choice') : null;
    const resolved = mergedDraftPayload({ original, attempted, latest }, {
      title: titleChoice,
      description: descriptionChoice,
      definition: definitionChoice,
    });
    const result = await submitWithPending({
      action: 'edit-draft',
      label: `Save reviewed draft ${ballotId}`,
      endpoint: `/api/ballots/${ballotId}/draft`,
      payload: resolved,
      successMessage: 'Reviewed draft saved.',
    });
    if (result) {
      app.draftConflict = null;
      app.editingBallotId = null;
    }
    return;
  }
  if (type === 'vote-ballot') {
    const ballotId = form.dataset.ballotId;
    const ballot = (app.data.ballots || []).find((item) => item.id === ballotId);
    const isSingle = ballot.method === 'single';
    const selected = Array.from(form.querySelectorAll('input[name="choice_ids"]:checked')).map((input) => input.value);
    if (!selected.length) {
      setStatus('Please choose at least one option.');
      return;
    }
    if (isSingle && selected.length !== 1) {
      setStatus('Please choose exactly one option.');
      return;
    }
    if (!isSingle && selected.length > ballot.max_selections) {
      setStatus('You chose too many options for this ballot.');
      return;
    }
    await submitWithPending({
      action: 'vote-ballot',
      label: `Vote on ${ballot.title}`,
      endpoint: `/api/ballots/${ballotId}/vote`,
      payload: { choice_ids: selected },
      successMessage: 'Your participation was recorded anonymously.',
    });
    return;
  }
  if (type === 'membership') {
    const memberId = form.dataset.memberId;
    const status = form.querySelector('[name="status"]').value;
    const expected_revision = Number(form.querySelector('[name="expected_revision"]').value);
    const member = (app.data.members || []).find((row) => row.user_id === memberId);
    await submitWithPending({
      action: 'update-membership',
      label: `Update ${member?.name || 'member'}`,
      endpoint: `/api/memberships/${memberId}`,
      payload: { expected_revision, status },
      successMessage: `${member?.name || 'Member'} updated.`,
    });
    return;
  }
}

async function handleClick(event) {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const action = button.dataset.action;
  if (action === 'add-choice') {
    event.preventDefault();
    addChoiceRow(button);
    return;
  }
  if (action === 'remove-choice') {
    event.preventDefault();
    removeChoiceRow(button);
    return;
  }
  if (action === 'toggle-edit') {
    event.preventDefault();
    openEditForm(button.dataset.ballotId);
    return;
  }
  if (action === 'cancel-edit') {
    event.preventDefault();
    clearEditorState();
    renderView();
    return;
  }
  if (action === 'open-ballot' || action === 'close-ballot' || action === 'publish-ballot') {
    event.preventDefault();
    const ballotId = button.dataset.ballotId;
    const ballot = (app.data.ballots || []).find((item) => item.id === ballotId);
    const endpoint = action === 'open-ballot' ? `/api/ballots/${ballotId}/open` : action === 'close-ballot' ? `/api/ballots/${ballotId}/close` : `/api/ballots/${ballotId}/publish`;
    await submitWithPending({
      action: action === 'open-ballot' ? 'open-ballot' : action === 'close-ballot' ? 'close-ballot' : 'publish-ballot',
      label: `${statusLabel(action.replace(/-ballot$/, ''))} ${ballot?.title || ballotId}`,
      endpoint,
      payload: { expected_revision: Number(button.dataset.revision) },
      successMessage: `${ballot?.title || 'Ballot'} updated.`,
    });
    return;
  }
  if (action === 'review-round') {
    event.preventDefault();
    const ballotIds = selectedRoundIds();
    if (ballotIds.length < 2) {
      setStatus('Select at least two drafts to review as a round.');
      return;
    }
    try {
      const review = await request('/api/ballots/open-review', { method: 'POST', body: { ballot_ids: ballotIds } });
      app.roundReview = review;
      renderModals();
    } catch (error) {
      setStatus(error.message);
    }
    return;
  }
  if (action === 'confirm-round') {
    event.preventDefault();
    if (!app.roundReview) return;
    const ballotIds = app.roundReview.selection.map((ballot) => ballot.id);
    const reviewedBallots = app.roundReview.selection.map((ballot) => ({ id: ballot.id, revision: ballot.revision }));
    await submitWithPending({
      action: 'open-round',
      label: `Open round: ${app.roundReview.selection.map((ballot) => ballot.title).join(', ')}`,
      endpoint: '/api/ballots/open-round',
      payload: {
        ballot_ids: ballotIds,
        reviewed_ballots: reviewedBallots,
        roster_version: app.roundReview.roster.version,
      },
      successMessage: 'The round opened successfully.',
    });
    app.roundReview = null;
    return;
  }
  if (action === 'cancel-round-review') {
    event.preventDefault();
    app.roundReview = null;
    renderModals();
    return;
  }
  if (action === 'close-conflict') {
    event.preventDefault();
    app.draftConflict = null;
    renderModals();
    return;
  }
  if (action === 'discard-conflict') {
    event.preventDefault();
    app.draftConflict = null;
    renderModals();
    return;
  }
  if (action === 'retry-pending') {
    event.preventDefault();
    const pending = app.pending.find((entry) => entry.operationId === button.dataset.pendingId);
    if (!pending || pending.inFlight) return;
    updatePendingEntry(pending.operationId, { inFlight: true, inFlightAt: Date.now(), lastError: '' });
    try {
      const result = await request(endpointFromPending(pending), { method: 'POST', body: pending.payload });
      removePendingEntry(pending.operationId);
      await refreshAfterSuccess('The saved action was confirmed.');
      return result;
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        updatePendingEntry(pending.operationId, { inFlight: false, status: 'needs_signin', lastError: error.message });
        setStatus(error.message);
        return;
      }
      if (error.status && error.status < 500) {
        removePendingEntry(pending.operationId);
        setStatus(error.message);
        await refreshAfterSuccess('The workspace was refreshed after the retry result.');
        return;
      }
      updatePendingEntry(pending.operationId, { inFlight: false, status: 'unknown', lastError: error.message || 'The outcome is unknown.' });
      setStatus('The outcome is unknown. You can retry from Pending actions.');
      return;
    }
  }
  if (action === 'dismiss-pending') {
    event.preventDefault();
    removePendingEntry(button.dataset.pendingId);
    setStatus('The reminder was dismissed.');
    return;
  }
}

function endpointFromPending(entry) {
  if (entry.action === 'create-ballot') return '/api/ballots';
  if (entry.action === 'edit-draft') return `/api/ballots/${entry.payload.ballot_id}/draft`;
  if (entry.action === 'open-ballot') return `/api/ballots/${entry.payload.ballot_id}/open`;
  if (entry.action === 'close-ballot') return `/api/ballots/${entry.payload.ballot_id}/close`;
  if (entry.action === 'publish-ballot') return `/api/ballots/${entry.payload.ballot_id}/publish`;
  if (entry.action === 'vote-ballot') return `/api/ballots/${entry.payload.ballot_id}/vote`;
  if (entry.action === 'update-membership') return `/api/memberships/${entry.payload.member_id}`;
  if (entry.action === 'open-round') return '/api/ballots/open-round';
  return '/api/state';
}

function installWorkspaceHandlers() {
  els.view.addEventListener('submit', async (event) => {
    const form = event.target.closest('form');
    if (!form) return;
    event.preventDefault();
    await handleFormSubmit(form);
  });
  els.view.addEventListener('click', handleClick);
  els.modalRoot.addEventListener('click', handleClick);
}

async function boot() {
  applyTheme(currentTheme());
  loadLoginHints();
  installLogin();
  installHeaderActions();
  installNavigation();
  installWorkspaceHandlers();
  installStorageSync();
  try {
    await loadState();
  } catch (error) {
    setStatus(error.message);
  }
  render();
}

window.addEventListener('DOMContentLoaded', boot);
