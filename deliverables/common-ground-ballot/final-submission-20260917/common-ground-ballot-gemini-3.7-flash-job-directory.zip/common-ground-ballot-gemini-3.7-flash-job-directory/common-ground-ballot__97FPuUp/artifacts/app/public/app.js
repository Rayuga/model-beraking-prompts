// Common Ground Frontend Application
(function() {
  "use strict";

  const TAB_ID = "tab-" + Math.random().toString(36).substring(2, 9);
  const PENDING_STORAGE_KEY = "cg_pending_actions";
  const THEME_STORAGE_KEY = "cg_theme";

  // Application State
  const state = {
    user: null,
    activeView: "ballots",
    ballots: [],
    turnout: [],
    results: [],
    members: [],
    audit: [],
    selectedRoundDraftIds: new Set(),
    draftEditingBase: null, // used for 3-way merge
    conflictState: null
  };

  // DOM Elements
  const el = {
    statusWrapper: document.getElementById("status-wrapper"),
    statusBox: document.getElementById("status-box"),
    statusMessage: document.getElementById("status-message"),
    statusDismiss: document.getElementById("status-dismiss"),
    signInShell: document.getElementById("sign-in"),
    workspaceShell: document.getElementById("workspace"),
    loginForm: document.getElementById("login-form"),
    loginBtn: document.getElementById("login-btn"),
    emailInput: document.getElementById("email"),
    passwordInput: document.getElementById("password"),
    identity: document.getElementById("identity"),
    themeBtn: document.getElementById("theme"),
    logoutBtn: document.getElementById("logout"),
    logoutAllBtn: document.getElementById("logout-all"),
    pendingSection: document.getElementById("pending-actions-section"),
    pendingList: document.getElementById("pending-actions-list"),
    navButtons: document.querySelectorAll(".nav-btn"),
    viewTitle: document.getElementById("view-title"),
    viewCopy: document.getElementById("view-copy"),
    viewPanels: {
      ballots: document.getElementById("view-panel-ballots"),
      vote: document.getElementById("view-panel-vote"),
      turnout: document.getElementById("view-panel-turnout"),
      results: document.getElementById("view-panel-results"),
      members: document.getElementById("view-panel-members"),
      audit: document.getElementById("view-panel-audit")
    },
    coordinatorBallotControls: document.getElementById("coordinator-ballot-controls"),
    btnShowCreateDraft: document.getElementById("btn-show-create-draft"),
    btnReviewRound: document.getElementById("btn-review-round"),
    roundSelectedCount: document.getElementById("round-selected-count"),
    ballotsContainer: document.getElementById("ballots-container"),
    votingContainer: document.getElementById("voting-container"),
    turnoutContainer: document.getElementById("turnout-container"),
    resultsContainer: document.getElementById("results-container"),
    membersContainer: document.getElementById("members-container"),
    auditContainer: document.getElementById("audit-container"),

    // Modals
    modalDraft: document.getElementById("modal-draft"),
    modalDraftTitle: document.getElementById("modal-draft-title"),
    modalDraftClose: document.getElementById("modal-draft-close"),
    draftForm: document.getElementById("draft-form"),
    draftBallotId: document.getElementById("draft-ballot-id"),
    draftBallotRevision: document.getElementById("draft-ballot-revision"),
    draftTitle: document.getElementById("draft-title"),
    draftDesc: document.getElementById("draft-desc"),
    draftMethod: document.getElementById("draft-method"),
    draftMaxGroup: document.getElementById("draft-max-group"),
    draftMax: document.getElementById("draft-max"),
    draftChoicesList: document.getElementById("draft-choices-list"),
    btnAddChoice: document.getElementById("btn-add-choice"),
    btnDraftCancel: document.getElementById("btn-draft-cancel"),
    btnDraftSave: document.getElementById("btn-draft-save"),

    modalRoundReview: document.getElementById("modal-round-review"),
    modalRoundClose: document.getElementById("modal-round-close"),
    roundReviewBallots: document.getElementById("round-review-ballots"),
    roundReviewRoster: document.getElementById("round-review-roster"),
    roundReviewBallotCount: document.getElementById("round-review-ballot-count"),
    roundReviewRosterCount: document.getElementById("round-review-roster-count"),
    btnRoundCancel: document.getElementById("btn-round-cancel"),
    btnRoundConfirm: document.getElementById("btn-round-confirm"),

    modalDraftConflict: document.getElementById("modal-draft-conflict"),
    modalConflictClose: document.getElementById("modal-conflict-close"),
    conflictLockedWarning: document.getElementById("conflict-locked-warning"),
    conflictSectionsContainer: document.getElementById("conflict-sections-container"),
    conflictTitleChoices: document.getElementById("conflict-title-choices"),
    conflictDescChoices: document.getElementById("conflict-desc-choices"),
    conflictVotingChoices: document.getElementById("conflict-voting-choices"),
    conflictMergedPreview: document.getElementById("conflict-merged-preview"),
    btnConflictDiscard: document.getElementById("btn-conflict-discard"),
    btnConflictSave: document.getElementById("btn-conflict-save")
  };

  const viewDescriptions = {
    ballots: "Build and manage membership decisions.",
    vote: "Submit one final private choice on an eligible open ballot.",
    turnout: "Review participation without revealing selections.",
    results: "Read exact outcomes after publication.",
    members: "Manage the roster used by future ballots.",
    audit: "Review administrative activity without private choices."
  };

  // Helper: Notifications / Status announcements
  function showStatus(message, type = "info") {
    if (!message) {
      el.statusWrapper.classList.add("hidden");
      el.statusMessage.textContent = "";
      return;
    }
    el.statusMessage.textContent = message;
    el.statusBox.className = "status-box" + (type === "error" ? " error" : type === "warning" ? " warning" : "");
    el.statusWrapper.classList.remove("hidden");
  }

  el.statusDismiss.addEventListener("click", () => {
    el.statusWrapper.classList.add("hidden");
  });

  // Helper: Format Date
  function formatDate(isoStr) {
    if (!isoStr) return "—";
    try {
      const d = new Date(isoStr);
      return d.toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short"
      });
    } catch {
      return isoStr;
    }
  }

  // -------------------------------------------------------------
  // PENDING ACTIONS ENGINE (Client-Side Storage & Multi-Tab Sync)
  // -------------------------------------------------------------

  function getStoredPendingActions() {
    try {
      const raw = localStorage.getItem(PENDING_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function setStoredPendingActions(items) {
    try {
      localStorage.setItem(PENDING_STORAGE_KEY, JSON.stringify(items));
    } catch {}
    renderPendingActions();
  }

  function getUserPendingActions() {
    if (!state.user) return [];
    return getStoredPendingActions().filter(item => item.user_id === state.user.id);
  }

  function addOrUpdatePendingAction(actionItem) {
    const items = getStoredPendingActions().filter(i => i.id !== actionItem.id);
    items.push(actionItem);
    setStoredPendingActions(items);
  }

  function removePendingAction(actionId) {
    const items = getStoredPendingActions().filter(i => i.id !== actionId);
    setStoredPendingActions(items);
  }

  function renderPendingActions() {
    const userActions = getUserPendingActions();
    if (!userActions.length) {
      el.pendingSection.classList.add("hidden");
      el.pendingList.innerHTML = "";
      return;
    }

    el.pendingSection.classList.remove("hidden");
    el.pendingList.innerHTML = userActions.map(item => {
      const isLocked = item.locked_by_tab && item.locked_by_tab !== TAB_ID && (Date.now() - (item.locked_at || 0) < 15000);
      const actionName = {
        create_ballot: "Create Draft",
        edit_ballot: "Edit Draft",
        open_ballot: "Open Ballot",
        round_open: "Round Open",
        close_ballot: "Close Ballot",
        publish_ballot: "Publish Results",
        update_membership: "Membership Update"
      }[item.action] || item.action;

      return `
        <div class="pending-item" data-id="${item.id}">
          <div class="pending-item-details">
            <span class="pending-item-action">${actionName}: ${item.target_label || "Record"}</span>
            <span class="pending-item-target">Status: ${isLocked ? "In flight in another tab" : "Outcome unconfirmed (connection interrupted or server error)"} · Viewed rev: ${item.viewed_revision || 1}</span>
          </div>
          <div class="pending-item-btns">
            <button type="button" class="btn-primary btn-sm btn-retry-pending" data-id="${item.id}" ${isLocked ? "disabled" : ""}>
              ${isLocked ? "Checking..." : "Retry Attempt"}
            </button>
            <button type="button" class="btn-secondary btn-sm btn-dismiss-pending" data-id="${item.id}">
              Dismiss
            </button>
          </div>
        </div>
      `;
    }).join("");

    el.pendingList.querySelectorAll(".btn-retry-pending").forEach(btn => {
      btn.addEventListener("click", () => retryPendingAction(btn.dataset.id));
    });

    el.pendingList.querySelectorAll(".btn-dismiss-pending").forEach(btn => {
      btn.addEventListener("click", () => dismissPendingAction(btn.dataset.id));
    });
  }

  async function retryPendingAction(actionId) {
    const items = getStoredPendingActions();
    const item = items.find(i => i.id === actionId);
    if (!item) return;

    if (!state.user || item.user_id !== state.user.id) {
      showStatus("Cannot retry action belonging to a different account.", "warning");
      return;
    }

    // Lock item
    item.locked_by_tab = TAB_ID;
    item.locked_at = Date.now();
    addOrUpdatePendingAction(item);

    try {
      const response = await fetch(item.url, {
        method: item.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item.payload)
      });
      const result = await response.json();

      // Check if active user is still the same person
      if (state.user && state.user.id === item.user_id) {
        if (response.ok) {
          removePendingAction(item.id);
          showStatus(result.message || "Action confirmed successfully.");
          await refreshCurrentView();
        } else if (response.status === 409) {
          // Definite business refusal receipt returned
          removePendingAction(item.id);
          if (item.action === "edit_ballot" && result.current_ballot) {
            initiateDraftConflictReview(item.payload, result.current_ballot);
          } else {
            showStatus(result.error || "Action was refused by the server.", "warning");
            await refreshCurrentView();
          }
        } else {
          removePendingAction(item.id);
          showStatus(result.error || "Request failed.", "error");
        }
      } else {
        // User changed: silently remove if confirmed
        if (response.ok || response.status === 409) {
          removePendingAction(item.id);
        }
      }
    } catch (err) {
      // Network still failing: release lock so Ruth can retry again
      item.locked_by_tab = null;
      item.locked_at = null;
      addOrUpdatePendingAction(item);
      showStatus("Retry failed: Network connection is still unavailable. Action remains in Pending Actions.", "warning");
    }
  }

  function dismissPendingAction(actionId) {
    removePendingAction(actionId);
    showStatus("Reminder dismissed. Note: Dismissing a reminder does not undo any changes the server may have accepted.");
  }

  // Multi-tab storage listener
  window.addEventListener("storage", (e) => {
    if (e.key === PENDING_STORAGE_KEY) {
      renderPendingActions();
    }
  });

  // -------------------------------------------------------------
  // API CLIENT
  // -------------------------------------------------------------

  async function apiCall(url, options = {}) {
    const method = options.method || "GET";
    const body = options.body;
    const isStaffAction = options.actionType && state.user && (state.user.role === "coordinator" || state.user.role === "observer");

    let opId = options.operation_id;
    let payload = body ? { ...body } : undefined;

    if (method !== "GET") {
      if (!opId) {
        opId = "op-" + crypto.randomUUID();
      }
      if (payload && typeof payload === "object") {
        payload.operation_id = opId;
      }
    }

    if (isStaffAction && method !== "GET") {
      const pendingItem = {
        id: opId,
        user_id: state.user.id,
        action: options.actionType,
        target_label: options.targetLabel || "Ballot record",
        url,
        method,
        payload,
        viewed_revision: options.viewedRevision || 1,
        status: "in_flight",
        locked_by_tab: TAB_ID,
        locked_at: Date.now(),
        created_at: new Date().toISOString()
      };
      addOrUpdatePendingAction(pendingItem);
    }

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: payload !== undefined ? JSON.stringify(payload) : undefined
      });

      let json = null;
      try {
        json = await res.json();
      } catch {}

      if (isStaffAction && method !== "GET") {
        if (res.ok) {
          removePendingAction(opId);
        } else if (res.status === 409) {
          removePendingAction(opId);
          if (options.actionType === "edit_ballot" && json && json.current_ballot) {
            initiateDraftConflictReview(payload, json.current_ballot);
          }
        } else if (res.status >= 400 && res.status < 500) {
          removePendingAction(opId);
        } else {
          // 5xx or unreadable
          const items = getStoredPendingActions();
          const it = items.find(i => i.id === opId);
          if (it) {
            it.locked_by_tab = null;
            it.locked_at = null;
            addOrUpdatePendingAction(it);
          }
        }
      }

      if (!res.ok) {
        const errorMsg = (json && json.error) || `Request failed with status ${res.status}.`;
        const err = new Error(errorMsg);
        err.status = res.status;
        err.body = json;
        throw err;
      }

      return json;
    } catch (err) {
      if (isStaffAction && method !== "GET") {
        if (err.name === "TypeError" || !err.status) {
          const items = getStoredPendingActions();
          const it = items.find(i => i.id === opId);
          if (it) {
            it.locked_by_tab = null;
            it.locked_at = null;
            addOrUpdatePendingAction(it);
          }
          showStatus("Connection error: your action outcome is unknown and was saved to Pending Actions for retry.", "warning");
        }
      }
      throw err;
    }
  }

  // -------------------------------------------------------------
  // THEME MANAGEMENT
  // -------------------------------------------------------------

  function initTheme() {
    const saved = localStorage.getItem(THEME_STORAGE_KEY) || "light";
    setTheme(saved);
  }

  function setTheme(theme) {
    state.theme = theme;
    document.documentElement.dataset.theme = theme;
    el.themeBtn.textContent = `Theme: ${theme === "dark" ? "Dark" : "Light"}`;
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  }

  el.themeBtn.addEventListener("click", () => {
    setTheme(state.theme === "dark" ? "light" : "dark");
  });

  // -------------------------------------------------------------
  // AUTHENTICATION FLOW
  // -------------------------------------------------------------

  function setAuthenticatedUser(user) {
    state.user = user;
    state.selectedRoundDraftIds.clear();

    if (user) {
      el.signInShell.classList.add("hidden");
      el.workspaceShell.classList.remove("hidden");
      el.identity.textContent = `${user.name} · ${user.role.charAt(0).toUpperCase() + user.role.slice(1)}`;
      if (user.role === "coordinator") {
        el.coordinatorBallotControls.classList.remove("hidden");
      } else {
        el.coordinatorBallotControls.classList.add("hidden");
      }
      renderPendingActions();
      navigateTo(state.activeView || "ballots");
    } else {
      el.signInShell.classList.remove("hidden");
      el.workspaceShell.classList.add("hidden");
      el.identity.textContent = "";
      el.pendingSection.classList.add("hidden");
    }
  }

  el.loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    el.loginBtn.disabled = true;
    try {
      const { user } = await apiCall("/api/auth/login", {
        method: "POST",
        body: {
          email: el.emailInput.value.trim(),
          password: el.passwordInput.value
        }
      });
      setAuthenticatedUser(user);
      showStatus(`Welcome, ${user.name}.`);
    } catch (err) {
      showStatus(err.message, "error");
    } finally {
      el.loginBtn.disabled = false;
    }
  });

  document.querySelectorAll(".demo-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      el.emailInput.value = btn.dataset.email;
      el.passwordInput.value = "CommonGround!2026";
    });
  });

  el.logoutBtn.addEventListener("click", async () => {
    try {
      await apiCall("/api/auth/logout", { method: "POST", body: {} });
    } catch {}
    setAuthenticatedUser(null);
    showStatus("Signed out.");
  });

  el.logoutAllBtn.addEventListener("click", async () => {
    try {
      await apiCall("/api/auth/logout-all", { method: "POST", body: {} });
    } catch {}
    setAuthenticatedUser(null);
    showStatus("All Common Ground sessions have been ended.");
  });

  // Check current session on page load
  async function checkInitialSession() {
    try {
      const res = await apiCall("/api/me");
      setAuthenticatedUser(res.user);
    } catch {
      setAuthenticatedUser(null);
    }
  }

  // -------------------------------------------------------------
  // NAVIGATION & VIEW CONTROLLER
  // -------------------------------------------------------------

  function navigateTo(viewName) {
    state.activeView = viewName;
    el.navButtons.forEach(btn => {
      const isTarget = btn.dataset.view === viewName;
      btn.classList.toggle("active", isTarget);
      if (isTarget) {
        btn.setAttribute("aria-current", "page");
      } else {
        btn.removeAttribute("aria-current");
      }
    });

    el.viewTitle.textContent = viewName.charAt(0).toUpperCase() + viewName.slice(1);
    el.viewCopy.textContent = viewDescriptions[viewName] || "";

    Object.keys(el.viewPanels).forEach(key => {
      el.viewPanels[key].classList.toggle("hidden", key !== viewName);
    });

    refreshCurrentView();
  }

  el.navButtons.forEach(btn => {
    btn.addEventListener("click", () => navigateTo(btn.dataset.view));
  });

  async function refreshCurrentView() {
    if (!state.user) return;
    try {
      switch (state.activeView) {
        case "ballots":
          await loadBallotsView();
          break;
        case "vote":
          await loadVoteView();
          break;
        case "turnout":
          await loadTurnoutView();
          break;
        case "results":
          await loadResultsView();
          break;
        case "members":
          await loadMembersView();
          break;
        case "audit":
          await loadAuditView();
          break;
      }
    } catch (err) {
      showStatus(err.message, "error");
    }
  }

  // -------------------------------------------------------------
  // 1. BALLOTS WORKSPACE
  // -------------------------------------------------------------

  async function loadBallotsView() {
    el.ballotsContainer.innerHTML = `<div class="loading-state">Loading ballots...</div>`;
    const res = await apiCall("/api/ballots");
    state.ballots = res.ballots;
    renderBallotsList();
  }

  function renderBallotsList() {
    if (!state.ballots.length) {
      el.ballotsContainer.innerHTML = `<div class="empty-state">No ballots available at this time.</div>`;
      return;
    }

    const isCoordinator = state.user && state.user.role === "coordinator";

    el.ballotsContainer.innerHTML = state.ballots.map(ballot => {
      const isDraft = ballot.status === "draft";
      const isOpen = ballot.status === "open";
      const isClosed = ballot.status === "closed";
      const isPublished = ballot.status === "published";
      const isRoundSelected = state.selectedRoundDraftIds.has(ballot.id);

      let actionButtonsHtml = "";
      if (isCoordinator) {
        if (isDraft) {
          actionButtonsHtml = `
            <label class="round-select-label">
              <input type="checkbox" class="cb-round-select" data-id="${ballot.id}" ${isRoundSelected ? "checked" : ""} />
              <span>Select for Round</span>
            </label>
            <button type="button" class="btn-secondary btn-sm btn-edit-draft" data-id="${ballot.id}">Edit Draft</button>
            <button type="button" class="btn-primary btn-sm btn-open-ballot" data-id="${ballot.id}">Open Ballot</button>
          `;
        } else if (isOpen) {
          actionButtonsHtml = `
            <button type="button" class="btn-secondary btn-sm btn-close-ballot" data-id="${ballot.id}">Close Ballot</button>
          `;
        } else if (isClosed) {
          actionButtonsHtml = `
            <button type="button" class="btn-primary btn-sm btn-publish-ballot" data-id="${ballot.id}">Publish Results</button>
          `;
        } else if (isPublished) {
          actionButtonsHtml = `
            <button type="button" class="btn-secondary btn-sm btn-view-results" data-id="${ballot.id}">View Results</button>
          `;
        }
      } else if (state.user && state.user.role === "member") {
        if (isOpen) {
          if (ballot.user_participated) {
            actionButtonsHtml = `<span class="badge badge-active">Participation Recorded</span>`;
          } else {
            actionButtonsHtml = `<button type="button" class="btn-primary btn-sm btn-go-vote" data-id="${ballot.id}">Vote Now</button>`;
          }
        } else if (isPublished) {
          actionButtonsHtml = `<button type="button" class="btn-secondary btn-sm btn-view-results" data-id="${ballot.id}">View Results</button>`;
        }
      }

      return `
        <article class="card ballot-card">
          <div>
            <div class="ballot-card-header">
              <span class="badge badge-${ballot.status}">${ballot.status.toUpperCase()}</span>
              <span class="text-muted" style="font-size:0.8rem;">Rev ${ballot.revision}</span>
            </div>
            <h2 class="ballot-card-title" style="margin-top:0.4rem;">${ballot.title}</h2>
            <div class="ballot-meta">
              <span>${ballot.method === "single" ? "Single Choice" : `Approval (max ${ballot.max_selections})`}</span>
              <span>·</span>
              <span>${ballot.choices.length} choices</span>
              ${ballot.status !== "draft" ? `<span>·</span><span>${ballot.participant_count} / ${ballot.eligible_count} voted</span>` : ""}
            </div>
            ${ballot.description ? `<p class="ballot-desc" style="margin-top:0.6rem;">${ballot.description}</p>` : ""}
            
            <div class="choices-preview-list" style="margin-top:0.75rem;">
              ${ballot.choices.map(c => `<div class="choice-preview-item"><span class="choice-bullet">•</span> ${c.label}</div>`).join("")}
            </div>
          </div>

          ${actionButtonsHtml ? `<div class="ballot-card-actions">${actionButtonsHtml}</div>` : ""}
        </article>
      `;
    }).join("");

    // Bind event listeners for actions
    el.ballotsContainer.querySelectorAll(".cb-round-select").forEach(cb => {
      cb.addEventListener("change", (e) => {
        if (e.target.checked) {
          state.selectedRoundDraftIds.add(e.target.dataset.id);
        } else {
          state.selectedRoundDraftIds.delete(e.target.dataset.id);
        }
        updateRoundSelectionUI();
      });
    });

    el.ballotsContainer.querySelectorAll(".btn-edit-draft").forEach(btn => {
      btn.addEventListener("click", () => openEditDraftModal(btn.dataset.id));
    });

    el.ballotsContainer.querySelectorAll(".btn-open-ballot").forEach(btn => {
      btn.addEventListener("click", () => executeSingleOpen(btn.dataset.id));
    });

    el.ballotsContainer.querySelectorAll(".btn-close-ballot").forEach(btn => {
      btn.addEventListener("click", () => executeCloseBallot(btn.dataset.id));
    });

    el.ballotsContainer.querySelectorAll(".btn-publish-ballot").forEach(btn => {
      btn.addEventListener("click", () => executePublishBallot(btn.dataset.id));
    });

    el.ballotsContainer.querySelectorAll(".btn-view-results").forEach(btn => {
      btn.addEventListener("click", () => navigateTo("results"));
    });

    el.ballotsContainer.querySelectorAll(".btn-go-vote").forEach(btn => {
      btn.addEventListener("click", () => navigateTo("vote"));
    });

    updateRoundSelectionUI();
  }

  function updateRoundSelectionUI() {
    const count = state.selectedRoundDraftIds.size;
    el.roundSelectedCount.textContent = count;
    el.btnReviewRound.disabled = count < 2;
  }

  // -------------------------------------------------------------
  // DRAFT CREATION & EDITING MODAL
  // -------------------------------------------------------------

  function renderDraftChoicesInputs(choicesArray = ["", ""]) {
    el.draftChoicesList.innerHTML = choicesArray.map((choiceLabel, idx) => `
      <div class="choice-edit-row">
        <input type="text" class="input-choice-label" value="${choiceLabel}" placeholder="Choice ${idx + 1}" required maxlength="200" />
        ${choicesArray.length > 2 ? `<button type="button" class="btn-icon btn-remove-choice" aria-label="Remove choice">✕</button>` : ""}
      </div>
    `).join("");

    el.draftChoicesList.querySelectorAll(".btn-remove-choice").forEach((btn, index) => {
      btn.addEventListener("click", () => {
        const currentVals = getCurrentChoiceValues();
        currentVals.splice(index, 1);
        renderDraftChoicesInputs(currentVals);
      });
    });
  }

  function getCurrentChoiceValues() {
    const inputs = el.draftChoicesList.querySelectorAll(".input-choice-label");
    return Array.from(inputs).map(i => i.value.trim());
  }

  el.btnAddChoice.addEventListener("click", () => {
    const currentVals = getCurrentChoiceValues();
    currentVals.push("");
    renderDraftChoicesInputs(currentVals);
  });

  el.draftMethod.addEventListener("change", () => {
    if (el.draftMethod.value === "approval") {
      el.draftMaxGroup.classList.remove("hidden");
      el.draftMax.required = true;
    } else {
      el.draftMaxGroup.classList.add("hidden");
      el.draftMax.required = false;
      el.draftMax.value = "1";
    }
  });

  el.btnShowCreateDraft.addEventListener("click", () => {
    el.modalDraftTitle.textContent = "Create Draft Ballot";
    el.draftBallotId.value = "";
    el.draftBallotRevision.value = "1";
    el.draftTitle.value = "";
    el.draftDesc.value = "";
    el.draftMethod.value = "single";
    el.draftMax.value = "1";
    el.draftMaxGroup.classList.add("hidden");
    renderDraftChoicesInputs(["", ""]);
    state.draftEditingBase = null;
    el.modalDraft.classList.remove("hidden");
    el.draftTitle.focus();
  });

  function openEditDraftModal(ballotId) {
    const ballot = state.ballots.find(b => b.id === ballotId);
    if (!ballot) return;

    el.modalDraftTitle.textContent = "Edit Draft Ballot";
    el.draftBallotId.value = ballot.id;
    el.draftBallotRevision.value = ballot.revision;
    el.draftTitle.value = ballot.title;
    el.draftDesc.value = ballot.description || "";
    el.draftMethod.value = ballot.method;
    el.draftMax.value = ballot.max_selections;
    if (ballot.method === "approval") {
      el.draftMaxGroup.classList.remove("hidden");
      el.draftMax.required = true;
    } else {
      el.draftMaxGroup.classList.add("hidden");
      el.draftMax.required = false;
    }
    renderDraftChoicesInputs(ballot.choices.map(c => c.label));

    // Save snapshot of base for 3-way merge conflict detection
    state.draftEditingBase = {
      id: ballot.id,
      revision: ballot.revision,
      title: ballot.title,
      description: ballot.description || "",
      method: ballot.method,
      max_selections: ballot.max_selections,
      choices: ballot.choices.map(c => c.label)
    };

    el.modalDraft.classList.remove("hidden");
    el.draftTitle.focus();
  }

  function closeDraftModal() {
    el.modalDraft.classList.add("hidden");
  }

  el.modalDraftClose.addEventListener("click", closeDraftModal);
  el.btnDraftCancel.addEventListener("click", closeDraftModal);

  el.draftForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const ballotId = el.draftBallotId.value;
    const isEdit = !!ballotId;
    const title = el.draftTitle.value.trim();
    const description = el.draftDesc.value.trim();
    const method = el.draftMethod.value;
    const max_selections = method === "single" ? 1 : parseInt(el.draftMax.value, 10);
    const choices = getCurrentChoiceValues().filter(Boolean);
    const revision = parseInt(el.draftBallotRevision.value, 10);

    if (choices.length < 2) {
      showStatus("At least two non-empty choices are required.", "warning");
      return;
    }

    const payload = {
      title,
      description,
      method,
      max_selections,
      choices
    };
    if (isEdit) {
      payload.revision = revision;
    }

    el.btnDraftSave.disabled = true;
    try {
      if (isEdit) {
        await apiCall(`/api/ballots/${ballotId}`, {
          method: "PUT",
          body: payload,
          actionType: "edit_ballot",
          targetLabel: title,
          viewedRevision: revision
        });
        showStatus(`Updated draft "${title}".`);
      } else {
        await apiCall("/api/ballots", {
          method: "POST",
          body: payload,
          actionType: "create_ballot",
          targetLabel: title,
          viewedRevision: 1
        });
        showStatus(`Created draft "${title}".`);
      }
      closeDraftModal();
      await loadBallotsView();
    } catch (err) {
      if (err.status !== 409) {
        showStatus(err.message, "error");
      }
    } finally {
      el.btnDraftSave.disabled = false;
    }
  });

  // -------------------------------------------------------------
  // SINGLE LIFECYCLE ACTIONS (Open, Close, Publish)
  // -------------------------------------------------------------

  async function executeSingleOpen(ballotId) {
    const ballot = state.ballots.find(b => b.id === ballotId);
    if (!ballot) return;
    try {
      await apiCall(`/api/ballots/${ballotId}/open`, {
        method: "POST",
        body: { revision: ballot.revision },
        actionType: "open_ballot",
        targetLabel: ballot.title,
        viewedRevision: ballot.revision
      });
      showStatus(`Opened "${ballot.title}".`);
      await loadBallotsView();
    } catch (err) {
      showStatus(err.message, "error");
    }
  }

  async function executeCloseBallot(ballotId) {
    const ballot = state.ballots.find(b => b.id === ballotId);
    if (!ballot) return;
    try {
      await apiCall(`/api/ballots/${ballotId}/close`, {
        method: "POST",
        body: { revision: ballot.revision },
        actionType: "close_ballot",
        targetLabel: ballot.title,
        viewedRevision: ballot.revision
      });
      showStatus(`Closed "${ballot.title}".`);
      await loadBallotsView();
    } catch (err) {
      showStatus(err.message, "error");
    }
  }

  async function executePublishBallot(ballotId) {
    const ballot = state.ballots.find(b => b.id === ballotId);
    if (!ballot) return;
    try {
      await apiCall(`/api/ballots/${ballotId}/publish`, {
        method: "POST",
        body: { revision: ballot.revision },
        actionType: "publish_ballot",
        targetLabel: ballot.title,
        viewedRevision: ballot.revision
      });
      showStatus(`Published results for "${ballot.title}".`);
      await loadBallotsView();
    } catch (err) {
      showStatus(err.message, "error");
    }
  }

  // -------------------------------------------------------------
  // ROUND OPEN REVIEW & SUBMISSION
  // -------------------------------------------------------------

  el.btnReviewRound.addEventListener("click", async () => {
    const selectedIds = Array.from(state.selectedRoundDraftIds);
    if (selectedIds.length < 2) return;

    try {
      // Fetch latest ballots and roster
      const [ballotsRes, membersRes] = await Promise.all([
        apiCall("/api/ballots"),
        apiCall("/api/members")
      ]);

      const selectedBallots = ballotsRes.ballots.filter(b => selectedIds.includes(b.id));
      const roster = membersRes.members;

      state.roundReviewData = {
        ballots: selectedBallots,
        roster: roster
      };

      el.roundReviewBallotCount.textContent = selectedBallots.length;
      el.roundReviewRosterCount.textContent = roster.filter(m => m.active).length;

      el.roundReviewBallots.innerHTML = selectedBallots.map(b => `
        <div class="card" style="margin-bottom:0.6rem; padding:0.85rem;">
          <strong>${b.title}</strong> (Rev ${b.revision})
          <div style="font-size:0.85rem; color:var(--text-muted); margin-top:0.25rem;">
            Method: ${b.method === "single" ? "Single Choice" : `Approval (max ${b.max_selections})`} · Choices: ${b.choices.map(c => c.label).join(", ")}
          </div>
        </div>
      `).join("");

      el.roundReviewRoster.innerHTML = `
        <table style="width:100%;">
          <thead>
            <tr><th>Member</th><th>Role</th><th>Eligibility Status</th><th>Revision</th></tr>
          </thead>
          <tbody>
            ${roster.map(m => `
              <tr>
                <td>${m.name}</td>
                <td>${m.role}</td>
                <td><span class="badge badge-${m.active ? "active" : "paused"}">${m.active ? "Eligible (Active)" : "Excluded (Paused)"}</span></td>
                <td>Rev ${m.revision}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;

      el.modalRoundReview.classList.remove("hidden");
    } catch (err) {
      showStatus(err.message, "error");
    }
  });

  function closeRoundModal() {
    el.modalRoundReview.classList.add("hidden");
  }

  el.modalRoundClose.addEventListener("click", closeRoundModal);
  el.btnRoundCancel.addEventListener("click", closeRoundModal);

  el.btnRoundConfirm.addEventListener("click", async () => {
    if (!state.roundReviewData) return;
    const { ballots, roster } = state.roundReviewData;

    const roundPayload = {
      ballots: ballots.map(b => ({ id: b.id, revision: b.revision })),
      roster: roster.map(m => ({ user_id: m.user_id, revision: m.revision }))
    };

    el.btnRoundConfirm.disabled = true;
    try {
      const res = await apiCall("/api/ballots/round-open", {
        method: "POST",
        body: roundPayload,
        actionType: "round_open",
        targetLabel: `${ballots.length} draft ballots`,
        viewedRevision: ballots[0].revision
      });

      closeRoundModal();
      state.selectedRoundDraftIds.clear();
      showStatus(res.message || "Round opened successfully.");
      await loadBallotsView();
    } catch (err) {
      showStatus(err.message, "error");
    } finally {
      el.btnRoundConfirm.disabled = false;
    }
  });

  // -------------------------------------------------------------
  // DRAFT 3-WAY MERGE CONFLICT RESOLUTION
  // -------------------------------------------------------------

  function initiateDraftConflictReview(attemptedPayload, currentBallot) {
    const base = state.draftEditingBase || {
      title: attemptedPayload.title,
      description: attemptedPayload.description,
      method: attemptedPayload.method,
      max_selections: attemptedPayload.max_selections,
      choices: attemptedPayload.choices
    };

    const currentChoicesLabels = currentBallot.choices.map(c => c.label);

    state.conflictState = {
      ballotId: currentBallot.id,
      base,
      attempted: {
        title: attemptedPayload.title,
        description: attemptedPayload.description || "",
        method: attemptedPayload.method,
        max_selections: attemptedPayload.max_selections,
        choices: attemptedPayload.choices
      },
      current: {
        status: currentBallot.status,
        revision: currentBallot.revision,
        title: currentBallot.title,
        description: currentBallot.description || "",
        method: currentBallot.method,
        max_selections: currentBallot.max_selections,
        choices: currentChoicesLabels
      },
      resolved: {
        title: "",
        description: "",
        method: "",
        max_selections: 1,
        choices: []
      }
    };

    closeDraftModal();
    renderConflictModal();
    el.modalDraftConflict.classList.remove("hidden");
  }

  function renderConflictModal() {
    const { attempted, current, base } = state.conflictState;

    if (current.status !== "draft") {
      el.conflictLockedWarning.classList.remove("hidden");
      el.conflictSectionsContainer.classList.add("hidden");
      el.btnConflictSave.classList.add("hidden");
      return;
    }

    el.conflictLockedWarning.classList.add("hidden");
    el.conflictSectionsContainer.classList.remove("hidden");
    el.btnConflictSave.classList.remove("hidden");

    // 1. Title Resolution
    const titleConflict = (attempted.title !== base.title) && (current.title !== base.title) && (attempted.title !== current.title);
    if (!titleConflict) {
      // Auto resolve
      state.conflictState.resolved.title = attempted.title !== base.title ? attempted.title : current.title;
      el.conflictTitleChoices.innerHTML = `<p style="color:var(--primary); font-weight:600;">Automatically combined: "${state.conflictState.resolved.title}"</p>`;
    } else {
      state.conflictState.resolved.title = attempted.title; // default
      el.conflictTitleChoices.innerHTML = `
        <label class="conflict-option-label">
          <input type="radio" name="conflict-title" value="attempted" checked />
          <div><strong>Your change:</strong> "${attempted.title}"</div>
        </label>
        <label class="conflict-option-label">
          <input type="radio" name="conflict-title" value="current" />
          <div><strong>Saved version:</strong> "${current.title}"</div>
        </label>
      `;
      el.conflictTitleChoices.querySelectorAll("input").forEach(radio => {
        radio.addEventListener("change", () => {
          state.conflictState.resolved.title = radio.value === "attempted" ? attempted.title : current.title;
          updateConflictPreview();
        });
      });
    }

    // 2. Description (Context) Resolution
    const descConflict = (attempted.description !== base.description) && (current.description !== base.description) && (attempted.description !== current.description);
    if (!descConflict) {
      state.conflictState.resolved.description = attempted.description !== base.description ? attempted.description : current.description;
      el.conflictDescChoices.innerHTML = `<p style="color:var(--primary); font-weight:600;">Automatically combined: "${state.conflictState.resolved.description || "(No description)"}"</p>`;
    } else {
      state.conflictState.resolved.description = attempted.description;
      el.conflictDescChoices.innerHTML = `
        <label class="conflict-option-label">
          <input type="radio" name="conflict-desc" value="attempted" checked />
          <div><strong>Your change:</strong> "${attempted.description || "(Empty)"}"</div>
        </label>
        <label class="conflict-option-label">
          <input type="radio" name="conflict-desc" value="current" />
          <div><strong>Saved version:</strong> "${current.description || "(Empty)"}"</div>
        </label>
      `;
      el.conflictDescChoices.querySelectorAll("input").forEach(radio => {
        radio.addEventListener("change", () => {
          state.conflictState.resolved.description = radio.value === "attempted" ? attempted.description : current.description;
          updateConflictPreview();
        });
      });
    }

    // 3. Voting Definition Resolution (Method, Limit & Choices together)
    const baseDefStr = JSON.stringify({ m: base.method, max: base.max_selections, c: base.choices });
    const attDefStr = JSON.stringify({ m: attempted.method, max: attempted.max_selections, c: attempted.choices });
    const curDefStr = JSON.stringify({ m: current.method, max: current.max_selections, c: current.choices });

    const defConflict = (attDefStr !== baseDefStr) && (curDefStr !== baseDefStr) && (attDefStr !== curDefStr);
    if (!defConflict) {
      const chosenDef = attDefStr !== baseDefStr ? attempted : current;
      state.conflictState.resolved.method = chosenDef.method;
      state.conflictState.resolved.max_selections = chosenDef.max_selections;
      state.conflictState.resolved.choices = [...chosenDef.choices];
      el.conflictVotingChoices.innerHTML = `<p style="color:var(--primary); font-weight:600;">Automatically combined: ${chosenDef.method} (${chosenDef.choices.join(", ")})</p>`;
    } else {
      state.conflictState.resolved.method = attempted.method;
      state.conflictState.resolved.max_selections = attempted.max_selections;
      state.conflictState.resolved.choices = [...attempted.choices];

      el.conflictVotingChoices.innerHTML = `
        <label class="conflict-option-label">
          <input type="radio" name="conflict-voting" value="attempted" checked />
          <div>
            <strong>Your voting definition:</strong>
            <div>Method: ${attempted.method === "single" ? "Single Choice" : `Approval (max ${attempted.max_selections})`}</div>
            <div>Choices: ${attempted.choices.join(", ")}</div>
          </div>
        </label>
        <label class="conflict-option-label">
          <input type="radio" name="conflict-voting" value="current" />
          <div>
            <strong>Saved voting definition:</strong>
            <div>Method: ${current.method === "single" ? "Single Choice" : `Approval (max ${current.max_selections})`}</div>
            <div>Choices: ${current.choices.join(", ")}</div>
          </div>
        </label>
      `;

      el.conflictVotingChoices.querySelectorAll("input").forEach(radio => {
        radio.addEventListener("change", () => {
          const chosen = radio.value === "attempted" ? attempted : current;
          state.conflictState.resolved.method = chosen.method;
          state.conflictState.resolved.max_selections = chosen.max_selections;
          state.conflictState.resolved.choices = [...chosen.choices];
          updateConflictPreview();
        });
      });
    }

    updateConflictPreview();
  }

  function updateConflictPreview() {
    const { resolved } = state.conflictState;
    el.conflictMergedPreview.innerHTML = `
      <h3>${resolved.title || "(Untitled)"}</h3>
      <p style="color:var(--text-muted); font-size:0.9rem; margin:0.35rem 0;">${resolved.description || "(No description)"}</p>
      <div style="font-size:0.85rem; font-weight:600;">
        Method: ${resolved.method === "single" ? "Single Choice" : `Approval (max ${resolved.max_selections})`}
      </div>
      <div class="choices-preview-list" style="margin-top:0.5rem;">
        ${resolved.choices.map(c => `<div class="choice-preview-item"><span class="choice-bullet">•</span> ${c}</div>`).join("")}
      </div>
    `;
  }

  function closeConflictModal() {
    el.modalDraftConflict.classList.add("hidden");
    state.conflictState = null;
  }

  el.modalConflictClose.addEventListener("click", closeConflictModal);
  el.btnConflictDiscard.addEventListener("click", () => {
    closeConflictModal();
    showStatus("Unsaved changes discarded.");
    loadBallotsView();
  });

  el.btnConflictSave.addEventListener("click", async () => {
    if (!state.conflictState) return;
    const { ballotId, current, resolved } = state.conflictState;

    el.btnConflictSave.disabled = true;
    try {
      await apiCall(`/api/ballots/${ballotId}`, {
        method: "PUT",
        body: {
          title: resolved.title,
          description: resolved.description,
          method: resolved.method,
          max_selections: resolved.max_selections,
          choices: resolved.choices,
          revision: current.revision
        },
        actionType: "edit_ballot",
        targetLabel: resolved.title,
        viewedRevision: current.revision
      });

      closeConflictModal();
      showStatus(`Saved reviewed draft "${resolved.title}".`);
      await loadBallotsView();
    } catch (err) {
      if (err.status !== 409) {
        showStatus(err.message, "error");
      }
    } finally {
      el.btnConflictSave.disabled = false;
    }
  });

  // -------------------------------------------------------------
  // 2. VOTE WORKSPACE (Member Privacy & Voting)
  // -------------------------------------------------------------

  async function loadVoteView() {
    if (state.user.role !== "member") {
      el.votingContainer.innerHTML = `
        <div class="card" style="grid-column: 1 / -1;">
          <h3>Staff Notice</h3>
          <p>The Vote workspace is reserved for eligible members to cast their ballots. Coordinators and observers can manage and review ballots in the Ballots, Turnout and Results workspaces.</p>
        </div>
      `;
      return;
    }

    el.votingContainer.innerHTML = `<div class="loading-state">Loading eligible ballots...</div>`;
    const res = await apiCall("/api/ballots");
    const openBallots = res.ballots.filter(b => b.status === "open");

    if (!openBallots.length) {
      el.votingContainer.innerHTML = `<div class="empty-state">There are no open ballots awaiting your vote at this time.</div>`;
      return;
    }

    el.votingContainer.innerHTML = openBallots.map(ballot => {
      const isSingle = ballot.method === "single";
      const hasVoted = ballot.user_participated;

      if (hasVoted) {
        return `
          <article class="card ballot-card">
            <div>
              <div class="ballot-card-header">
                <span class="badge badge-open">OPEN</span>
                <span class="badge badge-active">Voted</span>
              </div>
              <h2 style="margin-top:0.5rem;">${ballot.title}</h2>
              ${ballot.description ? `<p class="ballot-desc" style="margin-top:0.4rem;">${ballot.description}</p>` : ""}
              
              <div class="vote-receipt-banner" style="margin-top:1rem;">
                <strong>✓ Participation Recorded</strong>
                <span>Submitted: ${formatDate(ballot.user_submitted_at)}</span>
                <span>Receipt: <code>${ballot.user_receipt_id}</code></span>
                <span style="font-size:0.8rem; color:var(--text-muted); margin-top:0.25rem;">(In accordance with ballot privacy, your specific selections are stored separately and anonymously.)</span>
              </div>
            </div>
          </article>
        `;
      }

      const inputType = isSingle ? "radio" : "checkbox";
      const methodHelp = isSingle
        ? "Select exactly 1 choice:"
        : `Select up to ${ballot.max_selections} choices (at least 1 required):`;

      return `
        <article class="card ballot-card" data-id="${ballot.id}">
          <form class="vote-form" data-id="${ballot.id}" data-method="${ballot.method}" data-max="${ballot.max_selections}">
            <div>
              <div class="ballot-card-header">
                <span class="badge badge-open">OPEN</span>
                <span style="font-size:0.85rem; color:var(--text-muted);">${ballot.method === "single" ? "Single Choice" : `Approval (max ${ballot.max_selections})`}</span>
              </div>
              <h2 style="margin-top:0.5rem;">${ballot.title}</h2>
              ${ballot.description ? `<p class="ballot-desc" style="margin-top:0.4rem;">${ballot.description}</p>` : ""}
              
              <fieldset style="border:none; margin-top:1rem;">
                <legend style="font-weight:650; margin-bottom:0.6rem; font-size:0.95rem;">${methodHelp}</legend>
                <div style="display:flex; flex-direction:column; gap:0.5rem;">
                  ${ballot.choices.map(c => `
                    <label class="choice-vote-option">
                      <input type="${inputType}" name="vote_choice_${ballot.id}" value="${c.id}" />
                      <span>${c.label}</span>
                    </label>
                  `).join("")}
                </div>
              </fieldset>
            </div>

            <div style="padding-top:1rem; border-top:1px solid var(--border);">
              <button type="submit" class="btn-primary" style="width:100%;">Submit Anonymous Vote</button>
            </div>
          </form>
        </article>
      `;
    }).join("");

    el.votingContainer.querySelectorAll(".vote-form").forEach(form => {
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const ballotId = form.dataset.id;
        const method = form.dataset.method;
        const maxSelections = parseInt(form.dataset.max, 10);
        const checkedInputs = form.querySelectorAll(`input[name="vote_choice_${ballotId}"]:checked`);
        const selectedChoiceIds = Array.from(checkedInputs).map(i => i.value);

        if (!selectedChoiceIds.length) {
          showStatus("Please select at least one choice to cast your vote.", "warning");
          return;
        }

        if (method === "approval" && selectedChoiceIds.length > maxSelections) {
          showStatus(`You may select at most ${maxSelections} choices.`, "warning");
          return;
        }

        const submitBtn = form.querySelector("button[type='submit']");
        submitBtn.disabled = true;

        try {
          const res = await apiCall(`/api/ballots/${ballotId}/vote`, {
            method: "POST",
            body: { choice_ids: selectedChoiceIds }
          });

          showStatus(`Vote recorded. Participation receipt: ${res.receipt_id}`);
          await loadVoteView();
        } catch (err) {
          showStatus(err.message, "error");
          submitBtn.disabled = false;
        }
      });
    });
  }

  // -------------------------------------------------------------
  // 3. TURNOUT WORKSPACE
  // -------------------------------------------------------------

  async function loadTurnoutView() {
    el.turnoutContainer.innerHTML = `<div class="loading-state">Loading turnout records...</div>`;
    const res = await apiCall("/api/turnout");
    const turnoutList = res.turnout;

    if (!turnoutList.length) {
      el.turnoutContainer.innerHTML = `<div class="empty-state">No turnout records available.</div>`;
      return;
    }

    const isStaff = state.user && (state.user.role === "coordinator" || state.user.role === "observer");

    el.turnoutContainer.innerHTML = turnoutList.map(item => {
      const rosterHtml = isStaff && item.roster ? `
        <div style="margin-top:1rem; border-top:1px solid var(--border); padding-top:0.75rem;">
          <h4 style="margin-bottom:0.5rem;">Eligible Member Participation</h4>
          <table style="width:100%;">
            <thead>
              <tr><th>Member</th><th>Status</th><th>Submitted</th></tr>
            </thead>
            <tbody>
              ${item.roster.map(m => `
                <tr>
                  <td><strong>${m.name}</strong><br /><span style="font-size:0.8rem; color:var(--text-muted);">${m.email}</span></td>
                  <td><span class="badge badge-${m.participated ? "active" : "paused"}">${m.participated ? "Participated" : "Not yet voted"}</span></td>
                  <td style="font-size:0.85rem;">${formatDate(m.submitted_at)}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : "";

      const memberParticipationHtml = !isStaff && item.user_participation ? `
        <div style="margin-top:1rem; border-top:1px solid var(--border); padding-top:0.75rem;">
          <span class="badge badge-${item.user_participation.participated ? "active" : "paused"}">
            ${item.user_participation.participated ? "You have voted" : "You have not voted"}
          </span>
          ${item.user_participation.submitted_at ? `<div style="font-size:0.85rem; color:var(--text-muted); margin-top:0.25rem;">Submitted on ${formatDate(item.user_participation.submitted_at)} (Receipt: ${item.user_participation.receipt_id})</div>` : ""}
        </div>
      ` : "";

      return `
        <article class="card ballot-card" style="grid-column: 1 / -1;">
          <div>
            <div class="ballot-card-header">
              <span class="badge badge-${item.status}">${item.status.toUpperCase()}</span>
              <span style="font-weight:700; color:var(--primary); font-size:1.1rem;">${item.turnout_percentage}% Turnout</span>
            </div>
            <h2 style="margin-top:0.4rem;">${item.title}</h2>
            <div class="ballot-meta">
              <span>${item.participant_count} participating out of ${item.eligible_count} eligible members</span>
            </div>

            ${memberParticipationHtml}
            ${rosterHtml}
          </div>
        </article>
      `;
    }).join("");
  }

  // -------------------------------------------------------------
  // 4. RESULTS WORKSPACE
  // -------------------------------------------------------------

  async function loadResultsView() {
    el.resultsContainer.innerHTML = `<div class="loading-state">Loading published results...</div>`;
    const res = await apiCall("/api/results");
    const results = res.results;

    if (!results.length) {
      el.resultsContainer.innerHTML = `<div class="empty-state">No results available.</div>`;
      return;
    }

    el.resultsContainer.innerHTML = results.map(result => {
      if (!result.published) {
        return `
          <article class="card ballot-card">
            <div>
              <div class="ballot-card-header">
                <span class="badge badge-${result.status}">${result.status.toUpperCase()}</span>
              </div>
              <h2 style="margin-top:0.4rem;">${result.title}</h2>
              <div class="alert-banner alert-warning" style="margin-top:1rem;">
                ℹ️ ${result.message}
              </div>
            </div>
          </article>
        `;
      }

      const outcome = result.outcome;
      let outcomeBanner = "";
      if (outcome) {
        if (outcome.status === "winner") {
          outcomeBanner = `<div class="result-outcome-banner result-outcome-winner">🏆 Outcome: ${outcome.message}</div>`;
        } else if (outcome.status === "tie") {
          outcomeBanner = `<div class="result-outcome-banner result-outcome-tie">🤝 Tied Outcome: ${outcome.message}</div>`;
        } else {
          outcomeBanner = `<div class="result-outcome-banner" style="background:var(--bg-card-alt);">${outcome.message}</div>`;
        }
      }

      return `
        <article class="card ballot-card" style="grid-column: 1 / -1;">
          <div>
            <div class="ballot-card-header">
              <span class="badge badge-published">PUBLISHED</span>
              <span style="font-size:0.85rem; color:var(--text-muted);">Published: ${formatDate(result.published_at)}</span>
            </div>
            <h2 style="margin-top:0.4rem;">${result.title}</h2>
            ${result.description ? `<p class="ballot-desc" style="margin-top:0.35rem;">${result.description}</p>` : ""}
            
            <div class="ballot-meta" style="margin:0.75rem 0 1.25rem;">
              <span>Method: ${result.method === "single" ? "Single Choice" : `Approval (max ${result.max_selections})`}</span>
              <span>·</span>
              <span>Total ballots: ${result.total_ballots}</span>
              <span>·</span>
              <span>Turnout: ${result.turnout_percentage}% (${result.participant_count} / ${result.eligible_count} eligible)</span>
            </div>

            ${outcomeBanner}

            <div style="display:flex; flex-direction:column; gap:0.85rem;">
              ${result.choices.map(c => `
                <div class="result-choice-row">
                  <div class="result-choice-header">
                    <span>${c.label}</span>
                    <span>${c.count} ${result.method === "single" ? (c.count === 1 ? "vote" : "votes") : (c.count === 1 ? "approval" : "approvals")} (${c.percentage}%)</span>
                  </div>
                  <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: ${Math.min(c.percentage, 100)}%;"></div>
                  </div>
                </div>
              `).join("")}
            </div>

            ${result.method === "approval" ? `<p class="approval-note">* Percentages for approval voting represent the share of participating members who approved each choice, and may total over 100%.</p>` : ""}
          </div>
        </article>
      `;
    }).join("");
  }

  // -------------------------------------------------------------
  // 5. MEMBERS WORKSPACE
  // -------------------------------------------------------------

  async function loadMembersView() {
    el.membersContainer.innerHTML = `<div class="loading-state">Loading member directory...</div>`;
    const res = await apiCall("/api/members");
    state.members = res.members;

    const isCoordinator = state.user && state.user.role === "coordinator";

    el.membersContainer.innerHTML = `
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Membership Status</th>
            <th>Revision</th>
            ${isCoordinator ? "<th>Actions</th>" : ""}
          </tr>
        </thead>
        <tbody>
          ${state.members.map(m => `
            <tr>
              <td><strong>${m.name}</strong></td>
              <td>${m.email}</td>
              <td style="text-transform:capitalize;">${m.role}</td>
              <td><span class="badge badge-${m.active ? "active" : "paused"}">${m.active ? "Active" : "Paused"}</span></td>
              <td>Rev ${m.revision}</td>
              ${isCoordinator ? `
                <td>
                  <button type="button" class="btn-secondary btn-sm btn-toggle-membership" data-id="${m.user_id}" data-active="${m.active}" data-rev="${m.revision}" data-name="${m.name}">
                    ${m.active ? "Pause membership" : "Activate membership"}
                  </button>
                </td>
              ` : ""}
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;

    if (isCoordinator) {
      el.membersContainer.querySelectorAll(".btn-toggle-membership").forEach(btn => {
        btn.addEventListener("click", async () => {
          const userId = btn.dataset.id;
          const currentActive = btn.dataset.active === "true";
          const newActive = !currentActive;
          const revision = parseInt(btn.dataset.rev, 10);
          const memberName = btn.dataset.name;

          btn.disabled = true;
          try {
            await apiCall(`/api/members/${userId}`, {
              method: "PUT",
              body: { active: newActive, revision },
              actionType: "update_membership",
              targetLabel: `${memberName} (${newActive ? "Activate" : "Pause"})`,
              viewedRevision: revision
            });

            showStatus(`${newActive ? "Activated" : "Paused"} ${memberName}.`);
            await loadMembersView();
          } catch (err) {
            showStatus(err.message, "error");
            btn.disabled = false;
          }
        });
      });
    }
  }

  // -------------------------------------------------------------
  // 6. AUDIT WORKSPACE
  // -------------------------------------------------------------

  async function loadAuditView() {
    el.auditContainer.innerHTML = `<div class="loading-state">Loading audit history...</div>`;
    const res = await apiCall("/api/audit");
    const auditLogs = res.audit;

    if (!auditLogs.length) {
      el.auditContainer.innerHTML = `<div class="empty-state">No audit activity recorded.</div>`;
      return;
    }

    el.auditContainer.innerHTML = `
      <table>
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Action</th>
            <th>Entity</th>
            <th>Actor</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          ${auditLogs.map(log => `
            <tr>
              <td style="font-size:0.85rem; white-space:nowrap;">${formatDate(log.created_at)}</td>
              <td><span class="badge badge-${log.action.includes("open") ? "open" : log.action.includes("close") ? "closed" : log.action.includes("publish") ? "published" : "draft"}">${log.action}</span></td>
              <td style="font-size:0.85rem;"><code>${log.entity_id}</code></td>
              <td><strong>${log.actor_label}</strong></td>
              <td style="font-size:0.95rem;">${log.details}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  // -------------------------------------------------------------
  // INITIALIZATION
  // -------------------------------------------------------------
  initTheme();
  checkInitialSession();
})();
