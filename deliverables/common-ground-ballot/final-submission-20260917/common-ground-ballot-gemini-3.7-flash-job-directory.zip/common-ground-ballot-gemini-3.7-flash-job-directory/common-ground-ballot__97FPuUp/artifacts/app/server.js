// Common Ground Ballot - Backend Server
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const express = require("express");
const Database = require("better-sqlite3");

const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DB_PATH || "/app/commonground.db";
const SEED_PATH = process.env.SEED_PATH || "/app/common_ground_seed.json";
const PASSWORD = "CommonGround!2026";
const SESSION_SECONDS = 8 * 60 * 60;

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "256kb", strict: true }));
app.use((request, response, next) => {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("Referrer-Policy", "same-origin");
  if (request.path.startsWith("/api/")) response.setHeader("Cache-Control", "no-store");
  next();
});

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS seed_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK (role IN ('coordinator', 'observer', 'member')),
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS groups (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS memberships (
    group_id TEXT NOT NULL REFERENCES groups(id),
    user_id TEXT NOT NULL REFERENCES users(id),
    active INTEGER NOT NULL CHECK (active IN (0, 1)),
    revision INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (group_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS ballots (
    id TEXT PRIMARY KEY,
    group_id TEXT NOT NULL REFERENCES groups(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    method TEXT NOT NULL CHECK (method IN ('single', 'approval')),
    max_selections INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft', 'open', 'closed', 'published')),
    revision INTEGER NOT NULL,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    opened_at TEXT,
    closed_at TEXT,
    published_at TEXT
  );
  CREATE TABLE IF NOT EXISTS choices (
    id TEXT PRIMARY KEY,
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    position INTEGER NOT NULL,
    UNIQUE (ballot_id, position)
  );
  CREATE TABLE IF NOT EXISTS eligibility (
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id),
    PRIMARY KEY (ballot_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS participation (
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id),
    submitted_at TEXT NOT NULL,
    receipt_id TEXT NOT NULL UNIQUE,
    PRIMARY KEY (ballot_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS anonymous_votes (
    id TEXT PRIMARY KEY,
    ballot_id TEXT NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    choice_id TEXT NOT NULL REFERENCES choices(id) ON DELETE CASCADE,
    cast_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS operation_receipts (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    operation_id TEXT NOT NULL,
    action TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    status_code INTEGER NOT NULL,
    response_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, operation_id)
  );
  CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    actor_id TEXT REFERENCES users(id),
    actor_label TEXT NOT NULL,
    details TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ballots_status ON ballots(status);
  CREATE INDEX IF NOT EXISTS idx_choices_ballot ON choices(ballot_id, position);
  CREATE INDEX IF NOT EXISTS idx_votes_ballot ON anonymous_votes(ballot_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
  CREATE INDEX IF NOT EXISTS idx_audit_created ON audit(id DESC);
`);

class ApiError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.body = { error: message, ...extra };
  }
}

const now = () => new Date().toISOString();
const makeId = (prefix) => `${prefix}-${crypto.randomUUID()}`;
const tokenHash = (token) => crypto.createHash("sha256").update(token).digest("hex");
const fingerprint = (value) =>
  crypto.createHash("sha256").update(JSON.stringify(value)).digest("hex");

function passwordRecord(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  return { salt, hash: crypto.scryptSync(password, salt, 64).toString("hex") };
}

function passwordMatches(password, salt, expected) {
  const actual = crypto.scryptSync(password, salt, 64);
  const stored = Buffer.from(expected, "hex");
  return stored.length === actual.length && crypto.timingSafeEqual(actual, stored);
}

function seedApplication() {
  if (db.prepare("SELECT 1 FROM seed_state WHERE key = 'bootstrap-v1'").get()) return;
  const seed = JSON.parse(fs.readFileSync(SEED_PATH, "utf8"));
  const fixed = {
    draft: "2026-08-04T09:00:00.000Z",
    open: "2026-08-05T10:00:00.000Z",
    closed: "2026-08-06T11:00:00.000Z",
    published: "2026-08-07T12:00:00.000Z",
    member: "2026-08-08T13:00:00.000Z",
  };
  db.transaction(() => {
    db.prepare("INSERT INTO groups (id, name) VALUES (?, ?)").run(seed.group.id, seed.group.name);
    const insertUser = db.prepare(
      "INSERT INTO users (id, name, email, role, password_hash, password_salt) VALUES (?, ?, ?, ?, ?, ?)"
    );
    for (const user of seed.users) {
      const password = passwordRecord(PASSWORD);
      insertUser.run(user.id, user.name, user.email, user.role, password.hash, password.salt);
    }
    const insertMembership = db.prepare(
      "INSERT INTO memberships (group_id, user_id, active, revision, updated_at) VALUES (?, ?, ?, 1, ?)"
    );
    for (const member of seed.memberships) {
      insertMembership.run(seed.group.id, member.user_id, member.active ? 1 : 0, fixed.member);
    }
    const insertBallot = db.prepare(`
      INSERT INTO ballots
        (id, group_id, title, description, method, max_selections, status, revision,
         created_by, created_at, opened_at, closed_at, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'user-ruth', ?, ?, ?, ?)
    `);
    const insertChoice = db.prepare(
      "INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)"
    );
    const insertEligible = db.prepare(
      "INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)"
    );
    const insertParticipant = db.prepare(
      "INSERT INTO participation (ballot_id, user_id, submitted_at, receipt_id) VALUES (?, ?, ?, ?)"
    );
    const insertVote = db.prepare(
      "INSERT INTO anonymous_votes (id, ballot_id, choice_id, cast_at) VALUES (?, ?, ?, ?)"
    );
    for (const ballot of seed.ballots) {
      const opened = ballot.status === "draft" ? null : fixed.open;
      const closed = ["closed", "published"].includes(ballot.status) ? fixed.closed : null;
      const published = ballot.status === "published" ? fixed.published : null;
      insertBallot.run(
        ballot.id,
        seed.group.id,
        ballot.title,
        ballot.description,
        ballot.method,
        ballot.max_selections,
        ballot.status,
        ballot.revision,
        fixed.draft,
        opened,
        closed,
        published
      );
      ballot.choices.forEach((choice, index) =>
        insertChoice.run(choice.id, ballot.id, choice.label, index)
      );
      for (const userId of ballot.eligible_user_ids || []) {
        insertEligible.run(ballot.id, userId);
      }
      (ballot.participant_user_ids || []).forEach((userId, index) => {
        insertParticipant.run(
          ballot.id,
          userId,
          fixed.closed,
          `seed-receipt-${ballot.id}-${index + 1}`
        );
      });
      (ballot.anonymous_choice_ids || []).forEach((choiceId, index) => {
        insertVote.run(`seed-vote-${ballot.id}-${index + 1}`, ballot.id, choiceId, fixed.closed);
      });
    }
    const insertAudit = db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES (?, 'ballot', ?, 'user-ruth', 'Ruth Adebayo', ?, ?)
    `);
    insertAudit.run("created", "ballot-draft-picnic", "Created draft Annual picnic date", fixed.draft);
    insertAudit.run("opened", "ballot-open-courtyard", "Opened Courtyard closing time with 2 eligible Members", fixed.open);
    insertAudit.run("closed", "ballot-closed-improvements", "Closed Shared-space improvements", fixed.closed);
    insertAudit.run("published", "ballot-published-garden", "Published anonymous results for Garden location", fixed.published);
    db.prepare(`
      INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
      VALUES ('membership_paused', 'member', 'user-owen', 'user-ruth', 'Ruth Adebayo',
              'Paused Owen Park for future eligibility snapshots', ?)
    `).run(fixed.member);
    db.prepare("INSERT INTO seed_state (key, value) VALUES ('bootstrap-v1', ?)").run(
      String(seed.schema_version)
    );
  })();
}

seedApplication();

function cleanExpiredSessions() {
  db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(now());
}

function parseCookies(request) {
  const values = {};
  for (const part of (request.headers.cookie || "").split(";")) {
    const separator = part.indexOf("=");
    if (separator < 0) continue;
    values[part.slice(0, separator).trim()] = decodeURIComponent(part.slice(separator + 1).trim());
  }
  return values;
}

function currentUser(request) {
  cleanExpiredSessions();
  const token = parseCookies(request).cg_session;
  if (!token) return null;
  return db.prepare(`
    SELECT u.id, u.name, u.email, u.role, s.token_hash
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > ?
  `).get(tokenHash(token), now()) || null;
}

function requireUser(request, _response, next) {
  const user = currentUser(request);
  if (!user) return next(new ApiError(401, "Please sign in to continue."));
  request.user = user;
  next();
}

function requireRole(...roles) {
  return (request, _response, next) => {
    if (!roles.includes(request.user.role)) {
      return next(new ApiError(403, "Your role cannot perform this action."));
    }
    next();
  };
}

function requireObject(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ApiError(400, "A valid request body is required.");
  }
}

function exactKeys(value, allowed) {
  requireObject(value);
  const extras = Object.keys(value).filter((key) => !allowed.includes(key));
  if (extras.length) throw new ApiError(400, `Unexpected field: ${extras[0]}.`);
}

function text(value, label, max, required = true) {
  if (typeof value !== "string") throw new ApiError(400, `${label} must be text.`);
  const cleaned = value.trim();
  if (required && !cleaned) throw new ApiError(400, `${label} is required.`);
  if (cleaned.length > max) throw new ApiError(400, `${label} is too long.`);
  return cleaned;
}

function parsePositiveInteger(value, label) {
  if (typeof value === "number") {
    if (Number.isInteger(value) && value > 0) return value;
    throw new ApiError(400, `${label} must be a positive whole number.`);
  }
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (/^[1-9]\d*$/.test(trimmed)) {
      const num = parseInt(trimmed, 10);
      if (num > 0) return num;
    }
  }
  throw new ApiError(400, `${label} must be a positive whole number.`);
}

function parseActiveStatus(value, label = "Membership status") {
  if (typeof value === "boolean") {
    return value ? 1 : 0;
  }
  if (typeof value === "string") {
    const trimmed = value.trim().toLowerCase();
    if (trimmed === "active" || trimmed === "true") return 1;
    if (trimmed === "paused" || trimmed === "false") return 0;
  }
  throw new ApiError(400, `${label} must be active or paused.`);
}

function parseChoices(choicesInput, method, maxSelections) {
  if (!Array.isArray(choicesInput)) {
    throw new ApiError(400, "Choices must be an array.");
  }
  if (choicesInput.length < 2) {
    throw new ApiError(400, "At least two choices are required.");
  }
  const labels = [];
  for (let i = 0; i < choicesInput.length; i++) {
    const item = choicesInput[i];
    let label = "";
    if (typeof item === "string") {
      label = item.trim();
    } else if (item && typeof item === "object" && typeof item.label === "string") {
      label = item.label.trim();
    } else {
      throw new ApiError(400, `Choice ${i + 1} must be text.`);
    }
    if (!label) {
      throw new ApiError(400, `Choice ${i + 1} cannot be empty.`);
    }
    if (label.length > 200) {
      throw new ApiError(400, `Choice ${i + 1} is too long.`);
    }
    labels.push(label);
  }

  const set = new Set(labels.map((l) => l.toLowerCase()));
  if (set.size !== labels.length) {
    throw new ApiError(400, "Choices must be distinct.");
  }

  if (method === "single") {
    if (maxSelections !== 1) {
      throw new ApiError(400, "Single choice ballots must have maximum selections set to 1.");
    }
  } else if (method === "approval") {
    if (maxSelections < 1 || maxSelections > labels.length) {
      throw new ApiError(400, `Approval maximum selections must be between 1 and ${labels.length}.`);
    }
  } else {
    throw new ApiError(400, "Voting method must be 'single' or 'approval'.");
  }

  return labels;
}

function executeWithReceipt(user, operation_id, action, normalizedInput, workFn) {
  if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
    throw new ApiError(400, "Operation identifier is required.");
  }
  const opId = operation_id.trim();
  const inputFp = fingerprint({ action, ...normalizedInput });

  const existing = db.prepare(
    "SELECT * FROM operation_receipts WHERE user_id = ? AND operation_id = ?"
  ).get(user.id, opId);

  if (existing) {
    if (existing.action !== action) {
      throw new ApiError(409, "Operation identifier has already been used for a different action.");
    }
    if (existing.fingerprint !== inputFp) {
      throw new ApiError(409, "Operation identifier has already been used with different input.");
    }
    return { status: existing.status_code, body: JSON.parse(existing.response_json) };
  }

  try {
    const result = workFn();
    db.prepare(`
      INSERT INTO operation_receipts (user_id, operation_id, action, fingerprint, status_code, response_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(user.id, opId, action, inputFp, result.status, JSON.stringify(result.body), now());
    return result;
  } catch (err) {
    if (err instanceof ApiError && err.status === 409) {
      try {
        db.prepare(`
          INSERT INTO operation_receipts (user_id, operation_id, action, fingerprint, status_code, response_json, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(user.id, opId, action, inputFp, err.status, JSON.stringify(err.body), now());
      } catch (_insertErr) {
        // ignore if race
      }
    }
    throw err;
  }
}

function getBallotRecord(ballotId) {
  const ballot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
  if (!ballot) return null;
  const choices = db.prepare(
    "SELECT id, label, position FROM choices WHERE ballot_id = ? ORDER BY position ASC"
  ).all(ballotId);
  return { ...ballot, choices };
}

function formatBallotForUser(ballot, user) {
  if (!ballot) return null;

  const eligibleCount = db.prepare("SELECT COUNT(*) as c FROM eligibility WHERE ballot_id = ?").get(ballot.id).c;
  const participantCount = db.prepare("SELECT COUNT(*) as c FROM participation WHERE ballot_id = ?").get(ballot.id).c;
  const myEligibility = db.prepare("SELECT 1 FROM eligibility WHERE ballot_id = ? AND user_id = ?").get(ballot.id, user.id);
  const myParticipation = db.prepare("SELECT submitted_at, receipt_id FROM participation WHERE ballot_id = ? AND user_id = ?").get(ballot.id, user.id);

  if (user.role === "coordinator" || user.role === "observer") {
    return {
      id: ballot.id,
      group_id: ballot.group_id,
      title: ballot.title,
      description: ballot.description,
      method: ballot.method,
      max_selections: ballot.max_selections,
      status: ballot.status,
      revision: ballot.revision,
      created_at: ballot.created_at,
      opened_at: ballot.opened_at,
      closed_at: ballot.closed_at,
      published_at: ballot.published_at,
      choices: ballot.choices,
      eligible_count: eligibleCount,
      participant_count: participantCount,
      user_eligible: !!myEligibility,
      user_participated: !!myParticipation,
      user_submitted_at: myParticipation ? myParticipation.submitted_at : null,
      user_receipt_id: myParticipation ? myParticipation.receipt_id : null
    };
  }

  // Member role
  if (!myEligibility) return null;
  return {
    id: ballot.id,
    group_id: ballot.group_id,
    title: ballot.title,
    description: ballot.description,
    method: ballot.method,
    max_selections: ballot.max_selections,
    status: ballot.status,
    revision: ballot.revision,
    created_at: ballot.created_at,
    opened_at: ballot.opened_at,
    closed_at: ballot.closed_at,
    published_at: ballot.published_at,
    choices: ballot.choices.map((c) => ({ id: c.id, label: c.label, position: c.position })),
    eligible_count: eligibleCount,
    participant_count: participantCount,
    user_eligible: true,
    user_participated: !!myParticipation,
    user_submitted_at: myParticipation ? myParticipation.submitted_at : null,
    user_receipt_id: myParticipation ? myParticipation.receipt_id : null
  };
}

function getBallotResults(ballotId) {
  const ballot = getBallotRecord(ballotId);
  if (!ballot) return null;

  if (ballot.status !== "published") {
    return {
      id: ballot.id,
      title: ballot.title,
      description: ballot.description,
      method: ballot.method,
      max_selections: ballot.max_selections,
      status: ballot.status,
      revision: ballot.revision,
      published_at: ballot.published_at,
      published: false,
      message:
        ballot.status === "closed"
          ? "Voting has ended. Results are pending publication by the coordinator."
          : ballot.status === "open"
          ? "Voting is currently underway. Results are private until publication."
          : "Draft decision in preparation."
    };
  }

  const eligibleCount = db.prepare("SELECT COUNT(*) as c FROM eligibility WHERE ballot_id = ?").get(ballotId).c;
  const participantCount = db.prepare("SELECT COUNT(*) as c FROM participation WHERE ballot_id = ?").get(ballotId).c;

  const voteRows = db.prepare(`
    SELECT choice_id, COUNT(*) as vote_count
    FROM anonymous_votes
    WHERE ballot_id = ?
    GROUP BY choice_id
  `).all(ballotId);

  const voteCountMap = new Map();
  for (const row of voteRows) {
    voteCountMap.set(row.choice_id, row.vote_count);
  }

  const choicesWithResults = ballot.choices.map((choice) => {
    const count = voteCountMap.get(choice.id) || 0;
    const percentage =
      participantCount > 0 ? Number(((count / participantCount) * 100).toFixed(1)) : 0;
    return {
      id: choice.id,
      label: choice.label,
      position: choice.position,
      count,
      percentage
    };
  });

  let maxVotes = 0;
  for (const c of choicesWithResults) {
    if (c.count > maxVotes) maxVotes = c.count;
  }

  let outcome = null;
  if (participantCount === 0 || maxVotes === 0) {
    outcome = {
      status: "no_votes",
      is_tie: false,
      message: "No votes cast."
    };
  } else {
    const leaders = choicesWithResults.filter((c) => c.count === maxVotes);
    if (leaders.length === 1) {
      outcome = {
        status: "winner",
        is_tie: false,
        leader: leaders[0].label,
        leader_id: leaders[0].id,
        count: maxVotes,
        message: `${leaders[0].label} received the most votes (${maxVotes}).`
      };
    } else {
      const tiedLabels = leaders.map((l) => l.label);
      outcome = {
        status: "tie",
        is_tie: true,
        tied_choices: tiedLabels,
        count: maxVotes,
        message: `Tie between: ${tiedLabels.join(", ")} with ${maxVotes} votes each.`
      };
    }
  }

  const turnoutPercentage =
    eligibleCount > 0 ? Number(((participantCount / eligibleCount) * 100).toFixed(1)) : 0;

  return {
    id: ballot.id,
    title: ballot.title,
    description: ballot.description,
    method: ballot.method,
    max_selections: ballot.max_selections,
    status: ballot.status,
    revision: ballot.revision,
    published_at: ballot.published_at,
    published: true,
    total_ballots: participantCount,
    participant_count: participantCount,
    eligible_count: eligibleCount,
    turnout_percentage: turnoutPercentage,
    choices: choicesWithResults,
    outcome
  };
}

function getTurnoutData(user) {
  if (user.role === "coordinator" || user.role === "observer") {
    const ballots = db.prepare("SELECT * FROM ballots ORDER BY created_at DESC").all();
    return ballots.map((ballot) => {
      const eligibleUsers = db.prepare(`
        SELECT u.id as user_id, u.name, u.email,
               p.submitted_at,
               CASE WHEN p.user_id IS NOT NULL THEN 1 ELSE 0 END as participated
        FROM eligibility e
        JOIN users u ON u.id = e.user_id
        LEFT JOIN participation p ON p.ballot_id = e.ballot_id AND p.user_id = e.user_id
        WHERE e.ballot_id = ?
        ORDER BY u.name ASC
      `).all(ballot.id);

      const eligibleCount = eligibleUsers.length;
      const participantCount = eligibleUsers.filter((u) => u.participated === 1).length;
      const turnoutPercentage =
        eligibleCount > 0 ? Number(((participantCount / eligibleCount) * 100).toFixed(1)) : 0;

      return {
        id: ballot.id,
        title: ballot.title,
        status: ballot.status,
        method: ballot.method,
        max_selections: ballot.max_selections,
        eligible_count: eligibleCount,
        participant_count: participantCount,
        turnout_percentage: turnoutPercentage,
        roster: eligibleUsers.map((u) => ({
          user_id: u.user_id,
          name: u.name,
          email: u.email,
          participated: Boolean(u.participated),
          submitted_at: u.submitted_at
        }))
      };
    });
  }

  // Member role: ONLY ballots they are eligible for, and ONLY their own participation status
  const eligibleBallots = db.prepare(`
    SELECT b.*
    FROM ballots b
    JOIN eligibility e ON e.ballot_id = b.id
    WHERE e.user_id = ?
    ORDER BY b.created_at DESC
  `).all(user.id);

  return eligibleBallots.map((ballot) => {
    const eligibleCount = db.prepare("SELECT COUNT(*) as c FROM eligibility WHERE ballot_id = ?").get(ballot.id).c;
    const participantCount = db.prepare("SELECT COUNT(*) as c FROM participation WHERE ballot_id = ?").get(ballot.id).c;
    const myParticipation = db.prepare(
      "SELECT submitted_at, receipt_id FROM participation WHERE ballot_id = ? AND user_id = ?"
    ).get(ballot.id, user.id);
    const turnoutPercentage =
      eligibleCount > 0 ? Number(((participantCount / eligibleCount) * 100).toFixed(1)) : 0;

    return {
      id: ballot.id,
      title: ballot.title,
      status: ballot.status,
      method: ballot.method,
      max_selections: ballot.max_selections,
      eligible_count: eligibleCount,
      participant_count: participantCount,
      turnout_percentage: turnoutPercentage,
      user_participation: {
        participated: !!myParticipation,
        submitted_at: myParticipation ? myParticipation.submitted_at : null,
        receipt_id: myParticipation ? myParticipation.receipt_id : null
      }
    };
  });
}

function getMembersList() {
  return db.prepare(`
    SELECT u.id as user_id, u.name, u.email, u.role, m.active, m.revision, m.updated_at
    FROM memberships m
    JOIN users u ON u.id = m.user_id
    ORDER BY u.name ASC
  `).all().map((m) => ({
    user_id: m.user_id,
    name: m.name,
    email: m.email,
    role: m.role,
    active: Boolean(m.active),
    revision: m.revision,
    updated_at: m.updated_at
  }));
}

function getAuditLog() {
  return db.prepare(`
    SELECT id, action, entity_type, entity_id, actor_label, details, created_at
    FROM audit
    ORDER BY id DESC
    LIMIT 300
  `).all();
}

// ---------------- API ROUTES ----------------

app.get("/api/health", (_request, response) => {
  response.json({ ok: true, service: "common-ground-ballot" });
});

app.post("/api/auth/login", (request, response, next) => {
  try {
    exactKeys(request.body, ["email", "password"]);
    const email = text(request.body.email, "Email", 240).toLowerCase();
    const password = typeof request.body.password === "string" ? request.body.password : "";
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user || !passwordMatches(password, user.password_salt, user.password_hash)) {
      throw new ApiError(401, "Email or password is incorrect.");
    }
    const token = crypto.randomBytes(32).toString("base64url");
    const createdAt = now();
    const expiresAt = new Date(Date.now() + SESSION_SECONDS * 1000).toISOString();
    db.prepare(
      "INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)"
    ).run(tokenHash(token), user.id, createdAt, expiresAt);
    response.setHeader(
      "Set-Cookie",
      `cg_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_SECONDS}`
    );
    response.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/logout", requireUser, (request, response) => {
  db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(request.user.token_hash);
  response.setHeader("Set-Cookie", "cg_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0");
  response.json({ ok: true });
});

app.post("/api/auth/logout-all", requireUser, (request, response) => {
  db.prepare("DELETE FROM sessions WHERE user_id = ?").run(request.user.id);
  response.setHeader("Set-Cookie", "cg_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0");
  response.json({ ok: true, message: "All Common Ground sessions were ended." });
});

app.get("/api/me", (request, response) => {
  const user = currentUser(request);
  response.json({
    user: user ? { id: user.id, name: user.name, email: user.email, role: user.role } : null,
  });
});

// GET /api/ballots
app.get("/api/ballots", requireUser, (request, response, next) => {
  try {
    const user = request.user;
    let ballots;
    if (user.role === "coordinator" || user.role === "observer") {
      ballots = db.prepare("SELECT * FROM ballots ORDER BY created_at DESC").all();
    } else {
      ballots = db.prepare(`
        SELECT b.*
        FROM ballots b
        JOIN eligibility e ON e.ballot_id = b.id
        WHERE e.user_id = ?
        ORDER BY b.created_at DESC
      `).all(user.id);
    }

    const formatted = ballots
      .map((b) => formatBallotForUser(getBallotRecord(b.id), user))
      .filter(Boolean);

    response.json({ ballots: formatted });
  } catch (error) {
    next(error);
  }
});

// GET /api/ballots/:id
app.get("/api/ballots/:id", requireUser, (request, response, next) => {
  try {
    const ballot = getBallotRecord(request.params.id);
    if (!ballot) throw new ApiError(404, "Ballot not found.");
    const formatted = formatBallotForUser(ballot, request.user);
    if (!formatted) {
      throw new ApiError(403, "You do not have permission to view this ballot.");
    }
    response.json({ ballot: formatted });
  } catch (error) {
    next(error);
  }
});

// POST /api/ballots (Create draft)
app.post("/api/ballots", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const { title, description = "", method, max_selections, choices, operation_id } = request.body || {};

    const cleanTitle = text(title, "Title", 200, true);
    const cleanDesc = typeof description === "string" ? description.trim() : "";
    if (cleanDesc.length > 2000) throw new ApiError(400, "Context description is too long.");
    const cleanMethod = text(method, "Voting method", 50, true).toLowerCase();
    const cleanMax = parsePositiveInteger(max_selections, "Maximum selections");
    const cleanChoices = parseChoices(choices, cleanMethod, cleanMax);
    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    const normalizedInput = {
      title: cleanTitle,
      description: cleanDesc,
      method: cleanMethod,
      max_selections: cleanMax,
      choices: cleanChoices
    };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "create_ballot",
      normalizedInput,
      () => {
        const ballotId = makeId("ballot");
        const createdAt = now();

        db.transaction(() => {
          db.prepare(`
            INSERT INTO ballots
              (id, group_id, title, description, method, max_selections, status, revision,
               created_by, created_at, opened_at, closed_at, published_at)
            VALUES (?, 'group-riverside', ?, ?, ?, ?, 'draft', 1, ?, ?, NULL, NULL, NULL)
          `).run(ballotId, cleanTitle, cleanDesc, cleanMethod, cleanMax, request.user.id, createdAt);

          const insertChoice = db.prepare(
            "INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)"
          );
          cleanChoices.forEach((label, idx) => {
            insertChoice.run(makeId("choice"), ballotId, label, idx);
          });

          db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES ('created', 'ballot', ?, ?, ?, ?, ?)
          `).run(ballotId, request.user.id, request.user.name, `Created draft ${cleanTitle}`, createdAt);
        })();

        const created = getBallotRecord(ballotId);
        return {
          status: 201,
          body: {
            ok: true,
            message: `Created draft "${cleanTitle}".`,
            ballot: formatBallotForUser(created, request.user)
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// PUT /api/ballots/:id (Edit draft)
app.put("/api/ballots/:id", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const { title, description = "", method, max_selections, choices, revision, operation_id } =
      request.body || {};

    const cleanTitle = text(title, "Title", 200, true);
    const cleanDesc = typeof description === "string" ? description.trim() : "";
    if (cleanDesc.length > 2000) throw new ApiError(400, "Context description is too long.");
    const cleanMethod = text(method, "Voting method", 50, true).toLowerCase();
    const cleanMax = parsePositiveInteger(max_selections, "Maximum selections");
    const cleanChoices = parseChoices(choices, cleanMethod, cleanMax);
    const rev = parsePositiveInteger(revision, "Draft revision");
    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    const ballot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");

    const normalizedInput = {
      ballot_id: ballotId,
      revision: rev,
      title: cleanTitle,
      description: cleanDesc,
      method: cleanMethod,
      max_selections: cleanMax,
      choices: cleanChoices
    };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "edit_ballot",
      normalizedInput,
      () => {
        const current = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
        if (current.status !== "draft") {
          throw new ApiError(
            409,
            `Ballot "${current.title}" is no longer in draft stage and its definition is locked.`
          );
        }
        if (current.revision !== rev) {
          const latestBallot = getBallotRecord(ballotId);
          throw new ApiError(
            409,
            `Draft revision is outdated. The ballot has been modified by another action.`,
            { current_ballot: formatBallotForUser(latestBallot, request.user) }
          );
        }

        db.transaction(() => {
          db.prepare(`
            UPDATE ballots
            SET title = ?, description = ?, method = ?, max_selections = ?, revision = revision + 1
            WHERE id = ?
          `).run(cleanTitle, cleanDesc, cleanMethod, cleanMax, ballotId);

          db.prepare("DELETE FROM choices WHERE ballot_id = ?").run(ballotId);
          const insertChoice = db.prepare(
            "INSERT INTO choices (id, ballot_id, label, position) VALUES (?, ?, ?, ?)"
          );
          cleanChoices.forEach((label, idx) => {
            insertChoice.run(makeId("choice"), ballotId, label, idx);
          });

          db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES ('edited', 'ballot', ?, ?, ?, ?, ?)
          `).run(ballotId, request.user.id, request.user.name, `Updated draft ${cleanTitle}`, now());
        })();

        const updated = getBallotRecord(ballotId);
        return {
          status: 200,
          body: {
            ok: true,
            message: `Updated draft "${cleanTitle}".`,
            ballot: formatBallotForUser(updated, request.user)
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// POST /api/ballots/:id/open (Single open)
app.post("/api/ballots/:id/open", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const { revision, operation_id } = request.body || {};
    const rev = parsePositiveInteger(revision, "Ballot revision");
    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    const ballot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");

    const normalizedInput = { ballot_id: ballotId, revision: rev };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "open_ballot",
      normalizedInput,
      () => {
        const current = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
        if (current.status !== "draft") {
          throw new ApiError(409, `Ballot "${current.title}" must be in draft stage to open.`);
        }
        if (current.revision !== rev) {
          throw new ApiError(
            409,
            `Ballot "${current.title}" revision is outdated. Please refresh before opening.`
          );
        }

        const activeMembers = db.prepare(
          "SELECT user_id FROM memberships WHERE group_id = ? AND active = 1"
        ).all(current.group_id);

        if (activeMembers.length === 0) {
          throw new ApiError(409, "Cannot open a ballot with no active members.");
        }

        const openedAt = now();
        db.transaction(() => {
          db.prepare(
            "UPDATE ballots SET status = 'open', revision = revision + 1, opened_at = ? WHERE id = ?"
          ).run(openedAt, ballotId);

          db.prepare("DELETE FROM eligibility WHERE ballot_id = ?").run(ballotId);
          const insertEligible = db.prepare(
            "INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)"
          );
          for (const am of activeMembers) {
            insertEligible.run(ballotId, am.user_id);
          }

          db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES ('opened', 'ballot', ?, ?, ?, ?, ?)
          `).run(
            ballotId,
            request.user.id,
            request.user.name,
            `Opened ${current.title} with ${activeMembers.length} eligible Members`,
            openedAt
          );
        })();

        const updated = getBallotRecord(ballotId);
        return {
          status: 200,
          body: {
            ok: true,
            message: `Opened "${current.title}" with ${activeMembers.length} eligible Members.`,
            ballot: formatBallotForUser(updated, request.user)
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// POST /api/ballots/round-open (Round open)
app.post("/api/ballots/round-open", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const { ballots: rawBallots, roster: rawRoster, operation_id } = request.body || {};

    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    if (!Array.isArray(rawBallots) || rawBallots.length < 2) {
      throw new ApiError(400, "Round open requires at least two different draft ballots.");
    }
    if (!Array.isArray(rawRoster) || rawRoster.length === 0) {
      throw new ApiError(400, "Round open requires a complete member roster.");
    }

    const seenBallotIds = new Set();
    const parsedBallots = [];
    for (const b of rawBallots) {
      if (!b || typeof b !== "object" || Array.isArray(b)) {
        throw new ApiError(400, "Each ballot in round selection must be an object.");
      }
      if (typeof b.id !== "string" || !b.id.trim()) {
        throw new ApiError(400, "Ballot ID is required for each ballot in round.");
      }
      const bId = b.id.trim();
      if (seenBallotIds.has(bId)) {
        throw new ApiError(400, "Duplicate ballot in round selection.");
      }
      seenBallotIds.add(bId);
      const rev = parsePositiveInteger(b.revision, `Ballot ${bId} revision`);
      parsedBallots.push({ id: bId, revision: rev });
    }

    const seenUserIds = new Set();
    const parsedRoster = [];
    for (const m of rawRoster) {
      if (!m || typeof m !== "object" || Array.isArray(m)) {
        throw new ApiError(400, "Each member in roster must be an object.");
      }
      if (typeof m.user_id !== "string" || !m.user_id.trim()) {
        throw new ApiError(400, "Member user_id is required in roster.");
      }
      const uId = m.user_id.trim();
      if (seenUserIds.has(uId)) {
        throw new ApiError(400, "Duplicate member in roster.");
      }
      seenUserIds.add(uId);
      const rev = parsePositiveInteger(m.revision, `Member ${uId} revision`);
      parsedRoster.push({ user_id: uId, revision: rev });
    }

    const allGroupMembers = db.prepare(
      "SELECT user_id, active, revision FROM memberships WHERE group_id = 'group-riverside'"
    ).all();

    if (parsedRoster.length !== allGroupMembers.length) {
      throw new ApiError(400, "Incomplete roster provided. All group members must be reviewed.");
    }
    const dbMemberMap = new Map();
    for (const gm of allGroupMembers) {
      dbMemberMap.set(gm.user_id, gm);
    }
    for (const m of parsedRoster) {
      if (!dbMemberMap.has(m.user_id)) {
        throw new ApiError(400, `Unknown member ${m.user_id} in roster.`);
      }
    }

    for (const b of parsedBallots) {
      const dbBallot = db.prepare("SELECT id FROM ballots WHERE id = ?").get(b.id);
      if (!dbBallot) {
        throw new ApiError(400, `Unknown ballot ${b.id} in round selection.`);
      }
    }

    const sortedBallots = [...parsedBallots].sort((a, b) => a.id.localeCompare(b.id));
    const sortedRoster = [...parsedRoster].sort((a, b) => a.user_id.localeCompare(b.user_id));
    const normalizedInput = {
      ballots: sortedBallots,
      roster: sortedRoster
    };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "round_open",
      normalizedInput,
      () => {
        for (const b of sortedBallots) {
          const dbBallot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(b.id);
          if (dbBallot.status !== "draft") {
            throw new ApiError(
              409,
              `Ballot "${dbBallot.title}" is no longer in draft stage. Please review again.`
            );
          }
          if (dbBallot.revision !== b.revision) {
            throw new ApiError(
              409,
              `Ballot "${dbBallot.title}" has been updated since your review. Please review again.`
            );
          }
        }

        for (const m of sortedRoster) {
          const currentMember = db.prepare(
            "SELECT revision, active FROM memberships WHERE group_id = 'group-riverside' AND user_id = ?"
          ).get(m.user_id);
          if (currentMember.revision !== m.revision) {
            throw new ApiError(409, "Member roster has changed since your review. Please review again.");
          }
        }

        const activeMembers = db.prepare(
          "SELECT user_id FROM memberships WHERE group_id = 'group-riverside' AND active = 1"
        ).all();

        if (activeMembers.length === 0) {
          throw new ApiError(409, "Cannot open round with no active members.");
        }

        const openedAt = now();
        const openedBallots = [];

        db.transaction(() => {
          const updateBallot = db.prepare(
            "UPDATE ballots SET status = 'open', revision = revision + 1, opened_at = ? WHERE id = ?"
          );
          const insertEligibility = db.prepare(
            "INSERT INTO eligibility (ballot_id, user_id) VALUES (?, ?)"
          );
          const insertAudit = db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES ('opened', 'ballot', ?, ?, ?, ?, ?)
          `);

          for (const b of sortedBallots) {
            const dbBallot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(b.id);
            updateBallot.run(openedAt, b.id);
            db.prepare("DELETE FROM eligibility WHERE ballot_id = ?").run(b.id);
            for (const am of activeMembers) {
              insertEligibility.run(b.id, am.user_id);
            }
            insertAudit.run(
              b.id,
              request.user.id,
              request.user.name,
              `Opened ${dbBallot.title} with ${activeMembers.length} eligible Members`,
              openedAt
            );
            openedBallots.push({ id: b.id, title: dbBallot.title });
          }
        })();

        return {
          status: 200,
          body: {
            ok: true,
            message: `Opened ${openedBallots.length} ballots in round.`,
            opened_ballots: openedBallots
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// POST /api/ballots/:id/close (Close ballot)
app.post("/api/ballots/:id/close", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const { revision, operation_id } = request.body || {};
    const rev = parsePositiveInteger(revision, "Ballot revision");
    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    const ballot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");

    const normalizedInput = { ballot_id: ballotId, revision: rev };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "close_ballot",
      normalizedInput,
      () => {
        const current = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
        if (current.status !== "open") {
          throw new ApiError(409, `Ballot "${current.title}" must be open to be closed.`);
        }
        if (current.revision !== rev) {
          throw new ApiError(
            409,
            `Ballot "${current.title}" revision is outdated. Please refresh before closing.`
          );
        }

        const closedAt = now();
        db.transaction(() => {
          db.prepare(
            "UPDATE ballots SET status = 'closed', revision = revision + 1, closed_at = ? WHERE id = ?"
          ).run(closedAt, ballotId);
          db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES ('closed', 'ballot', ?, ?, ?, ?, ?)
          `).run(ballotId, request.user.id, request.user.name, `Closed ${current.title}`, closedAt);
        })();

        const updated = getBallotRecord(ballotId);
        return {
          status: 200,
          body: {
            ok: true,
            message: `Closed "${current.title}".`,
            ballot: formatBallotForUser(updated, request.user)
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// POST /api/ballots/:id/publish (Publish ballot)
app.post("/api/ballots/:id/publish", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const { revision, operation_id } = request.body || {};
    const rev = parsePositiveInteger(revision, "Ballot revision");
    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    const ballot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");

    const normalizedInput = { ballot_id: ballotId, revision: rev };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "publish_ballot",
      normalizedInput,
      () => {
        const current = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
        if (current.status !== "closed") {
          throw new ApiError(
            409,
            `Ballot "${current.title}" must be closed before publishing results.`
          );
        }
        if (current.revision !== rev) {
          throw new ApiError(
            409,
            `Ballot "${current.title}" revision is outdated. Please refresh before publishing.`
          );
        }

        const publishedAt = now();
        db.transaction(() => {
          db.prepare(
            "UPDATE ballots SET status = 'published', revision = revision + 1, published_at = ? WHERE id = ?"
          ).run(publishedAt, ballotId);
          db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES ('published', 'ballot', ?, ?, ?, ?, ?)
          `).run(
            ballotId,
            request.user.id,
            request.user.name,
            `Published anonymous results for ${current.title}`,
            publishedAt
          );
        })();

        const updated = getBallotRecord(ballotId);
        return {
          status: 200,
          body: {
            ok: true,
            message: `Published anonymous results for "${current.title}".`,
            ballot: formatBallotForUser(updated, request.user)
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// PUT /api/members/:userId (Update membership)
app.put("/api/members/:userId", requireUser, requireRole("coordinator"), (request, response, next) => {
  try {
    const targetUserId = request.params.userId;
    const { active, revision, operation_id } = request.body || {};
    const cleanActive = parseActiveStatus(active);
    const rev = parsePositiveInteger(revision, "Membership revision");
    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    const memberUser = db.prepare("SELECT * FROM users WHERE id = ?").get(targetUserId);
    if (!memberUser) throw new ApiError(404, "User not found.");

    const membership = db.prepare(
      "SELECT * FROM memberships WHERE group_id = 'group-riverside' AND user_id = ?"
    ).get(targetUserId);
    if (!membership) throw new ApiError(404, "Membership not found.");

    const normalizedInput = {
      user_id: targetUserId,
      revision: rev,
      active: cleanActive === 1
    };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "update_membership",
      normalizedInput,
      () => {
        const current = db.prepare(
          "SELECT * FROM memberships WHERE group_id = 'group-riverside' AND user_id = ?"
        ).get(targetUserId);
        if (current.revision !== rev) {
          throw new ApiError(
            409,
            `Membership record for ${memberUser.name} is outdated. Please refresh before making changes.`
          );
        }

        const updatedAt = now();
        db.transaction(() => {
          db.prepare(`
            UPDATE memberships
            SET active = ?, revision = revision + 1, updated_at = ?
            WHERE group_id = 'group-riverside' AND user_id = ?
          `).run(cleanActive, updatedAt, targetUserId);

          const actionName = cleanActive === 1 ? "membership_activated" : "membership_paused";
          const details = `${cleanActive === 1 ? "Activated" : "Paused"} ${memberUser.name} for future eligibility snapshots`;

          db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES (?, 'member', ?, ?, ?, ?, ?)
          `).run(actionName, targetUserId, request.user.id, request.user.name, details, updatedAt);
        })();

        const updated = db.prepare(
          "SELECT * FROM memberships WHERE group_id = 'group-riverside' AND user_id = ?"
        ).get(targetUserId);
        return {
          status: 200,
          body: {
            ok: true,
            message: `${cleanActive === 1 ? "Activated" : "Paused"} ${memberUser.name}.`,
            member: {
              user_id: targetUserId,
              name: memberUser.name,
              email: memberUser.email,
              role: memberUser.role,
              active: updated.active === 1,
              revision: updated.revision,
              updated_at: updated.updated_at
            }
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// POST /api/ballots/:id/vote (Submit vote)
app.post("/api/ballots/:id/vote", requireUser, requireRole("member"), (request, response, next) => {
  try {
    const ballotId = request.params.id;
    const { choice_id, choice_ids, operation_id } = request.body || {};

    if (!operation_id || typeof operation_id !== "string" || !operation_id.trim()) {
      throw new ApiError(400, "Operation identifier is required.");
    }

    const ballot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
    if (!ballot) throw new ApiError(404, "Ballot not found.");

    let rawChoiceIds = [];
    if (Array.isArray(choice_ids)) {
      rawChoiceIds = choice_ids;
    } else if (typeof choice_id === "string") {
      rawChoiceIds = [choice_id];
    } else {
      throw new ApiError(400, "Choice selection is required.");
    }

    if (rawChoiceIds.length === 0) {
      throw new ApiError(400, "At least one choice must be selected.");
    }

    for (let i = 0; i < rawChoiceIds.length; i++) {
      if (typeof rawChoiceIds[i] !== "string" || !rawChoiceIds[i].trim()) {
        throw new ApiError(400, `Choice item ${i + 1} must be a valid ID.`);
      }
      rawChoiceIds[i] = rawChoiceIds[i].trim();
    }

    const uniqueChoices = Array.from(new Set(rawChoiceIds));
    if (uniqueChoices.length !== rawChoiceIds.length) {
      throw new ApiError(400, "Duplicate choices are not allowed in vote.");
    }

    if (ballot.method === "single") {
      if (uniqueChoices.length !== 1) {
        throw new ApiError(400, "Single choice ballots require exactly one choice.");
      }
    } else if (ballot.method === "approval") {
      if (uniqueChoices.length < 1 || uniqueChoices.length > ballot.max_selections) {
        throw new ApiError(
          400,
          `Approval vote requires between 1 and ${ballot.max_selections} choices.`
        );
      }
    }

    const validChoices = db.prepare("SELECT id FROM choices WHERE ballot_id = ?").all(ballotId).map((c) => c.id);
    const validChoiceSet = new Set(validChoices);
    for (const cid of uniqueChoices) {
      if (!validChoiceSet.has(cid)) {
        throw new ApiError(400, "One or more selected choices are invalid for this ballot.");
      }
    }

    const sortedChoiceIds = [...uniqueChoices].sort();
    const normalizedInput = {
      ballot_id: ballotId,
      choice_ids: sortedChoiceIds
    };

    const result = executeWithReceipt(
      request.user,
      operation_id,
      "cast_vote",
      normalizedInput,
      () => {
        const currentBallot = db.prepare("SELECT * FROM ballots WHERE id = ?").get(ballotId);
        if (currentBallot.status !== "open") {
          throw new ApiError(409, "Voting is only allowed while the ballot is open.");
        }

        const isEligible = db.prepare(
          "SELECT 1 FROM eligibility WHERE ballot_id = ? AND user_id = ?"
        ).get(ballotId, request.user.id);
        if (!isEligible) {
          throw new ApiError(403, "You are not eligible to vote on this ballot.");
        }

        const existingParticipation = db.prepare(
          "SELECT 1 FROM participation WHERE ballot_id = ? AND user_id = ?"
        ).get(ballotId, request.user.id);
        if (existingParticipation) {
          throw new ApiError(409, "You have already voted on this ballot.");
        }

        const receiptId = makeId("rcpt");
        const submittedAt = now();

        db.transaction(() => {
          db.prepare(`
            INSERT INTO participation (ballot_id, user_id, submitted_at, receipt_id)
            VALUES (?, ?, ?, ?)
          `).run(ballotId, request.user.id, submittedAt, receiptId);

          const insertVote = db.prepare(`
            INSERT INTO anonymous_votes (id, ballot_id, choice_id, cast_at)
            VALUES (?, ?, ?, ?)
          `);
          for (const cid of sortedChoiceIds) {
            insertVote.run(makeId("vote"), ballotId, cid, submittedAt);
          }

          db.prepare(`
            INSERT INTO audit (action, entity_type, entity_id, actor_id, actor_label, details, created_at)
            VALUES ('voted', 'ballot', ?, NULL, 'Anonymous Member', ?, ?)
          `).run(ballotId, `Anonymous vote recorded for ${currentBallot.title}`, submittedAt);
        })();

        return {
          status: 200,
          body: {
            ok: true,
            message: "Your vote has been recorded.",
            ballot_id: ballotId,
            receipt_id: receiptId,
            submitted_at: submittedAt
          }
        };
      }
    );

    response.status(result.status).json(result.body);
  } catch (error) {
    next(error);
  }
});

// GET /api/turnout
app.get("/api/turnout", requireUser, (request, response, next) => {
  try {
    const turnout = getTurnoutData(request.user);
    response.json({ turnout });
  } catch (error) {
    next(error);
  }
});

// GET /api/results
app.get("/api/results", requireUser, (request, response, next) => {
  try {
    let ballots;
    if (request.user.role === "member") {
      ballots = db.prepare(`
        SELECT b.id
        FROM ballots b
        JOIN eligibility e ON e.ballot_id = b.id
        WHERE e.user_id = ?
        ORDER BY b.created_at DESC
      `).all(request.user.id);
    } else {
      ballots = db.prepare("SELECT id FROM ballots ORDER BY created_at DESC").all();
    }

    const results = ballots.map((b) => getBallotResults(b.id)).filter(Boolean);
    response.json({ results });
  } catch (error) {
    next(error);
  }
});

// GET /api/members
app.get("/api/members", requireUser, (_request, response, next) => {
  try {
    const members = getMembersList();
    response.json({ members });
  } catch (error) {
    next(error);
  }
});

// GET /api/audit
app.get("/api/audit", requireUser, (_request, response, next) => {
  try {
    const audit = getAuditLog();
    response.json({ audit });
  } catch (error) {
    next(error);
  }
});

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.get(/.*/, (_request, response) => response.sendFile(path.join(__dirname, "public", "index.html")));

app.use((error, _request, response, _next) => {
  if (error instanceof SyntaxError && "body" in error) {
    return response.status(400).json({ error: "Request body must be valid JSON." });
  }
  if (error instanceof ApiError) return response.status(error.status).json(error.body);
  console.error(error);
  response.status(500).json({ error: "Something went wrong on the server." });
});

let serverInstance = null;
if (require.main === module) {
  serverInstance = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Common Ground listening on ${PORT}`);
  });
}

function shutdown() {
  if (serverInstance) {
    serverInstance.close(() => {
      db.close();
      process.exit(0);
    });
  } else {
    db.close();
    process.exit(0);
  }
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

module.exports = { app, db };
