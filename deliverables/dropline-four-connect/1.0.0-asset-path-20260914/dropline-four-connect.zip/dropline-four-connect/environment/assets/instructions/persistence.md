# Server state and persistence

The server owns move validation, gravity, turn changes, win and draw detection,
terminal locking, account isolation, score changes, move history, undo, and
redo. Browser-only state is not sufficient.

Persist every accepted move, undo, redo, and New game action before reporting
success. Reload and later sign-in restore the exact board, turn or result,
winning cells, totals, applied history, and redo availability. Rejected moves
or history actions must not produce a partial database change.

The saved analyses described in analysis.md share this persistence guarantee:
their frozen prefixes, tree nodes, names, selected positions, revisions and
operation receipts survive ordinary server restarts without reseeding or loss.

Serve authentication, state reads, and state changes from the same origin as
the browser application. Public scripts, stylesheets, fonts, images and other
browser requests are allowed; an external URL alone is not a defect. Do not
outsource authentication or game storage to a hosted service. Provide a
same-origin health response at `GET /api/health` when the server is ready.
