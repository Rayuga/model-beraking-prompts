# Claude Haiku 4.5 evidence

`agent-run/` is the untouched OpenHands generation produced with
`openrouter/anthropic/claude-haiku-4.5` against task version 6.0.2. The agent
completed, but the original local Harbor run could not launch its separate
verifier because Windows Docker does not implement `network_mode="allowlist"`.

`verifier-v6.0.3/` is the later verifier-only run against that preserved
artifact using the final public-network local verifier copy. The platform task
still retains allowlisted verifier networking.

Final scored result:

- Constraints: 0.0000.
- Functional: 0.6842.
- Render: 0.0000.
- Polish: 0.0000.
- Hard-gated final reward: 0.0000.

The main failure is genuine model behavior. The server uses
`express.static('public')`, so starting it exactly as instructed with
`node /app/server.js` from the verifier directory resolves static files under
`/tests/public` instead of serving `/app/public/index.html`. The application
therefore fails the required workspace and render gates. The polish judge also
timed out after 900 seconds, but the final reward was already zero because of
the failed constraints gate.
