# DropLine Four Lite Claude Haiku 4.5 evidence

- Task: `turing/dropline-four-lite`
- Task version: `6.0.3`
- Task checksum: `c7400c4c34da652f7e4d050c40a063e4aa4fd4ffeacd3b6aa4ecd092d10aa528`
- Agent: OpenHands 0.62.0
- Model: `openrouter/anthropic/claude-haiku-4.5`, reasoning effort high
- Result: Render 1.0, Constraints 1.0, Functional 0.4211, Polish 0.2
- Final reward: `0.3327`
- Harbor status: graded 1, no-op 0; all 22 criteria have non-empty reasoning

This was a genuine end-to-end v6.0.3 attempt. Haiku built a server-backed app
that the full verifier graded without judge timeouts. The run records one
model-caused `NonZeroAgentExitCodeError`: after building the app, Haiku issued
`pkill -f "node /app/server.js"`; the pattern also matched the OpenHands process
because the task prompt contains that command, so OpenHands exited with SIGTERM
(143). The generated artifact and full verifier outputs are preserved here.

