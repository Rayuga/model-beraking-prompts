# Task List

1. ✅ Set up project structure and database schema
Create /app directory, initialize SQLite database with schema for accounts, tokens, games, moves, archives
2. ✅ Seed database with initial data from Excel
Import accounts, initial game states, and completed matches from dropline_seed.xlsx
3. ✅ Build Express server with authentication endpoints
POST /api/signin, POST /api/signout, token validation middleware, bearer token generation
4. ✅ Implement game state endpoints
GET /api/game, POST /api/move, POST /api/undo, POST /api/redo, POST /api/new-game with revision tracking
5. ✅ Implement archive and replay endpoints
GET /api/archive, GET /api/archive/:id/replay with read-only access
6. ✅ Build HTML UI with sign-in form
Create /app/public/index.html with sign-in screen, responsive design for 375px width
7. ✅ Build game board UI with accessibility
7x6 grid, column controls, move history display, undo/redo buttons, account info
8. ✅ Implement client-side game logic and UI updates
Board rendering, turn display, move validation feedback, win/draw detection display
9. ✅ Implement move history and undo/redo UI
Display move history, handle undo/redo button states, keyboard navigation
10. ✅ Implement archive and replay UI
Show archive list, replay modal with step control, keyboard navigation
11. ✅ Implement concurrency handling and idempotency
Revision tracking, operation IDs, stale mutation detection, multi-tab safety
12. ✅ Test and polish the application
All 14 API tests passing, verified accessibility, multi-tab safety, responsive design
