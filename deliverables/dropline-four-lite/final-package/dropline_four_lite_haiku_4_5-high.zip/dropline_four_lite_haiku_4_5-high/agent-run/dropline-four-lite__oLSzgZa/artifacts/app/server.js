const express = require('express');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const dbPath = '/app/dropline.db';
const PORT = 3000;

// Initialize database
let db;
function initializeDatabase() {
  const dbExists = fs.existsSync(dbPath);
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');

  if (!dbExists) {
    createSchema();
    seedDatabase();
  }
}

function createSchema() {
  db.exec(`
    CREATE TABLE accounts (
      id INTEGER PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      name TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE tokens (
      id INTEGER PRIMARY KEY,
      account_id INTEGER NOT NULL,
      token TEXT UNIQUE NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (account_id) REFERENCES accounts(id)
    );

    CREATE TABLE games (
      id INTEGER PRIMARY KEY,
      account_id INTEGER NOT NULL,
      round_id TEXT UNIQUE NOT NULL,
      board TEXT NOT NULL,
      current_player TEXT NOT NULL,
      status TEXT NOT NULL,
      winning_cells TEXT,
      red_wins INTEGER DEFAULT 0,
      yellow_wins INTEGER DEFAULT 0,
      draws INTEGER DEFAULT 0,
      revision INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (account_id) REFERENCES accounts(id)
    );

    CREATE TABLE moves (
      id INTEGER PRIMARY KEY,
      game_id INTEGER NOT NULL,
      move_number INTEGER NOT NULL,
      color TEXT NOT NULL,
      column_num INTEGER NOT NULL,
      row_num INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (game_id) REFERENCES games(id)
    );

    CREATE TABLE redo_stack (
      id INTEGER PRIMARY KEY,
      game_id INTEGER NOT NULL,
      move_number INTEGER NOT NULL,
      color TEXT NOT NULL,
      column_num INTEGER NOT NULL,
      row_num INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (game_id) REFERENCES games(id)
    );

    CREATE TABLE archives (
      id INTEGER PRIMARY KEY,
      account_id INTEGER NOT NULL,
      match_id TEXT UNIQUE NOT NULL,
      result TEXT NOT NULL,
      board TEXT NOT NULL,
      moves TEXT NOT NULL,
      completed_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (account_id) REFERENCES accounts(id)
    );

    CREATE TABLE operation_cache (
      id INTEGER PRIMARY KEY,
      account_id INTEGER NOT NULL,
      operation_id TEXT UNIQUE NOT NULL,
      result TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (account_id) REFERENCES accounts(id)
    );

    CREATE INDEX idx_tokens_account ON tokens(account_id);
    CREATE INDEX idx_games_account ON games(account_id);
    CREATE INDEX idx_moves_game ON moves(game_id);
    CREATE INDEX idx_redo_game ON redo_stack(game_id);
    CREATE INDEX idx_archives_account ON archives(account_id);
    CREATE INDEX idx_operation_cache_account ON operation_cache(account_id);
  `);
}

function seedDatabase() {
  const XLSX = require('xlsx');
  const workbook = XLSX.readFile('/assets/artifacts/dropline_seed.xlsx');

  // Seed accounts
  const accountsSheet = workbook.Sheets['Accounts'];
  const accountsData = XLSX.utils.sheet_to_json(accountsSheet);
  
  for (const account of accountsData) {
    db.prepare(`
      INSERT INTO accounts (email, password, name)
      VALUES (?, ?, ?)
    `).run(account.Email, account.Password, account.Name);
  }

  // Seed initial game states
  const gameStateSheet = workbook.Sheets['Initial Game State'];
  const gameStateData = XLSX.utils.sheet_to_json(gameStateSheet);

  for (const gameState of gameStateData) {
    const account = db.prepare('SELECT id FROM accounts WHERE email = ?').get(gameState['Account email']);
    if (account) {
      db.prepare(`
        INSERT INTO games (account_id, round_id, board, current_player, status, winning_cells, red_wins, yellow_wins, draws, revision)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        account.id,
        gameState['Round id'],
        gameState.Board,
        gameState['Current player'],
        gameState.Status,
        gameState['Winning cells'],
        gameState['Red wins'],
        gameState['Yellow wins'],
        gameState.Draws,
        gameState.Revision
      );

      const game = db.prepare('SELECT id FROM games WHERE round_id = ?').get(gameState['Round id']);
      
      // Insert applied history
      const appliedHistory = JSON.parse(gameState['Applied history']);
      for (let i = 0; i < appliedHistory.length; i++) {
        const move = appliedHistory[i];
        db.prepare(`
          INSERT INTO moves (game_id, move_number, color, column_num, row_num)
          VALUES (?, ?, ?, ?, ?)
        `).run(game.id, i + 1, move.color, move.column, move.row);
      }

      // Insert redo history
      const redoHistory = gameState['Redo history'];
      if (redoHistory !== 'none' && redoHistory) {
        const redoMoves = JSON.parse(redoHistory);
        for (let i = 0; i < redoMoves.length; i++) {
          const move = redoMoves[i];
          db.prepare(`
            INSERT INTO redo_stack (game_id, move_number, color, column_num, row_num)
            VALUES (?, ?, ?, ?, ?)
          `).run(game.id, i + 1, move.color, move.column, move.row);
        }
      }
    }
  }

  // Seed completed matches
  const archiveSheet = workbook.Sheets['Completed Matches'];
  const archiveData = XLSX.utils.sheet_to_json(archiveSheet);

  for (const archive of archiveData) {
    const account = db.prepare('SELECT id FROM accounts WHERE email = ?').get(archive['Account email']);
    if (account) {
      db.prepare(`
        INSERT INTO archives (account_id, match_id, result, board, moves, completed_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        account.id,
        archive['Match id'],
        archive.Result,
        archive['Final board'],
        archive.Moves,
        archive['Completed at']
      );
    }
  }
}

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Helper functions
function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

function getAccountFromToken(token) {
  const row = db.prepare(`
    SELECT a.id, a.email, a.name FROM tokens t
    JOIN accounts a ON t.account_id = a.id
    WHERE t.token = ?
  `).get(token);
  return row;
}

function getGameState(accountId) {
  const game = db.prepare(`
    SELECT * FROM games WHERE account_id = ? LIMIT 1
  `).get(accountId);
  
  if (!game) return null;

  const moves = db.prepare(`
    SELECT * FROM moves WHERE game_id = ? ORDER BY move_number
  `).all(game.id);

  const redoMoves = db.prepare(`
    SELECT * FROM redo_stack WHERE game_id = ? ORDER BY move_number
  `).all(game.id);

  return {
    ...game,
    board: JSON.parse(game.board),
    winning_cells: game.winning_cells === 'none' ? null : JSON.parse(game.winning_cells),
    applied_history: moves.map(m => ({
      color: m.color,
      column: m.column_num,
      row: m.row_num
    })),
    redo_history: redoMoves.map(m => ({
      color: m.color,
      column: m.column_num,
      row: m.row_num
    }))
  };
}

function cacheOperation(accountId, operationId, result) {
  if (!operationId) return;
  try {
    db.prepare('INSERT INTO operation_cache (account_id, operation_id, result) VALUES (?, ?, ?)').run(
      accountId,
      operationId,
      JSON.stringify(result)
    );
  } catch (e) {
    // Operation already cached, ignore
  }
}

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/signin', (req, res) => {
  const { email, password } = req.body;
  
  const account = db.prepare('SELECT * FROM accounts WHERE email = ? AND password = ?').get(email, password);
  
  if (!account) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const token = generateToken();
  db.prepare('INSERT INTO tokens (account_id, token) VALUES (?, ?)').run(account.id, token);

  const gameState = getGameState(account.id);

  res.json({
    token,
    account: {
      id: account.id,
      email: account.email,
      name: account.name
    },
    game: gameState
  });
});

app.post('/api/signout', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  // Revoke all tokens for this account
  db.prepare('DELETE FROM tokens WHERE account_id = ?').run(account.id);

  res.json({ success: true });
});

app.get('/api/game', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  const gameState = getGameState(account.id);
  res.json(gameState);
});

app.post('/api/move', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const { column, operationId, expectedRevision } = req.body;

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  // Check operation cache for idempotency
  if (operationId) {
    const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?').get(account.id, operationId);
    if (cached) {
      return res.json(JSON.parse(cached.result));
    }
  }

  const game = db.prepare('SELECT * FROM games WHERE account_id = ?').get(account.id);
  if (!game) {
    return res.status(404).json({ error: 'No game found' });
  }

  // Check revision
  if (expectedRevision !== undefined && expectedRevision !== game.revision) {
    const gameState = getGameState(account.id);
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      game: gameState
    });
  }

  const board = JSON.parse(game.board);
  const colIndex = column - 1;

  // Find lowest empty cell in column
  let row = -1;
  for (let r = 5; r >= 0; r--) {
    if (board[r * 7 + colIndex] === '') {
      row = r;
      break;
    }
  }

  if (row === -1) {
    return res.status(400).json({ error: `Column ${column} is full` });
  }

  // Check if game is terminal
  if (game.status !== 'active') {
    return res.status(400).json({ error: 'Game is not active' });
  }

  // Place piece
  const cellIndex = row * 7 + colIndex;
  board[cellIndex] = game.current_player;

  // Check for win
  const winningCells = checkWin(board, game.current_player);
  let newStatus = game.status;
  let newWinningCells = null;
  let redWins = game.red_wins;
  let yellowWins = game.yellow_wins;
  let draws = game.draws;

  if (winningCells) {
    newStatus = 'terminal';
    newWinningCells = winningCells;
    if (game.current_player === 'Red') {
      redWins++;
    } else {
      yellowWins++;
    }
  } else if (board.every(cell => cell !== '')) {
    newStatus = 'terminal';
    draws++;
  }

  // Update game
  const newRevision = game.revision + 1;
  const nextPlayer = game.current_player === 'Red' ? 'Yellow' : 'Red';

  db.prepare(`
    UPDATE games SET 
      board = ?, 
      current_player = ?, 
      status = ?, 
      winning_cells = ?,
      red_wins = ?,
      yellow_wins = ?,
      draws = ?,
      revision = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(
    JSON.stringify(board),
    nextPlayer,
    newStatus,
    newWinningCells ? JSON.stringify(newWinningCells) : 'none',
    redWins,
    yellowWins,
    draws,
    newRevision,
    game.id
  );

  // Add move to history
  const moveNumber = db.prepare('SELECT COUNT(*) as count FROM moves WHERE game_id = ?').get(game.id).count + 1;
  db.prepare(`
    INSERT INTO moves (game_id, move_number, color, column_num, row_num)
    VALUES (?, ?, ?, ?, ?)
  `).run(game.id, moveNumber, game.current_player, column, row + 1);

  // Clear redo stack
  db.prepare('DELETE FROM redo_stack WHERE game_id = ?').run(game.id);

  // Archive if terminal
  if (newStatus === 'terminal') {
    const result = newWinningCells ? `${game.current_player} wins` : 'Draw';
    const moves = db.prepare('SELECT * FROM moves WHERE game_id = ? ORDER BY move_number').all(game.id);
    const matchId = `match-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    db.prepare(`
      INSERT INTO archives (account_id, match_id, result, board, moves, completed_at)
      VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `).run(
      account.id,
      matchId,
      result,
      JSON.stringify(board),
      JSON.stringify(moves.map(m => ({
        color: m.color,
        column: m.column_num,
        row: m.row_num
      })))
    );
  }

  const gameState = getGameState(account.id);
  const result = { game: gameState };

  cacheOperation(account.id, operationId, result);
  res.json(result);
});

app.post('/api/undo', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const { operationId, expectedRevision } = req.body;

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  // Check operation cache
  if (operationId) {
    const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?').get(account.id, operationId);
    if (cached) {
      return res.json(JSON.parse(cached.result));
    }
  }

  const game = db.prepare('SELECT * FROM games WHERE account_id = ?').get(account.id);
  if (!game) {
    return res.status(404).json({ error: 'No game found' });
  }

  // Check revision
  if (expectedRevision !== undefined && expectedRevision !== game.revision) {
    const gameState = getGameState(account.id);
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      game: gameState
    });
  }

  const moves = db.prepare('SELECT * FROM moves WHERE game_id = ? ORDER BY move_number DESC LIMIT 1').get(game.id);
  if (!moves) {
    return res.status(400).json({ error: 'No moves to undo' });
  }

  const board = JSON.parse(game.board);
  const cellIndex = (moves.row_num - 1) * 7 + (moves.column_num - 1);
  board[cellIndex] = '';

  // Add to redo stack
  db.prepare(`
    INSERT INTO redo_stack (game_id, move_number, color, column_num, row_num)
    VALUES (?, ?, ?, ?, ?)
  `).run(game.id, moves.move_number, moves.color, moves.column_num, moves.row_num);

  // Remove from moves
  db.prepare('DELETE FROM moves WHERE id = ?').run(moves.id);

  // Update game
  const newRevision = game.revision + 1;
  const prevPlayer = moves.color;
  let redWins = game.red_wins;
  let yellowWins = game.yellow_wins;
  let draws = game.draws;

  // Check if we're undoing a terminal move
  if (game.status === 'terminal') {
    if (game.winning_cells && game.winning_cells !== 'none') {
      if (prevPlayer === 'Red') {
        redWins--;
      } else {
        yellowWins--;
      }
    } else {
      draws--;
    }
  }

  db.prepare(`
    UPDATE games SET 
      board = ?, 
      current_player = ?, 
      status = 'active',
      winning_cells = 'none',
      red_wins = ?,
      yellow_wins = ?,
      draws = ?,
      revision = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(
    JSON.stringify(board),
    prevPlayer,
    redWins,
    yellowWins,
    draws,
    newRevision,
    game.id
  );

  const gameState = getGameState(account.id);
  const result = { game: gameState };

  cacheOperation(account.id, operationId, result);
  res.json(result);
});

app.post('/api/redo', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const { operationId, expectedRevision } = req.body;

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  // Check operation cache
  if (operationId) {
    const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?').get(account.id, operationId);
    if (cached) {
      return res.json(JSON.parse(cached.result));
    }
  }

  const game = db.prepare('SELECT * FROM games WHERE account_id = ?').get(account.id);
  if (!game) {
    return res.status(404).json({ error: 'No game found' });
  }

  // Check revision
  if (expectedRevision !== undefined && expectedRevision !== game.revision) {
    const gameState = getGameState(account.id);
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      game: gameState
    });
  }

  const redoMove = db.prepare('SELECT * FROM redo_stack WHERE game_id = ? ORDER BY move_number LIMIT 1').get(game.id);
  if (!redoMove) {
    return res.status(400).json({ error: 'No moves to redo' });
  }

  const board = JSON.parse(game.board);
  const cellIndex = (redoMove.row_num - 1) * 7 + (redoMove.column_num - 1);
  board[cellIndex] = redoMove.color;

  // Add back to moves
  const moveNumber = db.prepare('SELECT COUNT(*) as count FROM moves WHERE game_id = ?').get(game.id).count + 1;
  db.prepare(`
    INSERT INTO moves (game_id, move_number, color, column_num, row_num)
    VALUES (?, ?, ?, ?, ?)
  `).run(game.id, moveNumber, redoMove.color, redoMove.column_num, redoMove.row_num);

  // Remove from redo stack
  db.prepare('DELETE FROM redo_stack WHERE id = ?').run(redoMove.id);

  // Check for win
  const winningCells = checkWin(board, redoMove.color);
  let newStatus = game.status;
  let newWinningCells = null;
  let redWins = game.red_wins;
  let yellowWins = game.yellow_wins;
  let draws = game.draws;

  if (winningCells) {
    newStatus = 'terminal';
    newWinningCells = winningCells;
    if (redoMove.color === 'Red') {
      redWins++;
    } else {
      yellowWins++;
    }
  } else if (board.every(cell => cell !== '')) {
    newStatus = 'terminal';
    draws++;
  }

  // Update game
  const newRevision = game.revision + 1;
  const nextPlayer = redoMove.color === 'Red' ? 'Yellow' : 'Red';

  db.prepare(`
    UPDATE games SET 
      board = ?, 
      current_player = ?, 
      status = ?,
      winning_cells = ?,
      red_wins = ?,
      yellow_wins = ?,
      draws = ?,
      revision = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(
    JSON.stringify(board),
    nextPlayer,
    newStatus,
    newWinningCells ? JSON.stringify(newWinningCells) : 'none',
    redWins,
    yellowWins,
    draws,
    newRevision,
    game.id
  );

  const gameState = getGameState(account.id);
  const result = { game: gameState };

  cacheOperation(account.id, operationId, result);
  res.json(result);
});

app.post('/api/new-game', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const { operationId, expectedRevision } = req.body;

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  // Check operation cache
  if (operationId) {
    const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?').get(account.id, operationId);
    if (cached) {
      return res.json(JSON.parse(cached.result));
    }
  }

  const game = db.prepare('SELECT * FROM games WHERE account_id = ?').get(account.id);
  if (!game) {
    return res.status(404).json({ error: 'No game found' });
  }

  // Check revision
  if (expectedRevision !== undefined && expectedRevision !== game.revision) {
    const gameState = getGameState(account.id);
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      game: gameState
    });
  }

  const emptyBoard = Array(42).fill('');
  const newRevision = game.revision + 1;

  db.prepare(`
    UPDATE games SET 
      board = ?, 
      current_player = 'Red', 
      status = 'active',
      winning_cells = 'none',
      revision = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(
    JSON.stringify(emptyBoard),
    newRevision,
    game.id
  );

  // Clear moves and redo
  db.prepare('DELETE FROM moves WHERE game_id = ?').run(game.id);
  db.prepare('DELETE FROM redo_stack WHERE game_id = ?').run(game.id);

  const gameState = getGameState(account.id);
  const result = { game: gameState };

  cacheOperation(account.id, operationId, result);
  res.json(result);
});

app.get('/api/archive', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  const archives = db.prepare(`
    SELECT id, match_id, result, moves, completed_at FROM archives 
    WHERE account_id = ? 
    ORDER BY completed_at DESC 
    LIMIT 10
  `).all(account.id);

  const total = db.prepare('SELECT COUNT(*) as count FROM archives WHERE account_id = ?').get(account.id).count;

  res.json({
    total,
    archives: archives.map(a => ({
      id: a.id,
      match_id: a.match_id,
      result: a.result,
      move_count: JSON.parse(a.moves).length,
      completed_at: a.completed_at
    }))
  });
});

app.get('/api/archive/:id/replay', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const { id } = req.params;

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  const archive = db.prepare('SELECT * FROM archives WHERE id = ? AND account_id = ?').get(id, account.id);
  if (!archive) {
    return res.status(404).json({ error: 'Archive not found' });
  }

  res.json({
    match_id: archive.match_id,
    result: archive.result,
    board: JSON.parse(archive.board),
    moves: JSON.parse(archive.moves)
  });
});

function checkWin(board, color) {
  const directions = [
    { dx: 1, dy: 0 },   // horizontal
    { dx: 0, dy: 1 },   // vertical
    { dx: 1, dy: 1 },   // diagonal down-right
    { dx: 1, dy: -1 }   // diagonal down-left
  ];

  for (let i = 0; i < 42; i++) {
    if (board[i] !== color) continue;

    const row = Math.floor(i / 7);
    const col = i % 7;

    for (const dir of directions) {
      const cells = [i];
      
      // Check forward
      for (let j = 1; j < 4; j++) {
        const newRow = row + dir.dy * j;
        const newCol = col + dir.dx * j;
        if (newRow < 0 || newRow >= 6 || newCol < 0 || newCol >= 7) break;
        const idx = newRow * 7 + newCol;
        if (board[idx] !== color) break;
        cells.push(idx);
      }

      // Check backward
      for (let j = 1; j < 4; j++) {
        const newRow = row - dir.dy * j;
        const newCol = col - dir.dx * j;
        if (newRow < 0 || newRow >= 6 || newCol < 0 || newCol >= 7) break;
        const idx = newRow * 7 + newCol;
        if (board[idx] !== color) break;
        cells.push(idx);
      }

      if (cells.length >= 4) {
        return cells.slice(0, 4);
      }
    }
  }

  return null;
}

// Start server
initializeDatabase();
app.listen(PORT, '0.0.0.0', () => {
  console.log(`DropLine server running on port ${PORT}`);
});
