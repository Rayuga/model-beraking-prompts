class DropLineApp {
  constructor() {
    this.token = localStorage.getItem('dropline_token');
    this.account = null;
    this.game = null;
    this.pendingOperationId = null;
    this.isProcessing = false;

    this.initializeEventListeners();
    this.checkAuthStatus();
  }

  initializeEventListeners() {
    // Sign-in
    document.getElementById('signinForm').addEventListener('submit', (e) => this.handleSignIn(e));

    // Sign-out
    document.getElementById('signoutBtn').addEventListener('click', () => this.handleSignOut());

    // Column controls
    document.getElementById('columnControls').addEventListener('click', (e) => {
      if (e.target.classList.contains('column-btn')) {
        const column = parseInt(e.target.dataset.column);
        this.makeMove(column);
      }
    });

    // Keyboard navigation for columns
    document.getElementById('columnControls').addEventListener('keydown', (e) => {
      const buttons = Array.from(document.querySelectorAll('.column-btn'));
      const currentBtn = document.activeElement;
      const currentIndex = buttons.indexOf(currentBtn);

      if (e.key === 'ArrowLeft' && currentIndex > 0) {
        e.preventDefault();
        buttons[currentIndex - 1].focus();
      } else if (e.key === 'ArrowRight' && currentIndex < buttons.length - 1) {
        e.preventDefault();
        buttons[currentIndex + 1].focus();
      } else if (e.key === 'Home') {
        e.preventDefault();
        buttons[0].focus();
      } else if (e.key === 'End') {
        e.preventDefault();
        buttons[buttons.length - 1].focus();
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const column = parseInt(currentBtn.dataset.column);
        this.makeMove(column);
      }
    });

    // Game controls
    document.getElementById('undoBtn').addEventListener('click', () => this.undo());
    document.getElementById('redoBtn').addEventListener('click', () => this.redo());
    document.getElementById('newGameBtn').addEventListener('click', () => this.newGame());

    // Archive
    document.getElementById('archiveBtn').addEventListener('click', () => this.showArchive());
    document.getElementById('archiveCloseBtn').addEventListener('click', () => this.closeArchive());
    document.getElementById('replayCloseBtn').addEventListener('click', () => this.closeReplay());

    // Replay controls
    document.getElementById('replayPrevBtn').addEventListener('click', () => this.replayPrevious());
    document.getElementById('replayNextBtn').addEventListener('click', () => this.replayNext());
    document.getElementById('replayStepInput').addEventListener('change', (e) => this.replayToStep(parseInt(e.target.value)));
  }

  async checkAuthStatus() {
    if (this.token) {
      try {
        const response = await fetch('/api/game', {
          headers: { 'Authorization': `Bearer ${this.token}` }
        });

        if (response.ok) {
          this.game = await response.json();
          this.account = { email: 'Loading...', name: 'Loading...' };
          this.showGameScreen();
          await this.loadAccountInfo();
          this.renderGame();
        } else {
          this.logout();
        }
      } catch (error) {
        console.error('Auth check failed:', error);
        this.logout();
      }
    } else {
      this.showSignInScreen();
    }
  }

  async loadAccountInfo() {
    // Account info is returned with game state, but we need to fetch it separately
    // For now, we'll extract from localStorage or make a dedicated endpoint
    const accountInfo = localStorage.getItem('dropline_account');
    if (accountInfo) {
      this.account = JSON.parse(accountInfo);
      this.updateAccountDisplay();
    }
  }

  async handleSignIn(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('signinError');

    try {
      const response = await fetch('/api/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      if (response.ok) {
        const data = await response.json();
        this.token = data.token;
        this.account = data.account;
        this.game = data.game;

        localStorage.setItem('dropline_token', this.token);
        localStorage.setItem('dropline_account', JSON.stringify(this.account));

        errorDiv.classList.remove('show');
        this.showGameScreen();
        this.renderGame();
      } else {
        const error = await response.json();
        errorDiv.textContent = error.error || 'Invalid email or password';
        errorDiv.classList.add('show');
      }
    } catch (error) {
      console.error('Sign-in failed:', error);
      errorDiv.textContent = 'Sign-in failed. Please try again.';
      errorDiv.classList.add('show');
    }
  }

  async handleSignOut() {
    try {
      await fetch('/api/signout', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${this.token}` }
      });
    } catch (error) {
      console.error('Sign-out error:', error);
    }

    this.logout();
  }

  logout() {
    this.token = null;
    this.account = null;
    this.game = null;
    localStorage.removeItem('dropline_token');
    localStorage.removeItem('dropline_account');
    this.showSignInScreen();
  }

  showSignInScreen() {
    document.querySelector('.signin-screen').classList.add('active');
    document.querySelector('.game-screen').classList.remove('active');
    document.getElementById('email').focus();
  }

  showGameScreen() {
    document.querySelector('.signin-screen').classList.remove('active');
    document.querySelector('.game-screen').classList.add('active');
    this.updateAccountDisplay();
  }

  updateAccountDisplay() {
    if (this.account) {
      document.getElementById('accountName').textContent = this.account.name;
      document.getElementById('accountEmail').textContent = this.account.email;
    }
  }

  async makeMove(column) {
    if (this.isProcessing || !this.game || this.game.status !== 'active') return;

    this.isProcessing = true;
    const operationId = this.generateOperationId();
    const expectedRevision = this.game.revision;

    try {
      const response = await fetch('/api/move', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ column, operationId, expectedRevision })
      });

      if (response.ok) {
        const data = await response.json();
        this.game = data.game;
        this.clearFeedback();
        this.renderGame();
      } else if (response.status === 409) {
        const data = await response.json();
        this.game = data.game;
        document.getElementById('staleWarning').classList.add('show');
        setTimeout(() => {
          document.getElementById('staleWarning').classList.remove('show');
        }, 3000);
        this.renderGame();
      } else {
        const error = await response.json();
        this.showFeedback(error.error, 'error');
      }
    } catch (error) {
      console.error('Move failed:', error);
      this.showFeedback('Move failed. Please try again.', 'error');
    } finally {
      this.isProcessing = false;
    }
  }

  async undo() {
    if (this.isProcessing || !this.game) return;

    this.isProcessing = true;
    const operationId = this.generateOperationId();
    const expectedRevision = this.game.revision;

    try {
      const response = await fetch('/api/undo', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ operationId, expectedRevision })
      });

      if (response.ok) {
        const data = await response.json();
        this.game = data.game;
        this.clearFeedback();
        this.renderGame();
      } else if (response.status === 409) {
        const data = await response.json();
        this.game = data.game;
        document.getElementById('staleWarning').classList.add('show');
        setTimeout(() => {
          document.getElementById('staleWarning').classList.remove('show');
        }, 3000);
        this.renderGame();
      } else {
        const error = await response.json();
        this.showFeedback(error.error, 'error');
      }
    } catch (error) {
      console.error('Undo failed:', error);
      this.showFeedback('Undo failed. Please try again.', 'error');
    } finally {
      this.isProcessing = false;
    }
  }

  async redo() {
    if (this.isProcessing || !this.game) return;

    this.isProcessing = true;
    const operationId = this.generateOperationId();
    const expectedRevision = this.game.revision;

    try {
      const response = await fetch('/api/redo', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ operationId, expectedRevision })
      });

      if (response.ok) {
        const data = await response.json();
        this.game = data.game;
        this.clearFeedback();
        this.renderGame();
      } else if (response.status === 409) {
        const data = await response.json();
        this.game = data.game;
        document.getElementById('staleWarning').classList.add('show');
        setTimeout(() => {
          document.getElementById('staleWarning').classList.remove('show');
        }, 3000);
        this.renderGame();
      } else {
        const error = await response.json();
        this.showFeedback(error.error, 'error');
      }
    } catch (error) {
      console.error('Redo failed:', error);
      this.showFeedback('Redo failed. Please try again.', 'error');
    } finally {
      this.isProcessing = false;
    }
  }

  async newGame() {
    if (this.isProcessing || !this.game) return;

    this.isProcessing = true;
    const operationId = this.generateOperationId();
    const expectedRevision = this.game.revision;

    try {
      const response = await fetch('/api/new-game', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ operationId, expectedRevision })
      });

      if (response.ok) {
        const data = await response.json();
        this.game = data.game;
        this.clearFeedback();
        this.renderGame();
      } else if (response.status === 409) {
        const data = await response.json();
        this.game = data.game;
        document.getElementById('staleWarning').classList.add('show');
        setTimeout(() => {
          document.getElementById('staleWarning').classList.remove('show');
        }, 3000);
        this.renderGame();
      } else {
        const error = await response.json();
        this.showFeedback(error.error, 'error');
      }
    } catch (error) {
      console.error('New game failed:', error);
      this.showFeedback('New game failed. Please try again.', 'error');
    } finally {
      this.isProcessing = false;
    }
  }

  renderGame() {
    if (!this.game) return;

    // Update revision
    document.getElementById('revision').textContent = `Revision: ${this.game.revision}`;

    // Update turn display
    const turnDisplay = document.getElementById('turnDisplay');
    if (this.game.status === 'active') {
      turnDisplay.textContent = `${this.game.current_player}'s turn`;
      turnDisplay.className = `turn-display ${this.game.current_player.toLowerCase()}`;
    } else {
      if (this.game.winning_cells && this.game.winning_cells.length > 0) {
        turnDisplay.textContent = `${this.game.current_player === 'Red' ? 'Yellow' : 'Red'} wins`;
      } else {
        turnDisplay.textContent = 'Draw';
      }
      turnDisplay.className = 'turn-display';
    }

    // Render board
    this.renderBoard();

    // Update stats
    document.getElementById('redWins').textContent = this.game.red_wins;
    document.getElementById('yellowWins').textContent = this.game.yellow_wins;
    document.getElementById('draws').textContent = this.game.draws;

    // Update history
    this.renderHistory();

    // Update button states
    document.getElementById('undoBtn').disabled = this.game.applied_history.length === 0;
    document.getElementById('redoBtn').disabled = this.game.redo_history.length === 0;

    // Update column controls
    this.renderColumnControls();
  }

  renderBoard() {
    const boardEl = document.getElementById('board');
    boardEl.innerHTML = '';

    for (let i = 0; i < 42; i++) {
      const cell = document.createElement('div');
      cell.className = 'cell';
      cell.setAttribute('role', 'gridcell');

      const row = Math.floor(i / 7) + 1;
      const col = (i % 7) + 1;
      const piece = this.game.board[i];

      let ariaLabel = `Row ${row}, Column ${col}, `;
      if (piece === '') {
        ariaLabel += 'empty';
      } else {
        ariaLabel += piece;
        cell.classList.add(piece.toLowerCase());
      }

      if (this.game.winning_cells && this.game.winning_cells.includes(i)) {
        ariaLabel += ', winning';
        cell.classList.add('winning');
      }

      cell.setAttribute('aria-label', ariaLabel);
      boardEl.appendChild(cell);
    }
  }

  renderColumnControls() {
    const controlsEl = document.getElementById('columnControls');
    controlsEl.innerHTML = '';

    for (let col = 1; col <= 7; col++) {
      const btn = document.createElement('button');
      btn.className = 'column-btn';
      btn.textContent = `${col}`;
      btn.setAttribute('aria-label', `Drop in column ${col}`);
      btn.dataset.column = col;
      btn.disabled = this.game.status !== 'active';

      controlsEl.appendChild(btn);
    }
  }

  renderHistory() {
    const historyEl = document.getElementById('historyList');
    const history = this.game.applied_history;

    if (history.length === 0) {
      historyEl.innerHTML = '<div class="history-empty">No moves yet</div>';
      return;
    }

    historyEl.innerHTML = history.map((move, idx) => {
      const className = `history-item ${move.color.toLowerCase()}`;
      return `<div class="${className}">Move ${idx + 1}: ${move.color} → Column ${move.column}, Row ${move.row}</div>`;
    }).join('');
  }

  showFeedback(message, type = 'error') {
    const feedbackEl = document.getElementById('feedback');
    feedbackEl.textContent = message;
    feedbackEl.className = `feedback ${type === 'success' ? 'success' : ''}`;
  }

  clearFeedback() {
    const feedbackEl = document.getElementById('feedback');
    feedbackEl.textContent = '';
    feedbackEl.className = 'feedback';
  }

  async showArchive() {
    try {
      const response = await fetch('/api/archive', {
        headers: { 'Authorization': `Bearer ${this.token}` }
      });

      if (response.ok) {
        const data = await response.json();
        this.renderArchiveList(data);
        document.getElementById('archiveModal').classList.add('active');
      } else if (response.status === 401) {
        this.logout();
      }
    } catch (error) {
      console.error('Archive fetch failed:', error);
    }
  }

  renderArchiveList(data) {
    const contentEl = document.getElementById('archiveContent');
    const { total, archives } = data;

    if (archives.length === 0) {
      contentEl.innerHTML = '<div style="text-align: center; color: #6b7280;">No completed matches yet</div>';
      return;
    }

    contentEl.innerHTML = `
      <div style="font-size: 0.9rem; color: #6b7280; margin-bottom: 1rem;">Total matches: ${total}</div>
      <div class="archive-list">
        ${archives.map(archive => `
          <button class="archive-item" data-archive-id="${archive.id}">
            <div class="archive-result ${archive.result.includes('Red') ? 'red' : archive.result.includes('Yellow') ? 'yellow' : 'draw'}">
              ${archive.result}
            </div>
            <div class="archive-meta">
              ${archive.move_count} moves • ${new Date(archive.completed_at).toLocaleDateString()}
            </div>
          </button>
        `).join('')}
      </div>
    `;

    contentEl.querySelectorAll('.archive-item').forEach(item => {
      item.addEventListener('click', () => this.showReplay(parseInt(item.dataset.archiveId)));
    });
  }

  closeArchive() {
    document.getElementById('archiveModal').classList.remove('active');
  }

  async showReplay(archiveId) {
    try {
      const response = await fetch(`/api/archive/${archiveId}/replay`, {
        headers: { 'Authorization': `Bearer ${this.token}` }
      });

      if (response.ok) {
        const data = await response.json();
        this.currentReplay = {
          ...data,
          currentStep: 0
        };
        this.renderReplay();
        document.getElementById('archiveModal').classList.remove('active');
        document.getElementById('replayModal').classList.add('active');
      }
    } catch (error) {
      console.error('Replay fetch failed:', error);
    }
  }

  renderReplay() {
    if (!this.currentReplay) return;

    const { moves, currentStep, board: finalBoard } = this.currentReplay;
    const replayBoard = this.reconstructBoard(moves, currentStep);

    // Render board
    const boardEl = document.getElementById('replayBoard');
    boardEl.innerHTML = '';

    for (let i = 0; i < 42; i++) {
      const cell = document.createElement('div');
      cell.className = 'replay-cell';
      cell.setAttribute('role', 'gridcell');

      const row = Math.floor(i / 7) + 1;
      const col = (i % 7) + 1;
      const piece = replayBoard[i];

      let ariaLabel = `Row ${row}, Column ${col}, `;
      if (piece === '') {
        ariaLabel += 'empty';
      } else {
        ariaLabel += piece;
        cell.classList.add(piece.toLowerCase());
      }

      cell.setAttribute('aria-label', ariaLabel);
      boardEl.appendChild(cell);
    }

    // Update info
    const infoEl = document.getElementById('replayInfo');
    infoEl.textContent = `Step ${currentStep} of ${moves.length}`;

    // Update controls
    document.getElementById('replayStepInput').max = moves.length;
    document.getElementById('replayStepInput').value = currentStep;
    document.getElementById('replayPrevBtn').disabled = currentStep === 0;
    document.getElementById('replayNextBtn').disabled = currentStep === moves.length;
  }

  reconstructBoard(moves, upToStep) {
    const board = Array(42).fill('');
    for (let i = 0; i < upToStep; i++) {
      const move = moves[i];
      const col = move.column - 1;
      const row = move.row - 1;
      board[row * 7 + col] = move.color;
    }
    return board;
  }

  replayPrevious() {
    if (this.currentReplay && this.currentReplay.currentStep > 0) {
      this.currentReplay.currentStep--;
      this.renderReplay();
    }
  }

  replayNext() {
    if (this.currentReplay && this.currentReplay.currentStep < this.currentReplay.moves.length) {
      this.currentReplay.currentStep++;
      this.renderReplay();
    }
  }

  replayToStep(step) {
    if (this.currentReplay) {
      this.currentReplay.currentStep = step;
      this.renderReplay();
    }
  }

  closeReplay() {
    document.getElementById('replayModal').classList.remove('active');
    this.currentReplay = null;
  }

  generateOperationId() {
    return `op-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.app = new DropLineApp();
});
