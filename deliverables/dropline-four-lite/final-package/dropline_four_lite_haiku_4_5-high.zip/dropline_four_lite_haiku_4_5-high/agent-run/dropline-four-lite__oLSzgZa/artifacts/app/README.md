# DropLine - Connect Four Game

A polished, real-time Connect Four game for two players sharing one browser with persistent game state, authentication, and complete match history.

## Features

### Core Gameplay
- **7x6 Connect Four Board**: Standard game board with gravity-based piece placement
- **Two-Player Mode**: Red and Yellow players take turns
- **Win Detection**: Automatically detects horizontal, vertical, and diagonal wins
- **Draw Detection**: Recognizes when all 42 cells are filled without a winner
- **Match Totals**: Persistent tracking of wins and draws per player

### Authentication & Accounts
- **Real Sign-In**: Two demo accounts with persistent authentication
  - `avery@dropline.test` / `password123`
  - `jordan@dropline.test` / `password123`
- **Bearer Token Authentication**: Secure token-based API access
- **Token Revocation**: Sign-out revokes all active tokens for the account
- **Account Isolation**: Each account has completely separate game state and history

### Move History & Undo/Redo
- **Move History Display**: Shows all moves in chronological order with color, column, and row
- **Undo**: Removes the most recent move and returns the turn to that player
- **Redo**: Restores undone moves in sequence
- **Terminal Move Handling**: Undoing a winning or drawing move correctly reverses the score

### Concurrency & Safety
- **Revision Tracking**: Every mutation increments a server-side revision number
- **Stale Mutation Detection**: Rejects mutations with outdated revision numbers
- **Multi-Tab Safety**: Detects when another tab has modified the game state
- **Idempotency**: Duplicate operation IDs return the same result without side effects
- **Operation Caching**: Prevents duplicate moves from duplicate requests

### Match Archive & Replay
- **Automatic Archiving**: Completed matches are automatically archived
- **Archive List**: Shows the 10 most recent matches with result and move count
- **Read-Only Replay**: Step through any archived match move-by-move
- **Replay Controls**: Previous/Next buttons and range slider for navigation
- **Persistent Archive**: Survives new games, reloads, and sign-outs

### Accessibility & Responsive Design
- **ARIA Labels**: All board cells and controls have descriptive labels
- **Keyboard Navigation**: 
  - Arrow keys to move between column controls
  - Home/End to jump to first/last column
  - Enter/Space to drop a piece
- **Reduced Motion Support**: Respects `prefers-reduced-motion` preference
- **Mobile Responsive**: Fully functional at 375px width without horizontal scrolling
- **High Contrast**: Strong color contrast and clear visual hierarchy

## Technical Stack

- **Frontend**: Vanilla HTML, CSS, and JavaScript (no frameworks)
- **Backend**: Node.js with Express
- **Database**: SQLite with WAL mode for concurrent access
- **Authentication**: Bearer tokens stored in SQLite
- **Data Format**: JSON for all API responses

## Project Structure

```
/app/
├── server.js              # Express server with all API endpoints
├── public/
│   ├── index.html         # Single-page HTML with embedded CSS
│   └── app.js             # Client-side game logic and UI
├── dropline.db            # SQLite database (created on first run)
└── .gitignore             # Git ignore rules
```

## Running the Application

### Start the Server
```bash
node /app/server.js
```

The server will:
1. Listen on `0.0.0.0:3000`
2. Create `/app/dropline.db` if it doesn't exist
3. Seed the database with demo accounts and initial game states
4. Serve the UI from `/app/public/index.html`

### Access the Application
Open your browser to `http://localhost:3000`

## API Endpoints

### Authentication
- `POST /api/signin` - Sign in with email and password
- `POST /api/signout` - Sign out and revoke all tokens

### Game State
- `GET /api/game` - Get current game state
- `POST /api/move` - Make a move (column 1-7)
- `POST /api/undo` - Undo the last move
- `POST /api/redo` - Redo an undone move
- `POST /api/new-game` - Start a new game (preserves match totals)

### Archive & Replay
- `GET /api/archive` - Get list of completed matches (latest 10)
- `GET /api/archive/:id/replay` - Get full replay data for a match

### Health
- `GET /api/health` - Health check endpoint

## Database Schema

### Tables
- **accounts**: User credentials and profile
- **tokens**: Active bearer tokens for authentication
- **games**: Current game state per account
- **moves**: Applied moves in chronological order
- **redo_stack**: Undone moves available for redo
- **archives**: Completed matches with full move history
- **operation_cache**: Cached operation results for idempotency

## Seed Data

The application comes pre-seeded with:
- **2 Demo Accounts**: Avery Morgan and Jordan Lee
- **2 Active Games**: Each account has a mid-game state with different board positions
- **11 Completed Matches**: Jordan's account has a full archive of past games

All seed data is imported from `/assets/artifacts/dropline_seed.xlsx` on first database creation.

## Key Implementation Details

### Concurrency Handling
- Every mutation (move, undo, redo, new game) increments the revision number
- Clients send their expected revision with each mutation
- If revisions don't match, the server returns a 409 error with the current state
- Clients can retry with the updated state

### Idempotency
- Each mutation includes an `operationId` (unpredictable UUID-like string)
- The server caches the result of each operation
- Duplicate operation IDs return the cached result without side effects
- Prevents issues from network retries or multi-tab duplicate submissions

### Win Detection
- Checks all four directions (horizontal, vertical, two diagonals)
- For each piece, checks forward and backward along each direction
- Returns the first four-in-a-row found
- Marks winning cells for visual highlighting

### Move Validation
- Checks if column is within bounds (1-7)
- Finds the lowest empty cell in the column
- Rejects moves if the column is full
- Rejects moves if the game is already terminal (won or drawn)

## Testing

A comprehensive test suite is included that verifies:
1. Health check endpoint
2. Sign-in with correct and incorrect credentials
3. Game state retrieval
4. Move acceptance and revision increment
5. Undo and redo functionality
6. New game creation
7. Archive retrieval
8. Replay functionality
9. Sign-out and token revocation
10. Stale revision detection
11. Idempotency

Run tests with:
```bash
/tmp/test_dropline.sh
```

## Browser Compatibility

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

- Database queries use prepared statements for security and performance
- WAL mode enables concurrent reads while writes are in progress
- Operation caching prevents redundant database operations
- Minimal JavaScript bundle (no external dependencies)
- All assets served from same origin (no external CDN)

## Security

- Bearer tokens are cryptographically random (32 bytes)
- Tokens are stored in SQLite and validated on every request
- Account isolation prevents cross-account data access
- No user-supplied data is used in SQL queries (all parameterized)
- CORS not needed (same-origin only)
- No external dependencies or public-internet assets

## Future Enhancements

Potential features for future versions:
- Multiplayer with real-time updates via WebSocket
- User registration and password management
- Leaderboards and statistics
- Game invitations and notifications
- Replay sharing
- AI opponent
- Customizable board sizes
- Themes and visual customization
