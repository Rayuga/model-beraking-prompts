const express = require('express');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const XLSX = require('xlsx');

const app = express();
const PORT = 3000;
const DB_PATH = '/app/dropline.db';
const SEED_PATH = '/assets/artifacts/dropline_seed.xlsx';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database initialization
let db;

function initializeDatabase() {
  const dbExists = fs.existsSync(DB_PATH);
  db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');

  if (!dbExists) {
    // Create schema
    db.exec(`
      CREATE TABLE accounts (
        id INTEGER PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL
      );

      CREATE TABLE tokens (
        id INTEGER PRIMARY KEY,
        account_id INTEGER NOT NULL,
        token TEXT UNIQUE NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (account_id) REFERENCES accounts(id)
      );

      CREATE TABLE games (
        id INTEGER PRIMARY KEY,
        account_id INTEGER NOT NULL,
        round_id TEXT NOT NULL,
        board TEXT NOT NULL,
        current_player TEXT NOT NULL,
        status TEXT NOT NULL,
        winning_cells TEXT NOT NULL,
        red_wins INTEGER NOT NULL DEFAULT 0,
        yellow_wins INTEGER NOT NULL DEFAULT 0,
        draws INTEGER NOT NULL DEFAULT 0,
        revision INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (account_id) REFERENCES accounts(id),
        UNIQUE(account_id)
      );

      CREATE TABLE moves (
        id INTEGER PRIMARY KEY,
        game_id INTEGER NOT NULL,
        color TEXT NOT NULL,
        column_num INTEGER NOT NULL,
        row_num INTEGER NOT NULL,
        move_index INTEGER NOT NULL,
        FOREIGN KEY (game_id) REFERENCES games(id)
      );

      CREATE TABLE redo_stack (
        id INTEGER PRIMARY KEY,
        game_id INTEGER NOT NULL,
        color TEXT NOT NULL,
        column_num INTEGER NOT NULL,
        row_num INTEGER NOT NULL,
        move_index INTEGER NOT NULL,
        FOREIGN KEY (game_id) REFERENCES games(id)
      );

      CREATE TABLE operation_cache (
        id INTEGER PRIMARY KEY,
        account_id INTEGER NOT NULL,
        operation_id TEXT UNIQUE NOT NULL,
        result TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (account_id) REFERENCES accounts(id)
      );

      CREATE TABLE archives (
        id INTEGER PRIMARY KEY,
        account_id INTEGER NOT NULL,
        match_id TEXT NOT NULL,
        result TEXT NOT NULL,
        board TEXT NOT NULL,
        moves TEXT NOT NULL,
        completed_at TEXT NOT NULL,
        FOREIGN KEY (account_id) REFERENCES accounts(id)
      );

      CREATE INDEX idx_tokens_account ON tokens(account_id);
      CREATE INDEX idx_games_account ON games(account_id);
      CREATE INDEX idx_moves_game ON moves(game_id);
      CREATE INDEX idx_redo_game ON redo_stack(game_id);
      CREATE INDEX idx_archives_account ON archives(account_id);
    `);

    // Seed data
    seedDatabase();
  }
}

function seedDatabase() {
  try {
    const workbook = XLSX.readFile(SEED_PATH);
    
    // Seed accounts
    const accountsSheet = workbook.Sheets['Accounts'];
    const accountsData = XLSX.utils.sheet_to_json(accountsSheet);
    
    for (const account of accountsData) {
      db.prepare(`
        INSERT INTO accounts (email, password, name)
        VALUES (?, ?, ?)
      `).run(account.Email, account.Password, account.Name);
    }

    // Seed initial game states
    const gameStateSheet = workbook.Sheets['Initial Game State'];
    const gameStateData = XLSX.utils.sheet_to_json(gameStateSheet);
    
    for (const gameState of gameStateData) {
      const account = db.prepare('SELECT id FROM accounts WHERE email = ?').get(gameState['Account email']);
      if (!account) continue;

      const board = JSON.parse(gameState.Board);
      const appliedHistory = gameState['Applied history'] === 'none' ? [] : JSON.parse(gameState['Applied history']);
      const redoHistory = gameState['Redo history'] === 'none' ? [] : JSON.parse(gameState['Redo history']);

      const gameId = db.prepare(`
        INSERT INTO games (
          account_id, round_id, board, current_player, status, winning_cells,
          red_wins, yellow_wins, draws, revision
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        account.id,
        gameState['Round id'],
        JSON.stringify(board),
        gameState['Current player'],
        gameState.Status,
        gameState['Winning cells'] === 'none' ? '[]' : JSON.stringify([]),
        gameState['Red wins'],
        gameState['Yellow wins'],
        gameState.Draws,
        gameState.Revision
      ).lastInsertRowid;

      // Insert applied moves
      for (const move of appliedHistory) {
        db.prepare(`
          INSERT INTO moves (game_id, color, column_num, row_num, move_index)
          VALUES (?, ?, ?, ?, ?)
        `).run(gameId, move.color, move.column, move.row, move.index);
      }

      // Insert redo stack
      for (const move of redoHistory) {
        db.prepare(`
          INSERT INTO redo_stack (game_id, color, column_num, row_num, move_index)
          VALUES (?, ?, ?, ?, ?)
        `).run(gameId, move.color, move.column, move.row, move.index);
      }
    }

    // Seed completed matches
    const archiveSheet = workbook.Sheets['Completed Matches'];
    const archiveData = XLSX.utils.sheet_to_json(archiveSheet);
    
    for (const archive of archiveData) {
      const account = db.prepare('SELECT id FROM accounts WHERE email = ?').get(archive['Account email']);
      if (!account) continue;

      db.prepare(`
        INSERT INTO archives (account_id, match_id, result, board, moves, completed_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        account.id,
        archive['Match id'],
        archive.Result,
        JSON.stringify(JSON.parse(archive['Final board'])),
        archive.Moves,
        archive['Completed at']
      );
    }
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}

// Utility functions
function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

function getAccountFromToken(token) {
  const row = db.prepare(`
    SELECT a.id, a.email, a.name FROM tokens t
    JOIN accounts a ON t.account_id = a.id
    WHERE t.token = ?
  `).get(token);
  return row;
}

function getGameState(accountId) {
  const game = db.prepare(`
    SELECT * FROM games WHERE account_id = ?
  `).get(accountId);
  
  if (!game) return null;

  const moves = db.prepare(`
    SELECT color, column_num, row_num, move_index FROM moves
    WHERE game_id = ? ORDER BY move_index ASC
  `).all(game.id);

  const redoStack = db.prepare(`
    SELECT color, column_num, row_num, move_index FROM redo_stack
    WHERE game_id = ? ORDER BY move_index ASC
  `).all(game.id);

  return {
    id: game.id,
    roundId: game.round_id,
    board: JSON.parse(game.board),
    currentPlayer: game.current_player,
    status: game.status,
    winningCells: JSON.parse(game.winning_cells),
    redWins: game.red_wins,
    yellowWins: game.yellow_wins,
    draws: game.draws,
    revision: game.revision,
    appliedHistory: moves,
    redoStack: redoStack
  };
}

function detectWin(board) {
  const ROWS = 6, COLS = 7;
  const directions = [
    [0, 1],   // horizontal
    [1, 0],   // vertical
    [1, 1],   // diagonal down-right
    [1, -1]   // diagonal down-left
  ];

  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const cell = board[row * COLS + col];
      if (!cell) continue;

      for (const [dr, dc] of directions) {
        let count = 1;
        let cells = [row * COLS + col];

        for (let i = 1; i < 4; i++) {
          const nr = row + dr * i;
          const nc = col + dc * i;
          if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) break;
          if (board[nr * COLS + nc] !== cell) break;
          count++;
          cells.push(nr * COLS + nc);
        }

        if (count === 4) {
          return { winner: cell, cells };
        }
      }
    }
  }

  return null;
}

function isBoardFull(board) {
  return board.every(cell => cell !== '');
}

// Middleware
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const token = authHeader.slice(7);
  const account = getAccountFromToken(token);
  if (!account) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  req.account = account;
  req.token = token;
  next();
}

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/signin', (req, res) => {
  const { email, password } = req.body;

  const account = db.prepare('SELECT id, name, email FROM accounts WHERE email = ? AND password = ?')
    .get(email, password);

  if (!account) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const token = generateToken();
  db.prepare('INSERT INTO tokens (account_id, token, created_at) VALUES (?, ?, ?)')
    .run(account.id, token, new Date().toISOString());

  res.json({ token, account: { id: account.id, name: account.name, email: account.email } });
});

app.post('/api/signout', authMiddleware, (req, res) => {
  const accountId = req.account.id;
  db.prepare('DELETE FROM tokens WHERE account_id = ?').run(accountId);
  res.json({ success: true });
});

app.get('/api/game', authMiddleware, (req, res) => {
  const gameState = getGameState(req.account.id);
  
  if (!gameState) {
    // Create new game if doesn't exist
    const gameId = db.prepare(`
      INSERT INTO games (
        account_id, round_id, board, current_player, status, winning_cells,
        red_wins, yellow_wins, draws, revision
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      req.account.id,
      'game-' + Date.now(),
      JSON.stringify(Array(42).fill('')),
      'Red',
      'active',
      '[]',
      0, 0, 0, 0
    ).lastInsertRowid;

    const newGameState = getGameState(req.account.id);
    return res.json(newGameState);
  }

  res.json(gameState);
});

app.post('/api/move', authMiddleware, (req, res) => {
  const { column, expectedRevision, operationId } = req.body;

  // Check operation cache for idempotency
  const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?')
    .get(req.account.id, operationId);
  if (cached) {
    return res.json(JSON.parse(cached.result));
  }

  const gameState = getGameState(req.account.id);
  if (!gameState) {
    return res.status(400).json({ error: 'No active game' });
  }

  if (gameState.revision !== expectedRevision) {
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      gameState 
    });
  }

  if (gameState.status !== 'active') {
    return res.status(400).json({ error: 'Game is not active' });
  }

  const COLS = 7;
  const ROWS = 6;
  const board = gameState.board.slice();

  // Find lowest empty cell in column
  let row = -1;
  for (let r = ROWS - 1; r >= 0; r--) {
    if (board[r * COLS + (column - 1)] === '') {
      row = r;
      break;
    }
  }

  if (row === -1) {
    const result = { error: `Column ${column} is full` };
    db.prepare('INSERT INTO operation_cache (account_id, operation_id, result, created_at) VALUES (?, ?, ?, ?)')
      .run(req.account.id, operationId, JSON.stringify(result), new Date().toISOString());
    return res.status(400).json(result);
  }

  const cellIndex = row * COLS + (column - 1);
  board[cellIndex] = gameState.currentPlayer;

  // Check for win
  const win = detectWin(board);
  let newStatus = gameState.status;
  let winningCells = [];
  let redWins = gameState.redWins;
  let yellowWins = gameState.yellowWins;
  let draws = gameState.draws;

  if (win) {
    newStatus = 'terminal';
    winningCells = win.cells;
    if (win.winner === 'Red') {
      redWins++;
    } else {
      yellowWins++;
    }
  } else if (isBoardFull(board)) {
    newStatus = 'terminal';
    draws++;
  }

  const nextPlayer = gameState.currentPlayer === 'Red' ? 'Yellow' : 'Red';
  const newRevision = gameState.revision + 1;

  // Update game
  db.prepare(`
    UPDATE games SET
      board = ?, current_player = ?, status = ?, winning_cells = ?,
      red_wins = ?, yellow_wins = ?, draws = ?, revision = ?
    WHERE id = ?
  `).run(
    JSON.stringify(board),
    newStatus === 'terminal' ? gameState.currentPlayer : nextPlayer,
    newStatus,
    JSON.stringify(winningCells),
    redWins,
    yellowWins,
    draws,
    newRevision,
    gameState.id
  );

  // Add move to history
  const moveIndex = gameState.appliedHistory.length;
  db.prepare(`
    INSERT INTO moves (game_id, color, column_num, row_num, move_index)
    VALUES (?, ?, ?, ?, ?)
  `).run(gameState.id, gameState.currentPlayer, column, row + 1, moveIndex);

  // Clear redo stack
  db.prepare('DELETE FROM redo_stack WHERE game_id = ?').run(gameState.id);

  const updatedGameState = getGameState(req.account.id);
  const result = { success: true, gameState: updatedGameState };
  
  db.prepare('INSERT INTO operation_cache (account_id, operation_id, result, created_at) VALUES (?, ?, ?, ?)')
    .run(req.account.id, operationId, JSON.stringify(result), new Date().toISOString());

  res.json(result);
});

app.post('/api/undo', authMiddleware, (req, res) => {
  const { expectedRevision, operationId } = req.body;

  // Check operation cache for idempotency
  const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?')
    .get(req.account.id, operationId);
  if (cached) {
    return res.json(JSON.parse(cached.result));
  }

  const gameState = getGameState(req.account.id);
  if (!gameState) {
    return res.status(400).json({ error: 'No active game' });
  }

  if (gameState.revision !== expectedRevision) {
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      gameState 
    });
  }

  if (gameState.appliedHistory.length === 0) {
    return res.status(400).json({ error: 'No moves to undo' });
  }

  const lastMove = gameState.appliedHistory[gameState.appliedHistory.length - 1];
  const COLS = 7;
  const board = gameState.board.slice();
  const cellIndex = (lastMove.row_num - 1) * COLS + (lastMove.column_num - 1);
  board[cellIndex] = '';

  let redWins = gameState.redWins;
  let yellowWins = gameState.yellowWins;
  let draws = gameState.draws;
  let newStatus = 'active';

  // If we're undoing a terminal move, reverse the score
  if (gameState.status === 'terminal') {
    if (gameState.winningCells.length > 0) {
      if (lastMove.color === 'Red') {
        redWins--;
      } else {
        yellowWins--;
      }
    } else {
      draws--;
    }
  }

  const newRevision = gameState.revision + 1;

  // Update game
  db.prepare(`
    UPDATE games SET
      board = ?, current_player = ?, status = ?, winning_cells = ?,
      red_wins = ?, yellow_wins = ?, draws = ?, revision = ?
    WHERE id = ?
  `).run(
    JSON.stringify(board),
    lastMove.color,
    newStatus,
    '[]',
    redWins,
    yellowWins,
    draws,
    newRevision,
    gameState.id
  );

  // Remove last move from history
  db.prepare('DELETE FROM moves WHERE game_id = ? AND move_index = ?')
    .run(gameState.id, gameState.appliedHistory.length - 1);

  // Add to redo stack
  db.prepare(`
    INSERT INTO redo_stack (game_id, color, column_num, row_num, move_index)
    VALUES (?, ?, ?, ?, ?)
  `).run(gameState.id, lastMove.color, lastMove.column_num, lastMove.row_num, lastMove.move_index);

  const updatedGameState = getGameState(req.account.id);
  const result = { success: true, gameState: updatedGameState };
  
  db.prepare('INSERT INTO operation_cache (account_id, operation_id, result, created_at) VALUES (?, ?, ?, ?)')
    .run(req.account.id, operationId, JSON.stringify(result), new Date().toISOString());

  res.json(result);
});

app.post('/api/redo', authMiddleware, (req, res) => {
  const { expectedRevision, operationId } = req.body;

  // Check operation cache for idempotency
  const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?')
    .get(req.account.id, operationId);
  if (cached) {
    return res.json(JSON.parse(cached.result));
  }

  const gameState = getGameState(req.account.id);
  if (!gameState) {
    return res.status(400).json({ error: 'No active game' });
  }

  if (gameState.revision !== expectedRevision) {
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      gameState 
    });
  }

  if (gameState.redoStack.length === 0) {
    return res.status(400).json({ error: 'No moves to redo' });
  }

  const redoMove = gameState.redoStack[0];
  const COLS = 7;
  const board = gameState.board.slice();
  const cellIndex = (redoMove.row_num - 1) * COLS + (redoMove.column_num - 1);
  board[cellIndex] = redoMove.color;

  // Check for win
  const win = detectWin(board);
  let newStatus = 'active';
  let winningCells = [];
  let redWins = gameState.redWins;
  let yellowWins = gameState.yellowWins;
  let draws = gameState.draws;

  if (win) {
    newStatus = 'terminal';
    winningCells = win.cells;
    if (win.winner === 'Red') {
      redWins++;
    } else {
      yellowWins++;
    }
  } else if (isBoardFull(board)) {
    newStatus = 'terminal';
    draws++;
  }

  const nextPlayer = redoMove.color === 'Red' ? 'Yellow' : 'Red';
  const newRevision = gameState.revision + 1;

  // Update game
  db.prepare(`
    UPDATE games SET
      board = ?, current_player = ?, status = ?, winning_cells = ?,
      red_wins = ?, yellow_wins = ?, draws = ?, revision = ?
    WHERE id = ?
  `).run(
    JSON.stringify(board),
    newStatus === 'terminal' ? redoMove.color : nextPlayer,
    newStatus,
    JSON.stringify(winningCells),
    redWins,
    yellowWins,
    draws,
    newRevision,
    gameState.id
  );

  // Add move back to history
  const moveIndex = gameState.appliedHistory.length;
  db.prepare(`
    INSERT INTO moves (game_id, color, column_num, row_num, move_index)
    VALUES (?, ?, ?, ?, ?)
  `).run(gameState.id, redoMove.color, redoMove.column_num, redoMove.row_num, moveIndex);

  // Remove from redo stack
  db.prepare('DELETE FROM redo_stack WHERE game_id = ? AND move_index = ?')
    .run(gameState.id, redoMove.move_index);

  const updatedGameState = getGameState(req.account.id);
  const result = { success: true, gameState: updatedGameState };
  
  db.prepare('INSERT INTO operation_cache (account_id, operation_id, result, created_at) VALUES (?, ?, ?, ?)')
    .run(req.account.id, operationId, JSON.stringify(result), new Date().toISOString());

  res.json(result);
});

app.post('/api/new-game', authMiddleware, (req, res) => {
  const { expectedRevision, operationId } = req.body;

  // Check operation cache for idempotency
  const cached = db.prepare('SELECT result FROM operation_cache WHERE account_id = ? AND operation_id = ?')
    .get(req.account.id, operationId);
  if (cached) {
    return res.json(JSON.parse(cached.result));
  }

  const gameState = getGameState(req.account.id);
  if (!gameState) {
    return res.status(400).json({ error: 'No active game' });
  }

  if (gameState.revision !== expectedRevision) {
    return res.status(409).json({ 
      error: 'Game updated in another tab',
      gameState 
    });
  }

  // Archive the completed game if it's terminal
  if (gameState.status === 'terminal') {
    let result = '';
    if (gameState.winningCells.length > 0) {
      const winner = gameState.appliedHistory[gameState.appliedHistory.length - 1].color;
      result = winner === 'Red' ? 'Red wins' : 'Yellow wins';
    } else {
      result = 'Draw';
    }

    const moves = gameState.appliedHistory.map(m => ({
      color: m.color,
      column: m.column_num,
      row: m.row_num,
      index: m.move_index
    }));

    db.prepare(`
      INSERT INTO archives (account_id, match_id, result, board, moves, completed_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      req.account.id,
      gameState.roundId,
      result,
      JSON.stringify(gameState.board),
      JSON.stringify(moves),
      new Date().toISOString()
    );
  }

  const newRevision = gameState.revision + 1;
  const newRoundId = 'game-' + Date.now();

  // Update game
  db.prepare(`
    UPDATE games SET
      round_id = ?, board = ?, current_player = ?, status = ?, winning_cells = ?,
      revision = ?
    WHERE id = ?
  `).run(
    newRoundId,
    JSON.stringify(Array(42).fill('')),
    'Red',
    'active',
    '[]',
    newRevision,
    gameState.id
  );

  // Clear move history and redo stack
  db.prepare('DELETE FROM moves WHERE game_id = ?').run(gameState.id);
  db.prepare('DELETE FROM redo_stack WHERE game_id = ?').run(gameState.id);

  const updatedGameState = getGameState(req.account.id);
  const result = { success: true, gameState: updatedGameState };
  
  db.prepare('INSERT INTO operation_cache (account_id, operation_id, result, created_at) VALUES (?, ?, ?, ?)')
    .run(req.account.id, operationId, JSON.stringify(result), new Date().toISOString());

  res.json(result);
});

app.get('/api/archive', authMiddleware, (req, res) => {
  const archives = db.prepare(`
    SELECT id, match_id, result, completed_at FROM archives
    WHERE account_id = ?
    ORDER BY completed_at DESC
    LIMIT 10
  `).all(req.account.id);

  const total = db.prepare('SELECT COUNT(*) as count FROM archives WHERE account_id = ?')
    .get(req.account.id).count;

  res.json({ total, archives });
});

app.get('/api/archive/:id/replay', authMiddleware, (req, res) => {
  const archive = db.prepare(`
    SELECT board, moves FROM archives
    WHERE id = ? AND account_id = ?
  `).get(req.params.id, req.account.id);

  if (!archive) {
    return res.status(404).json({ error: 'Archive not found' });
  }

  const board = JSON.parse(archive.board);
  const moves = JSON.parse(archive.moves);

  res.json({ board, moves });
});

// Serve index.html for all other routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
initializeDatabase();
app.listen(PORT, '0.0.0.0', () => {
  console.log(`DropLine server running on http://0.0.0.0:${PORT}`);
});
