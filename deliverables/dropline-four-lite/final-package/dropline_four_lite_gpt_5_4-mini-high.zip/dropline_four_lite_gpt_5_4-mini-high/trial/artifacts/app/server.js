const express = require('express');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const xlsx = require('xlsx');
const path = require('path');

const app = express();
const db = new Database('/app/dropline.db');
const seedPath = '/assets/artifacts/dropline_seed.xlsx';
const PORT = 3000;

db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS game_state (user_id INTEGER PRIMARY KEY, board TEXT NOT NULL, current_player TEXT NOT NULL, status TEXT NOT NULL, winning_cells TEXT NOT NULL, red_wins INTEGER NOT NULL, yellow_wins INTEGER NOT NULL, draws INTEGER NOT NULL, applied_history TEXT NOT NULL, redo_history TEXT NOT NULL, revision INTEGER NOT NULL, round_id TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS completed_matches (id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, result TEXT NOT NULL, final_board TEXT NOT NULL, moves TEXT NOT NULL, completed_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS operations (op_id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, kind TEXT NOT NULL, request_revision INTEGER, result_json TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
`);

const hash = s => crypto.createHash('sha256').update(s).digest('hex');
const uid = () => crypto.randomBytes(18).toString('hex');
const now = () => new Date().toISOString();
const blankBoard = () => Array(42).fill('');
const pjson = (v, d) => { try { return v ? JSON.parse(v) : d; } catch { return d; } };
const idx = (r, c) => (r - 1) * 7 + (c - 1);
const cell = (board, r, c) => board[idx(r, c)];
const next = c => c === 'Red' ? 'Yellow' : 'Red';

function importSeed() {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c) return;
  const wb = xlsx.readFile(seedPath);
  const accounts = xlsx.utils.sheet_to_json(wb.Sheets['Accounts'], { defval: '' });
  const states = xlsx.utils.sheet_to_json(wb.Sheets['Initial Game State'], { defval: '' });
  const matches = xlsx.utils.sheet_to_json(wb.Sheets['Completed Matches'], { defval: '' });
  const insUser = db.prepare('INSERT INTO users (email,password_hash,name) VALUES (?,?,?)');
  const insState = db.prepare('INSERT INTO game_state (user_id,board,current_player,status,winning_cells,red_wins,yellow_wins,draws,applied_history,redo_history,revision,round_id,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
  const insMatch = db.prepare('INSERT INTO completed_matches (id,user_id,result,final_board,moves,completed_at) VALUES (?,?,?,?,?,?)');
  const ids = new Map();
  db.transaction(() => {
    for (const a of accounts) ids.set(a.Email, insUser.run(a.Email, hash(a.Password), a.Name).lastInsertRowid);
    for (const s of states) insState.run(ids.get(s['Account email']), s.Board, s['Current player'], s.Status, s['Winning cells'], s['Red wins'], s['Yellow wins'], s.Draws, s['Applied history'], s['Redo history'], s.Revision, s['Round id'], now());
    for (const m of matches) insMatch.run(m['Match id'], ids.get(m['Account email']), m.Result, m['Final board'], m.Moves, m['Completed at']);
  })();
}
importSeed();

app.use(express.json());
app.use(express.static(path.join('/app', 'public')));

const auth = (req, res, next) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const user = token && db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?').get(token);
  if (!user) return res.status(401).json({ error: 'Sign in required' });
  req.user = user; req.token = token; next();
};
const load = userId => {
  const r = db.prepare('SELECT * FROM game_state WHERE user_id=?').get(userId);
  return { ...r, board: pjson(r.board, blankBoard()), winning_cells: pjson(r.winning_cells, []), applied_history: pjson(r.applied_history, []), redo_history: pjson(r.redo_history, []) };
};
const save = (s) => db.prepare('UPDATE game_state SET board=?,current_player=?,status=?,winning_cells=?,red_wins=?,yellow_wins=?,draws=?,applied_history=?,redo_history=?,revision=?,round_id=?,updated_at=? WHERE user_id=?').run(JSON.stringify(s.board), s.current_player, s.status, JSON.stringify(s.winning_cells), s.red_wins, s.yellow_wins, s.draws, JSON.stringify(s.applied_history), JSON.stringify(s.redo_history), s.revision, s.round_id, now(), s.user_id);
function winCheck(board) { for (let r=1;r<=6;r++) for (let c=1;c<=7;c++) { const color = cell(board,r,c); if (!color) continue; for (const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]) { const pts=[[r,c]]; let ok=true; for (let k=1;k<4;k++){ const rr=r+dr*k, cc=c+dc*k; if(rr<1||rr>6||cc<1||cc>7||cell(board,rr,cc)!==color){ok=false;break;} pts.push([rr,cc]); } if (ok) return { winner: color, cells: pts.map(([rr,cc])=>idx(rr,cc)) }; } } if (board.every(Boolean)) return { draw: true }; return {}; }
function payload(user, s){ return { user:{email:user.email,name:user.name}, board:s.board, currentPlayer:s.current_player, status:s.status, winningCells:s.winning_cells, redWins:s.red_wins, yellowWins:s.yellow_wins, draws:s.draws, appliedHistory:s.applied_history, redoHistory:s.redo_history, revision:s.revision, roundId:s.round_id, currentTurnLabel:s.status==='active' ? `${s.current_player}'s turn` : s.status, archiveCount: db.prepare('SELECT COUNT(*) c FROM completed_matches WHERE user_id=?').get(user.id).c, latestMatches: db.prepare('SELECT * FROM completed_matches WHERE user_id=? ORDER BY completed_at DESC LIMIT 10').all(user.id) }; }
function finishRound(s, color){ s.status = color === 'Red' ? 'Red wins' : 'Yellow wins'; s.winning_cells = winCheck(s.board).cells; if (color === 'Red') s.red_wins++; else s.yellow_wins++; }

app.get('/api/health', (req,res)=>res.json({ok:true}));
app.post('/api/login', (req,res)=>{ const {email,password} = req.body || {}; const user = db.prepare('SELECT * FROM users WHERE email=?').get(email); if (!user || user.password_hash !== hash(password || '')) return res.status(401).json({ error: 'Incorrect email or password' }); const token=uid(); db.prepare('INSERT INTO sessions (token,user_id,created_at) VALUES (?,?,?)').run(token, user.id, now()); res.json({ token }); });
app.post('/api/logout', auth, (req,res)=>{ db.prepare('DELETE FROM sessions WHERE user_id=?').run(req.user.id); res.json({ ok:true }); });
app.get('/api/state', auth, (req,res)=>res.json(payload(req.user, load(req.user.id))));

app.post('/api/new-game', auth, (req,res)=>{ const { opId, revision } = req.body || {}; const s = load(req.user.id); if (Number(revision) !== s.revision) return res.status(409).json({ message:'Game updated in another tab', state: payload(req.user, s) }); const ex = db.prepare('SELECT result_json FROM operations WHERE op_id=? AND user_id=?').get(opId, req.user.id); if (ex) return res.json(JSON.parse(ex.result_json)); s.board=blankBoard(); s.current_player='Red'; s.status='active'; s.winning_cells=[]; s.applied_history=[]; s.redo_history=[]; s.round_id=uid(); s.revision++; save(s); const out = { state: payload(req.user, s) }; db.prepare('INSERT INTO operations (op_id,user_id,kind,request_revision,result_json,created_at) VALUES (?,?,?,?,?,?)').run(opId, req.user.id, 'new-game', revision, JSON.stringify(out), now()); res.json(out); });

app.post('/api/move', auth, (req,res)=>{ const { opId, revision, column } = req.body || {}; const s = load(req.user.id); if (Number(revision) !== s.revision) return res.status(409).json({ message:'Game updated in another tab', state: payload(req.user, s) }); const ex = db.prepare('SELECT result_json FROM operations WHERE op_id=? AND user_id=?').get(opId, req.user.id); if (ex) return res.json(JSON.parse(ex.result_json)); if (s.status !== 'active') return res.status(400).json({ error:s.status, state: payload(req.user, s) }); const col = Number(column); let row = 0; for (let r=6;r>=1;r--) if (!cell(s.board, r, col)) { row=r; break; } if (!row) return res.status(400).json({ error:`Column ${col} is full`, state: payload(req.user, s) }); const move = { color:s.current_player, column:col, row, index:idx(row,col) }; s.board[move.index] = move.color; s.applied_history.push(move); s.redo_history = []; const a = winCheck(s.board); if (a.winner) { finishRound(s, a.winner); s.winning_cells = a.cells; } else if (a.draw) { s.status='Draw'; s.winning_cells=[]; s.draws++; } else { s.current_player = next(s.current_player); s.winning_cells=[]; } s.revision++; save(s); if (s.status !== 'active') db.prepare('INSERT OR IGNORE INTO completed_matches (id,user_id,result,final_board,moves,completed_at) VALUES (?,?,?,?,?,?)').run(s.round_id, req.user.id, s.status, JSON.stringify(s.board), JSON.stringify(s.applied_history), now()); const out = { state: payload(req.user, s) }; db.prepare('INSERT INTO operations (op_id,user_id,kind,request_revision,result_json,created_at) VALUES (?,?,?,?,?,?)').run(opId, req.user.id, 'move', revision, JSON.stringify(out), now()); res.json(out); });

app.post('/api/undo', auth, (req,res)=>{ const { opId, revision } = req.body || {}; const s = load(req.user.id); if (Number(revision) !== s.revision) return res.status(409).json({ message:'Game updated in another tab', state: payload(req.user, s) }); const ex = db.prepare('SELECT result_json FROM operations WHERE op_id=? AND user_id=?').get(opId, req.user.id); if (ex) return res.json(JSON.parse(ex.result_json)); if (!s.applied_history.length) return res.status(400).json({ error:'Nothing to undo', state: payload(req.user, s) }); const m = s.applied_history.pop(); s.board[m.index]=''; s.redo_history.push(m); if (s.status === 'Red wins') s.red_wins--; else if (s.status === 'Yellow wins') s.yellow_wins--; else if (s.status === 'Draw') s.draws--; s.status = 'active'; s.winning_cells=[]; s.current_player = m.color; s.revision++; save(s); const out = { state: payload(req.user, s) }; db.prepare('INSERT INTO operations (op_id,user_id,kind,request_revision,result_json,created_at) VALUES (?,?,?,?,?,?)').run(opId, req.user.id, 'undo', revision, JSON.stringify(out), now()); res.json(out); });

app.post('/api/redo', auth, (req,res)=>{ const { opId, revision } = req.body || {}; const s = load(req.user.id); if (Number(revision) !== s.revision) return res.status(409).json({ message:'Game updated in another tab', state: payload(req.user, s) }); const ex = db.prepare('SELECT result_json FROM operations WHERE op_id=? AND user_id=?').get(opId, req.user.id); if (ex) return res.json(JSON.parse(ex.result_json)); if (!s.redo_history.length) return res.status(400).json({ error:'Nothing to redo', state: payload(req.user, s) }); const m = s.redo_history.pop(); if (s.board[m.index]) return res.status(400).json({ error:'Redo is no longer available', state: payload(req.user, s) }); s.board[m.index] = m.color; s.applied_history.push(m); const a = winCheck(s.board); if (a.winner) { finishRound(s, a.winner); s.winning_cells = a.cells; } else if (a.draw) { s.status='Draw'; s.winning_cells=[]; s.draws++; } else { s.status='active'; s.current_player = next(m.color); s.winning_cells=[]; } s.revision++; save(s); if (s.status !== 'active') db.prepare('INSERT OR IGNORE INTO completed_matches (id,user_id,result,final_board,moves,completed_at) VALUES (?,?,?,?,?,?)').run(s.round_id, req.user.id, s.status, JSON.stringify(s.board), JSON.stringify(s.applied_history), now()); const out = { state: payload(req.user, s) }; db.prepare('INSERT INTO operations (op_id,user_id,kind,request_revision,result_json,created_at) VALUES (?,?,?,?,?,?)').run(opId, req.user.id, 'redo', revision, JSON.stringify(out), now()); res.json(out); });

app.get('/api/archive', auth, (req,res)=>res.json({ total: db.prepare('SELECT COUNT(*) c FROM completed_matches WHERE user_id=?').get(req.user.id).c, matches: db.prepare('SELECT * FROM completed_matches WHERE user_id=? ORDER BY completed_at DESC LIMIT 10').all(req.user.id) }));
app.get('/api/archive/:id', auth, (req,res)=>{ const m = db.prepare('SELECT * FROM completed_matches WHERE id=? AND user_id=?').get(req.params.id, req.user.id); if (!m) return res.status(404).json({ error:'Not found' }); res.json(m); });
app.listen(PORT, '0.0.0.0', ()=>console.log('DropLine listening on', PORT));
