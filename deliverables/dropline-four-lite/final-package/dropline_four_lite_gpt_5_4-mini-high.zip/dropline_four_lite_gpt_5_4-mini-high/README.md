# DropLine Four Lite GPT-5.4-mini evidence

- Task: `turing/dropline-four-lite`
- Task version: `6.0.3`
- Task checksum: `c7400c4c34da652f7e4d050c40a063e4aa4fd4ffeacd3b6aa4ecd092d10aa528`
- Agent: OpenHands 0.62.0
- Model: `openrouter/openai/gpt-5.4-mini`, reasoning effort high
- Result: Render 1.0, Constraints 1.0, Functional 0.6316, Polish 0.4
- Final reward: `0.5390`
- Harbor status: graded 1, no-op 0, no exception; agent reached `FINISHED`

The run used the same exact v6.0.3 checksum as Oracle. All 22 criteria returned
non-empty reasoning and no judge-timeout or provider-disconnect warning. The
score is inside the required 0.1–0.7 target band.

