const express = require('express');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const xlsx = require('xlsx');

const app = express();
const dbPath = '/app/dropline.db';
const seedPath = '/assets/artifacts/dropline_seed.xlsx';
const publicDir = '/app/public';
const db = new Database(dbPath);

app.use(express.json());
app.use(express.static(publicDir));

const blankBoard = () => Array(42).fill('');
const nowIso = () => new Date().toISOString();
const opResult = (state, extra = {}) => ({ ok: true, state, ...extra });
const authHeader = (req) => (req.headers.authorization || '').match(/^Bearer (.+)$/)?.[1] || null;

function ensureSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS accounts (
      email TEXT PRIMARY KEY,
      password TEXT NOT NULL,
      name TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tokens (
      token TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      created_at TEXT NOT NULL,
      revoked INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS game_state (
      email TEXT PRIMARY KEY,
      board TEXT NOT NULL,
      current_player TEXT NOT NULL,
      status TEXT NOT NULL,
      winning_cells TEXT NOT NULL,
      red_wins INTEGER NOT NULL,
      yellow_wins INTEGER NOT NULL,
      draws INTEGER NOT NULL,
      applied_history TEXT NOT NULL,
      redo_history TEXT NOT NULL,
      revision INTEGER NOT NULL,
      round_id TEXT NOT NULL,
      feedback TEXT NOT NULL,
      completed_matches_count INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS completed_matches (
      match_id TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      result TEXT NOT NULL,
      final_board TEXT NOT NULL,
      moves TEXT NOT NULL,
      completed_at TEXT NOT NULL,
      revision INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS operations (
      op_id TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      type TEXT NOT NULL,
      result TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);
}

function seedIfNeeded() {
  const accountCount = db.prepare('SELECT COUNT(*) AS c FROM accounts').get().c;
  if (accountCount > 0) return;
  const wb = xlsx.readFile(seedPath);
  const accounts = xlsx.utils.sheet_to_json(wb.Sheets['Accounts'], { defval: '' });
  const states = xlsx.utils.sheet_to_json(wb.Sheets['Initial Game State'], { defval: '' });
  const matches = xlsx.utils.sheet_to_json(wb.Sheets['Completed Matches'], { defval: '' });
  const insertAccount = db.prepare('INSERT INTO accounts (email, password, name) VALUES (?, ?, ?)');
  const insertState = db.prepare(`INSERT INTO game_state (email, board, current_player, status, winning_cells, red_wins, yellow_wins, draws, applied_history, redo_history, revision, round_id, feedback, completed_matches_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  const insertMatch = db.prepare('INSERT INTO completed_matches (match_id, email, result, final_board, moves, completed_at, revision) VALUES (?, ?, ?, ?, ?, ?, ?)');
  const tx = db.transaction(() => {
    for (const a of accounts) insertAccount.run(a.Email, a.Password, a.Name);
    for (const s of states) insertState.run(s['Account email'], s.Board, s['Current player'], s.Status, s['Winning cells'], s['Red wins'], s['Yellow wins'], s.Draws, s['Applied history'], s['Redo history'], s.Revision, s['Round id'], s.Status === 'active' ? `${s['Current player']}'s turn` : s.Status === 'win' ? `${JSON.parse(s['Winning cells']).color} wins` : 'Draw', 0);
    for (const m of matches) insertMatch.run(m['Match id'], m['Account email'], m.Result, m['Final board'], m.Moves, m['Completed at'], 0);
    db.prepare('UPDATE game_state SET completed_matches_count = (SELECT COUNT(*) FROM completed_matches WHERE completed_matches.email = game_state.email)').run();
  });
  tx();
}

function parseState(row) {
  return {
    email: row.email,
    board: JSON.parse(row.board),
    currentPlayer: row.current_player,
    status: row.status,
    winningCells: row.winning_cells === 'none' ? [] : JSON.parse(row.winning_cells),
    redWins: row.red_wins,
    yellowWins: row.yellow_wins,
    draws: row.draws,
    appliedHistory: JSON.parse(row.applied_history),
    redoHistory: JSON.parse(row.redo_history),
    revision: row.revision,
    roundId: row.round_id,
    feedback: row.feedback,
    completedMatchesCount: row.completed_matches_count,
  };
}
function serializeState(s) {
  return {
    email: s.email,
    board: JSON.stringify(s.board),
    current_player: s.currentPlayer,
    status: s.status,
    winning_cells: s.winningCells.length ? JSON.stringify(s.winningCells) : 'none',
    red_wins: s.redWins,
    yellow_wins: s.yellowWins,
    draws: s.draws,
    applied_history: JSON.stringify(s.appliedHistory),
    redo_history: JSON.stringify(s.redoHistory),
    revision: s.revision,
    round_id: s.roundId,
    feedback: s.feedback,
    completed_matches_count: s.completedMatchesCount,
  };
}
function getState(email) { return parseState(db.prepare('SELECT * FROM game_state WHERE email = ?').get(email)); }
function saveState(s) { const r = serializeState(s); db.prepare(`UPDATE game_state SET board=@board,current_player=@current_player,status=@status,winning_cells=@winning_cells,red_wins=@red_wins,yellow_wins=@yellow_wins,draws=@draws,applied_history=@applied_history,redo_history=@redo_history,revision=@revision,round_id=@round_id,feedback=@feedback,completed_matches_count=@completed_matches_count WHERE email=@email`).run(r); }
function createState(email, preset) { return { email, board: JSON.parse(preset?.board || JSON.stringify(blankBoard())), currentPlayer: preset?.currentPlayer || 'Red', status: preset?.status || 'active', winningCells: preset?.winningCells || [], redWins: preset?.redWins ?? 0, yellowWins: preset?.yellowWins ?? 0, draws: preset?.draws ?? 0, appliedHistory: preset?.appliedHistory || [], redoHistory: preset?.redoHistory || [], revision: preset?.revision ?? 0, roundId: preset?.roundId || crypto.randomUUID(), feedback: preset?.feedback || "Red's turn", completedMatchesCount: preset?.completedMatchesCount || 0 }; }
function auth(req, res, next) { const token = authHeader(req); if (!token) return res.status(401).json({ error: 'Sign in required' }); const row = db.prepare('SELECT email, revoked FROM tokens WHERE token = ?').get(token); if (!row || row.revoked) return res.status(401).json({ error: 'Sign in required' }); const acct = db.prepare('SELECT * FROM accounts WHERE email = ?').get(row.email); if (!acct) return res.status(401).json({ error: 'Sign in required' }); req.account = acct; req.token = token; next(); }
function boardMatrix(board){ return Array.from({length:6}, (_,r)=> Array.from({length:7}, (_,c)=> board[r*7+c])); }
function winningCells(board, lastIndex, color){ const dirs=[[1,0],[0,1],[1,1],[1,-1]]; const row=Math.floor(lastIndex/7), col=lastIndex%7; for(const [dr,dc] of dirs){ let cells=[lastIndex]; for(const s of [-1,1]){ let rr=row,cc=col; while(true){ rr+=dr*s; cc+=dc*s; if(rr<0||rr>5||cc<0||cc>6||board[rr*7+cc]!==color) break; cells.push(rr*7+cc); } } if(cells.length>=4){ cells.sort((a,b)=>a-b); return cells.slice(0,4); } } return []; }
function deriveFeedback(state){ if(state.status==='win') return `${state.winningCellsColor} wins`; if(state.status==='draw') return 'Draw'; return `${state.currentPlayer}'s turn`; }
function stateDTO(state){ return { account:{email:state.email,name:db.prepare('SELECT name FROM accounts WHERE email=?').get(state.email).name}, board:state.board, currentPlayer:state.currentPlayer, status:state.status, winningCells:state.winningCells, redWins:state.redWins, yellowWins:state.yellowWins, draws:state.draws, appliedHistory:state.appliedHistory, redoHistory:state.redoHistory, revision:state.revision, roundId:state.roundId, feedback:state.feedback, completedMatchesCount:state.completedMatchesCount, archiveCount: db.prepare('SELECT COUNT(*) c FROM completed_matches WHERE email=?').get(state.email).c } }
function completedMatches(email){ return db.prepare('SELECT * FROM completed_matches WHERE email = ? ORDER BY completed_at DESC LIMIT 10').all(email).map(m=>({matchId:m.match_id,result:m.result,moveCount:JSON.parse(m.moves).length,completedAt:m.completed_at,revision:m.revision})); }
function terminalArchive(state){ const result = state.status==='win' ? `${state.winningCellsColor} wins` : 'Draw'; const op = `archive-${state.roundId}`; if(db.prepare('SELECT 1 FROM completed_matches WHERE match_id=?').get(op)) return; db.prepare('INSERT INTO completed_matches (match_id,email,result,final_board,moves,completed_at,revision) VALUES (?,?,?,?,?,?,?)').run(op,state.email,result,JSON.stringify(state.board),JSON.stringify(state.appliedHistory),nowIso(),state.revision); state.completedMatchesCount++; }

ensureSchema(); seedIfNeeded();

app.get('/api/health', (_req,res)=>res.json({ok:true}));
app.post('/api/signin', (req,res)=>{ const {email,password}=req.body||{}; const acct=db.prepare('SELECT * FROM accounts WHERE email=? AND password=?').get(email,password); if(!acct) return res.status(401).json({error:'Incorrect email or password'}); const token=crypto.randomBytes(24).toString('hex'); db.prepare('INSERT INTO tokens (token,email,created_at,revoked) VALUES (?,?,?,0)').run(token,email,nowIso()); const state=getState(email); res.json({token,account:{email:acct.email,name:acct.name},state:stateDTO(state),archive:completedMatches(email)}); });
app.post('/api/signout', auth, (req,res)=>{ db.prepare('UPDATE tokens SET revoked=1 WHERE email=?').run(req.account.email); res.json({ok:true}); });
app.get('/api/state', auth, (req,res)=>res.json({account:{email:req.account.email,name:req.account.name},state:stateDTO(getState(req.account.email)),archive:completedMatches(req.account.email)}));
app.post('/api/move', auth, (req,res)=>mutate(req,res,'move'));
app.post('/api/undo', auth, (req,res)=>mutate(req,res,'undo'));
app.post('/api/redo', auth, (req,res)=>mutate(req,res,'redo'));
app.post('/api/new-game', auth, (req,res)=>mutate(req,res,'new-game'));
app.get('/api/archive', auth, (req,res)=>res.json({archive:completedMatches(req.account.email), total: db.prepare('SELECT COUNT(*) c FROM completed_matches WHERE email=?').get(req.account.email).c}));
app.get('/api/archive/:id', auth, (req,res)=>{ const m=db.prepare('SELECT * FROM completed_matches WHERE match_id=? AND email=?').get(req.params.id, req.account.email); if(!m) return res.status(404).json({error:'Not found'}); res.json({matchId:m.match_id,result:m.result,finalBoard:JSON.parse(m.final_board),moves:JSON.parse(m.moves),completedAt:m.completed_at}); });
app.use(express.static(publicDir));
function mutate(req,res,type){ const opId=req.body?.operationId||crypto.randomUUID(); const expected=req.body?.expectedRevision; const existing=db.prepare('SELECT result FROM operations WHERE op_id=?').get(opId); if(existing) return res.json(JSON.parse(existing.result)); const state=getState(req.account.email); if(expected!==undefined && expected!==state.revision) return res.status(409).json({error:'Game updated in another tab',state:stateDTO(state)}); let result; if(type==='move') result=doMove(state,req.body?.column,opId); else if(type==='undo') result=doUndo(state,opId); else if(type==='redo') result=doRedo(state,opId); else result=doNewGame(state,opId); db.prepare('INSERT INTO operations (op_id,email,type,result,created_at) VALUES (?,?,?,?,?)').run(opId,req.account.email,type,JSON.stringify(result),nowIso()); res.json(result); }
function doMove(state,column,opId){ const c=Number(column); if(!(c>=1&&c<=7)) return {ok:false,error:'Invalid column',state:stateDTO(state)}; if(state.status!=='active') return {ok:false,error:'Game over',state:stateDTO(state)}; if(state.redoHistory.length) state.redoHistory=[]; const col=c-1; let row=-1; for(let r=5;r>=0;r--) if(state.board[r*7+col]===''){ row=r; break; } if(row<0){ state.feedback=`Column ${c} is full`; return finalize(state,false); } const color=state.currentPlayer; state.board[row*7+col]=color; const move={color,column:c,row:row+1,index:row*7+col}; state.appliedHistory.push(move); const win=winningCells(state.board,row*7+col,color); if(win.length===4){ state.status='win'; state.winningCells=win; state.winningCellsColor=color; if(color==='Red') state.redWins++; else state.yellowWins++; state.feedback=`${color} wins`; terminalArchive(state); } else if(state.board.every(Boolean)){ state.status='draw'; state.winningCells=[]; state.feedback='Draw'; state.draws++; terminalArchive(state); } else { state.currentPlayer = color==='Red' ? 'Yellow' : 'Red'; state.feedback=`${state.currentPlayer}'s turn`; } state.revision++; saveState(state); return {ok:true,state:stateDTO(state),operationId:opId}; }
function doUndo(state,opId){ if(!state.appliedHistory.length) return finalize(state,true); const last=state.appliedHistory.pop(); state.board[(last.row-1)*7 + (last.column-1)]=''; state.redoHistory.push(last); if(state.status==='win' || state.status==='draw'){ if(state.status==='win'){ if(last.color==='Red') state.redWins--; else state.yellowWins--; const matchId=`archive-${state.roundId}`; db.prepare('DELETE FROM completed_matches WHERE match_id=? AND email=?').run(matchId,state.email); state.completedMatchesCount=Math.max(0,state.completedMatchesCount-1); } else if(state.status==='draw') state.draws--; state.status='active'; state.winningCells=[]; }
 state.currentPlayer=last.color; state.feedback=`${last.color}'s turn`; state.revision++; saveState(state); return {ok:true,state:stateDTO(state),operationId:opId}; }
function doRedo(state,opId){ if(!state.redoHistory.length) return finalize(state,true); const move=state.redoHistory.pop(); const idx=(move.row-1)*7+(move.column-1); state.board[idx]=move.color; state.appliedHistory.push(move); const win=winningCells(state.board,idx,move.color); if(win.length===4){ state.status='win'; state.winningCells=win; state.winningCellsColor=move.color; if(move.color==='Red') state.redWins++; else state.yellowWins++; state.feedback=`${move.color} wins`; terminalArchive(state); } else if(state.board.every(Boolean)){ state.status='draw'; state.winningCells=[]; state.draws++; state.feedback='Draw'; terminalArchive(state); } else { state.status='active'; state.currentPlayer=move.color==='Red'?'Yellow':'Red'; state.feedback=`${state.currentPlayer}'s turn`; } state.revision++; saveState(state); return {ok:true,state:stateDTO(state),operationId:opId}; }
function doNewGame(state,opId){ state.board=blankBoard(); state.currentPlayer='Red'; state.status='active'; state.winningCells=[]; state.feedback="Red's turn"; state.appliedHistory=[]; state.redoHistory=[]; state.roundId=crypto.randomUUID(); state.revision++; saveState(state); return {ok:true,state:stateDTO(state),operationId:opId}; }
function finalize(state,unchanged){ saveState(state); return {ok:true,state:stateDTO(state)}; }
app.get(/.*/, (_req,res)=>res.sendFile(path.join(publicDir,'index.html')));
app.listen(3000,'0.0.0.0');
