# DropLine, in raw HTML/CSS/JS

Build a polished local two-player Connect Four game using raw HTML, CSS, and
JavaScript. Use a standard seven-column, six-row board with gravity, alternating
Red and Yellow turns, horizontal/vertical/diagonal win detection, draw handling,
and a clear way to start a new game.

Make the game comfortable to use with pointer and keyboard controls. Clearly
show whose turn it is, the result of a finished game, full-column feedback, and
the four winning pieces. Keep the complete game visible and usable on both
desktop and narrow mobile screens.

Represent the board as an accessible grid of 42 cells whose names identify row,
column, and current state. Provide seven buttons named `Drop in column 1`
through `Drop in column 7`, and a `New game` button. Use `Red's turn` and
`Yellow's turn` while playing, `Red wins` or `Yellow wins` for a win, `Draw`
for a draw, and `Column N is full` when a full column is attempted. Include
`winning` in the accessible names of the four winning cells.

Do not use JavaScript libraries or external assets. Write the complete app to
`/app/index.html` as one self-contained file.
