#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from playwright.sync_api import Browser, Page, sync_playwright


APP_FILE = Path(os.environ.get("APP_FILE", "/app/index.html")).resolve()
LOG_DIR = Path(os.environ.get("VERIFIER_LOG_DIR", "/logs/verifier"))
CHROMIUM_BIN = os.environ.get("CHROMIUM_BIN")

SEQUENCES = {
    "horizontal": [1, 7, 2, 7, 3, 6, 4],
    "vertical": [1, 2, 1, 2, 1, 2, 1],
    "rising diagonal": [1, 2, 2, 3, 4, 3, 3, 4, 5, 4, 4],
    "falling diagonal": [7, 6, 6, 5, 4, 5, 5, 4, 3, 4, 4],
    "draw": [
        4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 5, 2, 5, 6, 5, 5,
        5, 5, 2, 2, 2, 2, 2, 6, 1, 6, 6, 6, 6, 1, 1, 1, 1, 1,
        7, 7, 7, 7, 7, 7,
    ],
}


@dataclass
class CheckResult:
    name: str
    status: str
    duration_ms: int
    message: str = ""


def fresh_page(browser: Browser, width: int = 1280, height: int = 900):
    context = browser.new_context(viewport={"width": width, "height": height})
    attempted_external: list[str] = []
    runtime_errors: list[str] = []

    def route_request(route):
        url = route.request.url
        if url.startswith(("file:", "data:", "blob:", "about:")):
            route.continue_()
        else:
            attempted_external.append(url)
            route.abort()

    context.route("**/*", route_request)
    page = context.new_page()
    page.on("pageerror", lambda error: runtime_errors.append(str(error)))
    page.on(
        "console",
        lambda message: runtime_errors.append(message.text) if message.type == "error" else None,
    )
    page.goto(APP_FILE.as_uri(), wait_until="load", timeout=20_000)
    page.wait_for_timeout(100)
    return context, page, attempted_external, runtime_errors


def column_button(page: Page, column: int):
    return page.get_by_role("button", name=re.compile(rf"drop\s+in\s+column\s+{column}\b", re.I))


def action_button(page: Page, name: str):
    return page.get_by_role("button", name=re.compile(rf"^{re.escape(name)}$", re.I))


def cell_state(page: Page, row: int, column: int) -> str:
    cell = page.get_by_role("gridcell").nth((row - 1) * 7 + column - 1)
    label = (cell.get_attribute("aria-label") or "").lower()
    for state in ("red", "yellow", "empty"):
        if state in label:
            return state
    raise AssertionError(f"cell {row},{column} has no readable state: {label!r}")


def board_state(page: Page) -> list[str]:
    return [cell_state(page, row, col) for row in range(1, 7) for col in range(1, 8)]


def click_moves(page: Page, sequence: list[int]) -> None:
    for column in sequence:
        column_button(page, column).click()


def body_text(page: Page) -> str:
    return page.locator("body").inner_text()


def check_single_file_and_bootstrap(browser: Browser) -> None:
    assert APP_FILE.is_file(), "/app/index.html is missing"
    source = APP_FILE.read_text(encoding="utf-8")
    assert len(source) >= 1000, "index.html is unexpectedly empty"
    context, page, external, errors = fresh_page(browser)
    try:
        assert "DropLine" in page.title()
        assert page.get_by_role("heading", name="DropLine").count() == 1
        scripts = page.locator("script").evaluate_all(
            "els => els.map(el => ({src: el.getAttribute('src'), text: el.textContent.length}))"
        )
        styles = page.locator("style, link[rel=stylesheet]").evaluate_all(
            "els => els.map(el => ({tag: el.tagName.toLowerCase(), text: el.textContent.length}))"
        )
        assert scripts and all(not item["src"] and item["text"] > 0 for item in scripts)
        assert styles and all(item["tag"] == "style" and item["text"] > 0 for item in styles)
        assert external == [], f"external resources attempted: {external}"
        assert errors == [], f"page errors: {errors}"
    finally:
        context.close()


def check_initial_board_and_controls(browser: Browser) -> None:
    context, page, _, _ = fresh_page(browser)
    try:
        assert page.get_by_role("grid", name=re.compile("connect four board", re.I)).count() == 1
        assert page.get_by_role("gridcell").count() == 42
        assert all(state == "empty" for state in board_state(page))
        assert all(column_button(page, col).is_visible() for col in range(1, 8))
        assert re.search(r"Red(?:'s)?\s+turn", body_text(page), re.I)
        assert action_button(page, "New game").is_visible()
    finally:
        context.close()


def check_gravity_turns_and_full_column(browser: Browser) -> None:
    context, page, _, _ = fresh_page(browser)
    try:
        click_moves(page, [4, 4, 4])
        assert [cell_state(page, row, 4) for row in (6, 5, 4, 3)] == ["red", "yellow", "red", "empty"]
        assert re.search(r"Yellow(?:'s)?\s+turn", body_text(page), re.I)
        action_button(page, "New game").click()
        click_moves(page, [1, 1, 1, 1, 1, 1])
        before = board_state(page)
        column_button(page, 1).click()
        assert board_state(page) == before
        assert re.search(r"column\s+1\s+is\s+full", body_text(page), re.I)
        assert re.search(r"Red(?:'s)?\s+turn", body_text(page), re.I)
    finally:
        context.close()


def check_all_win_directions(browser: Browser) -> None:
    for direction in ("horizontal", "vertical", "rising diagonal", "falling diagonal"):
        context, page, _, _ = fresh_page(browser)
        try:
            click_moves(page, SEQUENCES[direction])
            assert re.search(r"Red\s+wins", body_text(page), re.I), f"{direction} win missing"
            winning = page.get_by_role("gridcell").evaluate_all(
                "cells => cells.filter(cell => /winning/i.test(cell.getAttribute('aria-label') || '')).length"
            )
            assert winning == 4, f"{direction} should mark exactly four winning cells"
            assert all(column_button(page, col).is_disabled() for col in range(1, 8))
        finally:
            context.close()


def check_terminal_lock(browser: Browser) -> None:
    context, page, _, _ = fresh_page(browser)
    try:
        click_moves(page, SEQUENCES["horizontal"])
        before = board_state(page)
        page.evaluate("document.querySelector('.column-control').click()")
        assert board_state(page) == before
        assert re.search(r"Red\s+wins", body_text(page), re.I)
    finally:
        context.close()


def check_exact_draw(browser: Browser) -> None:
    context, page, _, _ = fresh_page(browser)
    try:
        click_moves(page, SEQUENCES["draw"])
        assert "empty" not in board_state(page)
        assert re.search(r"\bdraw\b", body_text(page), re.I)
        assert page.get_by_role("gridcell").evaluate_all(
            "cells => cells.filter(cell => /winning/i.test(cell.getAttribute('aria-label') || '')).length"
        ) == 0
        assert all(column_button(page, col).is_disabled() for col in range(1, 8))
    finally:
        context.close()


def check_new_game_reset(browser: Browser) -> None:
    context, page, _, _ = fresh_page(browser)
    try:
        click_moves(page, SEQUENCES["vertical"])
        action_button(page, "New game").click()
        assert all(state == "empty" for state in board_state(page))
        assert re.search(r"Red(?:'s)?\s+turn", body_text(page), re.I)
        assert all(column_button(page, col).is_enabled() for col in range(1, 8))
    finally:
        context.close()


def check_keyboard_play(browser: Browser) -> None:
    context, page, _, _ = fresh_page(browser)
    try:
        first = column_button(page, 1)
        first.focus()
        page.keyboard.press("ArrowRight")
        assert column_button(page, 2).evaluate("el => el === document.activeElement")
        page.keyboard.press("End")
        assert column_button(page, 7).evaluate("el => el === document.activeElement")
        page.keyboard.press("Home")
        assert column_button(page, 1).evaluate("el => el === document.activeElement")
        page.keyboard.press("ArrowRight")
        page.keyboard.press("Enter")
        assert cell_state(page, 6, 2) == "red"
        page.keyboard.press("Space")
        assert cell_state(page, 5, 2) == "yellow"
    finally:
        context.close()


def check_responsive_layout(browser: Browser) -> None:
    context, page, _, _ = fresh_page(browser, width=375, height=760)
    try:
        geometry = page.evaluate(
            """() => {
              const board = document.querySelector('[role=grid]').getBoundingClientRect();
              const buttons = [...document.querySelectorAll('.column-control')];
              return {
                scrollWidth: document.documentElement.scrollWidth,
                innerWidth: window.innerWidth,
                boardLeft: board.left,
                boardRight: board.right,
                boardVisible: board.width > 250 && board.height > 200,
                controlsVisible: buttons.length === 7 && buttons.every(b => {
                  const r = b.getBoundingClientRect();
                  return r.width > 20 && r.height > 25;
                })
              };
            }"""
        )
        assert geometry["scrollWidth"] <= geometry["innerWidth"] + 1
        assert geometry["boardLeft"] >= -1 and geometry["boardRight"] <= 376
        assert geometry["boardVisible"] and geometry["controlsVisible"]
        assert action_button(page, "New game").is_visible()
    finally:
        context.close()


CHECKS: list[tuple[str, Callable[[Browser], None]]] = [
    ("single_self_contained_file", check_single_file_and_bootstrap),
    ("initial_board_and_controls", check_initial_board_and_controls),
    ("gravity_turns_and_full_column", check_gravity_turns_and_full_column),
    ("all_four_win_directions", check_all_win_directions),
    ("terminal_move_lock", check_terminal_lock),
    ("exact_full_board_draw", check_exact_draw),
    ("new_game_reset", check_new_game_reset),
    ("keyboard_navigation_and_drop", check_keyboard_play),
    ("responsive_375px_layout", check_responsive_layout),
]


def execute_check(name: str, check: Callable[[Browser], None], browser: Browser) -> CheckResult:
    started = time.monotonic()
    try:
        check(browser)
        return CheckResult(name, "passed", int((time.monotonic() - started) * 1000))
    except Exception as exc:
        return CheckResult(name, "failed", int((time.monotonic() - started) * 1000), str(exc))


def write_results(results: list[CheckResult], preflight: bool) -> float:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    passed = sum(result.status == "passed" for result in results)
    failed = len(results) - passed
    reward = 1.0 if preflight and failed == 0 and len(results) == len(CHECKS) else 0.0
    diagnostic = round(passed / len(CHECKS), 4) if CHECKS else 0.0
    rewards = {
        "reward": reward,
        "diagnostic_score": diagnostic,
        "preflight_passed": int(preflight),
        "checks_passed": passed,
        "checks_failed": failed,
    }
    report = {
        **rewards,
        "checks": [asdict(result) for result in results],
    }
    ctrf = {
        "results": {
            "tool": {"name": "dropline-lite-playwright", "version": "1.0.0"},
            "summary": {
                "tests": len(results), "passed": passed, "failed": failed,
                "pending": 0, "skipped": 0, "other": 0,
            },
            "tests": [
                {
                    "name": result.name,
                    "status": result.status,
                    "duration": result.duration_ms,
                    **({"message": result.message} if result.message else {}),
                }
                for result in results
            ],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    }
    (LOG_DIR / "reward.txt").write_text(f"{reward:.1f}\n", encoding="utf-8")
    (LOG_DIR / "reward.json").write_text(json.dumps(rewards, indent=2), encoding="utf-8")
    (LOG_DIR / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (LOG_DIR / "ctrf.json").write_text(json.dumps(ctrf, indent=2), encoding="utf-8")
    return reward


def main() -> int:
    preflight = APP_FILE.is_file()
    if not preflight:
        result = CheckResult("deliverable_preflight", "failed", 0, "/app/index.html is missing")
        write_results([result], False)
        return 1

    results: list[CheckResult] = []
    with sync_playwright() as playwright:
        launch_options = {"args": ["--allow-file-access-from-files"]}
        if CHROMIUM_BIN:
            launch_options["executable_path"] = CHROMIUM_BIN
        browser = playwright.chromium.launch(**launch_options)
        try:
            for name, check in CHECKS:
                result = execute_check(name, check, browser)
                results.append(result)
                print(f"{result.status.upper():6} {name}: {result.message}")
        finally:
            browser.close()

    reward = write_results(results, True)
    print(json.dumps({"reward": reward, "passed": sum(r.status == "passed" for r in results), "failed": sum(r.status == "failed" for r in results)}))
    return 0 if reward == 1.0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
