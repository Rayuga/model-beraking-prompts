#!/usr/bin/env bash
set -uo pipefail
python3 /tests/test.py
status=$?
log_dir="${VERIFIER_LOG_DIR:-/logs/verifier}"
if [[ ! -f "$log_dir/reward.txt" ]]; then
  mkdir -p "$log_dir"
  printf '0.0\n' > "$log_dir/reward.txt"
  printf '{"reward":0.0,"checks_passed":0,"checks_failed":1}\n' > "$log_dir/reward.json"
  printf '{"results":{"tool":{"name":"dropline-lite-playwright","version":"1.0.0"},"summary":{"tests":1,"passed":0,"failed":1,"pending":0,"skipped":0,"other":0},"tests":[{"name":"verifier_startup","status":"failed","message":"verifier crashed before reporting"}]}}\n' > "$log_dir/ctrf.json"
fi
exit "$status"
