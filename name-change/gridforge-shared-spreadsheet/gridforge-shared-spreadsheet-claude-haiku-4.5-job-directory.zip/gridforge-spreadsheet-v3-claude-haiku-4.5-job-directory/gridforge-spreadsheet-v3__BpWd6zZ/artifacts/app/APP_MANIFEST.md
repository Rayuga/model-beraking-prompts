# GridForge Application Manifest

## Starting the Application

To start the GridForge server, run:

```bash start
npm start
```

This will start the Node.js server on port 3000 (or the PORT environment variable if set).

## Database

The SQLite database is stored at:
```
/app/gridforge.sqlite3
```

The database is automatically initialized on first start with the seed workbook from `/assets/workbook_seed.json`. Subsequent starts will preserve all workbooks and revision history.

## API Routes

### Workbook Operations
- **GET** `/api/workbook` - Fetch the current workbook state and active sessions
  - Query: `sessionId` (optional) to update session activity
  - Returns: Current workbook, revision number, and active user sessions

- **POST** `/api/save` - Save a workbook with collision detection
  - Body: `{ workbook, revision, sessionId, userId }`
  - Returns: `{ revision: number, success: boolean }`
  - Status 409 if concurrent edits conflict on same cell

### Revisions
- **GET** `/api/revisions?workbookId=ID` - List all revisions for a workbook
  - Returns: Array of revision records with timestamps and authors

- **GET** `/api/revision/:workbookId/:revisionNumber` - Get a specific revision's content
  - Returns: Complete workbook state at that revision

- **POST** `/api/restore` - Restore a previous revision
  - Body: `{ workbookId, revisionNumber, sessionId, userId }`
  - Returns: `{ revision: number, success: boolean }`

### Sessions
- **POST** `/api/session/create` - Create a new editing session
  - Body: `{ workbookId, userId, userName }`
  - Returns: `{ sessionId: string }`

- **POST** `/api/session/close` - Close an editing session
  - Body: `{ sessionId }`
  - Returns: `{ success: boolean }`

### Cell History
- **GET** `/api/cell-history/:workbookId/:cellAddress` - Get edit history for a specific cell
  - Returns: Array of changes with old value, new value, user, and timestamp

## Running the Server

```bash
cd /app
npm start
```

The server will:
1. Listen on `0.0.0.0:3000` (configurable via PORT environment variable)
2. Serve all static resources (HTML, CSS, JavaScript) from `/app/public`
3. Use SQLite at `/app/gridforge.sqlite3` for persistent storage
4. Support concurrent editing with collision detection
5. Automatically track revisions and user attribution
6. Maintain session management for collaboration features

## Environment Variables

- `PORT` - Server port (default: 3000)

## Dependencies

- `express` ^5.2.1 - Web framework
- `sqlite3` ^5.1.7 - SQLite database driver

All dependencies are included in `node_modules/` and no external internet access is required at runtime.

## Architecture

The application consists of:
- **Backend**: Express.js server with SQLite database for persistence
- **Frontend**: Custom JavaScript spreadsheet grid with formula calculation
- **Collaboration**: Session management with concurrent edit handling
- **Storage**: Automatic autosave with revision history and restore capability

No third-party spreadsheet widgets or formula engines are used. The grid and calculation engine are built from scratch.
