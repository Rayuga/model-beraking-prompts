const express = require('express');
const path = require('path');
const fs = require('fs');
const { Database, DB_PATH } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

let db;

// Initialize database
async function initializeDatabase() {
  const database = new Database();
  await database.init();
  
  // Load seed workbook if this is the first run
  const hasWorkbooks = await database.get('SELECT COUNT(*) as count FROM workbooks');
  if (hasWorkbooks.count === 0) {
    const seedPath = '/assets/workbook_seed.json';
    const seedData = JSON.parse(fs.readFileSync(seedPath, 'utf-8'));
    const workbook = seedData.workbook;
    
    // Create workbook entry
    await database.run(
      'INSERT INTO workbooks (id, title, current_revision) VALUES (?, ?, ?)',
      [workbook.id, workbook.title, 1]
    );
    
    // Create initial revision with the seed content
    const initialContent = {
      id: workbook.id,
      title: workbook.title,
      sheets: workbook.sheets
    };
    
    await database.run(
      'INSERT INTO revisions (workbook_id, revision_number, content) VALUES (?, ?, ?)',
      [workbook.id, 1, JSON.stringify(initialContent)]
    );
  }
  
  return database;
}

// Helper functions
function getCellAddress(row, col) {
  const colLetter = String.fromCharCode(65 + col);
  return colLetter + (row + 1);
}

function parseCellAddress(addr) {
  const match = addr.match(/^([A-Z]+)(\d+)$/);
  if (!match) return null;
  const col = addr.charCodeAt(0) - 65;
  const row = parseInt(addr.substring(1)) - 1;
  return { row, col };
}

// Merge cells from concurrent edits
function mergeCells(baseCells, incomingCells, existingCells) {
  const result = { ...existingCells };
  
  for (const [address, value] of Object.entries(incomingCells)) {
    const baseValue = baseCells[address];
    const existingValue = existingCells[address];
    
    // If both changed the same cell to the same value, no conflict
    if (existingValue !== undefined && existingValue !== baseValue) {
      if (incomingCells[address] !== existingValue) {
        // Conflict: both changed the same cell differently
        continue;
      }
    }
    
    // Safe to apply the change
    result[address] = value;
  }
  
  return result;
}

// API Routes

app.get('/api/workbook', async (req, res) => {
  try {
    const sessions = await db.all(
      'SELECT id, user_id, user_name FROM sessions WHERE last_activity > datetime("now", "-5 seconds")'
    );
    
    // Update session activity
    if (req.query.sessionId) {
      await db.run(
        'UPDATE sessions SET last_activity = CURRENT_TIMESTAMP WHERE id = ?',
        [req.query.sessionId]
      );
    }
    
    // Get latest revision
    const latestRev = await db.get(`
      SELECT workbook_id, MAX(revision_number) as revision_number 
      FROM revisions 
      GROUP BY workbook_id 
      LIMIT 1
    `);
    
    if (!latestRev) {
      return res.status(404).json({ error: 'No workbook found' });
    }
    
    const revision = await db.get(
      'SELECT content FROM revisions WHERE workbook_id = ? AND revision_number = ?',
      [latestRev.workbook_id, latestRev.revision_number]
    );
    
    const workbookData = JSON.parse(revision.content);
    
    // Get active sessions
    const activeSessions = await db.all(
      'SELECT id, user_id, user_name FROM sessions WHERE workbook_id = ?',
      [latestRev.workbook_id]
    );
    
    res.json({
      workbook: workbookData,
      revision: latestRev.revision_number,
      sessions: activeSessions
    });
  } catch (error) {
    console.error('Error fetching workbook:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/save', async (req, res) => {
  try {
    const { workbook, revision: baseRevision, sessionId, userId } = req.body;
    
    // Validate request
    if (!workbook || !workbook.id || !Array.isArray(workbook.sheets)) {
      return res.status(400).json({ error: 'Invalid workbook format' });
    }
    
    if (!sessionId || !userId) {
      return res.status(400).json({ error: 'Missing session or user information' });
    }
    
    // Verify session exists and is valid
    const session = await db.get(
      'SELECT * FROM sessions WHERE id = ? AND workbook_id = ?',
      [sessionId, workbook.id]
    );
    
    if (!session) {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }
    
    // Get current workbook state
    const currentWorkbook = await db.get(
      'SELECT current_revision FROM workbooks WHERE id = ?',
      [workbook.id]
    );
    
    if (!currentWorkbook) {
      return res.status(404).json({ error: 'Workbook not found' });
    }
    
    const currentRevision = currentWorkbook.current_revision;
    
    // If there's a newer revision, attempt to merge
    if (baseRevision < currentRevision) {
      const baseRev = await db.get(
        'SELECT content FROM revisions WHERE workbook_id = ? AND revision_number = ?',
        [workbook.id, baseRevision]
      );
      
      const existingRev = await db.get(
        'SELECT content FROM revisions WHERE workbook_id = ? AND revision_number = ?',
        [workbook.id, currentRevision]
      );
      
      if (!baseRev || !existingRev) {
        return res.status(400).json({ error: 'Invalid base revision' });
      }
      
      const baseCells = {};
      const incomingCells = {};
      const existingCells = {};
      
      // Collect cells from all versions
      JSON.parse(baseRev.content).sheets.forEach(sheet => {
        Object.assign(baseCells, sheet.cells || {});
      });
      
      workbook.sheets.forEach(sheet => {
        Object.assign(incomingCells, sheet.cells || {});
      });
      
      JSON.parse(existingRev.content).sheets.forEach(sheet => {
        Object.assign(existingCells, sheet.cells || {});
      });
      
      // Check for conflicts (same cell changed to different values)
      for (const address in incomingCells) {
        const baseVal = baseCells[address];
        const incomingVal = incomingCells[address];
        const existingVal = existingCells[address];
        
        if (baseVal !== undefined && existingVal !== undefined && incomingVal !== undefined) {
          if (baseVal !== existingVal && baseVal !== incomingVal && existingVal !== incomingVal) {
            // Conflict: all three are different
            return res.status(409).json({ error: 'Conflicting edits on same cell', cell: address });
          }
        }
      }
      
      // Merge cells
      const mergedCells = mergeCells(baseCells, incomingCells, existingCells);
      
      // Update the incoming workbook with merged cells
      workbook.sheets[0].cells = mergedCells;
    }
    
    // Save new revision
    const newRevision = currentRevision + 1;
    await db.run(
      'INSERT INTO revisions (workbook_id, revision_number, content, created_by) VALUES (?, ?, ?, ?)',
      [workbook.id, newRevision, JSON.stringify(workbook), userId]
    );
    
    // Update current revision
    await db.run(
      'UPDATE workbooks SET current_revision = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [newRevision, workbook.id]
    );
    
    // Record cell changes
    if (baseRevision && baseRevision < currentRevision) {
      const prevRev = await db.get(
        'SELECT content FROM revisions WHERE workbook_id = ? AND revision_number = ?',
        [workbook.id, baseRevision]
      );
      const prevCells = {};
      JSON.parse(prevRev.content).sheets.forEach(sheet => {
        Object.assign(prevCells, sheet.cells || {});
      });
      
      const currentCells = {};
      workbook.sheets.forEach(sheet => {
        Object.assign(currentCells, sheet.cells || {});
      });
      
      for (const address in currentCells) {
        if (prevCells[address] !== currentCells[address]) {
          await db.run(
            'INSERT INTO cell_history (workbook_id, cell_address, old_value, new_value, changed_by) VALUES (?, ?, ?, ?, ?)',
            [workbook.id, address, prevCells[address] || null, currentCells[address], userId]
          );
        }
      }
    }
    
    res.json({ revision: newRevision, success: true });
  } catch (error) {
    console.error('Error saving workbook:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/revisions', async (req, res) => {
  try {
    const workbookId = req.query.workbookId;
    
    if (!workbookId) {
      return res.status(400).json({ error: 'Missing workbookId' });
    }
    
    const revisions = await db.all(`
      SELECT revision_number, created_at, created_by 
      FROM revisions 
      WHERE workbook_id = ? 
      ORDER BY revision_number DESC
    `, [workbookId]);
    
    res.json({ revisions });
  } catch (error) {
    console.error('Error fetching revisions:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/revision/:workbookId/:revisionNumber', async (req, res) => {
  try {
    const { workbookId, revisionNumber } = req.params;
    
    const revision = await db.get(
      'SELECT content FROM revisions WHERE workbook_id = ? AND revision_number = ?',
      [workbookId, parseInt(revisionNumber)]
    );
    
    if (!revision) {
      return res.status(404).json({ error: 'Revision not found' });
    }
    
    res.json(JSON.parse(revision.content));
  } catch (error) {
    console.error('Error fetching revision:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/restore', async (req, res) => {
  try {
    const { workbookId, revisionNumber, sessionId, userId } = req.body;
    
    // Verify session
    const session = await db.get(
      'SELECT * FROM sessions WHERE id = ? AND workbook_id = ?',
      [sessionId, workbookId]
    );
    
    if (!session) {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }
    
    // Get the revision to restore
    const revision = await db.get(
      'SELECT content FROM revisions WHERE workbook_id = ? AND revision_number = ?',
      [workbookId, parseInt(revisionNumber)]
    );
    
    if (!revision) {
      return res.status(404).json({ error: 'Revision not found' });
    }
    
    const restoredWorkbook = JSON.parse(revision.content);
    const currentWorkbook = await db.get(
      'SELECT current_revision FROM workbooks WHERE id = ?',
      [workbookId]
    );
    
    const newRevision = currentWorkbook.current_revision + 1;
    
    // Save as new revision
    await db.run(
      'INSERT INTO revisions (workbook_id, revision_number, content, created_by) VALUES (?, ?, ?, ?)',
      [workbookId, newRevision, JSON.stringify(restoredWorkbook), userId]
    );
    
    await db.run(
      'UPDATE workbooks SET current_revision = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [newRevision, workbookId]
    );
    
    res.json({ revision: newRevision, success: true });
  } catch (error) {
    console.error('Error restoring revision:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/session/create', async (req, res) => {
  try {
    const { workbookId, userId, userName } = req.body;
    
    if (!workbookId || !userId || !userName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    // Verify workbook exists
    const workbook = await db.get(
      'SELECT id FROM workbooks WHERE id = ?',
      [workbookId]
    );
    
    if (!workbook) {
      return res.status(404).json({ error: 'Workbook not found' });
    }
    
    // Create session
    const sessionId = `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    await db.run(
      'INSERT INTO sessions (id, workbook_id, user_id, user_name) VALUES (?, ?, ?, ?)',
      [sessionId, workbookId, userId, userName]
    );
    
    res.json({ sessionId });
  } catch (error) {
    console.error('Error creating session:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/session/close', async (req, res) => {
  try {
    const { sessionId } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({ error: 'Missing sessionId' });
    }
    
    await db.run(
      'DELETE FROM sessions WHERE id = ?',
      [sessionId]
    );
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error closing session:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/cell-history/:workbookId/:cellAddress', async (req, res) => {
  try {
    const { workbookId, cellAddress } = req.params;
    
    const history = await db.all(`
      SELECT old_value, new_value, changed_by, changed_at 
      FROM cell_history 
      WHERE workbook_id = ? AND cell_address = ?
      ORDER BY changed_at DESC
      LIMIT 20
    `, [workbookId, cellAddress]);
    
    res.json({ history });
  } catch (error) {
    console.error('Error fetching cell history:', error);
    res.status(500).json({ error: error.message });
  }
});

// Serve the app
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
async function start() {
  try {
    db = await initializeDatabase();
    
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`GridForge server running on port ${PORT}`);
      console.log(`Database: ${DB_PATH}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGINT', async () => {
  if (db) {
    await db.close();
  }
  process.exit(0);
});

start();
