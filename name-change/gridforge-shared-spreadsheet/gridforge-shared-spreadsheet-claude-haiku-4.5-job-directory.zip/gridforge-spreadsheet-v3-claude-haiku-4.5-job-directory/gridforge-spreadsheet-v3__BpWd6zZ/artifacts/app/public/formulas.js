class FormulaParser {
  constructor(cells = {}) {
    this.cells = cells;
    this.evaluationCache = new Map();
  }

  parseFormula(formula) {
    const trimmed = formula.trim();
    if (!trimmed.startsWith('=')) {
      return { type: 'literal', value: trimmed };
    }

    const expr = trimmed.substring(1).trim();
    return this.parseExpression(expr);
  }

  parseExpression(expr) {
    try {
      return { type: 'formula', ast: this.buildAST(expr) };
    } catch (e) {
      return { type: 'error', value: e.message };
    }
  }

  buildAST(expr) {
    let pos = 0;

    const peek = () => expr[pos];
    const advance = () => expr[pos++];
    const skipWhitespace = () => {
      while (pos < expr.length && /\s/.test(expr[pos])) pos++;
    };

    const parseAddSub = () => {
      let left = parseMulDiv();
      skipWhitespace();

      while (peek() === '+' || peek() === '-') {
        const op = advance();
        skipWhitespace();
        const right = parseMulDiv();
        skipWhitespace();
        left = { type: 'binary', op, left, right };
      }

      return left;
    };

    const parseMulDiv = () => {
      let left = parsePrimary();
      skipWhitespace();

      while (peek() === '*' || peek() === '/') {
        const op = advance();
        skipWhitespace();
        const right = parsePrimary();
        skipWhitespace();
        left = { type: 'binary', op, left, right };
      }

      return left;
    };

    const parsePrimary = () => {
      skipWhitespace();
      const ch = peek();

      if (ch === '(') {
        advance();
        skipWhitespace();
        const result = parseAddSub();
        skipWhitespace();
        if (advance() !== ')') throw new Error('Expected )');
        return result;
      }

      // Check for function
      if (/[A-Za-z]/.test(ch)) {
        const nameStart = pos;
        while (pos < expr.length && /[A-Za-z0-9_]/.test(expr[pos])) pos++;
        const name = expr.substring(nameStart, pos).toUpperCase();

        skipWhitespace();
        if (peek() === '(') {
          advance();
          const args = parseArguments();
          skipWhitespace();
          if (advance() !== ')') throw new Error(`Expected ) for ${name}`);
          return { type: 'function', name, args };
        } else {
          // It's a cell reference
          pos = nameStart;
          return parseCellOrRange();
        }
      }

      // Number or cell reference
      if (/\d/.test(ch) || (ch === '-' && /\d/.test(expr[pos + 1]))) {
        return parseNumber();
      }

      if (/[A-Z]/.test(ch)) {
        return parseCellOrRange();
      }

      throw new Error(`Unexpected character: ${ch}`);
    };

    const parseArguments = () => {
      const args = [];
      skipWhitespace();

      if (peek() === ')') return args;

      while (true) {
        args.push(parseAddSub());
        skipWhitespace();

        if (peek() === ',') {
          advance();
          skipWhitespace();
        } else if (peek() === ';') {
          advance();
          skipWhitespace();
        } else {
          break;
        }
      }

      return args;
    };

    const parseNumber = () => {
      let numStr = '';
      if (peek() === '-') numStr += advance();

      while (pos < expr.length && /\d/.test(expr[pos])) {
        numStr += advance();
      }

      if (peek() === '.') {
        numStr += advance();
        while (pos < expr.length && /\d/.test(expr[pos])) {
          numStr += advance();
        }
      }

      return { type: 'literal', value: parseFloat(numStr) };
    };

    const parseCellOrRange = () => {
      const addrStart = pos;
      while (pos < expr.length && /[A-Z0-9]/.test(expr[pos])) pos++;
      const addr = expr.substring(addrStart, pos);

      skipWhitespace();
      if (peek() === ':') {
        advance();
        skipWhitespace();

        const addrStart2 = pos;
        while (pos < expr.length && /[A-Z0-9]/.test(expr[pos])) pos++;
        const addr2 = expr.substring(addrStart2, pos);

        return { type: 'range', start: addr, end: addr2 };
      }

      return { type: 'cell', address: addr };
    };

    const result = parseAddSub();
    skipWhitespace();
    if (pos !== expr.length) {
      throw new Error(`Unexpected token at position ${pos}`);
    }
    return result;
  }

  evaluate(ast, cells = null) {
    const cellsMap = cells || this.cells;
    const cacheKey = JSON.stringify(ast);

    if (this.evaluationCache.has(cacheKey)) {
      return this.evaluationCache.get(cacheKey);
    }

    let result;

    if (ast.type === 'literal') {
      result = ast.value;
    } else if (ast.type === 'cell') {
      const cellValue = cellsMap[ast.address];
      if (cellValue === undefined) {
        result = 0;
      } else if (typeof cellValue === 'string' && cellValue.startsWith('=')) {
        const parsed = this.parseFormula(cellValue);
        result = this.evaluate(parsed.ast, cellsMap);
      } else {
        const num = parseFloat(cellValue);
        result = isNaN(num) ? 0 : num;
      }
    } else if (ast.type === 'range') {
      result = this.expandRange(ast.start, ast.end, cellsMap);
    } else if (ast.type === 'binary') {
      const left = this.evaluate(ast.left, cellsMap);
      const right = this.evaluate(ast.right, cellsMap);

      if (ast.op === '+') result = left + right;
      else if (ast.op === '-') result = left - right;
      else if (ast.op === '*') result = left * right;
      else if (ast.op === '/') {
        if (right === 0) throw new Error('Division by zero');
        result = left / right;
      }
    } else if (ast.type === 'function') {
      result = this.callFunction(ast.name, ast.args, cellsMap);
    } else if (ast.type === 'error') {
      throw new Error(ast.value);
    } else {
      throw new Error('Unknown AST node type');
    }

    this.evaluationCache.set(cacheKey, result);
    return result;
  }

  expandRange(startAddr, endAddr, cells) {
    const start = this.parseAddress(startAddr);
    const end = this.parseAddress(endAddr);

    if (!start || !end) return [];

    const values = [];

    if (start.col === end.col) {
      // Vertical range
      const minRow = Math.min(start.row, end.row);
      const maxRow = Math.max(start.row, end.row);
      for (let r = minRow; r <= maxRow; r++) {
        const addr = String.fromCharCode(65 + start.col) + (r + 1);
        const cellValue = cells[addr];
        if (cellValue !== undefined) {
          if (typeof cellValue === 'string' && cellValue.startsWith('=')) {
            const parsed = this.parseFormula(cellValue);
            values.push(this.evaluate(parsed.ast, cells));
          } else {
            const num = parseFloat(cellValue);
            values.push(isNaN(num) ? 0 : num);
          }
        } else {
          values.push(0);
        }
      }
    } else if (start.row === end.row) {
      // Horizontal range
      const minCol = Math.min(start.col, end.col);
      const maxCol = Math.max(start.col, end.col);
      for (let c = minCol; c <= maxCol; c++) {
        const addr = String.fromCharCode(65 + c) + (start.row + 1);
        const cellValue = cells[addr];
        if (cellValue !== undefined) {
          if (typeof cellValue === 'string' && cellValue.startsWith('=')) {
            const parsed = this.parseFormula(cellValue);
            values.push(this.evaluate(parsed.ast, cells));
          } else {
            const num = parseFloat(cellValue);
            values.push(isNaN(num) ? 0 : num);
          }
        } else {
          values.push(0);
        }
      }
    }

    return values;
  }

  parseAddress(addr) {
    const match = addr.match(/^([A-Z]+)(\d+)$/);
    if (!match) return null;
    const col = addr.charCodeAt(0) - 65;
    const row = parseInt(addr.substring(1)) - 1;
    return { row, col };
  }

  callFunction(name, args, cells) {
    const evaluatedArgs = args.map(arg => {
      if (arg.type === 'range') {
        return this.expandRange(arg.start, arg.end, cells);
      }
      return this.evaluate(arg, cells);
    });

    switch (name) {
      case 'SUM':
        return evaluatedArgs.flat().reduce((a, b) => a + b, 0);
      case 'AVG':
        const flatArgs = evaluatedArgs.flat();
        return flatArgs.length > 0 ? flatArgs.reduce((a, b) => a + b, 0) / flatArgs.length : 0;
      case 'MIN':
        return Math.min(...evaluatedArgs.flat());
      case 'MAX':
        return Math.max(...evaluatedArgs.flat());
      case 'COUNT':
        return evaluatedArgs.flat().length;
      default:
        throw new Error(`Unknown function: ${name}`);
    }
  }

  calculateCell(formula, cells) {
    const parsed = this.parseFormula(formula);

    if (parsed.type === 'literal') {
      return parsed.value;
    }

    if (parsed.type === 'error') {
      throw new Error(parsed.value);
    }

    try {
      const result = this.evaluate(parsed.ast, cells);
      if (typeof result === 'number') {
        // Return with reasonable precision
        return Math.round(result * 100) / 100;
      }
      return result;
    } catch (e) {
      throw e;
    }
  }

  clearCache() {
    this.evaluationCache.clear();
  }
}
