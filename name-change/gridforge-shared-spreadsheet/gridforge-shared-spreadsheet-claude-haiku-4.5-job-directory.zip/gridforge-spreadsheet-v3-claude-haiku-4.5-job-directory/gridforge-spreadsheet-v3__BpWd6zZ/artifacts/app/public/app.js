class SpreadsheetApp {
  constructor() {
    this.workbook = null;
    this.currentSheet = null;
    this.sessionId = null;
    this.userId = null;
    this.userName = null;
    this.currentRevision = 1;
    this.unsavedChanges = false;
    this.autoSaveTimer = null;
    this.syncTimer = null;
    this.selectedCells = new Set();
    this.selectedStart = null;
    this.selectedEnd = null;
    this.editingCell = null;
    this.editingValue = null;
    this.clipboard = null;
    this.clipboardMode = 'copy'; // 'copy' or 'cut'
    this.history = [];
    this.historyIndex = -1;
    this.formulaParser = new FormulaParser();
    this.sessions = new Map();
    this.sessionPresence = new Map();
    this.findMatches = [];
    this.findCurrentIndex = 0;
    this.COLS = 20; // A-T
    this.ROWS = 80;
  }

  async init() {
    // Show user selection screen
    const users = [
      { id: 'riley', name: 'Riley Stone' },
      { id: 'morgan', name: 'Morgan Lee' },
      { id: 'priya', name: 'Priya Shah' }
    ];

    this.userId = await this.showUserSelection(users);
    if (!this.userId) return;

    this.userName = users.find(u => u.id === this.userId)?.name || this.userId;

    // Fetch workbook
    const workbookResponse = await fetch('/api/workbook');
    const data = await workbookResponse.json();

    this.workbook = data.workbook;
    this.currentRevision = data.revision;
    this.currentSheet = this.workbook.sheets[0];

    // Create session
    const sessionResponse = await fetch('/api/session/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        workbookId: this.workbook.id,
        userId: this.userId,
        userName: this.userName
      })
    });

    const sessionData = await sessionResponse.json();
    this.sessionId = sessionData.sessionId;

    // Initialize UI
    this.buildUI();
    this.updateTitle();
    this.renderGrid();
    this.attachEventListeners();

    // Save initial state for undo
    this.saveHistory();

    // Start auto-sync
    this.startAutoSync();

    // Handle window close
    window.addEventListener('beforeunload', () => this.closeSession());
  }

  showUserSelection(users) {
    return new Promise((resolve) => {
      const dialog = document.createElement('div');
      dialog.className = 'user-selection-overlay';
      dialog.innerHTML = `
        <div class="user-selection-dialog">
          <h2>Select Your Profile</h2>
          <div class="user-list">
            ${users.map(u => `<button class="user-btn" data-user-id="${u.id}">${u.name}</button>`).join('')}
          </div>
        </div>
      `;
      document.body.appendChild(dialog);

      dialog.querySelectorAll('.user-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const userId = btn.dataset.userId;
          dialog.remove();
          resolve(userId);
        });
      });
    });
  }

  buildUI() {
    document.body.innerHTML = `
      <div class="app-container">
        <header class="toolbar">
          <div class="toolbar-group">
            <h1 class="workbook-title">${this.workbook.title}</h1>
          </div>
          <div class="toolbar-group">
            <button id="save-btn" title="Save now (Ctrl+S)">Save</button>
            <button id="undo-btn" title="Undo (Ctrl+Z)">↶ Undo</button>
            <button id="redo-btn" title="Redo (Ctrl+Y)">↷ Redo</button>
          </div>
          <div class="toolbar-group">
            <input type="text" id="name-box" placeholder="Cell or range (e.g., A1 or A1:C3)" title="Name box - click to jump to a cell or select a range">
            <input type="text" id="search-box" placeholder="Find..." title="Find in cells">
            <button id="find-next-btn" title="Find next (F3)">Find Next</button>
            <button id="replace-btn" title="Open find and replace">Replace</button>
          </div>
          <div class="toolbar-group">
            <button id="fill-btn" title="Fill down (Ctrl+D)">Fill</button>
            <button id="revision-btn" title="View revision history">History</button>
          </div>
          <div class="toolbar-group">
            <span id="save-status" class="save-status"></span>
            <span id="user-badge" class="user-badge"></span>
          </div>
        </header>

        <div class="content-area">
          <div class="formula-bar-container">
            <label for="formula-input">fx</label>
            <input type="text" id="formula-input" placeholder="Enter formula or value" title="Formula bar">
            <div id="formula-suggestions" class="formula-suggestions"></div>
          </div>

          <div class="workspace">
            <div class="grid-wrapper">
              <div id="grid-container" class="grid-container"></div>
            </div>
            <div id="presence-panel" class="presence-panel"></div>
          </div>
        </div>

        <div id="replace-dialog" class="modal" style="display:none;">
          <div class="modal-content">
            <div class="modal-header">
              <h2>Find and Replace</h2>
              <button class="close-btn">×</button>
            </div>
            <div class="modal-body">
              <div class="form-group">
                <label>Find:</label>
                <input type="text" id="replace-find" placeholder="Text to find">
              </div>
              <div class="form-group">
                <label>Replace with:</label>
                <input type="text" id="replace-with" placeholder="Replacement text">
              </div>
              <div class="form-actions">
                <button id="replace-current-btn">Replace Current</button>
                <button id="replace-all-btn">Replace All</button>
              </div>
            </div>
          </div>
        </div>

        <div id="history-dialog" class="modal" style="display:none;">
          <div class="modal-content">
            <div class="modal-header">
              <h2>Revision History</h2>
              <button class="close-btn">×</button>
            </div>
            <div class="modal-body">
              <div id="revision-list" class="revision-list"></div>
            </div>
          </div>
        </div>

        <div id="cell-history-dialog" class="modal" style="display:none;">
          <div class="modal-content">
            <div class="modal-header">
              <h2>Cell History: <span id="cell-history-address"></span></h2>
              <button class="close-btn">×</button>
            </div>
            <div class="modal-body">
              <div id="cell-history-list" class="cell-history-list"></div>
            </div>
          </div>
        </div>
      </div>
    `;

    this.grid = document.getElementById('grid-container');
    this.formulaInput = document.getElementById('formula-input');
    this.nameBox = document.getElementById('name-box');
    this.searchBox = document.getElementById('search-box');
    this.saveStatus = document.getElementById('save-status');
    this.userBadge = document.getElementById('user-badge');
    this.presencePanel = document.getElementById('presence-panel');
    this.replaceDialog = document.getElementById('replace-dialog');
    this.historyDialog = document.getElementById('history-dialog');
    this.cellHistoryDialog = document.getElementById('cell-history-dialog');

    this.userBadge.textContent = this.userName;
  }

  updateTitle() {
    document.title = `${this.workbook.title} - GridForge`;
  }

  renderGrid() {
    this.grid.innerHTML = '';

    // Column headers
    const headerRow = document.createElement('div');
    headerRow.className = 'grid-row header-row';

    const cornerCell = document.createElement('div');
    cornerCell.className = 'grid-cell header-cell corner-cell';
    headerRow.appendChild(cornerCell);

    for (let col = 0; col < this.COLS; col++) {
      const cell = document.createElement('div');
      cell.className = 'grid-cell header-cell';
      cell.textContent = String.fromCharCode(65 + col);
      headerRow.appendChild(cell);
    }
    this.grid.appendChild(headerRow);

    // Data rows
    for (let row = 0; row < this.ROWS; row++) {
      const rowEl = document.createElement('div');
      rowEl.className = 'grid-row';

      // Row header
      const rowHeader = document.createElement('div');
      rowHeader.className = 'grid-cell header-cell row-header';
      rowHeader.textContent = row + 1;
      rowEl.appendChild(rowHeader);

      // Data cells
      for (let col = 0; col < this.COLS; col++) {
        const cellAddress = String.fromCharCode(65 + col) + (row + 1);
        const cellEl = document.createElement('div');
        cellEl.className = 'grid-cell data-cell';
        cellEl.dataset.address = cellAddress;
        cellEl.dataset.row = row;
        cellEl.dataset.col = col;

        const rawValue = this.currentSheet.cells[cellAddress] || '';
        const displayValue = this.getCellDisplayValue(cellAddress, rawValue);

        cellEl.textContent = displayValue;
        cellEl.title = rawValue;

        cellEl.addEventListener('click', (e) => this.onCellClick(cellAddress, e));
        cellEl.addEventListener('dblclick', () => this.startEditingCell(cellAddress));
        cellEl.addEventListener('mousedown', (e) => this.onCellMouseDown(cellAddress, e));
        cellEl.addEventListener('mouseenter', (e) => this.onCellMouseEnter(cellAddress, e));
        cellEl.addEventListener('contextmenu', (e) => this.onCellContextMenu(cellAddress, e));

        rowEl.appendChild(cellEl);
      }

      this.grid.appendChild(rowEl);
    }

    this.updateSelection();
    this.updateFormulaBar();
    this.updatePresenceIndicators();
  }

  getCellDisplayValue(address, rawValue) {
    if (!rawValue) return '';

    if (typeof rawValue === 'string' && rawValue.startsWith('=')) {
      try {
        const result = this.formulaParser.calculateCell(rawValue, this.currentSheet.cells);
        if (typeof result === 'number' && !Number.isInteger(result)) {
          return result.toFixed(2);
        }
        return result.toString();
      } catch (e) {
        return `#ERR: ${e.message.substring(0, 20)}`;
      }
    }

    return rawValue.toString();
  }

  onCellClick(address, event) {
    const isCtrl = event.ctrlKey || event.metaKey;
    const isShift = event.shiftKey;

    if (isCtrl) {
      this.toggleCellSelection(address);
    } else if (isShift) {
      this.extendSelectionTo(address);
    } else {
      this.selectCell(address);
    }

    this.editingCell = null;
    this.editingValue = null;
    this.updateFormulaBar();
    this.updateSelection();
  }

  onCellMouseDown(address, event) {
    if (event.button === 0) {
      this.dragStart = this.parseAddress(address);
      this.dragMode = 'select';
    }
  }

  onCellMouseEnter(address, event) {
    if (this.dragStart && event.buttons === 1) {
      const pos = this.parseAddress(address);
      if (pos) {
        this.selectRange(this.dragStart, pos);
        this.updateSelection();
      }
    }
  }

  onCellContextMenu(address, event) {
    event.preventDefault();
    this.selectCell(address);
    this.showCellHistory(address);
  }

  selectCell(address) {
    this.selectedCells.clear();
    this.selectedStart = address;
    this.selectedEnd = address;
    this.selectedCells.add(address);
    this.nameBox.value = address;
  }

  selectRange(start, end) {
    this.selectedCells.clear();
    this.selectedStart = this.formatAddress(start);
    this.selectedEnd = this.formatAddress(end);

    const minRow = Math.min(start.row, end.row);
    const maxRow = Math.max(start.row, end.row);
    const minCol = Math.min(start.col, end.col);
    const maxCol = Math.max(start.col, end.col);

    for (let r = minRow; r <= maxRow; r++) {
      for (let c = minCol; c <= maxCol; c++) {
        const addr = String.fromCharCode(65 + c) + (r + 1);
        this.selectedCells.add(addr);
      }
    }

    this.nameBox.value = `${this.selectedStart}:${this.selectedEnd}`;
  }

  toggleCellSelection(address) {
    if (this.selectedCells.has(address)) {
      this.selectedCells.delete(address);
    } else {
      this.selectedCells.add(address);
    }
  }

  extendSelectionTo(address) {
    if (!this.selectedStart) {
      this.selectCell(address);
      return;
    }

    const start = this.parseAddress(this.selectedStart);
    const end = this.parseAddress(address);

    if (start && end) {
      this.selectRange(start, end);
    }
  }

  updateSelection() {
    document.querySelectorAll('.grid-cell').forEach(cell => {
      cell.classList.remove('selected', 'active-cell');
      if (cell.dataset.address) {
        if (this.selectedCells.has(cell.dataset.address)) {
          cell.classList.add('selected');
          if (cell.dataset.address === this.selectedStart) {
            cell.classList.add('active-cell');
          }
        }
      }
    });
  }

  updateFormulaBar() {
    if (this.editingCell) {
      this.formulaInput.value = this.editingValue;
      this.formulaInput.focus();
    } else if (this.selectedStart) {
      const rawValue = this.currentSheet.cells[this.selectedStart] || '';
      this.formulaInput.value = rawValue;
    } else {
      this.formulaInput.value = '';
    }
  }

  startEditingCell(address) {
    this.editingCell = address;
    this.editingValue = this.currentSheet.cells[address] || '';
    this.updateFormulaBar();
    this.formulaInput.focus();
    this.formulaInput.select();
    this.showFormulaSuggestions();
  }

  showFormulaSuggestions() {
    const suggestionsDiv = document.getElementById('formula-suggestions');
    const functions = ['SUM', 'AVG', 'MIN', 'MAX', 'COUNT'];
    suggestionsDiv.innerHTML = functions
      .map(f => `<div class="suggestion">${f}(...)</div>`)
      .join('');

    suggestionsDiv.querySelectorAll('.suggestion').forEach(sug => {
      sug.addEventListener('click', () => {
        const func = sug.textContent.split('(')[0];
        this.formulaInput.value += `${func}()`;
        this.formulaInput.focus();
        const pos = this.formulaInput.value.length - 1;
        this.formulaInput.setSelectionRange(pos, pos);
      });
    });
  }

  parseAddress(address) {
    if (typeof address === 'string') {
      const match = address.match(/^([A-Z])(\d+)$/);
      if (match) {
        return { col: address.charCodeAt(0) - 65, row: parseInt(match[2]) - 1 };
      }
    }
    return null;
  }

  formatAddress(pos) {
    return String.fromCharCode(65 + pos.col) + (pos.row + 1);
  }

  attachEventListeners() {
    document.getElementById('save-btn').addEventListener('click', () => this.saveWorkbook());
    document.getElementById('undo-btn').addEventListener('click', () => this.undo());
    document.getElementById('redo-btn').addEventListener('click', () => this.redo());
    document.getElementById('find-next-btn').addEventListener('click', () => this.findNext());
    document.getElementById('fill-btn').addEventListener('click', () => this.fillDown());
    document.getElementById('revision-btn').addEventListener('click', () => this.showRevisionHistory());
    document.getElementById('replace-btn').addEventListener('click', () => this.showReplaceDialog());

    // Name box
    this.nameBox.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        const value = this.nameBox.value.trim();
        if (value.includes(':')) {
          const [start, end] = value.split(':');
          const startPos = this.parseAddress(start);
          const endPos = this.parseAddress(end);
          if (startPos && endPos) {
            this.selectRange(startPos, endPos);
            this.updateSelection();
          }
        } else {
          this.selectCell(value);
          this.updateSelection();
        }
        this.grid.focus();
      }
    });

    // Formula input
    this.formulaInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        const shiftEnter = e.shiftKey;
        this.commitEdit();

        if (this.editingCell) {
          const pos = this.parseAddress(this.editingCell);
          if (pos) {
            if (shiftEnter) {
              pos.row--;
            } else {
              pos.row++;
            }
            if (pos.row >= 0 && pos.row < this.ROWS) {
              this.selectCell(this.formatAddress(pos));
              this.updateSelection();
              this.startEditingCell(this.formatAddress(pos));
            }
          }
        }
      } else if (e.key === 'Tab') {
        e.preventDefault();
        this.commitEdit();

        if (this.editingCell) {
          const pos = this.parseAddress(this.editingCell);
          if (pos) {
            if (e.shiftKey) {
              pos.col--;
            } else {
              pos.col++;
            }
            if (pos.col >= 0 && pos.col < this.COLS) {
              const newAddr = this.formatAddress(pos);
              this.selectCell(newAddr);
              this.updateSelection();
              this.startEditingCell(newAddr);
            }
          }
        }
      } else if (e.key === 'Escape') {
        this.editingCell = null;
        this.editingValue = null;
        this.updateSelection();
        this.updateFormulaBar();
        this.grid.focus();
        document.getElementById('formula-suggestions').innerHTML = '';
      }
    });

    this.formulaInput.addEventListener('input', (e) => {
      this.editingValue = e.target.value;
      if (this.editingCell) {
        this.showFormulaSuggestions();
      }
    });

    // Search box
    this.searchBox.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.findNext();
      }
    });

    // Grid focus and keyboard navigation
    this.grid.addEventListener('keydown', (e) => this.onGridKeyDown(e));
    this.grid.setAttribute('tabindex', '0');

    // Modal dialogs
    document.querySelectorAll('.close-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.target.closest('.modal').style.display = 'none';
      });
    });

    // Close modal when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.style.display = 'none';
        }
      });
    });

    document.getElementById('replace-current-btn')?.addEventListener('click', () => this.replaceCurrent());
    document.getElementById('replace-all-btn')?.addEventListener('click', () => this.replaceAll());
  }

  onGridKeyDown(e) {
    if (this.editingCell) return;

    const key = e.key.toUpperCase();
    const ctrl = e.ctrlKey || e.metaKey;
    const shift = e.shiftKey;

    if (key === 'ARROWUP' || key === 'ARROWDOWN' || key === 'ARROWLEFT' || key === 'ARROWRIGHT') {
      e.preventDefault();
      this.moveSelection(key, shift);
    } else if (ctrl && key === 'C') {
      e.preventDefault();
      this.copy();
    } else if (ctrl && key === 'X') {
      e.preventDefault();
      this.cut();
    } else if (ctrl && key === 'V') {
      e.preventDefault();
      this.paste();
    } else if (ctrl && key === 'Z') {
      e.preventDefault();
      this.undo();
    } else if (ctrl && key === 'Y') {
      e.preventDefault();
      this.redo();
    } else if (ctrl && key === 'S') {
      e.preventDefault();
      this.saveWorkbook();
    } else if (ctrl && key === 'D') {
      e.preventDefault();
      this.fillDown();
    } else if (key === 'F3') {
      e.preventDefault();
      this.findNext();
    } else if (key === 'ENTER') {
      e.preventDefault();
      if (this.selectedStart) {
        this.startEditingCell(this.selectedStart);
      }
    } else if (key === 'DELETE' || key === 'BACKSPACE') {
      e.preventDefault();
      this.deleteSelection();
    } else if (/^[A-Z0-9]$/.test(key)) {
      // Start editing with this character
      if (this.selectedStart) {
        this.startEditingCell(this.selectedStart);
        this.formulaInput.value = key;
        this.editingValue = key;
      }
    }
  }

  moveSelection(direction, extend) {
    if (!this.selectedStart) return;

    const pos = this.parseAddress(this.selectedStart);
    if (!pos) return;

    switch (direction) {
      case 'ARROWUP':
        if (pos.row > 0) pos.row--;
        break;
      case 'ARROWDOWN':
        if (pos.row < this.ROWS - 1) pos.row++;
        break;
      case 'ARROWLEFT':
        if (pos.col > 0) pos.col--;
        break;
      case 'ARROWRIGHT':
        if (pos.col < this.COLS - 1) pos.col++;
        break;
    }

    const newAddr = this.formatAddress(pos);

    if (extend) {
      this.extendSelectionTo(newAddr);
    } else {
      this.selectCell(newAddr);
    }

    this.updateSelection();
    this.updateFormulaBar();

    // Scroll into view
    const cell = document.querySelector(`[data-address="${newAddr}"]`);
    if (cell) {
      cell.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
  }

  commitEdit() {
    if (!this.editingCell || this.editingValue === undefined) return;

    const oldValue = this.currentSheet.cells[this.editingCell];
    const newValue = this.editingValue;

    if (oldValue !== newValue) {
      this.currentSheet.cells[this.editingCell] = newValue;
      this.unsavedChanges = true;
      this.updateStatus('Unsaved changes');
      this.clearFormulaCache();
      this.renderGrid();
      this.saveHistory();
      this.scheduleAutoSave();
    }

    this.editingCell = null;
    this.editingValue = null;
    this.updateFormulaBar();
  }

  clearFormulaCache() {
    this.formulaParser.clearCache();
  }

  copy() {
    if (this.selectedCells.size === 0) return;

    const cells = Array.from(this.selectedCells).map(addr => ({
      address: addr,
      value: this.currentSheet.cells[addr] || ''
    }));

    this.clipboard = cells;
    this.clipboardMode = 'copy';
    this.updateStatus('Copied to clipboard');
  }

  cut() {
    this.copy();
    this.clipboardMode = 'cut';
  }

  paste() {
    if (!this.clipboard || this.clipboard.length === 0 || !this.selectedStart) return;

    const startPos = this.parseAddress(this.selectedStart);
    if (!startPos) return;

    const changes = [];
    const firstClipboardPos = this.parseAddress(this.clipboard[0].address);

    this.clipboard.forEach(item => {
      const clipPos = this.parseAddress(item.address);
      const offset = {
        row: clipPos.row - firstClipboardPos.row,
        col: clipPos.col - firstClipboardPos.col
      };

      const newPos = {
        row: startPos.row + offset.row,
        col: startPos.col + offset.col
      };

      if (newPos.row >= 0 && newPos.row < this.ROWS &&
          newPos.col >= 0 && newPos.col < this.COLS) {
        const newAddr = this.formatAddress(newPos);
        changes.push({ address: newAddr, oldValue: this.currentSheet.cells[newAddr] || '', value: item.value });
      }
    });

    // Apply changes as a single undo/redo action
    changes.forEach(change => {
      this.currentSheet.cells[change.address] = change.value;
    });

    if (this.clipboardMode === 'cut') {
      this.clipboard.forEach(item => {
        delete this.currentSheet.cells[item.address];
      });
      this.clipboard = null;
    }

    this.unsavedChanges = true;
    this.updateStatus('Unsaved changes');
    this.clearFormulaCache();
    this.renderGrid();
    this.saveHistory();
    this.scheduleAutoSave();
  }

  deleteSelection() {
    if (this.selectedCells.size === 0) return;

    this.selectedCells.forEach(addr => {
      delete this.currentSheet.cells[addr];
    });

    this.unsavedChanges = true;
    this.updateStatus('Unsaved changes');
    this.clearFormulaCache();
    this.renderGrid();
    this.saveHistory();
    this.scheduleAutoSave();
  }

  fillDown() {
    if (this.selectedCells.size < 2) return;

    const cells = Array.from(this.selectedCells).sort((a, b) => {
      const posA = this.parseAddress(a);
      const posB = this.parseAddress(b);
      if (posA.row !== posB.row) return posA.row - posB.row;
      return posA.col - posB.col;
    });

    const firstValue = this.currentSheet.cells[cells[0]] || '';
    if (!firstValue) return;

    const firstPos = this.parseAddress(cells[0]);
    let increment = 0;

    // Detect number increment pattern
    const numMatch = firstValue.match(/^(\d+)$/);
    if (numMatch && cells.length > 1) {
      const secondValue = this.currentSheet.cells[cells[1]];
      const secondNumMatch = secondValue?.match(/^(\d+)$/);
      if (secondNumMatch) {
        increment = parseInt(secondNumMatch[1]) - parseInt(numMatch[1]);
      }
    }

    // Apply fill with formula adjustment
    for (let i = 0; i < cells.length; i++) {
      const pos = this.parseAddress(cells[i]);
      const offset = pos.row - firstPos.row;

      if (offset === 0) continue;

      let fillValue = firstValue;

      if (increment) {
        fillValue = (parseInt(numMatch[1]) + offset * increment).toString();
      } else if (firstValue.startsWith('=')) {
        // Adjust formula references
        fillValue = this.adjustFormulaReferences(firstValue, offset);
      }

      this.currentSheet.cells[cells[i]] = fillValue;
    }

    this.unsavedChanges = true;
    this.updateStatus('Unsaved changes');
    this.clearFormulaCache();
    this.renderGrid();
    this.saveHistory();
    this.scheduleAutoSave();
  }

  adjustFormulaReferences(formula, rowOffset) {
    return formula.replace(/([A-Z])(\d+)/g, (match, col, row) => {
      const newRow = parseInt(row) + rowOffset;
      if (newRow < 1 || newRow > this.ROWS) return match;
      return col + newRow;
    });
  }

  find(text) {
    const searchLower = text.toLowerCase();
    this.findMatches = [];

    for (let r = 0; r < this.ROWS; r++) {
      for (let c = 0; c < this.COLS; c++) {
        const addr = String.fromCharCode(65 + c) + (r + 1);
        const value = this.currentSheet.cells[addr] || '';
        if (value.toString().toLowerCase().includes(searchLower)) {
          this.findMatches.push(addr);
        }
      }
    }

    this.findCurrentIndex = 0;
    if (this.findMatches.length > 0) {
      this.selectCell(this.findMatches[0]);
      this.updateSelection();
      return true;
    }
    return false;
  }

  findNext() {
    const searchText = this.searchBox.value;
    if (!searchText) return;

    if (this.findMatches.length === 0) {
      this.find(searchText);
      return;
    }

    this.findCurrentIndex = (this.findCurrentIndex + 1) % this.findMatches.length;
    this.selectCell(this.findMatches[this.findCurrentIndex]);
    this.updateSelection();
  }

  showReplaceDialog() {
    this.replaceDialog.style.display = 'block';
    document.getElementById('replace-find').focus();
  }

  replaceCurrent() {
    const findText = document.getElementById('replace-find').value;
    const replaceText = document.getElementById('replace-with').value;

    if (!findText || this.findMatches.length === 0) return;

    const currentMatch = this.findMatches[this.findCurrentIndex];
    const value = this.currentSheet.cells[currentMatch] || '';

    this.currentSheet.cells[currentMatch] = value.toString().replace(findText, replaceText);
    this.unsavedChanges = true;
    this.updateStatus('Unsaved changes');
    this.clearFormulaCache();
    this.renderGrid();
    this.saveHistory();
    this.scheduleAutoSave();

    this.findNext();
  }

  replaceAll() {
    const findText = document.getElementById('replace-find').value;
    const replaceText = document.getElementById('replace-with').value;

    if (!findText) return;

    this.find(findText);

    this.findMatches.forEach(addr => {
      const value = this.currentSheet.cells[addr] || '';
      this.currentSheet.cells[addr] = value.toString().replace(new RegExp(findText, 'g'), replaceText);
    });

    this.unsavedChanges = true;
    this.updateStatus('Unsaved changes');
    this.clearFormulaCache();
    this.renderGrid();
    this.saveHistory();
    this.scheduleAutoSave();

    this.replaceDialog.style.display = 'none';
  }

  saveHistory() {
    const state = JSON.parse(JSON.stringify(this.currentSheet.cells));
    this.history = this.history.slice(0, this.historyIndex + 1);
    this.history.push(state);
    this.historyIndex++;

    if (this.history.length > 100) {
      this.history.shift();
      this.historyIndex--;
    }
  }

  undo() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this.currentSheet.cells = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
      this.clearFormulaCache();
      this.renderGrid();
      this.updateStatus('Undo');
    }
  }

  redo() {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      this.currentSheet.cells = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
      this.clearFormulaCache();
      this.renderGrid();
      this.updateStatus('Redo');
    }
  }

  scheduleAutoSave() {
    clearTimeout(this.autoSaveTimer);
    this.autoSaveTimer = setTimeout(() => {
      this.saveWorkbook(true);
    }, 5000);
  }

  async saveWorkbook(autoSave = false) {
    try {
      const response = await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workbook: this.workbook,
          revision: this.currentRevision,
          sessionId: this.sessionId,
          userId: this.userId
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Save failed');
      }

      const data = await response.json();
      this.currentRevision = data.revision;
      this.unsavedChanges = false;

      if (autoSave) {
        this.updateStatus('Autosaved ✓');
      } else {
        this.updateStatus('Saved ✓');
      }

      setTimeout(() => {
        if (!this.unsavedChanges) {
          this.updateStatus('');
        }
      }, 3000);
    } catch (error) {
      this.updateStatus(`Save failed: ${error.message}`);
      console.error('Save error:', error);
    }
  }

  updateStatus(message) {
    this.saveStatus.textContent = message;
  }

  async showRevisionHistory() {
    const response = await fetch(`/api/revisions?workbookId=${this.workbook.id}`);
    const data = await response.json();

    const list = document.getElementById('revision-list');
    list.innerHTML = data.revisions.map((rev, idx) => `
      <div class="revision-item">
        <div class="revision-info">
          <span class="revision-number">Rev ${rev.revision_number}</span>
          <span class="revision-user">${rev.created_by || 'Unknown'}</span>
          <span class="revision-time">${new Date(rev.created_at).toLocaleString()}</span>
        </div>
        <div class="revision-actions">
          <button class="preview-btn" data-revision="${rev.revision_number}">Preview</button>
          <button class="restore-btn" data-revision="${rev.revision_number}">Restore</button>
        </div>
      </div>
    `).join('');

    document.querySelectorAll('.preview-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const revNum = btn.dataset.revision;
        const revResponse = await fetch(`/api/revision/${this.workbook.id}/${revNum}`);
        const revision = await revResponse.json();
        alert(`Preview Rev ${revNum}:\n${JSON.stringify(revision, null, 2).substring(0, 200)}...`);
      });
    });

    document.querySelectorAll('.restore-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (confirm('Restore this revision?')) {
          const revNum = btn.dataset.revision;
          const response = await fetch('/api/restore', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              workbookId: this.workbook.id,
              revisionNumber: parseInt(revNum),
              sessionId: this.sessionId,
              userId: this.userId
            })
          });

          if (response.ok) {
            const data = await response.json();
            this.currentRevision = data.revision;
            this.updateStatus('Restored revision');
            location.reload();
          }
        }
      });
    });

    this.historyDialog.style.display = 'block';
  }

  async showCellHistory(address) {
    const response = await fetch(`/api/cell-history/${this.workbook.id}/${address}`);
    const data = await response.json();

    document.getElementById('cell-history-address').textContent = address;
    const list = document.getElementById('cell-history-list');

    if (data.history.length === 0) {
      list.innerHTML = '<p>No history for this cell</p>';
    } else {
      list.innerHTML = data.history.map(h => `
        <div class="history-entry">
          <div class="history-user">${h.changed_by || 'Unknown'}</div>
          <div class="history-time">${new Date(h.changed_at).toLocaleString()}</div>
          <div class="history-values">
            <span class="old">Old: ${h.old_value || '(empty)'}</span>
            <span class="new">New: ${h.new_value || '(empty)'}</span>
          </div>
        </div>
      `).join('');
    }

    this.cellHistoryDialog.style.display = 'block';
  }

  startAutoSync() {
    this.syncTimer = setInterval(async () => {
      await this.syncWorkbook();
    }, 3000);
  }

  async syncWorkbook() {
    try {
      const response = await fetch(`/api/workbook?sessionId=${this.sessionId}`);
      const data = await response.json();

      // Update presence
      this.sessions = new Map();
      data.sessions.forEach(session => {
        this.sessions.set(session.id, { userId: session.user_id, userName: session.user_name });
      });

      this.updatePresenceIndicators();
    } catch (error) {
      console.error('Sync error:', error);
    }
  }

  updatePresenceIndicators() {
    const indicators = Array.from(this.sessions.values())
      .filter(session => session.userId !== this.userId);

    let html = '<div class="presence-header">Who\'s here:</div>';

    if (indicators.length === 0) {
      html += '<p>Just you</p>';
    } else {
      html += '<div class="presence-list">';
      indicators.forEach((session, idx) => {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8'];
        const color = colors[idx % colors.length];
        html += `<div class="presence-item"><span class="presence-dot" style="background:${color}"></span>${session.userName}</div>`;
      });
      html += '</div>';
    }

    this.presencePanel.innerHTML = html;
  }

  async closeSession() {
    if (this.sessionId) {
      await fetch('/api/session/close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: this.sessionId })
      }).catch(() => {});
    }
  }
}

// Initialize app
const app = new SpreadsheetApp();
app.init().catch(error => {
  console.error('App initialization failed:', error);
  alert('Failed to initialize app: ' + error.message);
});
