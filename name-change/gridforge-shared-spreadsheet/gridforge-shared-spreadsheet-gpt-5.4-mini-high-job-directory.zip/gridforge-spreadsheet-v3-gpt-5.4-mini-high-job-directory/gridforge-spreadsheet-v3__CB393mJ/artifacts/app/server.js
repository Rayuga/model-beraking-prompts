const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const Database = require('better-sqlite3');

const APP_ROOT = __dirname;
const PUBLIC_DIR = path.join(APP_ROOT, 'public');
const DB_PATH = path.join(APP_ROOT, 'gridforge.sqlite3');
const SEED_PATH = '/assets/workbook_seed.json';
const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const SESSION_TTL_MS = 15_000;
const COLOR_PALETTE = [
  '#2563eb',
  '#dc2626',
  '#16a34a',
  '#7c3aed',
  '#ea580c',
  '#0891b2',
  '#db2777',
  '#4f46e5',
  '#65a30d',
];

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function now() {
  return Date.now();
}

function hashColor(seed) {
  const hash = crypto.createHash('sha1').update(String(seed)).digest();
  return COLOR_PALETTE[hash[0] % COLOR_PALETTE.length];
}

function makeId(prefix) {
  return `${prefix}_${crypto.randomUUID()}`;
}

function badRequest(res, message, details = {}) {
  return res.status(400).json({ error: message, ...details });
}

function conflict(res, message, details = {}) {
  return res.status(409).json({ error: message, ...details });
}

function notFound(res, message = 'Not found') {
  return res.status(404).json({ error: message });
}

function validateAddress(address) {
  if (typeof address !== 'string') {
    throw new Error('Cell address must be a string');
  }
  const upper = address.toUpperCase();
  if (!/^[A-Z]{1,3}[1-9]\d*$/.test(upper)) {
    throw new Error(`Invalid cell address: ${address}`);
  }
  return upper;
}

function normalizeCells(cells) {
  if (!isPlainObject(cells)) {
    throw new Error('Cells must be an object');
  }
  const output = {};
  for (const [key, value] of Object.entries(cells)) {
    const address = validateAddress(key);
    if (typeof value !== 'string') {
      throw new Error(`Cell ${key} must be a string`);
    }
    if (value !== '') {
      output[address] = value;
    }
  }
  return output;
}

function normalizeWorkbookSnapshot(snapshot) {
  if (!isPlainObject(snapshot)) {
    throw new Error('Workbook snapshot must be an object');
  }
  if (typeof snapshot.id !== 'string' || !snapshot.id.trim()) {
    throw new Error('Workbook id must be a non-empty string');
  }
  if (typeof snapshot.title !== 'string' || !snapshot.title.trim()) {
    throw new Error('Workbook title must be a non-empty string');
  }
  if (!Array.isArray(snapshot.sheets) || snapshot.sheets.length === 0) {
    throw new Error('Workbook must contain at least one sheet');
  }
  const workbookId = snapshot.id.trim();
  const title = snapshot.title;
  const sheets = [];
  const seenSheetIds = new Set();
  const seenSheetNames = new Set();
  for (const sheet of snapshot.sheets) {
    if (!isPlainObject(sheet)) {
      throw new Error('Sheet must be an object');
    }
    if (typeof sheet.id !== 'string' || !sheet.id.trim()) {
      throw new Error('Sheet id must be a non-empty string');
    }
    if (typeof sheet.name !== 'string' || !sheet.name.trim()) {
      throw new Error('Sheet name must be a non-empty string');
    }
    if (seenSheetIds.has(sheet.id)) {
      throw new Error(`Duplicate sheet id: ${sheet.id}`);
    }
    if (seenSheetNames.has(sheet.name)) {
      throw new Error(`Duplicate sheet name: ${sheet.name}`);
    }
    seenSheetIds.add(sheet.id);
    seenSheetNames.add(sheet.name);
    sheets.push({
      id: sheet.id,
      name: sheet.name,
      cells: normalizeCells(sheet.cells || {}),
    });
  }
  return { id: workbookId, title, sheets };
}

function cloneSnapshot(snapshot) {
  return JSON.parse(JSON.stringify(snapshot));
}

function loadSeed() {
  const raw = fs.readFileSync(SEED_PATH, 'utf8');
  return JSON.parse(raw);
}

function setupSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workbooks (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      current_revision INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS revisions (
      workbook_id TEXT NOT NULL,
      revision INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      user_id TEXT NOT NULL,
      session_id TEXT,
      kind TEXT NOT NULL,
      snapshot TEXT NOT NULL,
      PRIMARY KEY (workbook_id, revision),
      FOREIGN KEY (workbook_id) REFERENCES workbooks(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      workbook_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      color TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      closed_at INTEGER,
      selection TEXT,
      active_address TEXT,
      claimed_user_id TEXT,
      FOREIGN KEY (workbook_id) REFERENCES workbooks(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_revisions_workbook ON revisions(workbook_id, revision DESC);
    CREATE INDEX IF NOT EXISTS idx_sessions_workbook ON sessions(workbook_id, updated_at DESC);
  `);
}

function seedDatabaseIfNeeded() {
  const count = db.prepare('SELECT COUNT(*) AS count FROM workbooks').get().count;
  if (count > 0) {
    return;
  }
  const seed = loadSeed();
  const workbook = normalizeWorkbookSnapshot(seed.workbook);
  const timestamp = now();
  const insertUser = db.prepare('INSERT INTO users (id, name) VALUES (?, ?)');
  const insertWorkbook = db.prepare('INSERT INTO workbooks (id, title, current_revision, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
  const insertRevision = db.prepare('INSERT INTO revisions (workbook_id, revision, created_at, user_id, session_id, kind, snapshot) VALUES (?, ?, ?, ?, ?, ?, ?)');
  const transaction = db.transaction(() => {
    for (const user of seed.users || []) {
      if (!isPlainObject(user) || typeof user.id !== 'string' || typeof user.name !== 'string') {
        throw new Error('Invalid seed user');
      }
      insertUser.run(user.id, user.name);
    }
    insertWorkbook.run(workbook.id, workbook.title, 1, timestamp, timestamp);
    insertRevision.run(workbook.id, 1, timestamp, 'seed', null, 'seed', JSON.stringify(workbook));
  });
  transaction();
}

setupSchema();
seedDatabaseIfNeeded();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(PUBLIC_DIR, { fallthrough: true, maxAge: '1h' }));

function getUsers() {
  return db.prepare('SELECT id, name FROM users ORDER BY name ASC').all();
}

function getWorkbookRow(workbookId) {
  return db.prepare('SELECT * FROM workbooks WHERE id = ?').get(workbookId);
}

function getRevisionRow(workbookId, revision) {
  return db.prepare('SELECT * FROM revisions WHERE workbook_id = ? AND revision = ?').get(workbookId, revision);
}

function loadSnapshot(workbookId, revision) {
  const row = getRevisionRow(workbookId, revision);
  if (!row) {
    return null;
  }
  return JSON.parse(row.snapshot);
}

function getCurrentSnapshot(workbookId) {
  const workbook = getWorkbookRow(workbookId);
  if (!workbook) {
    return null;
  }
  return loadSnapshot(workbookId, workbook.current_revision);
}

function sheetMap(snapshot) {
  const result = new Map();
  for (const sheet of snapshot.sheets) {
    result.set(sheet.id, sheet);
  }
  return result;
}

function diffSnapshots(baseSnapshot, nextSnapshot) {
  const diffs = [];
  const baseSheets = sheetMap(baseSnapshot);
  const nextSheets = sheetMap(nextSnapshot);
  for (const [sheetId, baseSheet] of baseSheets.entries()) {
    const nextSheet = nextSheets.get(sheetId);
    if (!nextSheet) {
      throw new Error(`Missing sheet in snapshot: ${sheetId}`);
    }
    const addresses = new Set([
      ...Object.keys(baseSheet.cells || {}),
      ...Object.keys(nextSheet.cells || {}),
    ]);
    for (const address of addresses) {
      const fromValue = baseSheet.cells?.[address] ?? '';
      const toValue = nextSheet.cells?.[address] ?? '';
      if (fromValue !== toValue) {
        diffs.push({ sheetId, address, fromValue, toValue });
      }
    }
  }
  return diffs;
}

function applyDiffs(snapshot, diffs) {
  const next = cloneSnapshot(snapshot);
  const map = sheetMap(next);
  for (const diff of diffs) {
    const sheet = map.get(diff.sheetId);
    if (!sheet) {
      throw new Error(`Unknown sheet: ${diff.sheetId}`);
    }
    sheet.cells = sheet.cells || {};
    if (diff.toValue === '') {
      delete sheet.cells[diff.address];
    } else {
      sheet.cells[diff.address] = diff.toValue;
    }
  }
  return next;
}

function sameWorkbookIdentity(baseSnapshot, nextSnapshot) {
  if (baseSnapshot.id !== nextSnapshot.id) {
    return false;
  }
  if (baseSnapshot.title !== nextSnapshot.title) {
    return false;
  }
  if (baseSnapshot.sheets.length !== nextSnapshot.sheets.length) {
    return false;
  }
  for (let index = 0; index < baseSnapshot.sheets.length; index += 1) {
    const left = baseSnapshot.sheets[index];
    const right = nextSnapshot.sheets[index];
    if (left.id !== right.id || left.name !== right.name) {
      return false;
    }
  }
  return true;
}

function currentSessionActive(row) {
  if (!row || row.closed_at) {
    return false;
  }
  return now() - row.updated_at <= SESSION_TTL_MS;
}

function parseSelectionBody(body) {
  if (!body) {
    return null;
  }
  if (!isPlainObject(body)) {
    throw new Error('Selection must be an object');
  }
  const required = ['r1', 'c1', 'r2', 'c2'];
  for (const key of required) {
    if (!Number.isInteger(body[key])) {
      throw new Error('Selection coordinates must be integers');
    }
  }
  return {
    r1: body.r1,
    c1: body.c1,
    r2: body.r2,
    c2: body.c2,
  };
}

function sessionPayload(row) {
  return {
    id: row.id,
    workbookId: row.workbook_id,
    userId: row.user_id,
    claimedUserId: row.claimed_user_id,
    color: row.color,
    selection: row.selection ? JSON.parse(row.selection) : null,
    activeAddress: row.active_address || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    closedAt: row.closed_at || null,
    isActive: currentSessionActive(row),
  };
}

function getActiveSessions(workbookId) {
  const rows = db.prepare('SELECT * FROM sessions WHERE workbook_id = ? ORDER BY updated_at DESC').all(workbookId);
  return rows.filter(currentSessionActive).map(sessionPayload);
}

function getRevisionSummaries(workbookId) {
  const rows = db.prepare(`
    SELECT revisions.revision, revisions.created_at, revisions.user_id, revisions.session_id, revisions.kind, users.name AS user_name
    FROM revisions
    LEFT JOIN users ON users.id = revisions.user_id
    WHERE revisions.workbook_id = ?
    ORDER BY revisions.revision DESC
  `).all(workbookId);
  return rows.map((row) => ({
    revision: row.revision,
    createdAt: row.created_at,
    userId: row.user_id,
    userName: row.user_name || row.user_id,
    sessionId: row.session_id,
    kind: row.kind,
  }));
}

function buildWorkbookState(workbookId) {
  const workbook = getWorkbookRow(workbookId);
  if (!workbook) {
    return null;
  }
  const snapshot = loadSnapshot(workbookId, workbook.current_revision);
  if (!snapshot) {
    throw new Error('Current workbook revision missing');
  }
  return {
    workbook: snapshot,
    currentRevision: workbook.current_revision,
    savedAt: workbook.updated_at,
    revisions: getRevisionSummaries(workbookId),
    sessions: getActiveSessions(workbookId),
    users: getUsers(),
  };
}

function requireWorkbook(req, res) {
  const workbookId = req.params.id || req.query.workbookId || req.body?.workbook?.id || req.body?.workbookId;
  if (typeof workbookId !== 'string' || !workbookId) {
    badRequest(res, 'Workbook id is required');
    return null;
  }
  const workbook = getWorkbookRow(workbookId);
  if (!workbook) {
    notFound(res, 'Workbook not found');
    return null;
  }
  return workbook;
}

function requireSession(req, res, workbookId) {
  const sessionId = req.body?.sessionId || req.get('x-gridforge-session') || req.query.sessionId;
  if (typeof sessionId !== 'string' || !sessionId.trim()) {
    badRequest(res, 'Session id is required');
    return null;
  }
  const row = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId.trim());
  if (!row) {
    conflict(res, 'Unknown editing session');
    return null;
  }
  if (row.workbook_id !== workbookId) {
    conflict(res, 'Session belongs to a different workbook');
    return null;
  }
  if (!currentSessionActive(row)) {
    conflict(res, 'Editing session has expired or been closed');
    return null;
  }
  const claimedUserId = req.body?.claimedUserId ?? req.body?.userId;
  if (claimedUserId != null && claimedUserId !== row.user_id) {
    conflict(res, 'Claimed user does not match the editing session');
    return null;
  }
  return row;
}

function updateSessionHeartbeat(sessionId, selection, activeAddress) {
  const row = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
  if (!row) {
    return null;
  }
  if (!currentSessionActive(row)) {
    return null;
  }
  const updatedAt = now();
  db.prepare('UPDATE sessions SET updated_at = ?, selection = ?, active_address = ? WHERE id = ?').run(
    updatedAt,
    selection == null ? null : JSON.stringify(selection),
    activeAddress || null,
    sessionId,
  );
  return db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
}

function cellHistoryForAddress(workbookId, sheetId, address) {
  const workbook = getWorkbookRow(workbookId);
  if (!workbook) {
    return null;
  }
  const normalizedAddress = validateAddress(address);
  const rows = db.prepare(`
    SELECT revisions.revision, revisions.created_at, revisions.user_id, revisions.session_id, revisions.kind, revisions.snapshot, users.name AS user_name
    FROM revisions
    LEFT JOIN users ON users.id = revisions.user_id
    WHERE revisions.workbook_id = ?
    ORDER BY revisions.revision ASC
  `).all(workbookId);
  if (rows.length === 0) {
    return { sheetId, address: normalizedAddress, history: [] };
  }
  const targetSheetId = sheetId || JSON.parse(rows[0].snapshot).sheets[0].id;
  const history = [];
  let previousValue = '';
  let seenAny = false;
  for (const row of rows) {
    const snapshot = JSON.parse(row.snapshot);
    const sheet = snapshot.sheets.find((entry) => entry.id === targetSheetId);
    if (!sheet) {
      continue;
    }
    const nextValue = sheet.cells?.[normalizedAddress] ?? '';
    if (!seenAny) {
      previousValue = nextValue;
      seenAny = true;
      continue;
    }
    if (nextValue !== previousValue) {
      history.push({
        revision: row.revision,
        at: row.created_at,
        userId: row.user_id,
        userName: row.user_name || row.user_id,
        sessionId: row.session_id,
        kind: row.kind,
        previousValue,
        newValue: nextValue,
      });
      previousValue = nextValue;
    }
  }
  return { sheetId: targetSheetId, address: normalizedAddress, history };
}

app.get('/api/bootstrap', (req, res) => {
  const workbook = getWorkbookRow('ops-plan');
  if (!workbook) {
    return notFound(res, 'Workbook not found');
  }
  return res.json(buildWorkbookState(workbook.id));
});

app.get('/api/workbooks/:id/state', (req, res) => {
  const workbook = requireWorkbook(req, res);
  if (!workbook) {
    return;
  }
  return res.json(buildWorkbookState(workbook.id));
});

app.get('/api/workbooks/:id/revisions', (req, res) => {
  const workbook = requireWorkbook(req, res);
  if (!workbook) {
    return;
  }
  return res.json({
    workbookId: workbook.id,
    currentRevision: workbook.current_revision,
    revisions: getRevisionSummaries(workbook.id),
  });
});

app.get('/api/workbooks/:id/revisions/:revision', (req, res) => {
  const workbook = requireWorkbook(req, res);
  if (!workbook) {
    return;
  }
  const revision = Number(req.params.revision);
  if (!Number.isInteger(revision)) {
    return badRequest(res, 'Revision must be an integer');
  }
  const row = getRevisionRow(workbook.id, revision);
  if (!row) {
    return notFound(res, 'Revision not found');
  }
  return res.json({
    workbookId: workbook.id,
    revision: row.revision,
    createdAt: row.created_at,
    userId: row.user_id,
    sessionId: row.session_id,
    kind: row.kind,
    snapshot: JSON.parse(row.snapshot),
  });
});

app.post('/api/workbooks/:id/revisions/:revision/restore', (req, res) => {
  const workbook = requireWorkbook(req, res);
  if (!workbook) {
    return;
  }
  const revision = Number(req.params.revision);
  if (!Number.isInteger(revision)) {
    return badRequest(res, 'Revision must be an integer');
  }
  const row = getRevisionRow(workbook.id, revision);
  if (!row) {
    return notFound(res, 'Revision not found');
  }
  return res.json({
    workbookId: workbook.id,
    revision: row.revision,
    snapshot: JSON.parse(row.snapshot),
  });
});

app.get('/api/workbooks/:id/cells/:address/history', (req, res) => {
  const workbook = requireWorkbook(req, res);
  if (!workbook) {
    return;
  }
  const result = cellHistoryForAddress(workbook.id, req.query.sheetId || null, req.params.address);
  if (!result) {
    return notFound(res, 'Workbook not found');
  }
  return res.json(result);
});

app.post('/api/sessions', (req, res) => {
  const workbook = requireWorkbook(req, res);
  if (!workbook) {
    return;
  }
  const userId = req.body?.userId;
  if (typeof userId !== 'string' || !userId.trim()) {
    return badRequest(res, 'userId is required');
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId.trim());
  if (!user) {
    return badRequest(res, 'Unknown user');
  }
  const sessionId = makeId('sess');
  const timestamp = now();
  const session = {
    id: sessionId,
    workbook_id: workbook.id,
    user_id: user.id,
    color: hashColor(sessionId),
    created_at: timestamp,
    updated_at: timestamp,
    closed_at: null,
    selection: null,
    active_address: null,
    claimed_user_id: user.id,
  };
  db.prepare(`
    INSERT INTO sessions (id, workbook_id, user_id, color, created_at, updated_at, closed_at, selection, active_address, claimed_user_id)
    VALUES (@id, @workbook_id, @user_id, @color, @created_at, @updated_at, @closed_at, @selection, @active_address, @claimed_user_id)
  `).run(session);
  return res.status(201).json({
    sessionId,
    workbookId: workbook.id,
    userId: user.id,
    userName: user.name,
    color: session.color,
    createdAt: timestamp,
  });
});

app.post('/api/sessions/:id/heartbeat', (req, res) => {
  const sessionId = req.params.id;
  const row = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
  if (!row) {
    return notFound(res, 'Session not found');
  }
  if (!currentSessionActive(row)) {
    return conflict(res, 'Editing session has expired or been closed');
  }
  let selection = null;
  try {
    selection = parseSelectionBody(req.body?.selection);
  } catch (error) {
    return badRequest(res, error.message);
  }
  const activeAddress = typeof req.body?.activeAddress === 'string' && req.body.activeAddress.trim()
    ? req.body.activeAddress.trim().toUpperCase()
    : null;
  if (activeAddress && !/^[A-Z]{1,3}[1-9]\d*$/.test(activeAddress)) {
    return badRequest(res, 'activeAddress must be a valid cell address');
  }
  const updated = updateSessionHeartbeat(sessionId, selection, activeAddress);
  if (!updated) {
    return conflict(res, 'Editing session has expired or been closed');
  }
  return res.json(sessionPayload(updated));
});

app.post('/api/sessions/:id/close', (req, res) => {
  const sessionId = req.params.id;
  const row = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
  if (!row) {
    return notFound(res, 'Session not found');
  }
  if (!row.closed_at) {
    db.prepare('UPDATE sessions SET closed_at = ?, updated_at = ? WHERE id = ?').run(now(), now(), sessionId);
  }
  return res.json({ ok: true });
});

app.post('/api/workbooks/:id/save', (req, res) => {
  const workbookRow = requireWorkbook(req, res);
  if (!workbookRow) {
    return;
  }
  const session = requireSession(req, res, workbookRow.id);
  if (!session) {
    return;
  }
  const baseRevision = Number(req.body?.baseRevision);
  if (!Number.isInteger(baseRevision)) {
    return badRequest(res, 'baseRevision must be an integer');
  }
  if (!isPlainObject(req.body?.workbook)) {
    return badRequest(res, 'workbook snapshot is required');
  }
  let nextSnapshot;
  try {
    nextSnapshot = normalizeWorkbookSnapshot(req.body.workbook);
  } catch (error) {
    return badRequest(res, error.message);
  }
  if (nextSnapshot.id !== workbookRow.id) {
    return badRequest(res, 'Workbook identity does not match the target workbook');
  }
  const currentSnapshot = getCurrentSnapshot(workbookRow.id);
  if (!currentSnapshot) {
    return conflict(res, 'Current workbook revision is unavailable');
  }
  if (!sameWorkbookIdentity(currentSnapshot, nextSnapshot)) {
    return badRequest(res, 'Workbook title or sheet identities cannot change during save');
  }
  if (baseRevision > workbookRow.current_revision) {
    return badRequest(res, 'baseRevision is invalid');
  }
  const baseSnapshot = loadSnapshot(workbookRow.id, baseRevision);
  if (!baseSnapshot) {
    return badRequest(res, 'baseRevision does not exist');
  }
  const incomingDiffs = diffSnapshots(baseSnapshot, nextSnapshot);
  const currentDiffs = diffSnapshots(baseSnapshot, currentSnapshot);
  if (incomingDiffs.length === 0) {
    updateSessionHeartbeat(session.id, session.selection ? JSON.parse(session.selection) : null, session.active_address || null);
    return res.json({
      ok: true,
      changed: false,
      revision: workbookRow.current_revision,
      workbook: currentSnapshot,
      merged: false,
      autosaved: req.body?.kind === 'autosave',
    });
  }
  let finalSnapshot = nextSnapshot;
  let merged = false;
  if (baseRevision !== workbookRow.current_revision) {
    const currentDiffKeys = new Set(currentDiffs.map((diff) => `${diff.sheetId}::${diff.address}`));
    const conflicts = incomingDiffs.filter((diff) => currentDiffKeys.has(`${diff.sheetId}::${diff.address}`));
    if (conflicts.length > 0) {
      return conflict(res, 'The save overlaps with changes that were already saved by someone else', {
        workbookId: workbookRow.id,
        baseRevision,
        currentRevision: workbookRow.current_revision,
        conflicts: conflicts.map((entry) => ({
          sheetId: entry.sheetId,
          address: entry.address,
          clientValue: entry.toValue,
          serverValue: currentSnapshot.sheets.find((sheet) => sheet.id === entry.sheetId)?.cells?.[entry.address] ?? '',
        })),
      });
    }
    finalSnapshot = applyDiffs(currentSnapshot, incomingDiffs);
    merged = true;
  }
  const timestamp = now();
  const nextRevision = workbookRow.current_revision + 1;
  const saveKind = typeof req.body?.kind === 'string' && req.body.kind.trim() ? req.body.kind.trim() : 'manual';
  const tx = db.transaction(() => {
    db.prepare('UPDATE workbooks SET current_revision = ?, updated_at = ? WHERE id = ?').run(nextRevision, timestamp, workbookRow.id);
    db.prepare('INSERT INTO revisions (workbook_id, revision, created_at, user_id, session_id, kind, snapshot) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
      workbookRow.id,
      nextRevision,
      timestamp,
      session.user_id,
      session.id,
      saveKind,
      JSON.stringify(finalSnapshot),
    );
  });
  tx();
  updateSessionHeartbeat(session.id, session.selection ? JSON.parse(session.selection) : null, session.active_address || null);
  return res.json({
    ok: true,
    changed: true,
    revision: nextRevision,
    workbook: finalSnapshot,
    merged,
    autosaved: saveKind === 'autosave',
  });
});

app.get('/api/users', (req, res) => {
  return res.json({ users: getUsers() });
});

app.get('/', (req, res) => {
  return res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return notFound(res);
  }
  return res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.use((err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }
  console.error(err);
  return res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, HOST, () => {
  console.log(`GridForge listening on http://${HOST}:${PORT}`);
});
