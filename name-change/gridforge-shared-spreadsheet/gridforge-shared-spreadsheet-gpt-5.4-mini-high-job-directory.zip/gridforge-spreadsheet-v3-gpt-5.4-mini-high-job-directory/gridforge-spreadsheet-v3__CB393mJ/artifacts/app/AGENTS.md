# GridForge repository notes

- Runtime entrypoint: `server.js`
- Local static assets live in `public/`
- SQLite database path: `/app/gridforge.sqlite3`
- Seed workbook source: `/assets/workbook_seed.json`
- The delivered app seeds the Northwind Operations Plan only on first database initialization.
- Active sessions expire after a short heartbeat window, so presence is refreshed frequently.
- Keep workbook and revision API routes in sync with `APP_MANIFEST.md`.
