# GridForge App Manifest

## Start

```bash start
npm start
```

## SQLite database

- `/app/gridforge.sqlite3`

## Main API routes

- `GET /api/bootstrap`
- `GET /api/workbooks/:id/state`
- `POST /api/workbooks/:id/save`
- `GET /api/workbooks/:id/revisions`
- `GET /api/workbooks/:id/revisions/:revision`
- `POST /api/workbooks/:id/revisions/:revision/restore`
- `GET /api/workbooks/:id/cells/:address/history`
