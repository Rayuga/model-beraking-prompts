(() => {
  const ROWS = 80;
  const COLS = 20;
  const FUNCTION_NAMES = ['SUM', 'AVG', 'MIN', 'MAX', 'COUNT'];
  const SHORTCUT_FUNCTIONS = new Set(FUNCTION_NAMES);
  const CELL_WIDTH = 112;
  const CELL_HEIGHT = 28;
  const HEADER_WIDTH = 52;
  const HEADER_HEIGHT = 30;
  const AUTOSAVE_DELAY = 4500;
  const SYNC_INTERVAL = 2500;

  const els = {
    workbookTitle: document.getElementById('workbookTitle'),
    saveStatus: document.getElementById('saveStatus'),
    userSelect: document.getElementById('userSelect'),
    newViewButton: document.getElementById('newViewButton'),
    saveNowButton: document.getElementById('saveNowButton'),
    undoButton: document.getElementById('undoButton'),
    redoButton: document.getElementById('redoButton'),
    nameBox: document.getElementById('nameBox'),
    formulaBar: document.getElementById('formulaBar'),
    editCellButton: document.getElementById('editCellButton'),
    fillDownButton: document.getElementById('fillDownButton'),
    fillRightButton: document.getElementById('fillRightButton'),
    restoreLatestButton: document.getElementById('restoreLatestButton'),
    sheetName: document.getElementById('sheetName'),
    revisionBadge: document.getElementById('revisionBadge'),
    sheetScroller: document.getElementById('sheetScroller'),
    formulaSuggestions: document.getElementById('formulaSuggestions'),
    presenceList: document.getElementById('presenceList'),
    findInput: document.getElementById('findInput'),
    replaceInput: document.getElementById('replaceInput'),
    findNextButton: document.getElementById('findNextButton'),
    replaceCurrentButton: document.getElementById('replaceCurrentButton'),
    replaceAllButton: document.getElementById('replaceAllButton'),
    searchSummary: document.getElementById('searchSummary'),
    cellHistory: document.getElementById('cellHistory'),
    revisionList: document.getElementById('revisionList'),
    sessionOverlay: document.getElementById('sessionOverlay'),
    sessionUsers: document.getElementById('sessionUsers'),
    messageBar: document.getElementById('messageBar'),
    hiddenEditor: document.getElementById('hiddenEditor'),
  };

  const state = {
    users: [],
    workbookId: 'ops-plan',
    workbookTitle: '',
    currentSheetIndex: 0,
    baseSnapshot: null,
    baseRevision: 0,
    draftSnapshot: null,
    currentRevision: 0,
    savedAt: 0,
    presence: [],
    revisions: [],
    session: null,
    editing: null,
    activeAddress: 'A1',
    selection: { r1: 1, c1: 1, r2: 1, c2: 1 },
    previewRevision: null,
    previewSnapshot: null,
    dirty: false,
    saveState: 'saved',
    saveMessage: '',
    undoStack: [],
    redoStack: [],
    searchQuery: '',
    replaceValue: '',
    searchMatches: [],
    searchIndex: -1,
    selectedHistoryAddress: 'A1',
    cellHistory: [],
    conflictCells: new Set(),
    autosaveTimer: null,
    syncTimer: null,
    syncInFlight: false,
    saveInFlight: false,
    dragging: false,
    dragStart: null,
    formulaRefMode: false,
    formulaRefInsertedAt: null,
    formulaSuggestions: [],
    formulaSuggestionIndex: 0,
  };

  const colCache = new Map();
  const rowCache = new Map();
  const addressPattern = /^[A-Z]{1,3}[1-9]\d*$/;

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function showMessage(text, kind = 'info') {
    els.messageBar.textContent = text;
    els.messageBar.className = `message-bar show ${kind}`;
    window.clearTimeout(showMessage._timer);
    showMessage._timer = window.setTimeout(() => {
      els.messageBar.className = 'message-bar';
    }, 2600);
  }

  function setStatus(text) {
    els.saveStatus.textContent = text;
  }

  function numberToColumn(number) {
    if (colCache.has(number)) {
      return colCache.get(number);
    }
    let n = number;
    let out = '';
    while (n > 0) {
      const remainder = (n - 1) % 26;
      out = String.fromCharCode(65 + remainder) + out;
      n = Math.floor((n - 1) / 26);
    }
    colCache.set(number, out);
    return out;
  }

  function columnToNumber(label) {
    const upper = label.toUpperCase();
    let value = 0;
    for (const char of upper) {
      value = (value * 26) + (char.charCodeAt(0) - 64);
    }
    return value;
  }

  function addressToCoords(address) {
    const match = String(address).toUpperCase().match(/^([A-Z]{1,3})([1-9]\d*)$/);
    if (!match) {
      throw new Error(`Invalid cell address: ${address}`);
    }
    return {
      col: columnToNumber(match[1]),
      row: Number(match[2]),
    };
  }

  function coordsToAddress(row, col) {
    if (!rowCache.has(`${row}:${col}`)) {
      rowCache.set(`${row}:${col}`, `${numberToColumn(col)}${row}`);
    }
    return rowCache.get(`${row}:${col}`);
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function rectFromSelection(selection) {
    return {
      r1: Math.min(selection.r1, selection.r2),
      c1: Math.min(selection.c1, selection.c2),
      r2: Math.max(selection.r1, selection.r2),
      c2: Math.max(selection.c1, selection.c2),
    };
  }

  function selectionToAddress(selection) {
    const rect = rectFromSelection(selection);
    const start = coordsToAddress(rect.r1, rect.c1);
    const end = coordsToAddress(rect.r2, rect.c2);
    return start === end ? start : `${start}:${end}`;
  }

  function parseAddressRange(text) {
    const value = String(text).trim().toUpperCase();
    if (addressPattern.test(value)) {
      const coords = addressToCoords(value);
      return { ...coords, r2: coords.row, c2: coords.col };
    }
    const match = value.match(/^([A-Z]{1,3}[1-9]\d*):([A-Z]{1,3}[1-9]\d*)$/);
    if (!match) {
      throw new Error('Enter a cell address like A1 or a range like A1:C3');
    }
    const start = addressToCoords(match[1]);
    const end = addressToCoords(match[2]);
    return {
      r1: Math.min(start.row, end.row),
      c1: Math.min(start.col, end.col),
      r2: Math.max(start.row, end.row),
      c2: Math.max(start.col, end.col),
    };
  }

  function isPlainObject(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
  }

  function snapshotSheet(snapshot) {
    return snapshot.sheets[state.currentSheetIndex];
  }

  function getDisplaySnapshot() {
    return state.previewSnapshot || state.draftSnapshot;
  }

  function getSheetById(snapshot, sheetId) {
    return snapshot.sheets.find((sheet) => sheet.id === sheetId) || snapshot.sheets[0];
  }

  function getCurrentSheet() {
    const snapshot = getDisplaySnapshot();
    return snapshot ? snapshot.sheets[state.currentSheetIndex] : null;
  }

  function getRawCell(snapshot, address, sheetIndex = state.currentSheetIndex) {
    const sheet = snapshot.sheets[sheetIndex];
    return sheet.cells?.[address] ?? '';
  }

  function setRawCell(snapshot, address, value, sheetIndex = state.currentSheetIndex) {
    const sheet = snapshot.sheets[sheetIndex];
    sheet.cells = sheet.cells || {};
    if (value === '') {
      delete sheet.cells[address];
    } else {
      sheet.cells[address] = value;
    }
  }

  function cellAddressesInRect(rect) {
    const addresses = [];
    for (let row = rect.r1; row <= rect.r2; row += 1) {
      for (let col = rect.c1; col <= rect.c2; col += 1) {
        addresses.push(coordsToAddress(row, col));
      }
    }
    return addresses;
  }

  function normalizeSelection(selection) {
    return rectFromSelection({
      r1: clamp(selection.r1, 1, ROWS),
      c1: clamp(selection.c1, 1, COLS),
      r2: clamp(selection.r2, 1, ROWS),
      c2: clamp(selection.c2, 1, COLS),
    });
  }

  function selectRect(rect, { active = true, scroll = true } = {}) {
    const next = normalizeSelection(rect);
    state.selection = next;
    if (active) {
      state.activeAddress = coordsToAddress(next.r2, next.c2);
    }
    if (scroll) {
      scrollSelectionIntoView(next);
    }
    state.formulaRefMode = false;
    renderAll();
    heartbeatSoon();
    fetchCellHistory();
  }

  function moveSelection(rowDelta, colDelta, extend = false) {
    const focus = { r: state.selection.r2, c: state.selection.c2 };
    const next = {
      r1: extend ? state.selection.r1 : clamp(focus.r + rowDelta, 1, ROWS),
      c1: extend ? state.selection.c1 : clamp(focus.c + colDelta, 1, COLS),
      r2: clamp(focus.r + rowDelta, 1, ROWS),
      c2: clamp(focus.c + colDelta, 1, COLS),
    };
    selectRect(next, { scroll: true });
  }

  function focusGrid() {
    els.sheetScroller.focus();
  }

  function scrollSelectionIntoView(selection) {
    const cell = getCellElement(selection.r2, selection.c2);
    if (cell) {
      cell.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
  }

  function getCellElement(row, col) {
    return document.querySelector(`[data-row="${row}"][data-col="${col}"]`);
  }

  function pushUndo(reason = '') {
    state.undoStack.push({
      snapshot: clone(state.draftSnapshot),
      selection: clone(state.selection),
      activeAddress: state.activeAddress,
      reason,
    });
    if (state.undoStack.length > 100) {
      state.undoStack.shift();
    }
    state.redoStack.length = 0;
    updateUndoRedoButtons();
  }

  function applySnapshot(snapshot, { markDirty = false } = {}) {
    state.draftSnapshot = clone(snapshot);
    if (!state.baseSnapshot) {
      state.baseSnapshot = clone(snapshot);
    }
    state.currentRevision = state.currentRevision || 0;
    state.dirty = markDirty;
    state.conflictCells = new Set();
    refreshComputedState();
    renderAll();
  }

  function setDraftCell(address, value) {
    const snapshot = clone(state.draftSnapshot);
    setRawCell(snapshot, address, value);
    state.draftSnapshot = snapshot;
  }

  function sameSelection(a, b) {
    return a.r1 === b.r1 && a.c1 === b.c1 && a.r2 === b.r2 && a.c2 === b.c2;
  }

  function valuesEqual(a, b) {
    return a === b;
  }

  function diffSnapshots(baseSnapshot, nextSnapshot) {
    const diffs = [];
    const baseSheet = baseSnapshot.sheets[state.currentSheetIndex];
    const nextSheet = nextSnapshot.sheets[state.currentSheetIndex];
    const addresses = new Set([
      ...Object.keys(baseSheet.cells || {}),
      ...Object.keys(nextSheet.cells || {}),
    ]);
    for (const address of addresses) {
      const fromValue = baseSheet.cells?.[address] ?? '';
      const toValue = nextSheet.cells?.[address] ?? '';
      if (fromValue !== toValue) {
        diffs.push({ address, fromValue, toValue });
      }
    }
    return diffs;
  }

  function applyDiffs(snapshot, diffs) {
    const next = clone(snapshot);
    const sheet = next.sheets[state.currentSheetIndex];
    sheet.cells = sheet.cells || {};
    for (const diff of diffs) {
      if (diff.toValue === '') {
        delete sheet.cells[diff.address];
      } else {
        sheet.cells[diff.address] = diff.toValue;
      }
    }
    return next;
  }

  function sameWorkbookIdentity(a, b) {
    if (a.id !== b.id || a.title !== b.title || a.sheets.length !== b.sheets.length) {
      return false;
    }
    for (let index = 0; index < a.sheets.length; index += 1) {
      if (a.sheets[index].id !== b.sheets[index].id || a.sheets[index].name !== b.sheets[index].name) {
        return false;
      }
    }
    return true;
  }

  function isNumericText(text) {
    return /^-?(?:\d+\.?\d*|\.\d+)$/.test(String(text).trim());
  }

  function parseNumeric(text) {
    return Number(String(text).trim());
  }

  function isFormulaText(text) {
    return typeof text === 'string' && text.startsWith('=');
  }

  function isIncompleteFormula(formula) {
    const body = formula.slice(1).trim();
    if (!body) {
      return true;
    }
    if (/[+\-*/(:,]$/.test(body)) {
      return true;
    }
    let depth = 0;
    for (const char of body) {
      if (char === '(') depth += 1;
      if (char === ')') depth -= 1;
    }
    if (depth > 0) {
      return true;
    }
    return false;
  }

  function tokenizeFormula(input) {
    const tokens = [];
    let index = 0;
    while (index < input.length) {
      const char = input[index];
      if (/\s/.test(char)) {
        index += 1;
        continue;
      }
      if ('+-*/(),:'.includes(char)) {
        tokens.push({ type: char, value: char });
        index += 1;
        continue;
      }
      if (/\d|\./.test(char)) {
        let end = index + 1;
        while (end < input.length && /[\d.]/.test(input[end])) {
          end += 1;
        }
        tokens.push({ type: 'number', value: input.slice(index, end) });
        index = end;
        continue;
      }
      if (/[A-Za-z]/.test(char)) {
        let end = index + 1;
        while (end < input.length && /[A-Za-z0-9_]/.test(input[end])) {
          end += 1;
        }
        const value = input.slice(index, end).toUpperCase();
        if (/^[A-Z]{1,3}[1-9]\d*$/.test(value)) {
          tokens.push({ type: 'cell', value });
        } else {
          tokens.push({ type: 'ident', value });
        }
        index = end;
        continue;
      }
      throw new Error(`Unexpected character '${char}' in formula`);
    }
    tokens.push({ type: 'eof', value: '' });
    return tokens;
  }

  function parseFormula(input) {
    const tokens = tokenizeFormula(input);
    let cursor = 0;

    function peek() {
      return tokens[cursor];
    }

    function consume(type) {
      const token = peek();
      if (type && token.type !== type) {
        throw new Error(`Expected ${type} but found ${token.type}`);
      }
      cursor += 1;
      return token;
    }

    function parseExpression() {
      let node = parseTerm();
      while (peek().type === '+' || peek().type === '-') {
        const operator = consume().type;
        node = { type: 'binary', operator, left: node, right: parseTerm() };
      }
      return node;
    }

    function parseTerm() {
      let node = parseFactor();
      while (peek().type === '*' || peek().type === '/') {
        const operator = consume().type;
        node = { type: 'binary', operator, left: node, right: parseFactor() };
      }
      return node;
    }

    function parseFactor() {
      const token = peek();
      if (token.type === '+' || token.type === '-') {
        const operator = consume().type;
        return { type: 'unary', operator, value: parseFactor() };
      }
      return parsePrimary();
    }

    function parsePrimary() {
      const token = peek();
      if (token.type === 'number') {
        consume('number');
        return { type: 'number', value: Number(token.value) };
      }
      if (token.type === 'cell') {
        consume('cell');
        if (peek().type === ':') {
          consume(':');
          const end = consume('cell');
          return { type: 'range', start: token.value, end: end.value };
        }
        return { type: 'cell', ref: token.value };
      }
      if (token.type === 'ident') {
        const name = consume('ident').value;
        consume('(');
        const args = [];
        if (peek().type !== ')') {
          while (true) {
            args.push(parseExpression());
            if (peek().type === ',') {
              consume(',');
              continue;
            }
            break;
          }
        }
        if (peek().type !== ')') {
          throw new Error('Expected closing parenthesis');
        }
        consume(')');
        return { type: 'function', name, args };
      }
      if (token.type === '(') {
        consume('(');
        const node = parseExpression();
        if (peek().type !== ')') {
          throw new Error('Expected closing parenthesis');
        }
        consume(')');
        return node;
      }
      throw new Error('Unexpected end of formula');
    }

    const expression = parseExpression();
    if (peek().type !== 'eof') {
      throw new Error(`Unexpected token ${peek().type}`);
    }
    return expression;
  }

  function expandRange(start, end) {
    const startCoords = addressToCoords(start);
    const endCoords = addressToCoords(end);
    const rows = [];
    const minRow = Math.min(startCoords.row, endCoords.row);
    const maxRow = Math.max(startCoords.row, endCoords.row);
    const minCol = Math.min(startCoords.col, endCoords.col);
    const maxCol = Math.max(startCoords.col, endCoords.col);
    for (let row = minRow; row <= maxRow; row += 1) {
      for (let col = minCol; col <= maxCol; col += 1) {
        rows.push(coordsToAddress(row, col));
      }
    }
    return rows;
  }

  function evaluateWorkbook(snapshot) {
    const sheet = snapshot.sheets[state.currentSheetIndex];
    const memo = new Map();
    const visiting = new Set();

    function cellToValue(address) {
      if (memo.has(address)) {
        return memo.get(address);
      }
      if (visiting.has(address)) {
        const error = new Error('Circular reference');
        error.code = 'CIRCULAR';
        throw error;
      }
      visiting.add(address);
      const raw = sheet.cells?.[address] ?? '';
      let value = raw;
      if (isFormulaText(raw) && raw.length > 1) {
        try {
          const ast = parseFormula(raw.slice(1));
          value = evaluateNode(ast);
        } catch (error) {
          value = { error: error.code === 'CIRCULAR' ? 'Circular reference' : error.message };
        }
      }
      visiting.delete(address);
      memo.set(address, value);
      return value;
    }

    function toNumeric(value) {
      if (typeof value === 'number') {
        return value;
      }
      if (typeof value === 'string') {
        if (value.trim() === '') {
          return 0;
        }
        if (isNumericText(value)) {
          return parseNumeric(value);
        }
      }
      throw new Error('Expected a number');
    }

    function flattenValues(nodeValue) {
      if (Array.isArray(nodeValue)) {
        return nodeValue.flat();
      }
      return [nodeValue];
    }

    function evaluateNode(node) {
      switch (node.type) {
        case 'number':
          return node.value;
        case 'cell':
          return cellToValue(node.ref);
        case 'range':
          return expandRange(node.start, node.end).map((address) => cellToValue(address));
        case 'unary': {
          const inner = toNumeric(evaluateNode(node.value));
          return node.operator === '-' ? -inner : inner;
        }
        case 'binary': {
          const left = toNumeric(evaluateNode(node.left));
          const right = toNumeric(evaluateNode(node.right));
          switch (node.operator) {
            case '+': return left + right;
            case '-': return left - right;
            case '*': return left * right;
            case '/':
              if (right === 0) {
                throw new Error('Division by zero');
              }
              return left / right;
            default:
              throw new Error(`Unsupported operator ${node.operator}`);
          }
        }
        case 'function': {
          const args = node.args.flatMap((arg) => flattenValues(evaluateNode(arg)));
          const numbers = args
            .map((item) => {
              try {
                return toNumeric(item);
              } catch (error) {
                return null;
              }
            })
            .filter((item) => item !== null);
          switch (node.name) {
            case 'SUM':
              return numbers.reduce((total, value) => total + value, 0);
            case 'AVG':
              if (numbers.length === 0) {
                throw new Error('AVG requires at least one numeric value');
              }
              return numbers.reduce((total, value) => total + value, 0) / numbers.length;
            case 'MIN':
              if (numbers.length === 0) {
                throw new Error('MIN requires at least one numeric value');
              }
              return Math.min(...numbers);
            case 'MAX':
              if (numbers.length === 0) {
                throw new Error('MAX requires at least one numeric value');
              }
              return Math.max(...numbers);
            case 'COUNT':
              return args.filter((item) => item !== '' && item != null).length;
            default:
              throw new Error(`Unknown function ${node.name}`);
          }
        }
        default:
          throw new Error(`Unsupported formula node ${node.type}`);
      }
    }

    const computed = {};
    const errors = {};
    for (let row = 1; row <= ROWS; row += 1) {
      for (let col = 1; col <= COLS; col += 1) {
        const address = coordsToAddress(row, col);
        const raw = sheet.cells?.[address] ?? '';
        if (isFormulaText(raw) && raw.length > 1 && !isIncompleteFormula(raw)) {
          try {
            computed[address] = cellToValue(address);
          } catch (error) {
            computed[address] = { error: error.code === 'CIRCULAR' ? 'Circular reference' : error.message };
            errors[address] = computed[address].error;
          }
        } else {
          computed[address] = raw;
        }
      }
    }
    return { computed, errors };
  }

  function formatDisplayValue(raw, computed) {
    if (raw === '') {
      return '';
    }
    if (raw.startsWith('=') && typeof computed === 'object' && computed && computed.error) {
      return computed.error.startsWith('Circular') ? '#CIRCULAR!' : `#ERROR: ${computed.error}`;
    }
    if (raw.startsWith('=') && isIncompleteFormula(raw)) {
      return raw;
    }
    if (raw.startsWith('=') && computed != null && typeof computed === 'object' && computed.error) {
      return `#ERROR: ${computed.error}`;
    }
    if (raw.startsWith('=') && computed != null && typeof computed !== 'object') {
      return String(computed);
    }
    return raw;
  }

  function refreshComputedState() {
    const snapshot = getDisplaySnapshot();
    if (!snapshot) {
      return;
    }
    state.computed = evaluateWorkbook(snapshot);
  }

  function renderShell() {
    const snapshot = getDisplaySnapshot();
    if (!snapshot) {
      return;
    }
    els.workbookTitle.textContent = snapshot.title;
    els.sheetName.textContent = snapshot.sheets[state.currentSheetIndex].name;
    els.revisionBadge.textContent = state.previewRevision
      ? `Previewing revision ${state.previewRevision}`
      : `Saved revision ${state.currentRevision}${state.dirty ? ' • unsaved edits' : ''}`;
    updateStatusBadge();
    syncInputs();
  }

  function updateStatusBadge() {
    if (state.previewRevision) {
      setStatus(`Previewing revision ${state.previewRevision}. Restore it or return to the latest saved version.`);
      return;
    }
    if (state.saveState === 'saving') {
      setStatus('Saving…');
      return;
    }
    if (state.saveState === 'conflict') {
      setStatus(state.saveMessage || 'Conflict detected. Resolve the highlighted cell changes before saving.');
      return;
    }
    if (state.dirty) {
      setStatus('Unsaved edits');
      return;
    }
    setStatus(`Saved revision ${state.currentRevision}${state.saveMessage ? ` • ${state.saveMessage}` : ''}`);
  }

  function updateUndoRedoButtons() {
    els.undoButton.disabled = state.undoStack.length === 0;
    els.redoButton.disabled = state.redoStack.length === 0;
  }

  function renderPresence() {
    els.presenceList.innerHTML = '';
    if (state.presence.length === 0) {
      els.presenceList.innerHTML = '<div class="muted">No other active views yet.</div>';
      return;
    }
    for (const session of state.presence) {
      const item = document.createElement('div');
      item.className = 'presence-item';
      const selectionText = session.selection ? selectionToAddress(session.selection) : 'No selection';
      item.innerHTML = `
        <div>
          <strong><span class="presence-dot" style="background:${session.color}"></span>${escapeHtml(session.userName)}</strong>
          <div class="presence-meta">${escapeHtml(selectionText)}${session.activeAddress ? ` • ${escapeHtml(session.activeAddress)}` : ''}</div>
        </div>
        <div class="badge" style="color:${session.color}; background:${session.color}22">${escapeHtml(session.id === state.session?.sessionId ? 'You' : 'Here')}</div>
      `;
      els.presenceList.appendChild(item);
    }
  }

  function renderRevisions() {
    els.revisionList.innerHTML = '';
    if (state.revisions.length === 0) {
      els.revisionList.innerHTML = '<div class="muted">No revisions yet.</div>';
      return;
    }
    for (const revision of state.revisions) {
      const item = document.createElement('div');
      item.className = 'revision-item';
      const timestamp = new Date(revision.createdAt).toLocaleString();
      item.innerHTML = `
        <div>
          <strong>Revision ${revision.revision}${revision.revision === state.currentRevision ? ' • latest' : ''}</strong>
          <div class="revision-meta muted">${escapeHtml(timestamp)} • ${escapeHtml(revision.userName)} • ${escapeHtml(revision.kind)}</div>
        </div>
      `;
      const actions = document.createElement('div');
      actions.className = 'button-row';
      const previewButton = document.createElement('button');
      previewButton.type = 'button';
      previewButton.textContent = 'Preview';
      previewButton.addEventListener('click', () => previewRevision(revision.revision));
      const restoreButton = document.createElement('button');
      restoreButton.type = 'button';
      restoreButton.textContent = 'Restore';
      restoreButton.addEventListener('click', () => restoreRevision(revision.revision));
      actions.appendChild(previewButton);
      actions.appendChild(restoreButton);
      item.appendChild(actions);
      els.revisionList.appendChild(item);
    }
  }

  function renderHistory() {
    els.cellHistory.innerHTML = '';
    if (!state.cellHistory.length) {
      els.cellHistory.innerHTML = '<div class="muted">Select a cell to see its changes.</div>';
      return;
    }
    for (const entry of state.cellHistory.slice().reverse()) {
      const item = document.createElement('div');
      item.className = 'history-item';
      item.innerHTML = `
        <strong>Revision ${entry.revision}</strong>
        <div class="muted">${escapeHtml(new Date(entry.at).toLocaleString())} • ${escapeHtml(entry.userName)} • ${escapeHtml(entry.kind)}</div>
        <div class="stack" style="margin-top:0.35rem;">
          <div><span class="muted">Previous:</span> ${escapeHtml(entry.previousValue || '(blank)')}</div>
          <div><span class="muted">New:</span> ${escapeHtml(entry.newValue || '(blank)')}</div>
        </div>
      `;
      els.cellHistory.appendChild(item);
    }
  }

  function renderSearchSummary() {
    if (!state.searchQuery) {
      els.searchSummary.textContent = 'Search the visible sheet values.';
      return;
    }
    els.searchSummary.textContent = `${state.searchMatches.length} match${state.searchMatches.length === 1 ? '' : 'es'}${state.searchIndex >= 0 ? ` • current ${state.searchIndex + 1}` : ''}`;
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function getVisibleSnapshot() {
    return state.previewSnapshot || state.draftSnapshot;
  }

  function cellClassNames(row, col, address) {
    const classes = ['grid-cell'];
    const rect = rectFromSelection(state.selection);
    if (row >= rect.r1 && row <= rect.r2 && col >= rect.c1 && col <= rect.c2) {
      classes.push('selected');
    }
    if (address === state.activeAddress) {
      classes.push('active');
    }
    if (state.conflictCells.has(address)) {
      classes.push('conflict');
    }
    const raw = getRawCell(getVisibleSnapshot(), address);
    const computed = state.computed?.computed?.[address];
    if (raw.startsWith('=') && computed && typeof computed === 'object' && computed.error) {
      classes.push('error');
    }
    if (state.previewRevision) {
      classes.push('previewed');
    }
    return classes.join(' ');
  }

  function renderGrid() {
    const snapshot = getVisibleSnapshot();
    if (!snapshot) {
      return;
    }
    const sheet = snapshot.sheets[state.currentSheetIndex];
    const stage = document.createElement('div');
    stage.className = 'sheet-stage';
    stage.style.width = `${HEADER_WIDTH + COLS * CELL_WIDTH}px`;
    stage.style.height = `${HEADER_HEIGHT + ROWS * CELL_HEIGHT}px`;

    const grid = document.createElement('div');
    grid.className = 'sheet-grid';

    const corner = document.createElement('div');
    corner.className = 'grid-corner';
    corner.textContent = '';
    grid.appendChild(corner);

    for (let col = 1; col <= COLS; col += 1) {
      const header = document.createElement('div');
      header.className = 'col-header';
      header.textContent = numberToColumn(col);
      grid.appendChild(header);
    }

    for (let row = 1; row <= ROWS; row += 1) {
      const rowHeader = document.createElement('div');
      rowHeader.className = 'row-header';
      rowHeader.textContent = row;
      grid.appendChild(rowHeader);
      for (let col = 1; col <= COLS; col += 1) {
        const address = coordsToAddress(row, col);
        const cell = document.createElement('div');
        cell.className = cellClassNames(row, col, address);
        cell.dataset.row = String(row);
        cell.dataset.col = String(col);
        cell.dataset.address = address;
        const raw = sheet.cells?.[address] ?? '';
        const computed = state.computed?.computed?.[address];
        cell.textContent = formatCellDisplay(raw, computed);
        cell.addEventListener('pointerdown', onCellPointerDown);
        cell.addEventListener('dblclick', () => beginEdit(address, raw));
        grid.appendChild(cell);
      }
    }

    stage.appendChild(grid);
    const selectionLayer = document.createElement('div');
    selectionLayer.className = 'selection-layer';
    renderSelectionOverlays(selectionLayer, snapshot);
    stage.appendChild(selectionLayer);

    const suggestionLayer = document.createElement('div');
    suggestionLayer.className = 'suggestion-layer';
    stage.appendChild(suggestionLayer);

    if (state.editing && state.editing.address) {
      const editor = document.createElement('input');
      editor.className = 'editor-input';
      editor.type = 'text';
      editor.autocomplete = 'off';
      editor.spellcheck = false;
      editor.value = state.editing.value;
      editor.style.left = `${HEADER_WIDTH + (state.selection.c2 - 1) * CELL_WIDTH}px`;
      editor.style.top = `${HEADER_HEIGHT + (state.selection.r2 - 1) * CELL_HEIGHT}px`;
      editor.style.width = `${CELL_WIDTH}px`;
      editor.style.height = `${CELL_HEIGHT}px`;
      editor.addEventListener('keydown', onEditorKeyDown);
      editor.addEventListener('input', onEditorInput);
      editor.addEventListener('blur', commitEditorFromBlur);
      stage.appendChild(editor);
      queueMicrotask(() => {
        editor.focus();
        editor.setSelectionRange(editor.value.length, editor.value.length);
      });
    }

    els.sheetScroller.innerHTML = '';
    els.sheetScroller.appendChild(stage);
    if (state.editing && state.editing.address) {
      const editor = stage.querySelector('.editor-input');
      if (editor) {
        renderSuggestions(stage, editor);
      }
    }
  }

  function renderSelectionOverlays(layer) {
    const rect = rectFromSelection(state.selection);
    const own = document.createElement('div');
    own.className = 'selection-box';
    own.style.left = `${HEADER_WIDTH + (rect.c1 - 1) * CELL_WIDTH}px`;
    own.style.top = `${HEADER_HEIGHT + (rect.r1 - 1) * CELL_HEIGHT}px`;
    own.style.width = `${(rect.c2 - rect.c1 + 1) * CELL_WIDTH}px`;
    own.style.height = `${(rect.r2 - rect.r1 + 1) * CELL_HEIGHT}px`;
    const ownLabel = document.createElement('div');
    ownLabel.className = 'selection-label';
    ownLabel.style.background = 'var(--accent)';
    ownLabel.textContent = state.selection.r1 === state.selection.r2 && state.selection.c1 === state.selection.c2
      ? state.activeAddress
      : selectionToAddress(state.selection);
    own.appendChild(ownLabel);
    layer.appendChild(own);

    for (const session of state.presence) {
      if (session.id === state.session?.sessionId || !session.selection) {
        continue;
      }
      const box = document.createElement('div');
      box.className = 'selection-box remote';
      box.style.borderColor = session.color;
      box.style.left = `${HEADER_WIDTH + (Math.min(session.selection.c1, session.selection.c2) - 1) * CELL_WIDTH}px`;
      box.style.top = `${HEADER_HEIGHT + (Math.min(session.selection.r1, session.selection.r2) - 1) * CELL_HEIGHT}px`;
      box.style.width = `${(Math.abs(session.selection.c2 - session.selection.c1) + 1) * CELL_WIDTH}px`;
      box.style.height = `${(Math.abs(session.selection.r2 - session.selection.r1) + 1) * CELL_HEIGHT}px`;
      const label = document.createElement('div');
      label.className = 'selection-label';
      label.style.background = session.color;
      label.textContent = session.userName;
      box.appendChild(label);
      layer.appendChild(box);
    }
  }

  function renderSuggestions(stage, editor) {
    const suggestions = getFormulaSuggestions(editor.value);
    state.formulaSuggestions = suggestions;
    if (!suggestions.length || !editor.value.startsWith('=')) {
      els.formulaSuggestions.classList.add('hidden');
      els.formulaSuggestions.innerHTML = '';
      return;
    }
    const rect = editor.getBoundingClientRect();
    const stageRect = stage.getBoundingClientRect();
    els.formulaSuggestions.style.left = `${rect.left - stageRect.left}px`;
    els.formulaSuggestions.style.top = `${rect.bottom - stageRect.top + 4}px`;
    els.formulaSuggestions.innerHTML = '';
    suggestions.forEach((suggestion, index) => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = `suggestion-item${index === state.formulaSuggestionIndex ? ' active' : ''}`;
      item.textContent = `${suggestion}(`;
      item.addEventListener('mousedown', (event) => {
        event.preventDefault();
        applyFunctionSuggestion(suggestion, editor);
      });
      els.formulaSuggestions.appendChild(item);
    });
    els.formulaSuggestions.classList.remove('hidden');
  }

  function getFormulaSuggestions(text) {
    if (!text.startsWith('=')) {
      return [];
    }
    const body = text.slice(1).toUpperCase();
    const lastTokenMatch = body.match(/([A-Z_]*)$/);
    const prefix = lastTokenMatch ? lastTokenMatch[1] : '';
    return FUNCTION_NAMES.filter((name) => name.startsWith(prefix));
  }

  function applyFunctionSuggestion(name, editor) {
    const start = editor.selectionStart ?? editor.value.length;
    const end = editor.selectionEnd ?? editor.value.length;
    const before = editor.value.slice(0, start);
    const after = editor.value.slice(end);
    const upperBefore = before.toUpperCase();
    const match = upperBefore.match(/([A-Z_]*)$/);
    let nextBefore = before;
    if (match && before.startsWith('=')) {
      nextBefore = before.slice(0, before.length - match[1].length) + name + '(';
    } else {
      nextBefore = `${before}${name}(`;
    }
    editor.value = `${nextBefore}${after}`;
    state.editing.value = editor.value;
    state.formulaRefMode = true;
    editor.focus();
    editor.setSelectionRange(editor.value.length, editor.value.length);
    renderSuggestions(els.sheetScroller.firstChild, editor);
  }

  function formatCellDisplay(raw, computed) {
    if (raw === '') {
      return '';
    }
    if (raw.startsWith('=') && isIncompleteFormula(raw)) {
      return raw;
    }
    if (raw.startsWith('=') && computed && typeof computed === 'object' && computed.error) {
      if (computed.error === 'Circular reference') {
        return '#CIRCULAR!';
      }
      return `#ERROR: ${computed.error}`;
    }
    if (raw.startsWith('=') && computed != null && typeof computed !== 'object') {
      return String(computed);
    }
    return raw;
  }

  function syncInputs() {
    const sheet = getDisplaySnapshot()?.sheets[state.currentSheetIndex];
    if (!sheet) {
      return;
    }
    const raw = sheet.cells?.[state.activeAddress] ?? '';
    if (document.activeElement !== els.formulaBar && !state.editing) {
      els.formulaBar.value = raw;
    }
    if (document.activeElement !== els.nameBox) {
      els.nameBox.value = selectionToAddress(state.selection);
    }
  }

  function renderAll() {
    renderShell();
    renderGrid();
    renderPresence();
    renderRevisions();
    renderHistory();
    renderSearchSummary();
    updateUndoRedoButtons();
    updateFormulaBar();
    updateSelectionStyles();
  }

  function updateSelectionStyles() {
    const sheet = getDisplaySnapshot()?.sheets[state.currentSheetIndex];
    if (!sheet) {
      return;
    }
    const rect = rectFromSelection(state.selection);
    document.querySelectorAll('.grid-cell').forEach((cell) => {
      const row = Number(cell.dataset.row);
      const col = Number(cell.dataset.col);
      const address = cell.dataset.address;
      cell.classList.toggle('selected', row >= rect.r1 && row <= rect.r2 && col >= rect.c1 && col <= rect.c2);
      cell.classList.toggle('active', address === state.activeAddress);
      cell.classList.toggle('conflict', state.conflictCells.has(address));
    });
  }

  function updateFormulaBar() {
    if (document.activeElement !== els.formulaBar) {
      const sheet = getDisplaySnapshot()?.sheets[state.currentSheetIndex];
      if (sheet) {
        els.formulaBar.value = sheet.cells?.[state.activeAddress] ?? '';
      }
    }
  }

  function beginEdit(address, initialValue = null) {
    if (state.previewRevision) {
      showMessage('Exit preview mode before editing.', 'warn');
      return;
    }
    state.activeAddress = address;
    const coords = addressToCoords(address);
    state.selection = { r1: coords.row, c1: coords.col, r2: coords.row, c2: coords.col };
    const value = initialValue != null ? initialValue : (getDisplaySnapshot().sheets[state.currentSheetIndex].cells?.[address] ?? '');
    state.editing = { address, value };
    state.formulaRefMode = true;
    renderAll();
  }

  function startEditingWithText(text) {
    beginEdit(state.activeAddress, text);
  }

  function commitEdit(nextValue, { moveRow = 0, moveCol = 0 } = {}) {
    if (state.previewRevision) {
      showMessage('Exit preview mode before editing.', 'warn');
      return;
    }
    const address = state.activeAddress;
    const currentRaw = getDisplaySnapshot().sheets[state.currentSheetIndex].cells?.[address] ?? '';
    if (nextValue === currentRaw) {
      state.editing = null;
      if (moveRow || moveCol) {
        moveSelection(moveRow, moveCol, false);
      }
      renderAll();
      return;
    }
    pushUndo('edit');
    const snapshot = clone(state.draftSnapshot);
    setRawCell(snapshot, address, nextValue);
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.saveMessage = '';
    state.editing = null;
    state.conflictCells.delete(address);
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
    if (moveRow || moveCol) {
      moveSelection(moveRow, moveCol, false);
    }
  }

  function commitEditorFromBlur() {
    if (!state.editing) {
      return;
    }
    commitEdit(state.editing.value);
  }

  function onEditorInput(event) {
    state.editing.value = event.target.value;
    state.formulaRefMode = true;
    renderSuggestions(els.sheetScroller.firstChild || els.sheetScroller, event.target);
  }

  function onEditorKeyDown(event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      state.editing = null;
      renderAll();
      focusGrid();
      return;
    }
    if (event.key === 'Enter' || event.key === 'Tab') {
      event.preventDefault();
      const moveRow = event.key === 'Enter' ? (event.shiftKey ? -1 : 1) : 0;
      const moveCol = event.key === 'Tab' ? (event.shiftKey ? -1 : 1) : 0;
      commitEdit(event.target.value, { moveRow, moveCol });
      return;
    }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp' || event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      if (event.metaKey || event.ctrlKey) {
        return;
      }
      return;
    }
    if (event.key === 'Backspace' || event.key === 'Delete') {
      state.formulaRefMode = true;
    }
    if (event.key === ' ' || event.key === '=' || event.key === '+' || event.key === '-' || event.key === '*' || event.key === '/' || event.key === '(' || event.key === ',' || event.key === ':') {
      state.formulaRefMode = false;
    }
    queueMicrotask(() => renderSuggestions(els.sheetScroller.firstChild || els.sheetScroller, event.target));
  }

  function onCellPointerDown(event) {
    event.preventDefault();
    const row = Number(event.currentTarget.dataset.row);
    const col = Number(event.currentTarget.dataset.col);
    const address = event.currentTarget.dataset.address;
    state.activeAddress = address;
    if (state.editing) {
      insertReferenceFromSelection({ r1: row, c1: col, r2: row, c2: col });
      return;
    }
    state.dragging = true;
    state.dragStart = { row, col };
    state.selection = { r1: row, c1: col, r2: row, c2: col };
    renderAll();
    focusGrid();
    const onMove = (moveEvent) => {
      if (!state.dragging) {
        return;
      }
      const target = document.elementFromPoint(moveEvent.clientX, moveEvent.clientY);
      const cell = target && target.closest && target.closest('.grid-cell');
      if (!cell) {
        return;
      }
      const nextRow = Number(cell.dataset.row);
      const nextCol = Number(cell.dataset.col);
      state.selection = normalizeSelection({
        r1: state.dragStart.row,
        c1: state.dragStart.col,
        r2: nextRow,
        c2: nextCol,
      });
      state.activeAddress = coordsToAddress(nextRow, nextCol);
      renderAll();
    };
    const onUp = () => {
      state.dragging = false;
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      if (state.editing) {
        insertReferenceFromSelection(state.selection);
      } else {
        heartbeatSoon();
        fetchCellHistory();
      }
    };
    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
  }

  function insertReferenceFromSelection(selection) {
    if (!state.editing) {
      return;
    }
    const editor = document.querySelector('.editor-input');
    const ref = selectionToAddress(selection);
    const current = state.editing.value;
    const start = editor?.selectionStart ?? current.length;
    const end = editor?.selectionEnd ?? current.length;
    const before = current.slice(0, start);
    const after = current.slice(end);
    let replacementBefore = before;
    if (state.formulaRefMode) {
      const trimmed = before.replace(/([A-Z]{1,3}[1-9]\d*(?::[A-Z]{1,3}[1-9]\d*)?)$/i, '');
      replacementBefore = `${trimmed}${ref}`;
      if (selection.r1 === selection.r2 && selection.c1 === selection.c2 && before.endsWith(ref)) {
        replacementBefore = before;
      }
    } else {
      replacementBefore = `${before}${ref}`;
    }
    state.editing.value = `${replacementBefore}${after}`;
    if (editor) {
      editor.value = state.editing.value;
      editor.focus();
      editor.setSelectionRange(state.editing.value.length, state.editing.value.length);
      renderSuggestions(els.sheetScroller.firstChild || els.sheetScroller, editor);
    }
    state.formulaRefMode = false;
  }

  function findMatches() {
    const query = state.searchQuery.trim().toLowerCase();
    if (!query) {
      state.searchMatches = [];
      state.searchIndex = -1;
      return;
    }
    const snapshot = getDisplaySnapshot();
    const sheet = snapshot.sheets[state.currentSheetIndex];
    const matches = [];
    for (let row = 1; row <= ROWS; row += 1) {
      for (let col = 1; col <= COLS; col += 1) {
        const address = coordsToAddress(row, col);
        const raw = sheet.cells?.[address] ?? '';
        if (String(raw).toLowerCase().includes(query)) {
          matches.push(address);
        }
      }
    }
    state.searchMatches = matches;
    state.searchIndex = matches.length ? 0 : -1;
    if (matches.length) {
      selectByAddress(matches[0]);
    }
    renderSearchSummary();
  }

  function selectByAddress(text) {
    try {
      const rect = parseAddressRange(text);
      state.selection = rect;
      state.activeAddress = coordsToAddress(rect.r2, rect.c2);
      scrollSelectionIntoView(rect);
      renderAll();
      heartbeatSoon();
      fetchCellHistory();
    } catch (error) {
      showMessage(error.message, 'warn');
    }
  }

  function findNext() {
    if (!state.searchMatches.length) {
      findMatches();
      if (!state.searchMatches.length) {
        return;
      }
    }
    state.searchIndex = (state.searchIndex + 1) % state.searchMatches.length;
    selectByAddress(state.searchMatches[state.searchIndex]);
    renderSearchSummary();
  }

  function replaceCurrent() {
    if (!state.searchMatches.length) {
      findMatches();
    }
    const address = state.searchMatches[state.searchIndex];
    if (!address) {
      return;
    }
    pushUndo('replace-current');
    const snapshot = clone(state.draftSnapshot);
    setRawCell(snapshot, address, state.replaceValue);
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
    findMatches();
  }

  function replaceAll() {
    const query = state.searchQuery.trim().toLowerCase();
    if (!query) {
      return;
    }
    pushUndo('replace-all');
    const snapshot = clone(state.draftSnapshot);
    const sheet = snapshot.sheets[state.currentSheetIndex];
    let changes = 0;
    for (let row = 1; row <= ROWS; row += 1) {
      for (let col = 1; col <= COLS; col += 1) {
        const address = coordsToAddress(row, col);
        const raw = sheet.cells?.[address] ?? '';
        if (String(raw).toLowerCase().includes(query)) {
          setRawCell(snapshot, address, state.replaceValue);
          changes += 1;
        }
      }
    }
    if (changes === 0) {
      showMessage('No matches found to replace.', 'warn');
      state.undoStack.pop();
      updateUndoRedoButtons();
      return;
    }
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
    findMatches();
    showMessage(`Replaced ${changes} cell${changes === 1 ? '' : 's'}.`, 'good');
  }

  function clearSelectedCells() {
    if (state.previewRevision) {
      showMessage('Exit preview mode before editing.', 'warn');
      return;
    }
    pushUndo('clear');
    const snapshot = clone(state.draftSnapshot);
    for (const address of cellAddressesInRect(state.selection)) {
      setRawCell(snapshot, address, '');
      state.conflictCells.delete(address);
    }
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
  }

  function copySelectionToClipboard(cut = false) {
    const rect = rectFromSelection(state.selection);
    const sheet = getDisplaySnapshot().sheets[state.currentSheetIndex];
    const rows = [];
    for (let row = rect.r1; row <= rect.r2; row += 1) {
      const values = [];
      for (let col = rect.c1; col <= rect.c2; col += 1) {
        values.push(sheet.cells?.[coordsToAddress(row, col)] ?? '');
      }
      rows.push(values.join('\t'));
    }
    const text = rows.join('\n');
    navigator.clipboard?.writeText(text).catch(() => {});
    if (cut) {
      clearSelectedCells();
    }
    showMessage(cut ? 'Cut selection.' : 'Copied selection.');
  }

  function parseClipboardTable(text) {
    if (text.includes('\t')) {
      return text.replace(/\r\n/g, '\n').split('\n').map((row) => row.split('\t'));
    }
    const rows = [];
    let current = '';
    let row = [];
    let inQuotes = false;
    for (let index = 0; index < text.length; index += 1) {
      const char = text[index];
      if (inQuotes) {
        if (char === '"' && text[index + 1] === '"') {
          current += '"';
          index += 1;
        } else if (char === '"') {
          inQuotes = false;
        } else {
          current += char;
        }
        continue;
      }
      if (char === '"') {
        inQuotes = true;
        continue;
      }
      if (char === ',') {
        row.push(current);
        current = '';
        continue;
      }
      if (char === '\n') {
        row.push(current);
        rows.push(row);
        row = [];
        current = '';
        continue;
      }
      if (char === '\r') {
        continue;
      }
      current += char;
    }
    row.push(current);
    rows.push(row);
    return rows;
  }

  function pasteText(text) {
    if (state.previewRevision) {
      showMessage('Exit preview mode before editing.', 'warn');
      return;
    }
    if (!text) {
      return;
    }
    const table = parseClipboardTable(text);
    pushUndo('paste');
    const snapshot = clone(state.draftSnapshot);
    const startRow = state.selection.r1;
    const startCol = state.selection.c1;
    for (let rowOffset = 0; rowOffset < table.length; rowOffset += 1) {
      for (let colOffset = 0; colOffset < table[rowOffset].length; colOffset += 1) {
        const row = startRow + rowOffset;
        const col = startCol + colOffset;
        if (row > ROWS || col > COLS) {
          continue;
        }
        setRawCell(snapshot, coordsToAddress(row, col), table[rowOffset][colOffset]);
      }
    }
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
  }

  function fillDown() {
    if (state.previewRevision) {
      showMessage('Exit preview mode before editing.', 'warn');
      return;
    }
    const rect = rectFromSelection(state.selection);
    if (rect.r2 <= rect.r1) {
      showMessage('Select at least two rows to fill down.', 'warn');
      return;
    }
    pushUndo('fill-down');
    const sourceSnapshot = clone(state.draftSnapshot);
    const snapshot = clone(state.draftSnapshot);
    const sourceSheet = sourceSnapshot.sheets[state.currentSheetIndex];
    for (let row = rect.r1 + 1; row <= rect.r2; row += 1) {
      for (let col = rect.c1; col <= rect.c2; col += 1) {
        const sourceAddress = coordsToAddress(rect.r1, col);
        const targetAddress = coordsToAddress(row, col);
        const sourceRaw = sourceSheet.cells?.[sourceAddress] ?? '';
        const prevRowRaw = row > rect.r1 + 1 ? (sourceSheet.cells?.[coordsToAddress(row - 1, col)] ?? '') : sourceRaw;
        const nextValue = fillSeriesValue(sourceRaw, prevRowRaw, row - rect.r1, 0, sourceAddress, targetAddress);
        setRawCell(snapshot, targetAddress, nextValue);
      }
    }
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
  }

  function fillRight() {
    if (state.previewRevision) {
      showMessage('Exit preview mode before editing.', 'warn');
      return;
    }
    const rect = rectFromSelection(state.selection);
    if (rect.c2 <= rect.c1) {
      showMessage('Select at least two columns to fill right.', 'warn');
      return;
    }
    pushUndo('fill-right');
    const sourceSnapshot = clone(state.draftSnapshot);
    const snapshot = clone(state.draftSnapshot);
    const sourceSheet = sourceSnapshot.sheets[state.currentSheetIndex];
    for (let col = rect.c1 + 1; col <= rect.c2; col += 1) {
      for (let row = rect.r1; row <= rect.r2; row += 1) {
        const sourceAddress = coordsToAddress(row, rect.c1);
        const targetAddress = coordsToAddress(row, col);
        const sourceRaw = sourceSheet.cells?.[sourceAddress] ?? '';
        const prevColRaw = col > rect.c1 + 1 ? (sourceSheet.cells?.[coordsToAddress(row, col - 1)] ?? '') : sourceRaw;
        const nextValue = fillSeriesValue(sourceRaw, prevColRaw, 0, col - rect.c1, sourceAddress, targetAddress);
        setRawCell(snapshot, targetAddress, nextValue);
      }
    }
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
  }

  function shiftFormulaText(formula, rowOffset, colOffset) {
    const body = formula.slice(1);
    return `=${body.replace(/([A-Z]{1,3})([1-9]\d*)(?::([A-Z]{1,3})([1-9]\d*))?/gi, (match, c1, r1, c2, r2) => {
      const start = shiftAddress(`${c1}${r1}`, rowOffset, colOffset);
      if (!c2) {
        return start;
      }
      const end = shiftAddress(`${c2}${r2}`, rowOffset, colOffset);
      return `${start}:${end}`;
    })}`;
  }

  function shiftAddress(address, rowOffset, colOffset) {
    const coords = addressToCoords(address);
    const row = clamp(coords.row + rowOffset, 1, ROWS);
    const col = clamp(coords.col + colOffset, 1, COLS);
    return coordsToAddress(row, col);
  }

  function fillSeriesValue(sourceRaw, previousRaw, rowOffset, colOffset, sourceAddress, targetAddress) {
    if (sourceRaw.startsWith('=')) {
      return shiftFormulaText(sourceRaw, rowOffset, colOffset);
    }
    if (isNumericText(sourceRaw) && isNumericText(previousRaw)) {
      const delta = parseNumeric(previousRaw) - parseNumeric(sourceRaw);
      if (rowOffset > 0) {
        return String(parseNumeric(sourceRaw) + (delta || 1) * rowOffset);
      }
      if (colOffset > 0) {
        return String(parseNumeric(sourceRaw) + (delta || 1) * colOffset);
      }
    }
    if (isNumericText(sourceRaw)) {
      const step = 1;
      if (rowOffset > 0) {
        return String(parseNumeric(sourceRaw) + step * rowOffset);
      }
      if (colOffset > 0) {
        return String(parseNumeric(sourceRaw) + step * colOffset);
      }
    }
    return sourceRaw;
  }

  function scheduleAutosave() {
    if (!state.session || state.previewRevision || !state.dirty) {
      return;
    }
    window.clearTimeout(state.autosaveTimer);
    state.autosaveTimer = window.setTimeout(() => {
      if (state.dirty && !state.saveInFlight && !state.previewRevision) {
        saveDraft('autosave');
      }
    }, AUTOSAVE_DELAY);
  }

  async function saveDraft(kind = 'manual') {
    if (!state.session) {
      showMessage('Choose a user first.', 'warn');
      return;
    }
    if (state.previewRevision) {
      showMessage('Exit preview mode before saving.', 'warn');
      return;
    }
    if (state.conflictCells.size > 0) {
      state.saveState = 'conflict';
      state.saveMessage = 'Resolve the highlighted conflict before saving.';
      updateStatusBadge();
      renderAll();
      showMessage('Resolve the highlighted conflict before saving.', 'warn');
      return;
    }
    const payload = {
      sessionId: state.session.sessionId,
      claimedUserId: state.session.userId,
      baseRevision: state.baseRevision || state.currentRevision,
      workbook: getDisplaySnapshot(),
      kind,
    };
    state.saveState = 'saving';
    updateStatusBadge();
    if (state.saveInFlight) {
      return;
    }
    state.saveInFlight = true;
    try {
      const response = await fetch(`/api/workbooks/${state.workbookId}/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) {
        state.saveState = response.status === 409 ? 'conflict' : 'error';
        state.saveMessage = result.error || 'Save failed';
        if (Array.isArray(result.conflicts)) {
          state.conflictCells = new Set(result.conflicts.map((entry) => entry.address));
        }
        updateStatusBadge();
        renderAll();
        showMessage(result.error || 'Save failed', 'warn');
        return;
      }
      state.currentRevision = result.revision;
      state.baseRevision = result.revision;
      state.baseSnapshot = clone(result.workbook);
      state.draftSnapshot = clone(result.workbook);
      state.dirty = false;
      state.saveState = 'saved';
      state.saveMessage = result.merged ? 'Merged with newer changes' : 'Saved';
      state.conflictCells = new Set();
      refreshComputedState();
      updateStatusBadge();
      renderAll();
      showMessage(result.autosaved ? 'Autosaved.' : 'Saved.');
    } catch (error) {
      state.saveState = 'error';
      state.saveMessage = error.message;
      updateStatusBadge();
      showMessage(error.message, 'warn');
    } finally {
      state.saveInFlight = false;
    }
  }

  async function heartbeat() {
    if (!state.session) {
      return;
    }
    if (state.saveInFlight) {
      return;
    }
    const payload = {
      selection: clone(state.selection),
      activeAddress: state.activeAddress,
    };
    try {
      const response = await fetch(`/api/sessions/${state.session.sessionId}/heartbeat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        if (response.status === 409) {
          showMessage(result.error || 'Your editing session expired.', 'warn');
          state.session = null;
          sessionStorage.removeItem('gridforge.session');
          showSessionOverlay();
        }
      }
    } catch (error) {
      // Offline/local hiccups are tolerated.
    }
  }

  async function syncState() {
    if (!state.session || state.syncInFlight) {
      return;
    }
    state.syncInFlight = true;
    try {
      await heartbeat();
      const response = await fetch(`/api/workbooks/${state.workbookId}/state`);
      if (!response.ok) {
        return;
      }
      const payload = await response.json();
      state.users = payload.users;
      state.revisions = payload.revisions;
      state.presence = payload.sessions;
      state.currentRevision = payload.currentRevision;
      state.savedAt = payload.savedAt;
      const remoteSnapshot = payload.workbook;
      if (!state.baseSnapshot) {
        state.baseSnapshot = clone(remoteSnapshot);
        state.draftSnapshot = clone(remoteSnapshot);
        state.baseRevision = payload.currentRevision;
      } else if (payload.currentRevision !== state.baseRevision) {
        if (!state.dirty) {
          state.baseSnapshot = clone(remoteSnapshot);
          state.draftSnapshot = clone(remoteSnapshot);
          state.baseRevision = payload.currentRevision;
          state.conflictCells = new Set();
          refreshComputedState();
        } else {
          const remoteChanges = diffSnapshots(state.baseSnapshot, remoteSnapshot);
          const localChanges = diffSnapshots(state.baseSnapshot, state.draftSnapshot);
          const remoteKeys = new Set(remoteChanges.map((change) => change.address));
          const localKeys = new Set(localChanges.map((change) => change.address));
          const overlaps = [...remoteKeys].filter((address) => localKeys.has(address));
          const nonConflictRemote = remoteChanges.filter((change) => !localKeys.has(change.address));
          if (nonConflictRemote.length) {
            state.draftSnapshot = applyDiffs(state.draftSnapshot, nonConflictRemote);
          }
          state.baseSnapshot = clone(remoteSnapshot);
          state.baseRevision = payload.currentRevision;
          state.conflictCells = new Set(overlaps);
          if (overlaps.length) {
            state.saveState = 'conflict';
            state.saveMessage = 'Another view changed the same cell. Resolve the conflict before saving.';
          } else {
            refreshComputedState();
          }
        }
      }
      if (!state.previewRevision) {
        renderAll();
      }
    } catch (error) {
      // Keep the current view if sync fails briefly.
    } finally {
      state.syncInFlight = false;
    }
  }

  async function loadCellHistory() {
    if (!state.session) {
      return;
    }
    const sheet = getDisplaySnapshot()?.sheets[state.currentSheetIndex];
    if (!sheet) {
      return;
    }
    const address = state.selectedHistoryAddress;
    try {
      const response = await fetch(`/api/workbooks/${state.workbookId}/cells/${address}/history?sheetId=${encodeURIComponent(sheet.id)}`);
      if (!response.ok) {
        return;
      }
      const result = await response.json();
      state.cellHistory = result.history || [];
      renderHistory();
    } catch (error) {
      // Ignore intermittent failures.
    }
  }

  function fetchCellHistory() {
    state.selectedHistoryAddress = state.activeAddress;
    loadCellHistory();
  }

  async function previewRevision(revisionNumber) {
    try {
      const response = await fetch(`/api/workbooks/${state.workbookId}/revisions/${revisionNumber}`);
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(payload.error || 'Unable to load revision');
      }
      const payload = await response.json();
      state.previewRevision = revisionNumber;
      state.previewSnapshot = payload.snapshot;
      refreshComputedState();
      renderAll();
      showMessage(`Previewing revision ${revisionNumber}.`);
    } catch (error) {
      showMessage(error.message, 'warn');
    }
  }

  async function restoreRevision(revisionNumber) {
    try {
      const response = await fetch(`/api/workbooks/${state.workbookId}/revisions/${revisionNumber}`);
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(payload.error || 'Unable to load revision');
      }
      const payload = await response.json();
      pushUndo('restore');
      state.previewRevision = null;
      state.previewSnapshot = null;
      state.draftSnapshot = clone(payload.snapshot);
      state.dirty = true;
      state.saveState = 'dirty';
        state.baseRevision = state.currentRevision;
      refreshComputedState();
      scheduleAutosave();
      renderAll();
      showMessage(`Restored revision ${revisionNumber} into a draft.`);
    } catch (error) {
      showMessage(error.message, 'warn');
    }
  }

  function backToLatest() {
    state.previewRevision = null;
    state.previewSnapshot = null;
    refreshComputedState();
    renderAll();
    showMessage('Returned to the latest draft.');
  }

  function updateUserSelect() {
    els.userSelect.innerHTML = '';
    for (const user of state.users) {
      const option = document.createElement('option');
      option.value = user.id;
      option.textContent = user.name;
      els.userSelect.appendChild(option);
    }
    if (state.session) {
      els.userSelect.value = state.session.userId;
    }
  }

  async function createSession(userId) {
    const response = await fetch(`/api/sessions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, workbookId: state.workbookId }),
    });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || 'Unable to create session');
    }
    state.session = { sessionId: payload.sessionId, userId: payload.userId, userName: payload.userName, color: payload.color };
    sessionStorage.setItem('gridforge.session', JSON.stringify(state.session));
    els.sessionOverlay.classList.add('hidden');
    updateUserSelect();
    showMessage(`Signed in as ${payload.userName}.`);
    return state.session;
  }

  function showSessionOverlay() {
    els.sessionOverlay.classList.remove('hidden');
  }

  function renderSessionChoices() {
    els.sessionUsers.innerHTML = '';
    state.users.forEach((user) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'stack-item';
      button.innerHTML = `<strong>${escapeHtml(user.name)}</strong><div class="muted">Session for this browser tab</div>`;
      button.addEventListener('click', async () => {
        try {
          await createSession(user.id);
                state.baseRevision = state.currentRevision;
          heartbeatSoon();
          syncState();
          focusGrid();
        } catch (error) {
          showMessage(error.message, 'warn');
        }
      });
      els.sessionUsers.appendChild(button);
    });
  }

  function heartbeatSoon() {
    if (!state.session) {
      return;
    }
    window.clearTimeout(state.heartbeatTimer);
    state.heartbeatTimer = window.setTimeout(() => {
      heartbeat();
    }, 200);
  }

  function openNewView() {
    window.open(window.location.href, '_blank', 'noopener');
  }

  function handleGridKeydown(event) {
    if (state.editing) {
      return;
    }
    if (document.activeElement && ['INPUT', 'SELECT', 'BUTTON'].includes(document.activeElement.tagName)) {
      return;
    }
    if (event.key === 'Escape') {
      event.preventDefault();
      els.formulaBar.focus();
      return;
    }
    if (event.key === 'Enter') {
      event.preventDefault();
      moveSelection(event.shiftKey ? -1 : 1, 0, false);
      return;
    }
    if (event.key === 'Tab') {
      event.preventDefault();
      moveSelection(0, event.shiftKey ? -1 : 1, false);
      return;
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      moveSelection(-1, 0, event.shiftKey);
      return;
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      moveSelection(1, 0, event.shiftKey);
      return;
    }
    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      moveSelection(0, -1, event.shiftKey);
      return;
    }
    if (event.key === 'ArrowRight') {
      event.preventDefault();
      moveSelection(0, 1, event.shiftKey);
      return;
    }
    if (event.key === 'F2') {
      event.preventDefault();
      beginEdit(state.activeAddress);
      return;
    }
    if (event.key === 'Delete' || event.key === 'Backspace') {
      event.preventDefault();
      clearSelectedCells();
      return;
    }
    const printable = event.key.length === 1 && !event.metaKey && !event.ctrlKey && !event.altKey;
    if (printable) {
      event.preventDefault();
      beginEdit(state.activeAddress, event.key);
    }
  }

  function handleClipboardEvent(event) {
    if (state.editing || !state.session) {
      return;
    }
    const key = event.type;
    if (key === 'copy') {
      event.preventDefault();
      copySelectionToClipboard(false);
    }
    if (key === 'cut') {
      event.preventDefault();
      copySelectionToClipboard(true);
    }
    if (key === 'paste') {
      event.preventDefault();
      const text = event.clipboardData?.getData('text/plain') || '';
      pasteText(text);
    }
  }

  function fillFromFormulaBar() {
    if (state.previewRevision) {
      showMessage('Exit preview mode before editing.', 'warn');
      return;
    }
    const currentRaw = getDisplaySnapshot().sheets[state.currentSheetIndex].cells?.[state.activeAddress] ?? '';
    if (els.formulaBar.value === currentRaw) {
      return;
    }
    pushUndo('formula-bar');
    const snapshot = clone(state.draftSnapshot);
    setRawCell(snapshot, state.activeAddress, els.formulaBar.value);
    state.draftSnapshot = snapshot;
    state.dirty = true;
    state.saveState = 'dirty';
    state.baseRevision = state.currentRevision;
    refreshComputedState();
    scheduleAutosave();
    renderAll();
  }

  function bindEvents() {
    document.addEventListener('keydown', handleGridKeydown);
    document.addEventListener('copy', handleClipboardEvent);
    document.addEventListener('cut', handleClipboardEvent);
    document.addEventListener('paste', handleClipboardEvent);

    els.formulaBar.addEventListener('focus', () => {
      const sheet = getDisplaySnapshot().sheets[state.currentSheetIndex];
      els.formulaBar.value = sheet.cells?.[state.activeAddress] ?? '';
    });
    els.formulaBar.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        fillFromFormulaBar();
        focusGrid();
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        focusGrid();
      }
    });
    els.formulaBar.addEventListener('blur', () => {
      if (document.activeElement !== els.hiddenEditor && document.activeElement !== els.sheetScroller) {
        fillFromFormulaBar();
      }
    });
    els.formulaBar.addEventListener('input', () => {
      state.saveMessage = '';
    });

    els.nameBox.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        try {
          selectByAddress(els.nameBox.value);
          focusGrid();
        } catch (error) {
          showMessage(error.message, 'warn');
        }
      }
    });

    els.findInput.addEventListener('input', () => {
      state.searchQuery = els.findInput.value;
      findMatches();
    });
    els.replaceInput.addEventListener('input', () => {
      state.replaceValue = els.replaceInput.value;
    });
    els.findNextButton.addEventListener('click', findNext);
    els.replaceCurrentButton.addEventListener('click', replaceCurrent);
    els.replaceAllButton.addEventListener('click', replaceAll);

    els.saveNowButton.addEventListener('click', () => saveDraft('manual'));
    els.undoButton.addEventListener('click', undo);
    els.redoButton.addEventListener('click', redo);
    els.fillDownButton.addEventListener('click', fillDown);
    els.fillRightButton.addEventListener('click', fillRight);
    els.restoreLatestButton.addEventListener('click', backToLatest);
    els.editCellButton.addEventListener('click', () => beginEdit(state.activeAddress));
    els.newViewButton.addEventListener('click', openNewView);

    els.userSelect.addEventListener('change', async () => {
      if (!els.userSelect.value) {
        return;
      }
      try {
        if (state.session) {
          await fetch(`/api/sessions/${state.session.sessionId}/close`, { method: 'POST' });
          sessionStorage.removeItem('gridforge.session');
        }
        state.session = null;
        showSessionOverlay();
        await createSession(els.userSelect.value);
      } catch (error) {
        showMessage(error.message, 'warn');
      }
    });

    window.addEventListener('beforeunload', () => {
      if (state.session) {
        const payload = JSON.stringify({ sessionId: state.session.sessionId });
        navigator.sendBeacon?.(`/api/sessions/${state.session.sessionId}/close`, new Blob([payload], { type: 'application/json' }));
      }
    });

    window.addEventListener('pagehide', () => {
      if (state.session) {
        navigator.sendBeacon?.(`/api/sessions/${state.session.sessionId}/close`, new Blob([JSON.stringify({ sessionId: state.session.sessionId })], { type: 'application/json' }));
      }
    });

    els.sheetScroller.addEventListener('focus', () => {
      syncInputs();
    });
  }

  function undo() {
    if (!state.undoStack.length) {
      return;
    }
    const previous = state.undoStack.pop();
    state.redoStack.push({ snapshot: clone(state.draftSnapshot), selection: clone(state.selection), activeAddress: state.activeAddress });
    state.draftSnapshot = clone(previous.snapshot);
    state.selection = clone(previous.selection);
    state.activeAddress = previous.activeAddress;
    state.dirty = true;
    state.saveState = 'dirty';
    refreshComputedState();
    updateUndoRedoButtons();
    scheduleAutosave();
    renderAll();
  }

  function redo() {
    if (!state.redoStack.length) {
      return;
    }
    const next = state.redoStack.pop();
    state.undoStack.push({ snapshot: clone(state.draftSnapshot), selection: clone(state.selection), activeAddress: state.activeAddress });
    state.draftSnapshot = clone(next.snapshot);
    state.selection = clone(next.selection);
    state.activeAddress = next.activeAddress;
    state.dirty = true;
    state.saveState = 'dirty';
    refreshComputedState();
    updateUndoRedoButtons();
    scheduleAutosave();
    renderAll();
  }

  async function bootstrap() {
    const response = await fetch('/api/bootstrap');
    if (!response.ok) {
      throw new Error('Unable to load workbook');
    }
    const payload = await response.json();
    state.users = payload.users || [];
    state.revisions = payload.revisions || [];
    state.presence = payload.sessions || [];
    state.workbookId = payload.workbook.id;
    state.workbookTitle = payload.workbook.title;
    state.baseSnapshot = clone(payload.workbook);
    state.draftSnapshot = clone(payload.workbook);
    state.baseRevision = payload.currentRevision;
    state.currentRevision = payload.currentRevision;
    state.savedAt = payload.savedAt;
    state.selection = { r1: 1, c1: 1, r2: 1, c2: 1 };
    state.activeAddress = 'A1';
    state.selectedHistoryAddress = 'A1';
    updateUserSelect();
    renderSessionChoices();
    refreshComputedState();
    renderAll();
    const stored = sessionStorage.getItem('gridforge.session');
    if (stored) {
      try {
        const session = JSON.parse(stored);
        const responseSession = await fetch('/api/workbooks/ops-plan/state');
        const payloadState = await responseSession.json();
        if (payloadState.users.some((user) => user.id === session.userId)) {
          const verify = await fetch(`/api/sessions/${session.sessionId}/heartbeat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ selection: state.selection, activeAddress: state.activeAddress }),
          });
          if (verify.ok) {
            state.session = session;
            els.sessionOverlay.classList.add('hidden');
            state.presence = payloadState.sessions || [];
            state.revisions = payloadState.revisions || [];
            state.currentRevision = payloadState.currentRevision;
            state.baseSnapshot = clone(payloadState.workbook);
            state.draftSnapshot = clone(payloadState.workbook);
            state.baseRevision = payloadState.currentRevision;
            refreshComputedState();
            renderAll();
          } else {
            sessionStorage.removeItem('gridforge.session');
            showSessionOverlay();
          }
        } else {
          showSessionOverlay();
        }
      } catch (error) {
        showSessionOverlay();
      }
    } else {
      showSessionOverlay();
    }
  }

  async function init() {
    bindEvents();
    setStatus('Loading workbook…');
    try {
      await bootstrap();
    } catch (error) {
      showMessage(error.message, 'warn');
    }
    state.syncTimer = window.setInterval(syncState, SYNC_INTERVAL);
    state.heartbeatTimer = window.setInterval(heartbeat, 5000);
    updateUndoRedoButtons();
    focusGrid();
  }

  window.addEventListener('load', init);
})();
