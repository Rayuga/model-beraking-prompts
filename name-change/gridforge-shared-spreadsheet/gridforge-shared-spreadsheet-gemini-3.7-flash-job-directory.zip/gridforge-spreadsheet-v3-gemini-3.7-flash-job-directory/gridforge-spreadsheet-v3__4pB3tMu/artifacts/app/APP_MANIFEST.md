# GridForge Application Manifest

## Start Command

```bash start
npm start
```

## Database

- **SQLite Database Path:** `/app/gridforge.db`

## Application API Routes

### Workbook & Editing Routes
- `GET /api/workbooks/:id` - Fetch current workbook snapshot and revision details.
- `POST /api/workbooks/:id/save` (also `PUT /api/workbooks/:id`) - Save workbook edits with base revision check, snapshot validation, and 3-way merge conflict detection.
- `GET /api/workbooks/:id/revisions` - List timestamped revision history with author and change summaries.
- `GET /api/workbooks/:id/revisions/:rev` - Retrieve the complete workbook snapshot for a specific revision number.
- `GET /api/workbooks/:id/sheets/:sheetId/cells/:cell/history` - Retrieve audit history for a specific cell across all revisions.

### Collaboration & Session Routes
- `GET /api/users` - List all seeded and available users.
- `POST /api/sessions` - Register an editing session for a user.
- `POST /api/sessions/:sessionId/presence` - Update active cell/range cursor presence and keepalive heartbeat.
- `POST /api/sessions/:sessionId/close` - Explicitly close an editing session.
- `GET /api/workbooks/:id/presence` - Get all active collaborator presences in a workbook.
- `WS /ws` - Real-time WebSocket connection for instant multi-user presence and workbook update broadcasts.
