const assert = require('assert');
const fs = require('fs');
const path = require('path');
const http = require('http');
const { WebSocket } = require('ws');

// 1. Check Formula Engine
console.log('--- Test Suite 1: Formula Engine ---');
const formula = require('./formula');

const testCells = {
  'A1': 'Item',
  'B2': '3',
  'C2': '120',
  'D2': '=B2*C2',
  'B3': '2',
  'C3': '350',
  'D3': '=B3*C3',
  'B4': '5',
  'C4': '80',
  'D4': '=B4*C4',
  'D6': '=SUM(D2:D4)',
  'D7': '=AVG(C2:C4)',
  'A10': 'North',
  'B10': '1200',
  'C10': '700',
  'D10': '=B10-C10',
  'M1': '=MIN(B2:B4)',
  'M2': '=MAX(B2:B4)',
  'M3': '=COUNT(A1, B2:B4, "text", 99)',
  'DIV': '=100/0',
  'ERR': '=SUM(A1:',
  'MIX': '=SUM(B2:B3, 10, C4)'
};

const computed = formula.recalculateSheet(testCells);
assert.strictEqual(computed['D2'], 360, 'D2 = 3 * 120 = 360');
assert.strictEqual(computed['D3'], 700, 'D3 = 2 * 350 = 700');
assert.strictEqual(computed['D4'], 400, 'D4 = 5 * 80 = 400');
assert.strictEqual(computed['D6'], 1460, 'D6 = 360 + 700 + 400 = 1460');
assert.strictEqual(computed['D7'], 183.3333333333, 'D7 = (120+350+80)/3');
assert.strictEqual(computed['D10'], 500, 'D10 = 1200 - 700 = 500');
assert.strictEqual(computed['M1'], 2, 'MIN is 2');
assert.strictEqual(computed['M2'], 5, 'MAX is 5');
assert.strictEqual(computed['M3'], 4, 'COUNT is 4 numbers (B2, B3, B4, 99)');
assert.strictEqual(computed['DIV'], '#DIV/0!', 'Division by zero is #DIV/0!');
assert.strictEqual(computed['ERR'], '#ERROR!', 'Syntax error is #ERROR!');
assert.strictEqual(computed['MIX'], 95, 'MIX = 3 + 2 + 10 + 80 = 95');

// Cycle detection
const cycleCells = { 'A1': '=B1+1', 'B1': '=A1+1' };
const cycleComp = formula.recalculateSheet(cycleCells);
assert.strictEqual(cycleComp['A1'], '#REF!');
assert.strictEqual(cycleComp['B1'], '#REF!');

// Shift formulas
assert.strictEqual(formula.shiftFormulaReferences('=B2*C2', 0, 1), '=B3*C3');
assert.strictEqual(formula.shiftFormulaReferences('=B2*C2', 1, 0), '=C2*D2');
assert.strictEqual(formula.shiftFormulaReferences('=$B$2*C2', 0, 2), '=$B$2*C4');
assert.strictEqual(formula.shiftFormulaReferences('=SUM(D2:D4)', 0, 1), '=SUM(D3:D5)');

console.log('✓ Formula engine tests passed.');

// 2. Check Static Files and Local Assets (No external CDNs)
console.log('--- Test Suite 2: Local Assets & Static Files ---');
const html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(__dirname, 'public', 'style.css'), 'utf8');
const jsFiles = ['formula.js', 'grid.js', 'collaboration.js', 'history.js', 'app.js'];

assert(!html.includes('http://') && !html.includes('https://'), 'No external CDNs in index.html');
assert(!css.includes('http://') && !css.includes('https://'), 'No external CDNs in style.css');

for (const f of jsFiles) {
  const code = fs.readFileSync(path.join(__dirname, 'public', 'js', f), 'utf8');
  assert(!code.includes('cdn.') && !code.includes('unpkg.com') && !code.includes('cdnjs.cloudflare.com'), `No CDN in ${f}`);
}
console.log('✓ Local assets verified (100% self-contained).');

// 3. Database & Server REST / WebSocket Integration Tests
console.log('--- Test Suite 3: Database & Server Integration ---');

const { app, server, getDb, DB_PATH } = require('./server');

const TEST_PORT = 3999;
server.listen(TEST_PORT, async () => {
  const baseUrl = `http://localhost:${TEST_PORT}`;

  async function api(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    const res = await fetch(baseUrl + path, { ...options, headers });
    const text = await res.text();
    let body;
    try { body = JSON.parse(text); } catch (e) { body = text; }
    return { status: res.status, body };
  }

  try {
    // 3.1 Get Users
    let r = await api('/api/users');
    assert.strictEqual(r.status, 200);
    assert(r.body.some(u => u.id === 'riley'));
    assert(r.body.some(u => u.id === 'morgan'));
    assert(r.body.some(u => u.id === 'priya'));
    console.log('✓ /api/users passed');

    // 3.2 Get Workbook
    r = await api('/api/workbooks/ops-plan');
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.body.workbook.title, 'Northwind Operations Plan');
    assert.strictEqual(r.body.workbook.sheets[0].cells['A1'], 'Item');
    assert.strictEqual(r.body.workbook.sheets[0].cells['A80'], 'ANCHOR-BOTTOM');
    const baseRev = r.body.revision;
    console.log('✓ /api/workbooks/ops-plan passed (Rev #' + baseRev + ')');

    // 3.3 Create Session
    r = await api('/api/sessions', {
      method: 'POST',
      body: JSON.stringify({ userId: 'riley', workbookId: 'ops-plan' })
    });
    assert.strictEqual(r.status, 200);
    const session1 = r.body;
    assert(session1.sessionId);
    assert.strictEqual(session1.userId, 'riley');
    console.log('✓ /api/sessions created session');

    // 3.4 Presence update
    r = await api(`/api/sessions/${session1.sessionId}/presence`, {
      method: 'POST',
      body: JSON.stringify({ selectedCell: 'B2', selectedRange: 'B2:C5', sheetId: 'plan' })
    });
    assert.strictEqual(r.status, 200);
    console.log('✓ /api/sessions/:id/presence updated');

    // 3.5 Normal Save
    const wb = (await api('/api/workbooks/ops-plan')).body;
    const modifiedSnapshot = JSON.parse(JSON.stringify(wb.workbook));
    const testVal = 'Qty_' + Date.now();
    modifiedSnapshot.sheets[0].cells['B2'] = testVal;

    r = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': session1.sessionId },
      body: JSON.stringify({
        sessionId: session1.sessionId,
        workbookId: 'ops-plan',
        baseRevision: wb.revision,
        workbook: modifiedSnapshot
      })
    });
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.body.revision, wb.revision + 1);
    const revAfterNormal = r.body.revision;
    console.log('✓ Normal save created Rev #' + revAfterNormal);

    // 3.6 Unchanged Save (no new revision)
    r = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': session1.sessionId },
      body: JSON.stringify({
        sessionId: session1.sessionId,
        workbookId: 'ops-plan',
        baseRevision: revAfterNormal,
        workbook: modifiedSnapshot
      })
    });
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.body.revision, revAfterNormal, 'Unchanged save must not increment revision');
    console.log('✓ Unchanged save handled properly');

    // 3.7 Invalid Session Refusal
    r = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': 'invalid_sess_999' },
      body: JSON.stringify({
        sessionId: 'invalid_sess_999',
        workbookId: 'ops-plan',
        baseRevision: revAfterNormal,
        workbook: modifiedSnapshot
      })
    });
    assert.strictEqual(r.status, 403, 'Invalid session must return 403');
    console.log('✓ Invalid session refused with 403');

    // 3.8 Contradictory Claimed User Refusal
    r = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': session1.sessionId },
      body: JSON.stringify({
        sessionId: session1.sessionId,
        userId: 'priya', // Mismatched with Riley session!
        workbookId: 'ops-plan',
        baseRevision: revAfterNormal,
        workbook: modifiedSnapshot
      })
    });
    assert.strictEqual(r.status, 400, 'Contradictory user must return 400');
    console.log('✓ Contradictory user refused with 400');

    // 3.9 Malformed cell value (non-string)
    const badSnapshot = JSON.parse(JSON.stringify(modifiedSnapshot));
    badSnapshot.sheets[0].cells['B2'] = 12345; // number instead of string!
    r = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': session1.sessionId },
      body: JSON.stringify({
        sessionId: session1.sessionId,
        workbookId: 'ops-plan',
        baseRevision: revAfterNormal,
        workbook: badSnapshot
      })
    });
    assert.strictEqual(r.status, 400, 'Non-string cell must return 400');
    console.log('✓ Non-string cell value refused with 400');

    // 3.10 Stale 3-Way Merge (Non-overlapping changes)
    // Create Morgan session
    const sessionMorgan = (await api('/api/sessions', {
      method: 'POST',
      body: JSON.stringify({ userId: 'morgan', workbookId: 'ops-plan' })
    })).body;

    const baseForMerge = (await api('/api/workbooks/ops-plan')).body;

    // Riley edits C2 based on baseForMerge
    const wbRiley = JSON.parse(JSON.stringify(baseForMerge.workbook));
    const rileyVal = 'Riley_' + Date.now();
    wbRiley.sheets[0].cells['C2'] = rileyVal;
    const rRiley = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': session1.sessionId },
      body: JSON.stringify({
        sessionId: session1.sessionId,
        workbookId: 'ops-plan',
        baseRevision: baseForMerge.revision,
        workbook: wbRiley
      })
    });
    assert.strictEqual(rRiley.status, 200);

    // Morgan edits E2 based on OLD baseForMerge (non-overlapping)
    const wbMorgan = JSON.parse(JSON.stringify(baseForMerge.workbook));
    const morganVal = 'Morgan_' + Date.now();
    wbMorgan.sheets[0].cells['E2'] = morganVal;
    const rMorgan = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': sessionMorgan.sessionId },
      body: JSON.stringify({
        sessionId: sessionMorgan.sessionId,
        workbookId: 'ops-plan',
        baseRevision: baseForMerge.revision, // older revision!
        workbook: wbMorgan
      })
    });
    assert.strictEqual(rMorgan.status, 200, 'Non-overlapping stale edit must merge cleanly');
    const mergedCheck = (await api('/api/workbooks/ops-plan')).body;
    assert.strictEqual(mergedCheck.workbook.sheets[0].cells['C2'], rileyVal, 'Riley change preserved');
    assert.strictEqual(mergedCheck.workbook.sheets[0].cells['E2'], morganVal, 'Morgan change merged');
    console.log('✓ 3-way merge on non-conflicting cells succeeded');

    // 3.11 Stale Overlapping Conflict Detection
    const curWb = (await api('/api/workbooks/ops-plan')).body;
    // Riley edits A10 to "NorthRegion"
    const wbConflict1 = JSON.parse(JSON.stringify(curWb.workbook));
    const conflictVal1 = 'Conflict1_' + Date.now();
    wbConflict1.sheets[0].cells['A10'] = conflictVal1;
    await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': session1.sessionId },
      body: JSON.stringify({
        sessionId: session1.sessionId,
        workbookId: 'ops-plan',
        baseRevision: curWb.revision,
        workbook: wbConflict1
      })
    });

    // Morgan also edits A10 to a different value based on old curWb.revision
    const wbConflict2 = JSON.parse(JSON.stringify(curWb.workbook));
    const conflictVal2 = 'Conflict2_' + Date.now();
    wbConflict2.sheets[0].cells['A10'] = conflictVal2;
    const rConflict = await api('/api/workbooks/ops-plan/save', {
      method: 'POST',
      headers: { 'x-session-id': sessionMorgan.sessionId },
      body: JSON.stringify({
        sessionId: sessionMorgan.sessionId,
        workbookId: 'ops-plan',
        baseRevision: curWb.revision,
        workbook: wbConflict2
      })
    });
    assert.strictEqual(rConflict.status, 409, 'Overlapping edit must return 409 Conflict');
    assert(rConflict.body.conflictingCells.some(c => c.cell === 'A10'));
    console.log('✓ 409 Conflict properly detected on overlapping edit');

    // 3.12 Cell History & Revisions History
    const revs = (await api('/api/workbooks/ops-plan/revisions')).body;
    assert(revs.length >= 3, 'Multiple revisions stored');
    const rev1Snap = (await api(`/api/workbooks/ops-plan/revisions/${revs[revs.length - 1].revision}`)).body;
    assert(rev1Snap.workbook);

    const a10Hist = (await api('/api/workbooks/ops-plan/sheets/plan/cells/A10/history')).body;
    assert(a10Hist.length >= 2, 'Cell history records multiple changes');
    console.log('✓ Revisions list and cell history verified');

    // 3.13 WebSocket Real-Time Sync Test
    console.log('--- Test Suite 4: WebSocket Real-Time Presence & Broadcasts ---');
    await new Promise((resolve, reject) => {
      const wsUrl = `ws://localhost:${TEST_PORT}/ws?sessionId=${session1.sessionId}&workbookId=ops-plan`;
      const ws = new WebSocket(wsUrl);

      ws.on('open', () => {
        ws.send(JSON.stringify({ type: 'PRESENCE', selectedCell: 'D10', selectedRange: 'D10:D12' }));
      });

      ws.on('message', (data) => {
        const msg = JSON.parse(data.toString());
        if (msg.type === 'PRESENCE_STATE') {
          assert(Array.isArray(msg.sessions));
          ws.close();
          resolve();
        }
      });

      ws.on('error', reject);
    });
    console.log('✓ WebSocket presence messaging verified');

    console.log('\n========================================');
    console.log('  ALL GRIDFORGE INTEGRATION TESTS PASSED');
    console.log('========================================\n');

  } catch (err) {
    console.error('Test Suite Failure:', err);
    process.exit(1);
  } finally {
    server.close();
    process.exit(0);
  }
});
