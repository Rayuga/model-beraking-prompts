const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'gridforge.db');
const SEED_PATH = process.env.SEED_PATH || path.join(__dirname, '..', 'assets', 'workbook_seed.json');

let db = null;

function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    initSchema();
    initSeedData();
  }
  return db;
}

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workbooks (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      current_revision INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sheets (
      id TEXT NOT NULL,
      workbook_id TEXT NOT NULL,
      name TEXT NOT NULL,
      sheet_order INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (workbook_id, id)
    );

    CREATE TABLE IF NOT EXISTS revisions (
      workbook_id TEXT NOT NULL,
      revision INTEGER NOT NULL,
      snapshot_json TEXT NOT NULL,
      author_id TEXT,
      author_name TEXT,
      summary TEXT,
      created_at TEXT NOT NULL,
      PRIMARY KEY (workbook_id, revision)
    );

    CREATE TABLE IF NOT EXISTS cell_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      workbook_id TEXT NOT NULL,
      sheet_id TEXT NOT NULL,
      cell_address TEXT NOT NULL,
      revision INTEGER NOT NULL,
      old_value TEXT,
      new_value TEXT NOT NULL,
      author_id TEXT,
      author_name TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      session_id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      user_name TEXT NOT NULL,
      workbook_id TEXT NOT NULL,
      sheet_id TEXT,
      selected_cell TEXT,
      selected_range TEXT,
      color TEXT,
      last_seen INTEGER NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE INDEX IF NOT EXISTS idx_cell_history_lookup 
      ON cell_history(workbook_id, sheet_id, cell_address, revision DESC);

    CREATE INDEX IF NOT EXISTS idx_revisions_lookup 
      ON revisions(workbook_id, revision DESC);
  `);
}

function initSeedData() {
  const existingWorkbook = db.prepare('SELECT id FROM workbooks WHERE id = ?').get('ops-plan');
  if (existingWorkbook) {
    return;
  }

  let seed = null;
  if (fs.existsSync(SEED_PATH)) {
    try {
      const data = fs.readFileSync(SEED_PATH, 'utf8');
      seed = JSON.parse(data);
    } catch (err) {
      console.error('Error reading seed file:', err);
    }
  }

  if (!seed) {
    seed = {
      users: [
        { id: "riley", name: "Riley Stone" },
        { id: "morgan", name: "Morgan Lee" },
        { id: "priya", name: "Priya Shah" }
      ],
      workbook: {
        id: "ops-plan",
        title: "Northwind Operations Plan",
        sheets: [
          {
            id: "plan",
            name: "Plan",
            cells: {
              "A1": "Item", "B1": "Qty", "C1": "Unit Cost", "D1": "Total", "E1": "Owner",
              "A2": "Server", "B2": "3", "C2": "120", "D2": "=B2*C2", "E2": "Riley",
              "A3": "Database", "B3": "2", "C3": "350", "D3": "=B3*C3", "E3": "Morgan",
              "A4": "Support", "B4": "5", "C4": "80", "D4": "=B4*C4", "E4": "Casey",
              "A6": "Subtotal", "D6": "=SUM(D2:D4)",
              "A7": "Average Cost", "D7": "=AVG(C2:C4)",
              "A9": "Region", "B9": "Revenue", "C9": "Cost", "D9": "Margin",
              "A10": "North", "B10": "1200", "C10": "700", "D10": "=B10-C10",
              "A11": "South", "B11": "900", "C11": "500", "D11": "=B11-C11",
              "A12": "West", "B12": "1500", "C12": "850", "D12": "=B12-C12",
              "A14": "ANCHOR-TOP", "A40": "ANCHOR-MIDDLE", "A80": "ANCHOR-BOTTOM"
            }
          }
        ]
      }
    };
  }

  const now = new Date().toISOString();
  const insertUser = db.prepare('INSERT OR REPLACE INTO users (id, name) VALUES (?, ?)');
  const insertWorkbook = db.prepare('INSERT INTO workbooks (id, title, current_revision, updated_at) VALUES (?, ?, ?, ?)');
  const insertSheet = db.prepare('INSERT INTO sheets (id, workbook_id, name, sheet_order) VALUES (?, ?, ?, ?)');
  const insertRevision = db.prepare('INSERT INTO revisions (workbook_id, revision, snapshot_json, author_id, author_name, summary, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
  const insertCellHistory = db.prepare('INSERT INTO cell_history (workbook_id, sheet_id, cell_address, revision, old_value, new_value, author_id, author_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');

  const initTx = db.transaction(() => {
    if (seed.users && Array.isArray(seed.users)) {
      for (const u of seed.users) {
        insertUser.run(u.id, u.name);
      }
    }

    const wb = seed.workbook;
    insertWorkbook.run(wb.id, wb.title, 1, now);

    if (wb.sheets && Array.isArray(wb.sheets)) {
      wb.sheets.forEach((sh, idx) => {
        insertSheet.run(sh.id, wb.id, sh.name, idx);
      });
    }

    insertRevision.run(wb.id, 1, JSON.stringify(wb), 'system', 'Initial Seed', 'Initial workbook seed', now);

    if (wb.sheets && Array.isArray(wb.sheets)) {
      for (const sh of wb.sheets) {
        if (sh.cells) {
          for (const [addr, val] of Object.entries(sh.cells)) {
            insertCellHistory.run(wb.id, sh.id, addr.toUpperCase(), 1, null, String(val), 'system', 'Initial Seed', now);
          }
        }
      }
    }
  });

  initTx();
}

module.exports = {
  getDb,
  DB_PATH
};
