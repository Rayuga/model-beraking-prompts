const express = require('express');
const http = require('http');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');
const { getDb, DB_PATH } = require('./db');
const formulaEngine = require('./formula');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = '0.0.0.0';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const db = getDb();

// Session timeout threshold in milliseconds (20 seconds without presence/heartbeat)
const SESSION_TIMEOUT_MS = 20000;

// Connected WebSocket clients: Map<sessionId, { ws, sessionId, workbookId } >
const activeWsClients = new Map();

// Helper: Clean up expired sessions periodically
function pruneExpiredSessions() {
  const cutoff = Date.now() - SESSION_TIMEOUT_MS;
  // Mark inactive in DB if not in activeWsClients and last_seen < cutoff
  const activeSessions = db.prepare('SELECT session_id, last_seen, is_active FROM sessions WHERE is_active = 1').all();
  let changed = false;
  for (const s of activeSessions) {
    if (!activeWsClients.has(s.session_id) && s.last_seen < cutoff) {
      db.prepare('UPDATE sessions SET is_active = 0 WHERE session_id = ?').run(s.session_id);
      changed = true;
    }
  }
  if (changed) {
    broadcastPresence('ops-plan');
  }
}
setInterval(pruneExpiredSessions, 5000);

// Helper: Get active sessions for a workbook
function getActiveWorkbookSessions(workbookId) {
  const cutoff = Date.now() - SESSION_TIMEOUT_MS;
  const rows = db.prepare(`
    SELECT session_id as sessionId, user_id as userId, user_name as userName, 
           workbook_id as workbookId, sheet_id as sheetId, selected_cell as selectedCell, 
           selected_range as selectedRange, color, last_seen as lastSeen, is_active as isActive
    FROM sessions 
    WHERE workbook_id = ? AND is_active = 1 AND last_seen >= ?
  `).all(workbookId, cutoff);
  return rows;
}

// Helper: Broadcast message to WS clients watching a workbook
function broadcastToWorkbook(workbookId, messageObj) {
  const msgStr = JSON.stringify(messageObj);
  for (const client of activeWsClients.values()) {
    if (client.workbookId === workbookId && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(msgStr);
    }
  }
}

function broadcastPresence(workbookId) {
  const sessions = getActiveWorkbookSessions(workbookId);
  broadcastToWorkbook(workbookId, {
    type: 'PRESENCE_STATE',
    sessions
  });
}

// User color palette
const USER_COLORS = {
  riley: '#2563eb', // Blue
  morgan: '#059669', // Emerald
  priya: '#7c3aed', // Purple
};

const EXTRA_COLORS = ['#d97706', '#dc2626', '#0891b2', '#db2777', '#4f46e5', '#ca8a04'];

function getColorForUser(userId) {
  if (USER_COLORS[userId.toLowerCase()]) {
    return USER_COLORS[userId.toLowerCase()];
  }
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) % EXTRA_COLORS.length;
  }
  return EXTRA_COLORS[Math.abs(hash)];
}

// --- REST API Endpoints ---

// 1. Get users
app.get('/api/users', (req, res) => {
  const users = db.prepare('SELECT id, name FROM users ORDER BY name ASC').all();
  res.json(users);
});

// 2. Create / Register Session
app.post('/api/sessions', (req, res) => {
  const { userId, workbookId = 'ops-plan', userName } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }

  // Find or insert user
  let user = db.prepare('SELECT id, name FROM users WHERE id = ?').get(userId);
  if (!user) {
    const finalName = userName || userId;
    db.prepare('INSERT OR REPLACE INTO users (id, name) VALUES (?, ?)').run(userId, finalName);
    user = { id: userId, name: finalName };
  }

  const sessionId = 'sess_' + Math.random().toString(36).substring(2, 12) + '_' + Date.now();
  const color = getColorForUser(user.id);
  const now = Date.now();

  db.prepare(`
    INSERT INTO sessions (session_id, user_id, user_name, workbook_id, sheet_id, selected_cell, selected_range, color, last_seen, is_active)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `).run(sessionId, user.id, user.name, workbookId, 'plan', 'A1', 'A1', color, now);

  res.json({
    sessionId,
    userId: user.id,
    userName: user.name,
    color,
    workbookId
  });
});

// 3. Update session presence / heartbeat
app.post('/api/sessions/:sessionId/presence', (req, res) => {
  const { sessionId } = req.params;
  const { sheetId, selectedCell, selectedRange, userId, userName } = req.body;

  const session = db.prepare('SELECT * FROM sessions WHERE session_id = ?').get(sessionId);
  if (!session || !session.is_active) {
    return res.status(404).json({ error: 'Session not found or inactive' });
  }

  let finalUserId = session.user_id;
  let finalUserName = session.user_name;
  let finalColor = session.color;

  if (userId && userId !== session.user_id) {
    const u = db.prepare('SELECT id, name FROM users WHERE id = ?').get(userId);
    if (u) {
      finalUserId = u.id;
      finalUserName = u.name;
    } else {
      finalUserId = userId;
      finalUserName = userName || userId;
      db.prepare('INSERT OR REPLACE INTO users (id, name) VALUES (?, ?)').run(finalUserId, finalUserName);
    }
    finalColor = getColorForUser(finalUserId);
  }

  const now = Date.now();
  db.prepare(`
    UPDATE sessions
    SET sheet_id = COALESCE(?, sheet_id),
        selected_cell = COALESCE(?, selected_cell),
        selected_range = COALESCE(?, selected_range),
        user_id = ?,
        user_name = ?,
        color = ?,
        last_seen = ?,
        is_active = 1
    WHERE session_id = ?
  `).run(sheetId || null, selectedCell || null, selectedRange || null, finalUserId, finalUserName, finalColor, now, sessionId);

  broadcastPresence(session.workbook_id);
  res.json({ success: true, sessionId, userId: finalUserId, userName: finalUserName, color: finalColor });
});

// 4. Close session
app.post('/api/sessions/:sessionId/close', (req, res) => {
  const { sessionId } = req.params;
  const session = db.prepare('SELECT * FROM sessions WHERE session_id = ?').get(sessionId);
  if (session) {
    db.prepare('UPDATE sessions SET is_active = 0 WHERE session_id = ?').run(sessionId);
    broadcastPresence(session.workbook_id);
  }
  if (activeWsClients.has(sessionId)) {
    const client = activeWsClients.get(sessionId);
    try { client.ws.close(); } catch (e) {}
    activeWsClients.delete(sessionId);
  }
  res.json({ success: true });
});

// 5. Get current workbook
app.get('/api/workbooks/:id', (req, res) => {
  const { id } = req.params;
  const wbRow = db.prepare('SELECT * FROM workbooks WHERE id = ?').get(id);
  if (!wbRow) {
    return res.status(404).json({ error: 'Workbook not found' });
  }

  const revRow = db.prepare('SELECT * FROM revisions WHERE workbook_id = ? AND revision = ?').get(id, wbRow.current_revision);
  let snapshot = null;
  if (revRow) {
    try {
      snapshot = JSON.parse(revRow.snapshot_json);
    } catch (e) {
      console.error('Error parsing snapshot JSON:', e);
    }
  }

  if (!snapshot) {
    // Fallback: build from sheets and revisions
    const sheets = db.prepare('SELECT * FROM sheets WHERE workbook_id = ? ORDER BY sheet_order ASC').all(id);
    snapshot = {
      id: wbRow.id,
      title: wbRow.title,
      sheets: sheets.map(s => ({ id: s.id, name: s.name, cells: {} }))
    };
  }

  res.json({
    workbook: snapshot,
    revision: wbRow.current_revision,
    updatedAt: wbRow.updated_at
  });
});

// 6. Get workbook active presence
app.get('/api/workbooks/:id/presence', (req, res) => {
  const { id } = req.params;
  const sessions = getActiveWorkbookSessions(id);
  res.json(sessions);
});

// 7. Get revisions list
app.get('/api/workbooks/:id/revisions', (req, res) => {
  const { id } = req.params;
  const rows = db.prepare(`
    SELECT revision, author_id as authorId, author_name as authorName, summary, created_at as createdAt
    FROM revisions
    WHERE workbook_id = ?
    ORDER BY revision DESC
  `).all(id);
  res.json(rows);
});

// 8. Get specific revision snapshot
app.get('/api/workbooks/:id/revisions/:rev', (req, res) => {
  const { id, rev } = req.params;
  const revNum = parseInt(rev, 10);
  if (isNaN(revNum)) {
    return res.status(400).json({ error: 'Revision must be an integer' });
  }

  const row = db.prepare('SELECT * FROM revisions WHERE workbook_id = ? AND revision = ?').get(id, revNum);
  if (!row) {
    return res.status(404).json({ error: 'Revision not found' });
  }

  let snapshot;
  try {
    snapshot = JSON.parse(row.snapshot_json);
  } catch (err) {
    return res.status(500).json({ error: 'Corrupt snapshot in revision' });
  }

  res.json({
    workbookId: id,
    revision: row.revision,
    authorId: row.author_id,
    authorName: row.author_name,
    summary: row.summary,
    createdAt: row.created_at,
    workbook: snapshot
  });
});

// 9. Get cell history
app.get('/api/workbooks/:id/sheets/:sheetId/cells/:cell/history', (req, res) => {
  const { id, sheetId, cell } = req.params;
  const cleanAddr = cell.toUpperCase().replace(/\$/g, '');

  const rows = db.prepare(`
    SELECT revision, old_value as oldValue, new_value as newValue, author_id as authorId, author_name as authorName, created_at as createdAt
    FROM cell_history
    WHERE workbook_id = ? AND sheet_id = ? AND cell_address = ?
    ORDER BY revision DESC, id DESC
  `).all(id, sheetId, cleanAddr);

  res.json(rows);
});

// Helper: Validate Snapshot Structure
function validateSnapshot(snapshot, expectedWorkbookId) {
  if (!snapshot || typeof snapshot !== 'object') {
    return { valid: false, error: 'Snapshot must be an object' };
  }
  if (snapshot.id !== expectedWorkbookId) {
    return { valid: false, error: `Mismatched workbook ID in snapshot: expected '${expectedWorkbookId}', got '${snapshot.id}'` };
  }
  if (typeof snapshot.title !== 'string' || !snapshot.title.trim()) {
    return { valid: false, error: 'Workbook title must be a non-empty string' };
  }
  if (!Array.isArray(snapshot.sheets) || snapshot.sheets.length === 0) {
    return { valid: false, error: 'Workbook must contain a non-empty sheets array' };
  }

  for (const sheet of snapshot.sheets) {
    if (!sheet || typeof sheet !== 'object') {
      return { valid: false, error: 'Each sheet must be an object' };
    }
    if (typeof sheet.id !== 'string' || !sheet.id.trim()) {
      return { valid: false, error: 'Sheet ID must be a non-empty string' };
    }
    if (typeof sheet.name !== 'string' || !sheet.name.trim()) {
      return { valid: false, error: 'Sheet name must be a non-empty string' };
    }
    if (!sheet.cells || typeof sheet.cells !== 'object' || Array.isArray(sheet.cells)) {
      return { valid: false, error: `Sheet '${sheet.id}' cells must be an object` };
    }
    // Check all cell values are strings
    for (const [addr, val] of Object.entries(sheet.cells)) {
      if (typeof val !== 'string') {
        return { valid: false, error: `Cell '${addr}' value must be a string, got ${typeof val}` };
      }
      // Check address format
      const parsed = formulaEngine.parseCellAddress(addr);
      if (!parsed) {
        return { valid: false, error: `Invalid cell address '${addr}'` };
      }
    }
  }

  return { valid: true };
}

// 10. Save Workbook
app.post('/api/workbooks/:id/save', (req, res) => {
  const { id: urlWorkbookId } = req.params;
  const body = req.body || {};
  const sessionId = req.headers['x-session-id'] || body.sessionId;
  const { workbookId: bodyWorkbookId, baseRevision, workbook: snapshot, userId: claimedUserId } = body;

  // Validate workbook ID
  const targetWorkbookId = urlWorkbookId;
  if (bodyWorkbookId && bodyWorkbookId !== targetWorkbookId) {
    return res.status(400).json({ error: 'Mismatched workbookId in URL and body' });
  }

  // Validate session
  if (!sessionId) {
    return res.status(400).json({ error: 'Session ID is required to save' });
  }
  const cutoff = Date.now() - SESSION_TIMEOUT_MS;
  const session = db.prepare('SELECT * FROM sessions WHERE session_id = ?').get(sessionId);
  if (!session || !session.is_active || session.last_seen < cutoff) {
    return res.status(403).json({ error: 'Session is invalid, inactive, or expired' });
  }

  // If claimedUserId is provided, it must agree with the session
  if (claimedUserId && claimedUserId !== session.user_id) {
    return res.status(400).json({ error: 'Claimed user does not match active session' });
  }

  // Validate baseRevision
  if (typeof baseRevision !== 'number' || !Number.isInteger(baseRevision) || baseRevision < 1) {
    return res.status(400).json({ error: 'baseRevision must be a positive integer' });
  }

  // Validate snapshot structure
  const valResult = validateSnapshot(snapshot, targetWorkbookId);
  if (!valResult.valid) {
    return res.status(400).json({ error: valResult.error });
  }

  // Check existing workbook
  const currentWb = db.prepare('SELECT * FROM workbooks WHERE id = ?').get(targetWorkbookId);
  if (!currentWb) {
    return res.status(404).json({ error: 'Target workbook does not exist' });
  }

  // Verify title and sheets haven't been renamed contradictorily
  if (snapshot.title !== currentWb.title) {
    return res.status(400).json({ error: 'Renaming workbook is not permitted during cell edit' });
  }
  const existingSheets = db.prepare('SELECT id, name FROM sheets WHERE workbook_id = ?').all(targetWorkbookId);
  const existingSheetMap = new Map(existingSheets.map(s => [s.id, s.name]));
  for (const s of snapshot.sheets) {
    if (!existingSheetMap.has(s.id)) {
      return res.status(400).json({ error: `Unknown sheet ID '${s.id}'` });
    }
  }

  // Load current revision snapshot from DB
  const currentRevRow = db.prepare('SELECT * FROM revisions WHERE workbook_id = ? AND revision = ?')
    .get(targetWorkbookId, currentWb.current_revision);
  let currentSnapshot = JSON.parse(currentRevRow.snapshot_json);

  // Normalize cell maps (keys to upper case, remove empty strings if needed)
  function getSheetCells(snap, sheetId) {
    const sh = snap.sheets.find(s => s.id === sheetId);
    if (!sh || !sh.cells) return {};
    const norm = {};
    for (const [k, v] of Object.entries(sh.cells)) {
      norm[k.toUpperCase()] = v;
    }
    return norm;
  }

  // Check if content has changed at all compared to current DB snapshot
  let hasAnyChangeFromCurrent = false;
  for (const sheet of snapshot.sheets) {
    const currentCells = getSheetCells(currentSnapshot, sheet.id);
    const clientCells = getSheetCells(snapshot, sheet.id);

    const allKeys = new Set([...Object.keys(currentCells), ...Object.keys(clientCells)]);
    for (const k of allKeys) {
      const cVal = currentCells[k] !== undefined ? currentCells[k] : '';
      const clVal = clientCells[k] !== undefined ? clientCells[k] : '';
      if (cVal !== clVal) {
        hasAnyChangeFromCurrent = true;
        break;
      }
    }
    if (hasAnyChangeFromCurrent) break;
  }

  if (!hasAnyChangeFromCurrent) {
    // No content change - do not create a new revision
    return res.json({
      success: true,
      revision: currentWb.current_revision,
      workbook: currentSnapshot,
      unchanged: true
    });
  }

  // Concurrent edit resolution:
  let finalSnapshotToSave = snapshot;
  const changesToRecord = []; // { sheetId, address, oldValue, newValue }

  if (baseRevision === currentWb.current_revision) {
    // Clean save based on latest revision
    for (const sheet of snapshot.sheets) {
      const currentCells = getSheetCells(currentSnapshot, sheet.id);
      const clientCells = getSheetCells(snapshot, sheet.id);
      const allKeys = new Set([...Object.keys(currentCells), ...Object.keys(clientCells)]);
      for (const k of allKeys) {
        const cVal = currentCells[k] !== undefined ? currentCells[k] : '';
        const clVal = clientCells[k] !== undefined ? clientCells[k] : '';
        if (cVal !== clVal) {
          changesToRecord.push({
            sheetId: sheet.id,
            address: k,
            oldValue: cVal,
            newValue: clVal
          });
        }
      }
    }
  } else if (baseRevision < currentWb.current_revision) {
    // Base revision is older than current revision: 3-way merge or conflict detection
    const baseRevRow = db.prepare('SELECT * FROM revisions WHERE workbook_id = ? AND revision = ?')
      .get(targetWorkbookId, baseRevision);
    if (!baseRevRow) {
      return res.status(400).json({ error: `Base revision ${baseRevision} not found in history` });
    }
    const baseSnapshot = JSON.parse(baseRevRow.snapshot_json);

    // Merge sheet by sheet
    const mergedSheets = [];
    const conflictingCells = [];

    for (const sheet of snapshot.sheets) {
      const baseCells = getSheetCells(baseSnapshot, sheet.id);
      const currentCells = getSheetCells(currentSnapshot, sheet.id);
      const clientCells = getSheetCells(snapshot, sheet.id);

      const mergedCells = { ...currentCells };
      const allKeys = new Set([...Object.keys(baseCells), ...Object.keys(currentCells), ...Object.keys(clientCells)]);

      for (const k of allKeys) {
        const bVal = baseCells[k] !== undefined ? baseCells[k] : '';
        const curVal = currentCells[k] !== undefined ? currentCells[k] : '';
        const cliVal = clientCells[k] !== undefined ? clientCells[k] : '';

        const clientChanged = (cliVal !== bVal);
        const serverChanged = (curVal !== bVal);

        if (clientChanged && serverChanged) {
          if (cliVal !== curVal) {
            // Overlapping conflicting edit!
            conflictingCells.push({
              sheetId: sheet.id,
              cell: k,
              baseValue: bVal,
              serverValue: curVal,
              clientValue: cliVal
            });
          } else {
            // Both changed to same value - no conflict
            mergedCells[k] = curVal;
          }
        } else if (clientChanged && !serverChanged) {
          // Client changed, server did not -> apply client change
          if (cliVal === '') {
            delete mergedCells[k];
          } else {
            mergedCells[k] = cliVal;
          }
          changesToRecord.push({
            sheetId: sheet.id,
            address: k,
            oldValue: curVal,
            newValue: cliVal
          });
        } else if (!clientChanged && serverChanged) {
          // Server changed, client did not -> keep server value
          // (already in mergedCells)
        }
      }

      mergedSheets.push({
        id: sheet.id,
        name: sheet.name,
        cells: mergedCells
      });
    }

    if (conflictingCells.length > 0) {
      return res.status(409).json({
        error: 'Conflict: Stale overlapping edit detected',
        conflictingCells,
        currentRevision: currentWb.current_revision,
        currentWorkbook: currentSnapshot
      });
    }

    // Merged cleanly
    finalSnapshotToSave = {
      id: snapshot.id,
      title: snapshot.title,
      sheets: mergedSheets
    };
  } else {
    // baseRevision > currentRevision -> invalid future revision
    return res.status(400).json({ error: `Invalid base revision ${baseRevision} > current revision ${currentWb.current_revision}` });
  }

  // If no changes to record after merge
  if (changesToRecord.length === 0) {
    return res.json({
      success: true,
      revision: currentWb.current_revision,
      workbook: currentSnapshot,
      unchanged: true
    });
  }

  // Write new revision
  const newRevisionNum = currentWb.current_revision + 1;
  const now = new Date().toISOString();
  const summary = `Edited by ${session.user_name} (${changesToRecord.length} cell${changesToRecord.length > 1 ? 's' : ''})`;

  const saveTx = db.transaction(() => {
    // 1. Insert revision
    db.prepare(`
      INSERT INTO revisions (workbook_id, revision, snapshot_json, author_id, author_name, summary, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(targetWorkbookId, newRevisionNum, JSON.stringify(finalSnapshotToSave), session.user_id, session.user_name, summary, now);

    // 2. Insert cell histories
    const insertHistory = db.prepare(`
      INSERT INTO cell_history (workbook_id, sheet_id, cell_address, revision, old_value, new_value, author_id, author_name, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const ch of changesToRecord) {
      insertHistory.run(targetWorkbookId, ch.sheetId, ch.address, newRevisionNum, ch.oldValue, ch.newValue, session.user_id, session.user_name, now);
    }

    // 3. Update workbook
    db.prepare(`
      UPDATE workbooks
      SET current_revision = ?, updated_at = ?
      WHERE id = ?
    `).run(newRevisionNum, now, targetWorkbookId);
  });

  saveTx();

  // Broadcast update to all connected WebSocket clients
  broadcastToWorkbook(targetWorkbookId, {
    type: 'WORKBOOK_UPDATED',
    workbookId: targetWorkbookId,
    revision: newRevisionNum,
    author: session.user_name,
    authorId: session.user_id,
    summary,
    createdAt: now,
    workbook: finalSnapshotToSave,
    changes: changesToRecord
  });

  res.json({
    success: true,
    revision: newRevisionNum,
    workbook: finalSnapshotToSave,
    summary,
    createdAt: now
  });
});

// Also support saving via PUT /api/workbooks/:id or POST /api/workbooks/:id
app.put('/api/workbooks/:id', (req, res) => {
  req.url = `/api/workbooks/${req.params.id}/save`;
  app._router.handle(req, res);
});

app.post('/api/workbooks/:id', (req, res) => {
  req.url = `/api/workbooks/${req.params.id}/save`;
  app._router.handle(req, res);
});

// --- WebSocket Handling ---

wss.on('connection', (ws, req) => {
  const urlParams = new URLSearchParams(req.url.replace(/^[^?]*\??/, ''));
  const sessionId = urlParams.get('sessionId');
  const workbookId = urlParams.get('workbookId') || 'ops-plan';

  if (!sessionId) {
    ws.close(4001, 'Missing sessionId');
    return;
  }

  // Register client
  activeWsClients.set(sessionId, { ws, sessionId, workbookId });

  // Update session active
  const now = Date.now();
  db.prepare('UPDATE sessions SET is_active = 1, last_seen = ? WHERE session_id = ?').run(now, sessionId);

  // Send initial presence state
  const sessions = getActiveWorkbookSessions(workbookId);
  ws.send(JSON.stringify({
    type: 'PRESENCE_STATE',
    sessions
  }));

  // Broadcast presence update
  broadcastPresence(workbookId);

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());
      const curTime = Date.now();

      if (msg.type === 'HEARTBEAT' || msg.type === 'PRESENCE') {
        db.prepare(`
          UPDATE sessions 
          SET last_seen = ?,
              is_active = 1,
              sheet_id = COALESCE(?, sheet_id),
              selected_cell = COALESCE(?, selected_cell),
              selected_range = COALESCE(?, selected_range)
          WHERE session_id = ?
        `).run(curTime, msg.sheetId || null, msg.selectedCell || null, msg.selectedRange || null, sessionId);

        broadcastPresence(workbookId);
      } else if (msg.type === 'SET_USER') {
        const { userId, userName } = msg;
        if (userId) {
          let u = db.prepare('SELECT id, name FROM users WHERE id = ?').get(userId);
          if (!u) {
            db.prepare('INSERT OR REPLACE INTO users (id, name) VALUES (?, ?)').run(userId, userName || userId);
            u = { id: userId, name: userName || userId };
          }
          const color = getColorForUser(u.id);
          db.prepare(`
            UPDATE sessions 
            SET user_id = ?, user_name = ?, color = ?, last_seen = ?, is_active = 1
            WHERE session_id = ?
          `).run(u.id, u.name, color, curTime, sessionId);
          broadcastPresence(workbookId);
        }
      }
    } catch (err) {
      console.error('Error handling WS message:', err);
    }
  });

  ws.on('close', () => {
    activeWsClients.delete(sessionId);
    // Mark inactive
    db.prepare('UPDATE sessions SET is_active = 0, last_seen = ? WHERE session_id = ?').run(Date.now(), sessionId);
    broadcastPresence(workbookId);
  });

  ws.on('error', (err) => {
    console.error('WS client error:', err);
    activeWsClients.delete(sessionId);
  });
});

// Start Server
if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log(`GridForge server listening on http://${HOST}:${PORT}`);
  });
}

module.exports = { app, server, getDb };
