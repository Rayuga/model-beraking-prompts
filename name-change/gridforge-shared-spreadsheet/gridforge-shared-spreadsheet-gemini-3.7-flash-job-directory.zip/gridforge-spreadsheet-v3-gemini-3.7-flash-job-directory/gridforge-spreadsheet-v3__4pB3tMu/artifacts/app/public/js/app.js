// GridForge Main Application Controller

document.addEventListener('DOMContentLoaded', async () => {
  const workbookId = 'ops-plan';
  let currentRevision = 1;
  let baseRevision = 1;
  let hasUnsavedChanges = false;
  let autosaveTimer = null;
  let isPreviewMode = false;
  let previewRevisionData = null;
  let autosavePaused = false;
  let autosavePauseTimer = null;

  // DOM Elements
  const workbookTitleEl = document.getElementById('workbook-title');
  const saveStatusEl = document.getElementById('save-status');
  const saveStatusTextEl = document.getElementById('save-status-text');
  const userSelectEl = document.getElementById('user-select');
  const presenceLegendEl = document.getElementById('presence-legend');
  const btnSaveNow = document.getElementById('btn-save-now');
  const btnUndo = document.getElementById('btn-undo');
  const btnRedo = document.getElementById('btn-redo');
  const btnHistory = document.getElementById('btn-history');
  const btnCellHistory = document.getElementById('btn-cell-history');
  const btnFindReplace = document.getElementById('btn-find-replace');
  const btnFillDown = document.getElementById('btn-fill-down');
  const btnFillRight = document.getElementById('btn-fill-right');

  // Preview Banner
  const previewBanner = document.getElementById('preview-banner');
  const previewBannerText = document.getElementById('preview-banner-text');
  const btnRestoreRevision = document.getElementById('btn-restore-revision');
  const btnExitPreview = document.getElementById('btn-exit-preview');

  // Modals
  const historyModal = document.getElementById('history-modal');
  const btnCloseHistory = document.getElementById('btn-close-history');
  const btnHistoryCancel = document.getElementById('btn-history-cancel');
  const revisionsListEl = document.getElementById('revisions-list');

  const cellHistoryModal = document.getElementById('cell-history-modal');
  const btnCloseCellHistory = document.getElementById('btn-close-cell-history');
  const btnCellHistoryClose = document.getElementById('btn-cell-history-close');
  const cellHistoryAddrEl = document.getElementById('cell-history-addr');
  const cellHistoryListEl = document.getElementById('cell-history-list');

  const conflictModal = document.getElementById('conflict-modal');
  const conflictDetailsEl = document.getElementById('conflict-details');
  const btnConflictKeepMine = document.getElementById('btn-conflict-keep-mine');
  const btnConflictKeepServer = document.getElementById('btn-conflict-keep-server');

  // Find & Replace Drawer
  const findReplaceDrawer = document.getElementById('find-replace-drawer');
  const findInput = document.getElementById('find-input');
  const replaceInput = document.getElementById('replace-input');
  const btnFindNext = document.getElementById('btn-find-next');
  const btnReplaceCurrent = document.getElementById('btn-replace-current');
  const btnReplaceAll = document.getElementById('btn-replace-all');
  const btnCloseFind = document.getElementById('btn-close-find');
  const findStatusText = document.getElementById('find-status');

  const toastContainer = document.getElementById('toast-container');

  // Initialize Undo/Redo
  const undoRedo = new HistoryManager.UndoRedoStack();

  // Initialize Spreadsheet Grid
  const grid = new GridForgeGrid.SpreadsheetGrid({
    undoRedo,
    onCellChange: (changes) => {
      markUnsaved();
      triggerAutosave();
    },
    onSelectionChange: ({ activeCell, selectedRange, sheetId }) => {
      if (collab) {
        collab.sendPresence(activeCell, selectedRange, sheetId);
      }
    }
  });

  // Initialize Collaboration Manager
  const initialUserId = userSelectEl.value || 'riley';
  const initialUserName = userSelectEl.options[userSelectEl.selectedIndex]?.text || 'Riley Stone';

  const collab = new CollaborationClient.CollaborationManager({
    workbookId,
    userId: initialUserId,
    userName: initialUserName,
    onPresenceChange: (sessions) => {
      renderPresence(sessions);
      renderPresenceLegend(sessions);
    },
    onRemoteUpdate: (msg) => {
      handleRemoteUpdate(msg);
    }
  });

  // --- Helper: Toast Notification ---
  function showToast(message, type = 'info', duration = 3500) {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  // --- Helper: Save Status Badge ---
  function setSaveStatus(state, text) {
    saveStatusEl.className = `save-status-badge ${state}`;
    saveStatusTextEl.textContent = text;
  }

  function markUnsaved() {
    if (isPreviewMode) return;
    hasUnsavedChanges = true;
    setSaveStatus('unsaved', 'Unsaved edits');
  }

  function markSaved(rev) {
    hasUnsavedChanges = false;
    currentRevision = rev;
    baseRevision = rev;
    setSaveStatus('saved', `Saved (Rev #${rev})`);
  }

  // --- Load Initial Users & Workbook ---
  async function loadInitialData() {
    try {
      // 1. Fetch Users
      const usersRes = await fetch('/api/users');
      if (usersRes.ok) {
        const users = await usersRes.json();
        userSelectEl.innerHTML = '';
        users.forEach(u => {
          const opt = document.createElement('option');
          opt.value = u.id;
          opt.textContent = u.name;
          userSelectEl.appendChild(opt);
        });
        userSelectEl.value = collab.userId;
      }

      // 2. Fetch Workbook
      const wbRes = await fetch(`/api/workbooks/${encodeURIComponent(workbookId)}`);
      if (!wbRes.ok) throw new Error('Failed to load workbook');
      const wbData = await wbRes.json();

      currentRevision = wbData.revision;
      baseRevision = wbData.revision;

      if (wbData.workbook) {
        if (wbData.workbook.title) {
          workbookTitleEl.textContent = wbData.workbook.title;
        }
        const sheet = (wbData.workbook.sheets && wbData.workbook.sheets[0]) || { cells: {} };
        grid.sheetId = sheet.id || 'plan';
        grid.loadSheetData(sheet.cells);
      }

      markSaved(currentRevision);

      // 3. Init Collaboration Session
      await collab.init();
    } catch (err) {
      console.error('Error loading initial data:', err);
      showToast('Error loading workbook from server', 'error');
    }
  }

  // --- Save Workbook to Server ---
  async function saveWorkbook(isManual = false) {
    if (isPreviewMode) return;
    if (!collab || !collab.sessionId) {
      showToast('No active session, cannot save', 'error');
      return;
    }

    setSaveStatus('saving', 'Saving...');

    const snapshot = {
      id: workbookId,
      title: workbookTitleEl.textContent,
      sheets: [
        {
          id: grid.sheetId,
          name: 'Plan',
          cells: grid.getSnapshotCells()
        }
      ]
    };

    try {
      const res = await fetch(`/api/workbooks/${encodeURIComponent(workbookId)}/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': collab.sessionId
        },
        body: JSON.stringify({
          sessionId: collab.sessionId,
          userId: collab.userId,
          workbookId,
          baseRevision,
          workbook: snapshot
        })
      });

      const data = await res.json();

      if (res.status === 200) {
        markSaved(data.revision);
        if (data.workbook && data.workbook.sheets && data.workbook.sheets[0]) {
          // If server merged changes, reload merged state
          if (data.merged) {
            grid.loadSheetData(data.workbook.sheets[0].cells);
            showToast('Changes merged with latest server revision', 'info');
          }
        }
        if (isManual) {
          showToast('Workbook saved successfully', 'success');
        }
      } else if (res.status === 409) {
        // Conflict!
        setSaveStatus('error', 'Conflict');
        showConflictModal(data);
      } else {
        setSaveStatus('error', 'Save error');
        showToast(`Save failed: ${data.error || res.statusText}`, 'error');
      }
    } catch (err) {
      console.error('Save error:', err);
      setSaveStatus('error', 'Save failed');
      showToast('Network error while saving', 'error');
    }
  }

  // --- Autosave Handling ---
  function triggerAutosave() {
    if (autosavePaused || isPreviewMode) return;
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(() => {
      saveWorkbook(false);
    }, 2500);
  }

  function pauseAutosave(durationMs = 10000) {
    autosavePaused = true;
    clearTimeout(autosaveTimer);
    clearTimeout(autosavePauseTimer);
    autosavePauseTimer = setTimeout(() => {
      autosavePaused = false;
      if (hasUnsavedChanges) {
        triggerAutosave();
      }
    }, durationMs);
  }

  // --- Remote Update Broadcasts ---
  function handleRemoteUpdate(msg) {
    if (msg.authorId === collab.userId && msg.workbookId === workbookId) {
      // Own update already reflected
      return;
    }

    const incomingCells = (msg.workbook && msg.workbook.sheets && msg.workbook.sheets[0] && msg.workbook.sheets[0].cells) || {};
    const newRev = msg.revision;

    if (!hasUnsavedChanges) {
      // Clean sync
      grid.loadSheetData(incomingCells);
      markSaved(newRev);
      showToast(`Updated by ${msg.author || 'colleague'} (Rev #${newRev})`, 'info');
    } else {
      // Local unsaved draft exists: combine non-overlapping edits, conflict on overlapping
      const localCells = grid.getSnapshotCells();
      const conflicts = [];
      const mergedCells = { ...incomingCells };

      for (const [addr, localVal] of Object.entries(localCells)) {
        const incomingVal = incomingCells[addr] !== undefined ? incomingCells[addr] : '';
        // If changed locally
        if (localVal !== incomingVal) {
          // Check if incoming update also changed this cell
          const changedByColleague = (msg.changes || []).some(ch => ch.address === addr);
          if (changedByColleague) {
            conflicts.push({
              cell: addr,
              localValue: localVal,
              serverValue: incomingVal
            });
          } else {
            // Keep local draft
            mergedCells[addr] = localVal;
          }
        }
      }

      baseRevision = newRev;

      if (conflicts.length > 0) {
        showConflictModal({ conflictingCells: conflicts, currentRevision: newRev, currentWorkbook: msg.workbook });
      } else {
        grid.loadSheetData(mergedCells);
        showToast(`Merged changes from ${msg.author || 'colleague'}`, 'info');
      }
    }
  }

  // --- Conflict Modal ---
  let activeConflictData = null;
  function showConflictModal(conflictData) {
    activeConflictData = conflictData;
    conflictDetailsEl.innerHTML = '';

    const list = conflictData.conflictingCells || [];
    list.forEach(c => {
      const div = document.createElement('div');
      div.style.marginBottom = '6px';
      div.innerHTML = `<strong>Cell ${c.cell || c.address}:</strong> Local Draft: "<code>${c.clientValue || c.localValue || ''}</code>" vs Server: "<code>${c.serverValue || ''}</code>"`;
      conflictDetailsEl.appendChild(div);
    });

    conflictModal.classList.remove('hidden');
  }

  btnConflictKeepMine.addEventListener('click', async () => {
    conflictModal.classList.add('hidden');
    if (activeConflictData && activeConflictData.currentRevision) {
      baseRevision = activeConflictData.currentRevision;
      await saveWorkbook(true);
    }
  });

  btnConflictKeepServer.addEventListener('click', () => {
    conflictModal.classList.add('hidden');
    if (activeConflictData && activeConflictData.currentWorkbook && activeConflictData.currentWorkbook.sheets) {
      const cells = activeConflictData.currentWorkbook.sheets[0]?.cells || {};
      grid.loadSheetData(cells);
      markSaved(activeConflictData.currentRevision);
      showToast('Reset to latest server revision', 'info');
    }
  });

  // --- Presence Overlay & Legend Rendering ---
  function renderPresence(sessions) {
    const overlay = grid.presenceOverlay;
    if (!overlay) return;
    overlay.innerHTML = '';

    sessions.forEach(sess => {
      if (!sess.selectedCell) return;
      const cell = FormulaEngine.parseCellAddress(sess.selectedCell);
      if (!cell) return;

      const td = grid.getCellTd(cell.col, cell.row);
      if (!td) return;

      const box = document.createElement('div');
      box.className = 'presence-box';
      box.style.left = `${td.offsetLeft}px`;
      box.style.top = `${td.offsetTop}px`;
      box.style.width = `${td.offsetWidth}px`;
      box.style.height = `${td.offsetHeight}px`;
      box.style.borderColor = sess.color || '#2563eb';

      const tag = document.createElement('div');
      tag.className = 'presence-tag';
      tag.style.backgroundColor = sess.color || '#2563eb';
      tag.textContent = sess.userName || sess.userId;

      box.appendChild(tag);
      overlay.appendChild(box);
    });
  }

  function renderPresenceLegend(sessions) {
    presenceLegendEl.innerHTML = '';

    // Show self
    const selfAvatar = document.createElement('div');
    selfAvatar.className = 'presence-avatar';
    selfAvatar.style.backgroundColor = collab.color;
    selfAvatar.title = `${collab.userName} (You)`;
    selfAvatar.textContent = (collab.userName || 'U').substring(0, 2).toUpperCase();
    presenceLegendEl.appendChild(selfAvatar);

    // Show others
    sessions.forEach(sess => {
      const avatar = document.createElement('div');
      avatar.className = 'presence-avatar';
      avatar.style.backgroundColor = sess.color || '#64748b';
      avatar.title = `${sess.userName || sess.userId} (${sess.selectedCell || 'viewing'})`;
      avatar.textContent = (sess.userName || sess.userId || 'U').substring(0, 2).toUpperCase();
      presenceLegendEl.appendChild(avatar);
    });
  }

  // --- User Switching ---
  userSelectEl.addEventListener('change', async () => {
    const selectedUserId = userSelectEl.value;
    const selectedUserName = userSelectEl.options[userSelectEl.selectedIndex].text;
    await collab.switchUser(selectedUserId, selectedUserName);
    renderPresenceLegend(collab.activeSessions);
    showToast(`Switched user to ${selectedUserName}`, 'info');
  });

  // --- Undo / Redo UI Button Sync ---
  undoRedo.onChange(({ canUndo, canRedo }) => {
    btnUndo.disabled = !canUndo;
    btnRedo.disabled = !canRedo;
    btnUndo.style.opacity = canUndo ? '1' : '0.4';
    btnRedo.style.opacity = canRedo ? '1' : '0.4';
  });
  undoRedo.notifyChange();

  btnUndo.addEventListener('click', () => undoRedo.undo());
  btnRedo.addEventListener('click', () => undoRedo.redo());
  btnSaveNow.addEventListener('click', () => saveWorkbook(true));

  // --- Fill Toolbar Buttons ---
  btnFillDown.addEventListener('click', () => grid.fillDown());
  btnFillRight.addEventListener('click', () => grid.fillRight());

  // --- Revision History Modal & Preview ---
  btnHistory.addEventListener('click', async () => {
    try {
      const res = await fetch(`/api/workbooks/${encodeURIComponent(workbookId)}/revisions`);
      if (!res.ok) throw new Error('Failed to fetch revisions');
      const revisions = await res.json();

      revisionsListEl.innerHTML = '';
      revisions.forEach(rev => {
        const card = document.createElement('div');
        card.className = `revision-card ${rev.revision === currentRevision ? 'current' : ''}`;
        const dateStr = new Date(rev.createdAt).toLocaleString();

        card.innerHTML = `
          <div class="revision-meta">
            <div class="revision-number">
              Revision #${rev.revision}
              ${rev.revision === currentRevision ? '<span class="current-badge">Current</span>' : ''}
            </div>
            <div class="revision-details">
              Saved by <strong>${rev.authorName || rev.authorId}</strong> &bull; ${dateStr}
            </div>
          </div>
          <button class="btn btn-sm btn-outline btn-preview-rev" data-rev="${rev.revision}">Preview</button>
        `;

        card.querySelector('.btn-preview-rev').addEventListener('click', (e) => {
          e.stopPropagation();
          previewRevision(rev.revision);
        });

        card.addEventListener('click', () => {
          previewRevision(rev.revision);
        });

        revisionsListEl.appendChild(card);
      });

      historyModal.classList.remove('hidden');
    } catch (err) {
      console.error('Error fetching revisions:', err);
      showToast('Error loading revision history', 'error');
    }
  });

  function closeHistoryModal() {
    historyModal.classList.add('hidden');
  }

  btnCloseHistory.addEventListener('click', closeHistoryModal);
  btnHistoryCancel.addEventListener('click', closeHistoryModal);

  async function previewRevision(revNumber) {
    try {
      closeHistoryModal();
      const res = await fetch(`/api/workbooks/${encodeURIComponent(workbookId)}/revisions/${revNumber}`);
      if (!res.ok) throw new Error('Failed to fetch revision snapshot');
      const data = await res.json();

      isPreviewMode = true;
      previewRevisionData = data;
      grid.isReadOnly = true;

      const sheet = (data.workbook && data.workbook.sheets && data.workbook.sheets[0]) || { cells: {} };
      grid.loadSheetData(sheet.cells);

      previewBannerText.textContent = `Previewing Revision #${data.revision} (Saved by ${data.authorName || 'User'} on ${new Date(data.createdAt).toLocaleString()})`;
      previewBanner.classList.remove('hidden');

      showToast(`Previewing Revision #${data.revision}`, 'info');
    } catch (err) {
      console.error('Error previewing revision:', err);
      showToast('Error loading revision snapshot', 'error');
    }
  }

  function exitPreview() {
    if (!isPreviewMode) return;
    isPreviewMode = false;
    grid.isReadOnly = false;
    previewBanner.classList.add('hidden');
    previewRevisionData = null;

    // Reload latest current workbook
    loadInitialData();
  }

  btnExitPreview.addEventListener('click', exitPreview);

  btnRestoreRevision.addEventListener('click', () => {
    if (!previewRevisionData) return;
    const restoredSnapshot = previewRevisionData.workbook;
    const restoredRev = previewRevisionData.revision;
    const restoredCells = (restoredSnapshot.sheets && restoredSnapshot.sheets[0] && restoredSnapshot.sheets[0].cells) || {};

    // Capture previous state for undo
    const prevCells = grid.getSnapshotCells();

    isPreviewMode = false;
    grid.isReadOnly = false;
    previewBanner.classList.add('hidden');

    // Load restored version into undoable draft
    grid.loadSheetData(restoredCells);

    undoRedo.push({
      description: `Restore Revision #${restoredRev}`,
      undo: () => {
        grid.loadSheetData(prevCells);
        markUnsaved();
      },
      redo: () => {
        grid.loadSheetData(restoredCells);
        markUnsaved();
      }
    });

    markUnsaved();
    setSaveStatus('unsaved', `Draft restored from Rev #${restoredRev} (Unsaved)`);
    pauseAutosave(15000); // Give user time to inspect or undo before autosave

    showToast(`Revision #${restoredRev} restored as draft (Unsaved). Press Ctrl+Z to undo.`, 'success', 5000);
  });

  // --- Cell History Inspector ---
  btnCellHistory.addEventListener('click', async () => {
    const addr = FormulaEngine.formatCellAddress(grid.activeCol, grid.activeRow);
    cellHistoryAddrEl.textContent = addr;

    try {
      const res = await fetch(`/api/workbooks/${encodeURIComponent(workbookId)}/sheets/${encodeURIComponent(grid.sheetId)}/cells/${encodeURIComponent(addr)}/history`);
      if (!res.ok) throw new Error('Failed to fetch cell history');
      const history = await res.json();

      cellHistoryListEl.innerHTML = '';
      if (history.length === 0) {
        cellHistoryListEl.innerHTML = '<p class="modal-subtitle">No recorded edits for this cell.</p>';
      } else {
        history.forEach(item => {
          const div = document.createElement('div');
          div.className = 'cell-history-item';
          const timeStr = new Date(item.createdAt).toLocaleString();
          div.innerHTML = `
            <div class="cell-history-header">
              <span>Revision #${item.revision} &bull; <strong>${item.authorName || item.authorId}</strong></span>
              <span>${timeStr}</span>
            </div>
            <div class="cell-history-val-change">
              <span class="old-val">${item.oldValue === null ? '(empty)' : item.oldValue}</span>
              <span>&rarr;</span>
              <span class="new-val">${item.newValue}</span>
            </div>
          `;
          cellHistoryListEl.appendChild(div);
        });
      }

      cellHistoryModal.classList.remove('hidden');
    } catch (err) {
      console.error('Error fetching cell history:', err);
      showToast('Error loading cell history', 'error');
    }
  });

  function closeCellHistoryModal() {
    cellHistoryModal.classList.add('hidden');
  }

  btnCloseCellHistory.addEventListener('click', closeCellHistoryModal);
  btnCellHistoryClose.addEventListener('click', closeCellHistoryModal);

  // --- Find & Replace ---
  btnFindReplace.addEventListener('click', () => {
    findReplaceDrawer.classList.toggle('hidden');
    if (!findReplaceDrawer.classList.contains('hidden')) {
      findInput.focus();
      findInput.select();
    } else {
      grid.clearFindHighlights();
    }
  });

  btnCloseFind.addEventListener('click', () => {
    findReplaceDrawer.classList.add('hidden');
    grid.clearFindHighlights();
    grid.container.focus();
  });

  findInput.addEventListener('input', () => {
    const q = findInput.value;
    const matches = grid.findAll(q);
    findStatusText.textContent = matches.length > 0 ? `${matches.length} match${matches.length > 1 ? 'es' : ''}` : (q ? 'No matches' : '');
  });

  findInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      executeFindNext();
    } else if (e.key === 'Escape') {
      btnCloseFind.click();
    }
  });

  replaceInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      btnReplaceCurrent.click();
    } else if (e.key === 'Escape') {
      btnCloseFind.click();
    }
  });

  function executeFindNext() {
    const q = findInput.value;
    const res = grid.findNext(q);
    if (res) {
      findStatusText.textContent = `${res.index} of ${res.total}`;
    } else {
      findStatusText.textContent = q ? 'No matches' : '';
    }
  }

  btnFindNext.addEventListener('click', executeFindNext);

  btnReplaceCurrent.addEventListener('click', () => {
    const q = findInput.value;
    const r = replaceInput.value;
    if (q) {
      grid.replaceCurrent(q, r);
      executeFindNext();
    }
  });

  btnReplaceAll.addEventListener('click', () => {
    const q = findInput.value;
    const r = replaceInput.value;
    if (q) {
      grid.replaceAll(q, r);
      findStatusText.textContent = 'All replaced';
      showToast(`Replaced all occurrences of "${q}" with "${r}"`, 'success');
    }
  });

  // Global Keyboard Shortcuts (Ctrl+S, Ctrl+F, Ctrl+H)
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
      e.preventDefault();
      saveWorkbook(true);
    } else if ((e.ctrlKey || e.metaKey) && (e.key === 'f' || e.key === 'F' || e.key === 'h' || e.key === 'H')) {
      e.preventDefault();
      findReplaceDrawer.classList.remove('hidden');
      findInput.focus();
      findInput.select();
    }
  });

  // Load application
  await loadInitialData();
});
