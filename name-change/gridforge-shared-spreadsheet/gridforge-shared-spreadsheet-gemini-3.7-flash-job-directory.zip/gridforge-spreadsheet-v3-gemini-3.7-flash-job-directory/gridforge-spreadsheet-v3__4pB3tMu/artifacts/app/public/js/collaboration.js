// GridForge Real-Time Collaboration Client

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.CollaborationClient = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {

  class CollaborationManager {
    constructor(options = {}) {
      this.workbookId = options.workbookId || 'ops-plan';
      this.userId = options.userId || 'riley';
      this.userName = options.userName || 'Riley Stone';
      this.sessionId = null;
      this.color = '#2563eb';
      this.ws = null;
      this.activeSessions = [];
      this.onRemoteUpdate = options.onRemoteUpdate || null;
      this.onPresenceChange = options.onPresenceChange || null;
      this.heartbeatTimer = null;
      this.reconnectTimer = null;
    }

    async init() {
      try {
        const res = await fetch('/api/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: this.userId,
            userName: this.userName,
            workbookId: this.workbookId
          })
        });
        if (!res.ok) {
          throw new Error(`Failed to create session: ${res.status}`);
        }
        const data = await res.json();
        this.sessionId = data.sessionId;
        this.userId = data.userId;
        this.userName = data.userName;
        this.color = data.color;

        this.connectWebSocket();
        this.startHeartbeat();

        window.addEventListener('beforeunload', () => {
          this.closeSession();
        });

        return data;
      } catch (err) {
        console.error('Collaboration init failed:', err);
        throw err;
      }
    }

    connectWebSocket() {
      if (!this.sessionId) return;
      if (this.ws) {
        try { this.ws.close(); } catch (e) {}
      }

      const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${location.host}/ws?sessionId=${encodeURIComponent(this.sessionId)}&workbookId=${encodeURIComponent(this.workbookId)}`;

      try {
        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
          // Send initial presence
          this.sendPresence();
        };

        this.ws.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data);
            this.handleMessage(msg);
          } catch (e) {
            console.error('Error parsing WS message:', e);
          }
        };

        this.ws.onclose = () => {
          this.ws = null;
          // Attempt reconnect if session is still alive
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = setTimeout(() => {
            this.connectWebSocket();
          }, 3000);
        };

        this.ws.onerror = (err) => {
          console.error('WS Error:', err);
        };
      } catch (err) {
        console.error('WebSocket connection failed:', err);
      }
    }

    handleMessage(msg) {
      if (msg.type === 'PRESENCE_STATE') {
        this.activeSessions = (msg.sessions || []).filter(s => s.sessionId !== this.sessionId);
        if (this.onPresenceChange) {
          this.onPresenceChange(this.activeSessions);
        }
      } else if (msg.type === 'WORKBOOK_UPDATED') {
        if (this.onRemoteUpdate) {
          this.onRemoteUpdate(msg);
        }
      }
    }

    sendPresence(selectedCell = 'A1', selectedRange = 'A1', sheetId = 'plan') {
      this._lastCell = selectedCell;
      this._lastRange = selectedRange;
      this._lastSheet = sheetId;

      const payload = {
        type: 'PRESENCE',
        selectedCell,
        selectedRange,
        sheetId
      };

      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify(payload));
      } else if (this.sessionId) {
        // Fallback to REST presence
        fetch(`/api/sessions/${encodeURIComponent(this.sessionId)}/presence`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }).catch(err => console.error('REST presence fallback error:', err));
      }
    }

    async switchUser(newUserId, newUserName) {
      this.userId = newUserId;
      this.userName = newUserName || newUserId;

      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({
          type: 'SET_USER',
          userId: this.userId,
          userName: this.userName
        }));
      }

      if (this.sessionId) {
        try {
          const res = await fetch(`/api/sessions/${encodeURIComponent(this.sessionId)}/presence`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId: this.userId,
              userName: this.userName,
              selectedCell: this._lastCell || 'A1',
              selectedRange: this._lastRange || 'A1',
              sheetId: this._lastSheet || 'plan'
            })
          });
          const data = await res.json();
          if (data && data.color) {
            this.color = data.color;
          }
        } catch (e) {
          console.error('Error switching user via REST:', e);
        }
      }
    }

    startHeartbeat() {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = setInterval(() => {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ type: 'HEARTBEAT' }));
        } else if (this.sessionId) {
          fetch(`/api/sessions/${encodeURIComponent(this.sessionId)}/presence`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              selectedCell: this._lastCell || 'A1',
              selectedRange: this._lastRange || 'A1',
              sheetId: this._lastSheet || 'plan'
            })
          }).catch(() => {});
        }
      }, 10000);
    }

    closeSession() {
      if (this.sessionId) {
        const url = `/api/sessions/${encodeURIComponent(this.sessionId)}/close`;
        if (navigator.sendBeacon) {
          navigator.sendBeacon(url, JSON.stringify({}));
        } else {
          fetch(url, { method: 'POST', keepalive: true }).catch(() => {});
        }
      }
      if (this.ws) {
        try { this.ws.close(); } catch (e) {}
      }
      clearInterval(this.heartbeatTimer);
    }
  }

  return {
    CollaborationManager
  };
}));
