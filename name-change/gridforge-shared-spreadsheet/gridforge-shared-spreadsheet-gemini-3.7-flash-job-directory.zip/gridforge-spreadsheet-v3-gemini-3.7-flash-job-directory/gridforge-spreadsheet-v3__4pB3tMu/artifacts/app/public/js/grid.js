// GridForge Spreadsheet Grid Component

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.GridForgeGrid = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {

  const TOTAL_ROWS = 100;
  const TOTAL_COLS = 26; // A to Z

  const FORMULA_FUNCTIONS = [
    { name: 'SUM', desc: 'SUM(range, ...): Sums all numbers' },
    { name: 'AVG', desc: 'AVG(range, ...): Calculates average' },
    { name: 'MIN', desc: 'MIN(range, ...): Finds minimum value' },
    { name: 'MAX', desc: 'MAX(range, ...): Finds maximum value' },
    { name: 'COUNT', desc: 'COUNT(range, ...): Counts numeric items' }
  ];

  class SpreadsheetGrid {
    constructor(options = {}) {
      this.container = options.container || document.getElementById('grid-scroll-container');
      this.table = options.table || document.getElementById('sheet-table');
      this.thead = options.thead || document.getElementById('grid-thead');
      this.tbody = options.tbody || document.getElementById('grid-tbody');
      this.formulaBar = options.formulaBar || document.getElementById('formula-bar');
      this.nameBox = options.nameBox || document.getElementById('name-box');
      this.editorInput = options.editorInput || document.getElementById('cell-editor-input');
      this.selectionBox = options.selectionBox || document.getElementById('selection-box');
      this.fillHandle = options.fillHandle || document.getElementById('fill-handle');
      this.suggestionsBox = options.suggestionsBox || document.getElementById('formula-suggestions');
      this.refOverlay = options.refOverlay || document.getElementById('formula-references-overlay');
      this.presenceOverlay = options.presenceOverlay || document.getElementById('presence-overlay');

      this.undoRedo = options.undoRedo || new FormulaEngine.HistoryManager.UndoRedoStack();
      this.onCellChange = options.onCellChange || null;
      this.onSelectionChange = options.onSelectionChange || null;

      this.rowsCount = TOTAL_ROWS;
      this.colsCount = TOTAL_COLS;

      // Workbook State
      this.sheetId = 'plan';
      this.rawCells = {}; // { "A1": "Item", "D2": "=B2*C2" }
      this.computedCells = {}; // { "A1": "Item", "D2": 360 }

      // Selection State
      this.activeCol = 0;
      this.activeRow = 0;
      this.selection = { startCol: 0, startRow: 0, endCol: 0, endRow: 0 };
      this.isSelecting = false;
      this.isFillDragging = false;
      this.fillStartSelection = null;
      this.fillTarget = null;

      // Editing State
      this.isEditing = false;
      this.editInitialValue = '';
      this.isFormulaPicking = false;
      this.formulaPickLastRange = null;
      this.selectedSuggestionIndex = -1;
      this.filteredSuggestions = [];

      // Find State
      this.findMatches = [];
      this.currentFindIndex = -1;
      this.isReadOnly = false;

      // DOM Elements Cache: tdMap[row][col]
      this.tdMap = [];

      this.initDOM();
      this.bindEvents();
    }

    // --- DOM Initialization ---

    initDOM() {
      // Build Header
      const headerTr = document.createElement('tr');
      const cornerTh = document.createElement('th');
      cornerTh.className = 'corner-header';
      headerTr.appendChild(cornerTh);

      for (let c = 0; c < this.colsCount; c++) {
        const colTh = document.createElement('th');
        colTh.className = 'col-header';
        colTh.dataset.col = c;
        colTh.textContent = FormulaEngine.indexToColName(c);
        headerTr.appendChild(colTh);
      }
      this.thead.innerHTML = '';
      this.thead.appendChild(headerTr);

      // Build Rows & Cells
      this.tbody.innerHTML = '';
      this.tdMap = [];

      for (let r = 0; r < this.rowsCount; r++) {
        const tr = document.createElement('tr');
        const rowTh = document.createElement('th');
        rowTh.className = 'row-header';
        rowTh.dataset.row = r;
        rowTh.textContent = r + 1;
        tr.appendChild(rowTh);

        const rowCells = [];
        for (let c = 0; c < this.colsCount; c++) {
          const td = document.createElement('td');
          td.className = 'grid-cell';
          td.dataset.col = c;
          td.dataset.row = r;
          const addr = FormulaEngine.formatCellAddress(c, r);
          td.dataset.addr = addr;
          tr.appendChild(td);
          rowCells.push(td);
        }
        this.tbody.appendChild(tr);
        this.tdMap.push(rowCells);
      }

      this.updateSelectionDOM();
    }

    // --- Data Loading & Recalculation ---

    loadSheetData(cellsObj) {
      this.rawCells = {};
      if (cellsObj) {
        for (const [k, v] of Object.entries(cellsObj)) {
          this.rawCells[k.toUpperCase()] = String(v);
        }
      }
      this.recalculateAll();
      this.renderAllCells();
    }

    getSnapshotCells() {
      const snap = {};
      for (const [k, v] of Object.entries(this.rawCells)) {
        if (v !== '' && v !== null && v !== undefined) {
          snap[k] = String(v);
        }
      }
      return snap;
    }

    recalculateAll() {
      this.computedCells = FormulaEngine.recalculateSheet(this.rawCells);
    }

    renderAllCells() {
      for (let r = 0; r < this.rowsCount; r++) {
        for (let c = 0; c < this.colsCount; c++) {
          this.renderCell(c, r);
        }
      }
    }

    renderCell(col, row) {
      const td = this.getCellTd(col, row);
      if (!td) return;
      const addr = FormulaEngine.formatCellAddress(col, row);
      const computed = this.computedCells[addr];
      const raw = this.rawCells[addr] || '';

      td.classList.remove('cell-error', 'align-right', 'align-center');

      if (computed === undefined || computed === null || computed === '') {
        td.textContent = '';
      } else if (typeof computed === 'string' && computed.startsWith('#')) {
        // Formula error
        td.textContent = computed;
        td.classList.add('cell-error');
      } else if (typeof computed === 'number') {
        td.textContent = computed;
        td.classList.add('align-right');
      } else if (typeof computed === 'boolean') {
        td.textContent = computed ? 'TRUE' : 'FALSE';
        td.classList.add('align-center');
      } else {
        // String
        td.textContent = computed;
        if (!isNaN(Number(computed)) && computed.trim() !== '') {
          td.classList.add('align-right');
        }
      }
    }

    getCellTd(col, row) {
      if (row >= 0 && row < this.rowsCount && col >= 0 && col < this.colsCount) {
        return this.tdMap[row][col];
      }
      return null;
    }

    getRawValue(col, row) {
      const addr = FormulaEngine.formatCellAddress(col, row);
      return this.rawCells[addr] || '';
    }

    setRawValue(col, row, value, isUndoable = true) {
      const addr = FormulaEngine.formatCellAddress(col, row);
      const oldValue = this.rawCells[addr] || '';
      const strVal = String(value);

      if (oldValue === strVal) return;

      if (isUndoable) {
        this.undoRedo.push({
          description: `Edit ${addr}`,
          undo: () => {
            if (oldValue === '') {
              delete this.rawCells[addr];
            } else {
              this.rawCells[addr] = oldValue;
            }
            this.recalculateAll();
            this.renderAllCells();
            this.updateFormulaBar();
            if (this.onCellChange) this.onCellChange({ [addr]: oldValue });
          },
          redo: () => {
            if (strVal === '') {
              delete this.rawCells[addr];
            } else {
              this.rawCells[addr] = strVal;
            }
            this.recalculateAll();
            this.renderAllCells();
            this.updateFormulaBar();
            if (this.onCellChange) this.onCellChange({ [addr]: strVal });
          }
        });
      }

      if (strVal === '') {
        delete this.rawCells[addr];
      } else {
        this.rawCells[addr] = strVal;
      }

      this.recalculateAll();
      this.renderAllCells();
      this.updateFormulaBar();

      if (this.onCellChange) {
        this.onCellChange({ [addr]: strVal });
      }
    }

    setMultipleCells(changesMap, description = 'Batch edit', isUndoable = true) {
      // changesMap: { "A1": "newVal", "B2": "otherVal" }
      const oldValues = {};
      const newValues = {};
      let hasChanges = false;

      for (const [addr, newVal] of Object.entries(changesMap)) {
        const cleanAddr = addr.toUpperCase();
        const oldVal = this.rawCells[cleanAddr] || '';
        const strVal = String(newVal);
        if (oldVal !== strVal) {
          oldValues[cleanAddr] = oldVal;
          newValues[cleanAddr] = strVal;
          hasChanges = true;
        }
      }

      if (!hasChanges) return;

      if (isUndoable) {
        this.undoRedo.push({
          description,
          undo: () => {
            for (const [k, v] of Object.entries(oldValues)) {
              if (v === '') delete this.rawCells[k];
              else this.rawCells[k] = v;
            }
            this.recalculateAll();
            this.renderAllCells();
            this.updateFormulaBar();
            if (this.onCellChange) this.onCellChange(oldValues);
          },
          redo: () => {
            for (const [k, v] of Object.entries(newValues)) {
              if (v === '') delete this.rawCells[k];
              else this.rawCells[k] = v;
            }
            this.recalculateAll();
            this.renderAllCells();
            this.updateFormulaBar();
            if (this.onCellChange) this.onCellChange(newValues);
          }
        });
      }

      for (const [k, v] of Object.entries(newValues)) {
        if (v === '') delete this.rawCells[k];
        else this.rawCells[k] = v;
      }

      this.recalculateAll();
      this.renderAllCells();
      this.updateFormulaBar();

      if (this.onCellChange) {
        this.onCellChange(newValues);
      }
    }

    // --- Selection Management ---

    setSelection(startCol, startRow, endCol, endRow, scrollIntoView = true) {
      startCol = Math.max(0, Math.min(this.colsCount - 1, startCol));
      endCol = Math.max(0, Math.min(this.colsCount - 1, endCol));
      startRow = Math.max(0, Math.min(this.rowsCount - 1, startRow));
      endRow = Math.max(0, Math.min(this.rowsCount - 1, endRow));

      this.activeCol = startCol;
      this.activeRow = startRow;
      this.selection = { startCol, startRow, endCol, endRow };

      this.updateSelectionDOM();
      this.updateFormulaBar();
      this.updateNameBox();

      if (scrollIntoView) {
        this.scrollToCell(startCol, startRow);
      }

      if (this.onSelectionChange) {
        const addr = FormulaEngine.formatCellAddress(startCol, startRow);
        const range = this.getSelectionRangeAddress();
        this.onSelectionChange({ activeCell: addr, selectedRange: range, sheetId: this.sheetId });
      }
    }

    getNormalizedSelection() {
      const minCol = Math.min(this.selection.startCol, this.selection.endCol);
      const maxCol = Math.max(this.selection.startCol, this.selection.endCol);
      const minRow = Math.min(this.selection.startRow, this.selection.endRow);
      const maxRow = Math.max(this.selection.startRow, this.selection.endRow);
      return { minCol, maxCol, minRow, maxRow };
    }

    getSelectionRangeAddress() {
      const { minCol, maxCol, minRow, maxRow } = this.getNormalizedSelection();
      const c1 = FormulaEngine.formatCellAddress(minCol, minRow);
      if (minCol === maxCol && minRow === maxRow) {
        return c1;
      }
      const c2 = FormulaEngine.formatCellAddress(maxCol, maxRow);
      return `${c1}:${c2}`;
    }

    updateSelectionDOM() {
      const { minCol, maxCol, minRow, maxRow } = this.getNormalizedSelection();

      // Clear previous cell selections
      const prevSelected = this.tbody.querySelectorAll('.cell-selected, .cell-active');
      prevSelected.forEach(el => el.classList.remove('cell-selected', 'cell-active'));

      // Clear header highlights
      const prevHeaders = this.table.querySelectorAll('.selected-header');
      prevHeaders.forEach(el => el.classList.remove('selected-header'));

      // Highlight headers
      for (let c = minCol; c <= maxCol; c++) {
        const th = this.thead.querySelector(`th[data-col="${c}"]`);
        if (th) th.classList.add('selected-header');
      }
      for (let r = minRow; r <= maxRow; r++) {
        const th = this.tbody.querySelector(`th[data-row="${r}"]`);
        if (th) th.classList.add('selected-header');
      }

      // Highlight cells in selection
      for (let r = minRow; r <= maxRow; r++) {
        for (let c = minCol; c <= maxCol; c++) {
          const td = this.getCellTd(c, r);
          if (td) {
            if (c === this.activeCol && r === this.activeRow) {
              td.classList.add('cell-active');
            } else {
              td.classList.add('cell-selected');
            }
          }
        }
      }

      // Position selection bounding box
      const startTd = this.getCellTd(minCol, minRow);
      const endTd = this.getCellTd(maxCol, maxRow);

      if (startTd && endTd && this.selectionBox) {
        const sLeft = startTd.offsetLeft;
        const sTop = startTd.offsetTop;
        const sWidth = (endTd.offsetLeft + endTd.offsetWidth) - sLeft;
        const sHeight = (endTd.offsetTop + endTd.offsetHeight) - sTop;

        this.selectionBox.style.left = `${sLeft}px`;
        this.selectionBox.style.top = `${sTop}px`;
        this.selectionBox.style.width = `${sWidth}px`;
        this.selectionBox.style.height = `${sHeight}px`;
        this.selectionBox.classList.remove('hidden');
      }
    }

    scrollToCell(col, row) {
      const td = this.getCellTd(col, row);
      if (!td || !this.container) return;

      const container = this.container;
      const tdLeft = td.offsetLeft;
      const tdTop = td.offsetTop;
      const tdRight = tdLeft + td.offsetWidth;
      const tdBottom = tdTop + td.offsetHeight;

      const viewLeft = container.scrollLeft + 48; // row header offset
      const viewRight = container.scrollLeft + container.clientWidth;
      const viewTop = container.scrollTop + 26; // col header offset
      const viewBottom = container.scrollTop + container.clientHeight;

      if (tdLeft < viewLeft) {
        container.scrollLeft = tdLeft - 50;
      } else if (tdRight > viewRight) {
        container.scrollLeft = tdRight - container.clientWidth + 10;
      }

      if (tdTop < viewTop) {
        container.scrollTop = tdTop - 30;
      } else if (tdBottom > viewBottom) {
        container.scrollTop = tdBottom - container.clientHeight + 10;
      }
    }

    updateFormulaBar() {
      if (this.formulaBar && !this.isEditing) {
        const raw = this.getRawValue(this.activeCol, this.activeRow);
        this.formulaBar.value = raw;
      }
    }

    updateNameBox() {
      if (this.nameBox) {
        this.nameBox.value = this.getSelectionRangeAddress();
      }
    }

    // --- Cell Editing & Formula Autocomplete ---

    startEditing(initialChar = null) {
      if (this.isReadOnly) return;
      this.isEditing = true;

      const raw = this.getRawValue(this.activeCol, this.activeRow);
      this.editInitialValue = raw;

      const td = this.getCellTd(this.activeCol, this.activeRow);
      if (!td) return;

      let val = raw;
      if (initialChar !== null) {
        val = initialChar;
      }

      this.editorInput.style.left = `${td.offsetLeft}px`;
      this.editorInput.style.top = `${td.offsetTop}px`;
      this.editorInput.style.width = `${td.offsetWidth}px`;
      this.editorInput.style.height = `${td.offsetHeight}px`;
      this.editorInput.value = val;
      this.editorInput.classList.remove('hidden');
      this.editorInput.focus();

      if (initialChar === null) {
        this.editorInput.select();
      }

      if (this.formulaBar) {
        this.formulaBar.value = val;
      }

      this.checkFormulaSuggestions(val);
      this.updateFormulaReferenceHighlight(val);
    }

    commitEdit(moveDirection = null) {
      if (!this.isEditing) return;

      const newVal = this.editorInput.value;
      const col = this.activeCol;
      const row = this.activeRow;

      this.isEditing = false;
      this.isFormulaPicking = false;
      this.formulaPickLastRange = null;
      this.editorInput.classList.add('hidden');
      this.hideSuggestions();
      this.clearFormulaReferenceHighlight();

      this.setRawValue(col, row, newVal, true);

      // Navigate after commit
      if (moveDirection === 'down') {
        this.setSelection(col, row + 1, col, row + 1);
      } else if (moveDirection === 'up') {
        this.setSelection(col, row - 1, col, row - 1);
      } else if (moveDirection === 'right') {
        this.setSelection(col + 1, row, col + 1, row);
      } else if (moveDirection === 'left') {
        this.setSelection(col - 1, row, col - 1, row);
      }

      this.container.focus();
    }

    cancelEdit() {
      if (!this.isEditing) return;

      this.isEditing = false;
      this.isFormulaPicking = false;
      this.formulaPickLastRange = null;
      this.editorInput.classList.add('hidden');
      this.hideSuggestions();
      this.clearFormulaReferenceHighlight();

      this.updateFormulaBar();
      this.container.focus();
    }

    // Suggestions Dropdown
    checkFormulaSuggestions(text) {
      if (!text || !text.startsWith('=')) {
        this.hideSuggestions();
        return;
      }

      // Find token at cursor or end
      const m = text.match(/=([A-Za-z]*)$/);
      if (m) {
        const query = m[1].toUpperCase();
        this.filteredSuggestions = FORMULA_FUNCTIONS.filter(f => f.name.startsWith(query));
        if (this.filteredSuggestions.length > 0) {
          this.showSuggestions(this.filteredSuggestions);
          return;
        }
      }
      this.hideSuggestions();
    }

    showSuggestions(list) {
      this.suggestionsBox.innerHTML = '';
      this.selectedSuggestionIndex = 0;

      list.forEach((item, idx) => {
        const div = document.createElement('div');
        div.className = `suggestion-item ${idx === 0 ? 'selected' : ''}`;
        div.innerHTML = `<span class="suggestion-name">${item.name}</span><span class="suggestion-desc">${item.desc}</span>`;
        div.addEventListener('mousedown', (e) => {
          e.preventDefault();
          this.applySuggestion(item.name);
        });
        this.suggestionsBox.appendChild(div);
      });

      const td = this.getCellTd(this.activeCol, this.activeRow);
      if (td) {
        this.suggestionsBox.style.left = `${td.offsetLeft}px`;
        this.suggestionsBox.style.top = `${td.offsetTop + td.offsetHeight + 2}px`;
        this.suggestionsBox.classList.remove('hidden');
      }
    }

    hideSuggestions() {
      this.suggestionsBox.classList.add('hidden');
      this.selectedSuggestionIndex = -1;
      this.filteredSuggestions = [];
    }

    applySuggestion(funcName) {
      const cur = this.editorInput.value;
      const replaced = cur.replace(/=([A-Za-z]*)$/, `=${funcName}(`);
      this.editorInput.value = replaced;
      if (this.formulaBar) this.formulaBar.value = replaced;
      this.hideSuggestions();
      this.editorInput.focus();
      this.updateFormulaReferenceHighlight(replaced);
    }

    // Formula Reference Picking
    handleFormulaReferencePick(rangeAddress) {
      if (!this.isEditing) return;

      const input = this.editorInput;
      let text = input.value;

      if (!text.startsWith('=')) {
        text = '=' + text;
      }

      if (this.isFormulaPicking && this.formulaPickLastRange) {
        // Replace previous picked reference if user didn't type anything since
        if (text.endsWith(this.formulaPickLastRange)) {
          text = text.slice(0, -this.formulaPickLastRange.length) + rangeAddress;
        } else {
          text += rangeAddress;
        }
      } else {
        // Append reference
        text += rangeAddress;
      }

      this.isFormulaPicking = true;
      this.formulaPickLastRange = rangeAddress;
      input.value = text;
      if (this.formulaBar) this.formulaBar.value = text;
      this.updateFormulaReferenceHighlight(text);
    }

    updateFormulaReferenceHighlight(formulaText) {
      this.clearFormulaReferenceHighlight();
      if (!formulaText || !formulaText.startsWith('=')) return;

      const deps = FormulaEngine.extractDependencies(formulaText);
      for (const cell of deps) {
        const parsed = FormulaEngine.parseCellAddress(cell);
        if (parsed) {
          const td = this.getCellTd(parsed.col, parsed.row);
          if (td && this.refOverlay) {
            const box = document.createElement('div');
            box.className = 'formula-reference-box';
            box.style.left = `${td.offsetLeft}px`;
            box.style.top = `${td.offsetTop}px`;
            box.style.width = `${td.offsetWidth}px`;
            box.style.height = `${td.offsetHeight}px`;
            this.refOverlay.appendChild(box);
          }
        }
      }
    }

    clearFormulaReferenceHighlight() {
      if (this.refOverlay) {
        this.refOverlay.innerHTML = '';
      }
    }

    // --- Fill Handle & Pattern Continuation ---

    startFillDrag(e) {
      if (this.isReadOnly) return;
      e.preventDefault();
      e.stopPropagation();
      this.isFillDragging = true;
      this.fillStartSelection = { ...this.getNormalizedSelection() };
      this.fillTarget = { ...this.fillStartSelection };

      const onMouseMove = (moveEvent) => {
        if (!this.isFillDragging) return;
        const cell = this.getCellFromPoint(moveEvent.clientX, moveEvent.clientY);
        if (cell) {
          this.updateFillTarget(cell.col, cell.row);
        }
      };

      const onMouseUp = () => {
        this.isFillDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        this.executeFill();
      };

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    }

    updateFillTarget(col, row) {
      const src = this.fillStartSelection;
      if (!src) return;

      // Determine dominant direction
      const dX = (col > src.maxCol) ? (col - src.maxCol) : (col < src.minCol) ? (src.minCol - col) : 0;
      const dY = (row > src.maxRow) ? (row - src.maxRow) : (row < src.minRow) ? (src.minRow - row) : 0;

      if (dY >= dX && dY > 0) {
        if (row > src.maxRow) {
          this.fillTarget = { ...src, maxRow: row };
        } else if (row < src.minRow) {
          this.fillTarget = { ...src, minRow: row };
        }
      } else if (dX > 0) {
        if (col > src.maxCol) {
          this.fillTarget = { ...src, maxCol: col };
        } else if (col < src.minCol) {
          this.fillTarget = { ...src, minCol: col };
        }
      } else {
        this.fillTarget = { ...src };
      }

      // Update selection box size
      const startTd = this.getCellTd(this.fillTarget.minCol, this.fillTarget.minRow);
      const endTd = this.getCellTd(this.fillTarget.maxCol, this.fillTarget.maxRow);
      if (startTd && endTd && this.selectionBox) {
        const sLeft = startTd.offsetLeft;
        const sTop = startTd.offsetTop;
        const sWidth = (endTd.offsetLeft + endTd.offsetWidth) - sLeft;
        const sHeight = (endTd.offsetTop + endTd.offsetHeight) - sTop;
        this.selectionBox.style.left = `${sLeft}px`;
        this.selectionBox.style.top = `${sTop}px`;
        this.selectionBox.style.width = `${sWidth}px`;
        this.selectionBox.style.height = `${sHeight}px`;
      }
    }

    executeFill() {
      const src = this.fillStartSelection;
      const target = this.fillTarget;
      if (!src || !target) return;

      const changes = {};

      if (target.maxRow > src.maxRow) {
        // Fill Down
        this.performFillDown(src, target.maxRow, changes);
      } else if (target.maxCol > src.maxCol) {
        // Fill Right
        this.performFillRight(src, target.maxCol, changes);
      }

      if (Object.keys(changes).length > 0) {
        this.setMultipleCells(changes, 'Fill pattern');
      }

      this.setSelection(target.minCol, target.minRow, target.maxCol, target.maxRow);
      this.fillStartSelection = null;
      this.fillTarget = null;
    }

    performFillDown(src, targetMaxRow, changes) {
      const srcRowCount = src.maxRow - src.minRow + 1;

      for (let c = src.minCol; c <= src.maxCol; c++) {
        // Collect source values in this column
        const colVals = [];
        for (let r = src.minRow; r <= src.maxRow; r++) {
          colVals.push(this.getRawValue(c, r));
        }

        // Check if numeric progression (e.g. 1, 2, 3 or 10, 20)
        const allNumeric = colVals.length >= 2 && colVals.every(v => v !== '' && !isNaN(Number(v)));
        let step = 0;
        if (allNumeric) {
          const numVals = colVals.map(Number);
          step = (numVals[numVals.length - 1] - numVals[0]) / (numVals.length - 1);
        }

        for (let r = src.maxRow + 1; r <= targetMaxRow; r++) {
          const deltaRow = r - src.maxRow;
          const targetAddr = FormulaEngine.formatCellAddress(c, r);

          if (allNumeric) {
            const lastVal = Number(colVals[colVals.length - 1]);
            const nextVal = lastVal + step * deltaRow;
            // Format cleanly
            changes[targetAddr] = String(Math.round(nextVal * 1e8) / 1e8);
          } else {
            // Pattern repeat or formula reference adjustment
            const srcRowOffset = (r - src.minRow) % srcRowCount;
            const srcRow = src.minRow + srcRowOffset;
            const srcVal = this.getRawValue(c, srcRow);
            const rShift = r - srcRow;

            if (srcVal.startsWith('=')) {
              changes[targetAddr] = FormulaEngine.shiftFormulaReferences(srcVal, 0, rShift);
            } else if (srcRowCount === 1 && !isNaN(Number(srcVal)) && srcVal.trim() !== '') {
              // Single number incrementing by 1
              changes[targetAddr] = String(Number(srcVal) + deltaRow);
            } else {
              changes[targetAddr] = srcVal;
            }
          }
        }
      }
    }

    performFillRight(src, targetMaxCol, changes) {
      const srcColCount = src.maxCol - src.minCol + 1;

      for (let r = src.minRow; r <= src.maxRow; r++) {
        const rowVals = [];
        for (let c = src.minCol; c <= src.maxCol; c++) {
          rowVals.push(this.getRawValue(c, r));
        }

        const allNumeric = rowVals.length >= 2 && rowVals.every(v => v !== '' && !isNaN(Number(v)));
        let step = 0;
        if (allNumeric) {
          const numVals = rowVals.map(Number);
          step = (numVals[numVals.length - 1] - numVals[0]) / (numVals.length - 1);
        }

        for (let c = src.maxCol + 1; c <= targetMaxCol; c++) {
          const deltaCol = c - src.maxCol;
          const targetAddr = FormulaEngine.formatCellAddress(c, r);

          if (allNumeric) {
            const lastVal = Number(rowVals[rowVals.length - 1]);
            const nextVal = lastVal + step * deltaCol;
            changes[targetAddr] = String(Math.round(nextVal * 1e8) / 1e8);
          } else {
            const srcColOffset = (c - src.minCol) % srcColCount;
            const srcCol = src.minCol + srcColOffset;
            const srcVal = this.getRawValue(srcCol, r);
            const cShift = c - srcCol;

            if (srcVal.startsWith('=')) {
              changes[targetAddr] = FormulaEngine.shiftFormulaReferences(srcVal, cShift, 0);
            } else if (srcColCount === 1 && !isNaN(Number(srcVal)) && srcVal.trim() !== '') {
              changes[targetAddr] = String(Number(srcVal) + deltaCol);
            } else {
              changes[targetAddr] = srcVal;
            }
          }
        }
      }
    }

    fillDown() {
      const norm = this.getNormalizedSelection();
      if (norm.minRow === norm.maxRow) {
        // Expand down 1 row if single row
        this.fillStartSelection = { ...norm };
        this.fillTarget = { ...norm, maxRow: Math.min(this.rowsCount - 1, norm.maxRow + 1) };
      } else {
        // Fill from top row down to bottom of selection
        this.fillStartSelection = { ...norm, maxRow: norm.minRow };
        this.fillTarget = { ...norm };
      }
      this.executeFill();
    }

    fillRight() {
      const norm = this.getNormalizedSelection();
      if (norm.minCol === norm.maxCol) {
        this.fillStartSelection = { ...norm };
        this.fillTarget = { ...norm, maxCol: Math.min(this.colsCount - 1, norm.maxCol + 1) };
      } else {
        this.fillStartSelection = { ...norm, maxCol: norm.minCol };
        this.fillTarget = { ...norm };
      }
      this.executeFill();
    }

    // --- Clipboard Operations (TSV / CSV) ---

    copySelection(isCut = false) {
      const { minCol, maxCol, minRow, maxRow } = this.getNormalizedSelection();
      const rows = [];
      const changesToClear = {};

      for (let r = minRow; r <= maxRow; r++) {
        const rowCells = [];
        for (let c = minCol; c <= maxCol; c++) {
          const val = this.getRawValue(c, r);
          rowCells.push(val);
          if (isCut) {
            changesToClear[FormulaEngine.formatCellAddress(c, r)] = '';
          }
        }
        rows.push(rowCells.join('\t'));
      }

      const tsvText = rows.join('\n');
      if (navigator.clipboard) {
        navigator.clipboard.writeText(tsvText).catch(() => {});
      }

      if (isCut) {
        this.setMultipleCells(changesToClear, 'Cut cells');
      }
    }

    pasteClipboardText(clipboardText) {
      if (!clipboardText || this.isReadOnly) return;

      // Parse TSV or CSV
      const lines = clipboardText.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
      // If trailing empty line, remove
      if (lines.length > 1 && lines[lines.length - 1] === '') {
        lines.pop();
      }

      const startCol = this.activeCol;
      const startRow = this.activeRow;
      const changes = {};

      lines.forEach((line, rIdx) => {
        const targetRow = startRow + rIdx;
        if (targetRow >= this.rowsCount) return;

        // Check delimiter: tab vs comma
        let cells = line.split('\t');
        if (cells.length === 1 && line.includes(',')) {
          // Simple CSV parser
          cells = line.split(',');
        }

        cells.forEach((cellVal, cIdx) => {
          const targetCol = startCol + cIdx;
          if (targetCol >= this.colsCount) return;

          const addr = FormulaEngine.formatCellAddress(targetCol, targetRow);
          changes[addr] = cellVal.trim();
        });
      });

      if (Object.keys(changes).length > 0) {
        this.setMultipleCells(changes, 'Paste data');
        // Extend selection over pasted area
        const pRows = lines.length;
        const pCols = lines[0] ? lines[0].split('\t').length : 1;
        this.setSelection(startCol, startRow, Math.min(this.colsCount - 1, startCol + pCols - 1), Math.min(this.rowsCount - 1, startRow + pRows - 1));
      }
    }

    clearSelection() {
      if (this.isReadOnly) return;
      const { minCol, maxCol, minRow, maxRow } = this.getNormalizedSelection();
      const changes = {};
      for (let r = minRow; r <= maxRow; r++) {
        for (let c = minCol; c <= maxCol; c++) {
          changes[FormulaEngine.formatCellAddress(c, r)] = '';
        }
      }
      this.setMultipleCells(changes, 'Clear cells');
    }

    // --- Find & Replace ---

    findAll(query) {
      this.findMatches = [];
      this.currentFindIndex = -1;
      this.clearFindHighlights();

      if (!query || query.trim() === '') return [];

      const q = query.toLowerCase();

      for (let r = 0; r < this.rowsCount; r++) {
        for (let c = 0; c < this.colsCount; c++) {
          const raw = this.getRawValue(c, r).toLowerCase();
          const comp = String(this.computedCells[FormulaEngine.formatCellAddress(c, r)] || '').toLowerCase();
          if (raw.includes(q) || comp.includes(q)) {
            this.findMatches.push({ col: c, row: r, addr: FormulaEngine.formatCellAddress(c, r) });
            const td = this.getCellTd(c, r);
            if (td) td.classList.add('cell-find-match');
          }
        }
      }

      return this.findMatches;
    }

    findNext(query) {
      if (this.findMatches.length === 0 || query) {
        this.findAll(query);
      }
      if (this.findMatches.length === 0) return null;

      this.currentFindIndex = (this.currentFindIndex + 1) % this.findMatches.length;
      const match = this.findMatches[this.currentFindIndex];

      // Highlight active match
      this.tbody.querySelectorAll('.cell-find-active').forEach(el => el.classList.remove('cell-find-active'));
      const td = this.getCellTd(match.col, match.row);
      if (td) td.classList.add('cell-find-active');

      this.setSelection(match.col, match.row, match.col, match.row, true);
      return { match, index: this.currentFindIndex + 1, total: this.findMatches.length };
    }

    replaceCurrent(findQuery, replaceText) {
      if (this.currentFindIndex < 0 || this.currentFindIndex >= this.findMatches.length) {
        this.findNext(findQuery);
      }
      if (this.findMatches.length === 0 || this.currentFindIndex < 0) return;

      const match = this.findMatches[this.currentFindIndex];
      const curVal = this.getRawValue(match.col, match.row);

      const regex = new RegExp(findQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      const newVal = curVal.replace(regex, replaceText);

      this.setRawValue(match.col, match.row, newVal, true);
      this.findNext(findQuery);
    }

    replaceAll(findQuery, replaceText) {
      if (!findQuery) return;
      const matches = this.findAll(findQuery);
      if (matches.length === 0) return;

      const changes = {};
      const regex = new RegExp(findQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');

      for (const m of matches) {
        const curVal = this.getRawValue(m.col, m.row);
        changes[m.addr] = curVal.replace(regex, replaceText);
      }

      this.setMultipleCells(changes, `Replace all '${findQuery}' with '${replaceText}'`);
      this.clearFindHighlights();
    }

    clearFindHighlights() {
      this.tbody.querySelectorAll('.cell-find-match, .cell-find-active').forEach(el => {
        el.classList.remove('cell-find-match', 'cell-find-active');
      });
      this.findMatches = [];
      this.currentFindIndex = -1;
    }

    // --- Event Binding ---

    getCellFromPoint(clientX, clientY) {
      const el = document.elementFromPoint(clientX, clientY);
      if (!el) return null;
      const td = el.closest('td.grid-cell');
      if (td && td.dataset.col !== undefined && td.dataset.row !== undefined) {
        return {
          col: parseInt(td.dataset.col, 10),
          row: parseInt(td.dataset.row, 10),
          addr: td.dataset.addr
        };
      }
      return null;
    }

    bindEvents() {
      // Table Mouse Events
      this.tbody.addEventListener('mousedown', (e) => {
        const td = e.target.closest('td.grid-cell');
        if (!td) return;

        const col = parseInt(td.dataset.col, 10);
        const row = parseInt(td.dataset.row, 10);

        if (this.isEditing && (col !== this.activeCol || row !== this.activeRow)) {
          // If editing formula, check if reference picking
          const currentText = this.editorInput.value;
          if (currentText.startsWith('=')) {
            e.preventDefault();
            this.handleFormulaReferencePick(FormulaEngine.formatCellAddress(col, row));
            return;
          } else {
            this.commitEdit();
          }
        }

        if (e.shiftKey) {
          // Extend selection
          this.setSelection(this.selection.startCol, this.selection.startRow, col, row, false);
          return;
        }

        this.isSelecting = true;
        this.setSelection(col, row, col, row, false);

        const onMouseMove = (moveEvent) => {
          if (!this.isSelecting) return;
          const targetTd = moveEvent.target.closest('td.grid-cell');
          if (targetTd) {
            const tCol = parseInt(targetTd.dataset.col, 10);
            const tRow = parseInt(targetTd.dataset.row, 10);
            this.setSelection(this.selection.startCol, this.selection.startRow, tCol, tRow, false);
          }
        };

        const onMouseUp = () => {
          this.isSelecting = false;
          document.removeEventListener('mousemove', onMouseMove);
          document.removeEventListener('mouseup', onMouseUp);
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });

      // Double Click to Edit
      this.tbody.addEventListener('dblclick', (e) => {
        const td = e.target.closest('td.grid-cell');
        if (!td) return;
        const col = parseInt(td.dataset.col, 10);
        const row = parseInt(td.dataset.row, 10);
        this.setSelection(col, row, col, row, false);
        this.startEditing();
      });

      // Fill Handle Drag
      if (this.fillHandle) {
        this.fillHandle.addEventListener('mousedown', (e) => {
          this.startFillDrag(e);
        });
      }

      // Keyboard Events on Container
      this.container.addEventListener('keydown', (e) => {
        if (this.isEditing) return;

        const { activeCol, activeRow } = this;

        // Navigation
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          if (e.shiftKey) {
            this.setSelection(this.selection.startCol, this.selection.startRow, this.selection.endCol, Math.max(0, this.selection.endRow - 1));
          } else {
            this.setSelection(activeCol, activeRow - 1, activeCol, activeRow - 1);
          }
        } else if (e.key === 'ArrowDown') {
          e.preventDefault();
          if (e.shiftKey) {
            this.setSelection(this.selection.startCol, this.selection.startRow, this.selection.endCol, Math.min(this.rowsCount - 1, this.selection.endRow + 1));
          } else {
            this.setSelection(activeCol, activeRow + 1, activeCol, activeRow + 1);
          }
        } else if (e.key === 'ArrowLeft') {
          e.preventDefault();
          if (e.shiftKey) {
            this.setSelection(this.selection.startCol, this.selection.startRow, Math.max(0, this.selection.endCol - 1), this.selection.endRow);
          } else {
            this.setSelection(activeCol - 1, activeRow, activeCol - 1, activeRow);
          }
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          if (e.shiftKey) {
            this.setSelection(this.selection.startCol, this.selection.startRow, Math.min(this.colsCount - 1, this.selection.endCol + 1), this.selection.endRow);
          } else {
            this.setSelection(activeCol + 1, activeRow, activeCol + 1, activeRow);
          }
        } else if (e.key === 'Tab') {
          e.preventDefault();
          if (e.shiftKey) {
            this.setSelection(activeCol - 1, activeRow, activeCol - 1, activeRow);
          } else {
            this.setSelection(activeCol + 1, activeRow, activeCol + 1, activeRow);
          }
        } else if (e.key === 'Enter') {
          e.preventDefault();
          if (e.shiftKey) {
            this.setSelection(activeCol, activeRow - 1, activeCol, activeRow - 1);
          } else {
            this.setSelection(activeCol, activeRow + 1, activeCol, activeRow + 1);
          }
        } else if (e.key === 'F2') {
          e.preventDefault();
          this.startEditing();
        } else if (e.key === 'Delete' || e.key === 'Backspace') {
          e.preventDefault();
          this.clearSelection();
        } else if (e.key === 'Escape') {
          // Blur container to reach surrounding controls
          this.container.blur();
          if (this.formulaBar) this.formulaBar.focus();
        } else if (e.ctrlKey || e.metaKey) {
          if (e.key === 'c' || e.key === 'C') {
            this.copySelection(false);
          } else if (e.key === 'x' || e.key === 'X') {
            e.preventDefault();
            this.copySelection(true);
          } else if (e.key === 'z' || e.key === 'Z') {
            e.preventDefault();
            if (e.shiftKey) {
              this.undoRedo.redo();
            } else {
              this.undoRedo.undo();
            }
          } else if (e.key === 'y' || e.key === 'Y') {
            e.preventDefault();
            this.undoRedo.redo();
          }
        } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
          // Direct typing into active cell
          e.preventDefault();
          this.startEditing(e.key);
        }
      });

      // Paste Event
      document.addEventListener('paste', (e) => {
        if (this.isEditing) return;
        const target = e.target;
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

        const clipboardData = e.clipboardData || window.clipboardData;
        if (clipboardData) {
          e.preventDefault();
          const pastedText = clipboardData.getData('text');
          this.pasteClipboardText(pastedText);
        }
      });

      // Active Cell Editor Input Events
      this.editorInput.addEventListener('input', () => {
        const val = this.editorInput.value;
        if (this.formulaBar) this.formulaBar.value = val;
        this.checkFormulaSuggestions(val);
        this.updateFormulaReferenceHighlight(val);
      });

      this.editorInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          if (!this.suggestionsBox.classList.contains('hidden') && this.selectedSuggestionIndex >= 0) {
            this.applySuggestion(this.filteredSuggestions[this.selectedSuggestionIndex].name);
          } else {
            this.commitEdit(e.shiftKey ? 'up' : 'down');
          }
        } else if (e.key === 'Tab') {
          e.preventDefault();
          if (!this.suggestionsBox.classList.contains('hidden') && this.selectedSuggestionIndex >= 0) {
            this.applySuggestion(this.filteredSuggestions[this.selectedSuggestionIndex].name);
          } else {
            this.commitEdit(e.shiftKey ? 'left' : 'right');
          }
        } else if (e.key === 'Escape') {
          e.preventDefault();
          this.cancelEdit();
        } else if (e.key === 'ArrowDown' && !this.suggestionsBox.classList.contains('hidden')) {
          e.preventDefault();
          this.selectedSuggestionIndex = (this.selectedSuggestionIndex + 1) % this.filteredSuggestions.length;
          this.highlightSelectedSuggestion();
        } else if (e.key === 'ArrowUp' && !this.suggestionsBox.classList.contains('hidden')) {
          e.preventDefault();
          this.selectedSuggestionIndex = (this.selectedSuggestionIndex - 1 + this.filteredSuggestions.length) % this.filteredSuggestions.length;
          this.highlightSelectedSuggestion();
        }
      });

      // Formula Bar Events
      if (this.formulaBar) {
        this.formulaBar.addEventListener('focus', () => {
          if (!this.isEditing) {
            this.startEditing();
          }
        });

        this.formulaBar.addEventListener('input', () => {
          if (this.isEditing) {
            this.editorInput.value = this.formulaBar.value;
            this.checkFormulaSuggestions(this.formulaBar.value);
            this.updateFormulaReferenceHighlight(this.formulaBar.value);
          }
        });

        this.formulaBar.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            this.commitEdit(e.shiftKey ? 'up' : 'down');
          } else if (e.key === 'Escape') {
            e.preventDefault();
            this.cancelEdit();
          }
        });
      }

      // Name Box Jump
      if (this.nameBox) {
        this.nameBox.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            const val = this.nameBox.value.trim().toUpperCase();
            if (val.includes(':')) {
              const parsed = FormulaEngine.parseRangeAddress(val);
              if (parsed) {
                this.setSelection(parsed.c1.col, parsed.c1.row, parsed.c2.col, parsed.c2.row, true);
                this.container.focus();
              }
            } else {
              const parsed = FormulaEngine.parseCellAddress(val);
              if (parsed) {
                this.setSelection(parsed.col, parsed.row, parsed.col, parsed.row, true);
                this.container.focus();
              }
            }
          }
        });
      }
    }

    highlightSelectedSuggestion() {
      const items = this.suggestionsBox.querySelectorAll('.suggestion-item');
      items.forEach((item, idx) => {
        if (idx === this.selectedSuggestionIndex) {
          item.classList.add('selected');
          item.scrollIntoView({ block: 'nearest' });
        } else {
          item.classList.remove('selected');
        }
      });
    }
  }

  return {
    SpreadsheetGrid,
    TOTAL_ROWS,
    TOTAL_COLS
  };
}));
