// GridForge History & Undo/Redo System

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.HistoryManager = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {

  class UndoRedoStack {
    constructor(maxSize = 100) {
      this.maxSize = maxSize;
      this.undoStack = [];
      this.redoStack = [];
    }

    push(action) {
      // action: { description, undo: () => {}, redo: () => {} }
      this.undoStack.push(action);
      if (this.undoStack.length > this.maxSize) {
        this.undoStack.shift();
      }
      this.redoStack = []; // Clear redo stack on new action
      this.notifyChange();
    }

    undo() {
      if (this.undoStack.length === 0) return false;
      const action = this.undoStack.pop();
      try {
        action.undo();
      } catch (err) {
        console.error('Error executing undo:', err);
      }
      this.redoStack.push(action);
      this.notifyChange();
      return true;
    }

    redo() {
      if (this.redoStack.length === 0) return false;
      const action = this.redoStack.pop();
      try {
        action.redo();
      } catch (err) {
        console.error('Error executing redo:', err);
      }
      this.undoStack.push(action);
      this.notifyChange();
      return true;
    }

    canUndo() {
      return this.undoStack.length > 0;
    }

    canRedo() {
      return this.redoStack.length > 0;
    }

    clear() {
      this.undoStack = [];
      this.redoStack = [];
      this.notifyChange();
    }

    onChange(callback) {
      this._onChangeCb = callback;
    }

    notifyChange() {
      if (this._onChangeCb) {
        this._onChangeCb({ canUndo: this.canUndo(), canRedo: this.canRedo() });
      }
    }
  }

  return {
    UndoRedoStack
  };
}));
