// GridForge Formula & Calculation Engine
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.FormulaEngine = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {

  // --- Address Conversion Utilities ---

  function colNameToIndex(colStr) {
    let col = 0;
    const clean = colStr.replace(/\$/g, '').toUpperCase();
    for (let i = 0; i < clean.length; i++) {
      col = col * 26 + (clean.charCodeAt(i) - 64);
    }
    return col - 1;
  }

  function indexToColName(index) {
    let num = index + 1;
    let name = '';
    while (num > 0) {
      const rem = (num - 1) % 26;
      name = String.fromCharCode(65 + rem) + name;
      num = Math.floor((num - 1) / 26);
    }
    return name;
  }

  const CELL_REF_REGEX = /^(\$?)([A-Za-z]+)(\$?)([0-9]+)$/;
  const RANGE_REF_REGEX = /^(\$?)([A-Za-z]+)(\$?)([0-9]+):(\$?)([A-Za-z]+)(\$?)([0-9]+)$/;

  function parseCellAddress(addr) {
    const m = String(addr).trim().match(CELL_REF_REGEX);
    if (!m) return null;
    const colAbs = m[1] === '$';
    const colName = m[2].toUpperCase();
    const rowAbs = m[3] === '$';
    const rowNum = parseInt(m[4], 10);
    const col = colNameToIndex(colName);
    const row = rowNum - 1;
    return { col, row, colName, rowNum, colAbs, rowAbs, key: `${colName}${rowNum}` };
  }

  function formatCellAddress(col, row, colAbs = false, rowAbs = false) {
    const colStr = (colAbs ? '$' : '') + indexToColName(col);
    const rowStr = (rowAbs ? '$' : '') + (row + 1);
    return colStr + rowStr;
  }

  function parseRangeAddress(rangeStr) {
    const m = String(rangeStr).trim().match(RANGE_REF_REGEX);
    if (!m) return null;
    const c1Abs = m[1] === '$';
    const c1Name = m[2].toUpperCase();
    const r1Abs = m[3] === '$';
    const r1Num = parseInt(m[4], 10);

    const c2Abs = m[5] === '$';
    const c2Name = m[6].toUpperCase();
    const r2Abs = m[7] === '$';
    const r2Num = parseInt(m[8], 10);

    const col1 = colNameToIndex(c1Name);
    const row1 = r1Num - 1;
    const col2 = colNameToIndex(c2Name);
    const row2 = r2Num - 1;

    const minCol = Math.min(col1, col2);
    const maxCol = Math.max(col1, col2);
    const minRow = Math.min(row1, row2);
    const maxRow = Math.max(row1, row2);

    return {
      minCol, maxCol, minRow, maxRow,
      c1Abs, r1Abs, c2Abs, r2Abs,
      c1: { col: col1, row: row1, colAbs: c1Abs, rowAbs: r1Abs },
      c2: { col: col2, row: row2, colAbs: c2Abs, rowAbs: r2Abs }
    };
  }

  function expandRange(rangeStr) {
    const parsed = parseRangeAddress(rangeStr);
    if (!parsed) return [];
    const cells = [];
    for (let r = parsed.minRow; r <= parsed.maxRow; r++) {
      for (let c = parsed.minCol; c <= parsed.maxCol; c++) {
        cells.push(formatCellAddress(c, r));
      }
    }
    return cells;
  }

  // --- Reference Shifting for Fill Operations ---

  function shiftFormulaReferences(formula, deltaCol, deltaRow) {
    if (!formula || typeof formula !== 'string' || !formula.startsWith('=')) {
      return formula;
    }

    // Match range refs and single cell refs
    // Use regex that captures ranges first, then single refs
    const REF_PATTERN = /(\$?)([A-Za-z]+)(\$?)([0-9]+)(?::(\$?)([A-Za-z]+)(\$?)([0-9]+))?/g;

    return formula.replace(REF_PATTERN, (match, c1Abs, c1, r1Abs, r1, c2Abs, c2, r2Abs, r2) => {
      // Shift first part
      const col1Idx = colNameToIndex(c1);
      const row1Idx = parseInt(r1, 10) - 1;
      const newCol1 = c1Abs ? col1Idx : Math.max(0, col1Idx + deltaCol);
      const newRow1 = r1Abs ? row1Idx : Math.max(0, row1Idx + deltaRow);
      const part1 = (c1Abs ? '$' : '') + indexToColName(newCol1) + (r1Abs ? '$' : '') + (newRow1 + 1);

      if (c2 && r2) {
        const col2Idx = colNameToIndex(c2);
        const row2Idx = parseInt(r2, 10) - 1;
        const newCol2 = c2Abs ? col2Idx : Math.max(0, col2Idx + deltaCol);
        const newRow2 = r2Abs ? row2Idx : Math.max(0, row2Idx + deltaRow);
        const part2 = (c2Abs ? '$' : '') + indexToColName(newCol2) + (r2Abs ? '$' : '') + (newRow2 + 1);
        return part1 + ':' + part2;
      }
      return part1;
    });
  }

  // Extract cell dependencies from a formula text
  function extractDependencies(formulaText) {
    if (!formulaText || typeof formulaText !== 'string' || !formulaText.startsWith('=')) {
      return [];
    }
    const deps = new Set();
    const REF_PATTERN = /(\$?)([A-Za-z]+)(\$?)([0-9]+)(?::(\$?)([A-Za-z]+)(\$?)([0-9]+))?/g;
    let match;
    while ((match = REF_PATTERN.exec(formulaText)) !== null) {
      if (match[5] !== undefined && match[6] !== undefined) {
        // Range
        const cells = expandRange(match[0]);
        for (const cell of cells) {
          deps.add(cell.toUpperCase());
        }
      } else {
        // Single cell
        const cell = parseCellAddress(match[0]);
        if (cell) {
          deps.add(formatCellAddress(cell.col, cell.row).toUpperCase());
        }
      }
    }
    return Array.from(deps);
  }

  // --- Lexer / Tokenizer ---

  const TokenType = {
    NUMBER: 'NUMBER',
    STRING: 'STRING',
    IDENTIFIER: 'IDENTIFIER',
    CELL_REF: 'CELL_REF',
    RANGE_REF: 'RANGE_REF',
    OPERATOR: 'OPERATOR',
    LPAREN: 'LPAREN',
    RPAREN: 'RPAREN',
    COMMA: 'COMMA',
    EOF: 'EOF'
  };

  function tokenize(input) {
    let pos = 0;
    const tokens = [];
    const text = input.startsWith('=') ? input.slice(1).trim() : input.trim();

    while (pos < text.length) {
      const ch = text[pos];

      // Whitespace
      if (/\s/.test(ch)) {
        pos++;
        continue;
      }

      // String literal
      if (ch === '"' || ch === "'") {
        const quote = ch;
        pos++;
        let str = '';
        while (pos < text.length && text[pos] !== quote) {
          if (text[pos] === '\\' && pos + 1 < text.length) {
            pos++;
            str += text[pos];
          } else {
            str += text[pos];
          }
          pos++;
        }
        if (pos < text.length && text[pos] === quote) {
          pos++;
        }
        tokens.push({ type: TokenType.STRING, value: str });
        continue;
      }

      // Numbers
      if (/[0-9]/.test(ch) || (ch === '.' && pos + 1 < text.length && /[0-9]/.test(text[pos + 1]))) {
        let numStr = '';
        while (pos < text.length && /[0-9.]/.test(text[pos])) {
          numStr += text[pos];
          pos++;
        }
        tokens.push({ type: TokenType.NUMBER, value: parseFloat(numStr) });
        continue;
      }

      // Range reference or Cell reference or Identifier
      if (/[A-Za-z$]/.test(ch)) {
        let ident = '';
        while (pos < text.length && /[A-Za-z0-9_$:.]/.test(text[pos])) {
          ident += text[pos];
          pos++;
        }

        // Check if Range Reference: e.g. A1:B3 or $A$1:$B$3
        if (RANGE_REF_REGEX.test(ident)) {
          tokens.push({ type: TokenType.RANGE_REF, value: ident.toUpperCase() });
          continue;
        }

        // Check if Cell Reference: e.g. A1 or $A$1
        if (CELL_REF_REGEX.test(ident)) {
          tokens.push({ type: TokenType.CELL_REF, value: ident.toUpperCase() });
          continue;
        }

        // Otherwise Function name or general Identifier
        tokens.push({ type: TokenType.IDENTIFIER, value: ident.toUpperCase() });
        continue;
      }

      // Multi-char operators (<=, >=, <>)
      if (ch === '<' && pos + 1 < text.length) {
        if (text[pos + 1] === '=') {
          tokens.push({ type: TokenType.OPERATOR, value: '<=' });
          pos += 2;
          continue;
        }
        if (text[pos + 1] === '>') {
          tokens.push({ type: TokenType.OPERATOR, value: '<>' });
          pos += 2;
          continue;
        }
      }
      if (ch === '>' && pos + 1 < text.length && text[pos + 1] === '=') {
        tokens.push({ type: TokenType.OPERATOR, value: '>=' });
        pos += 2;
        continue;
      }

      // Single char tokens
      if (ch === '(') {
        tokens.push({ type: TokenType.LPAREN, value: '(' });
        pos++;
        continue;
      }
      if (ch === ')') {
        tokens.push({ type: TokenType.RPAREN, value: ')' });
        pos++;
        continue;
      }
      if (ch === ',') {
        tokens.push({ type: TokenType.COMMA, value: ',' });
        pos++;
        continue;
      }
      if ('+-*/%^&=<>'.includes(ch)) {
        tokens.push({ type: TokenType.OPERATOR, value: ch });
        pos++;
        continue;
      }

      // Unrecognized character
      throw new Error(`Unexpected character '${ch}' at index ${pos}`);
    }

    tokens.push({ type: TokenType.EOF, value: '' });
    return tokens;
  }

  // --- Parser & AST Evaluator ---

  function evaluateFormula(formulaText, getCellValue) {
    if (!formulaText || typeof formulaText !== 'string') {
      return '';
    }
    if (!formulaText.startsWith('=')) {
      // Literal
      return formulaText;
    }

    const rawExpr = formulaText.slice(1).trim();
    if (rawExpr === '') {
      return '';
    }

    let tokens;
    try {
      tokens = tokenize(formulaText);
    } catch (err) {
      return '#ERROR!';
    }

    let current = 0;

    function peek() {
      return tokens[current] || { type: TokenType.EOF, value: '' };
    }

    function consume(expectedType) {
      const tok = peek();
      if (expectedType && tok.type !== expectedType) {
        throw new Error(`Expected token ${expectedType} but got ${tok.type}`);
      }
      current++;
      return tok;
    }

    // Helper to resolve cell value to number or string or error
    function resolveCell(addr) {
      const val = getCellValue(addr);
      if (val === undefined || val === null || val === '') {
        return 0; // Empty cell treated as 0 in arithmetic
      }
      if (typeof val === 'string' && val.startsWith('#')) {
        // Error propagation
        throw { isCellError: true, code: val };
      }
      const num = Number(val);
      if (!isNaN(num)) {
        return num;
      }
      return val;
    }

    function resolveRange(rangeStr) {
      const cells = expandRange(rangeStr);
      const values = [];
      for (const c of cells) {
        const v = getCellValue(c);
        if (v === undefined || v === null || v === '') {
          continue;
        }
        if (typeof v === 'string' && v.startsWith('#')) {
          throw { isCellError: true, code: v };
        }
        const num = Number(v);
        if (!isNaN(num)) {
          values.push(num);
        } else {
          values.push(v);
        }
      }
      return values;
    }

    // Parsing Grammar
    function parseExpression() {
      return parseComparison();
    }

    function parseComparison() {
      let left = parseAdditive();
      while (peek().type === TokenType.OPERATOR && ['=', '<>', '<', '<=', '>', '>='].includes(peek().value)) {
        const op = consume().value;
        const right = parseAdditive();
        if (op === '=') left = (left == right);
        else if (op === '<>') left = (left != right);
        else if (op === '<') left = (left < right);
        else if (op === '<=') left = (left <= right);
        else if (op === '>') left = (left > right);
        else if (op === '>=') left = (left >= right);
      }
      return left;
    }

    function parseAdditive() {
      let left = parseMultiplicative();
      while (peek().type === TokenType.OPERATOR && ['+', '-', '&'].includes(peek().value)) {
        const op = consume().value;
        const right = parseMultiplicative();
        if (op === '+') {
          left = Number(left) + Number(right);
        } else if (op === '-') {
          left = Number(left) - Number(right);
        } else if (op === '&') {
          left = String(left) + String(right);
        }
      }
      return left;
    }

    function parseMultiplicative() {
      let left = parsePower();
      while (peek().type === TokenType.OPERATOR && ['*', '/', '%'].includes(peek().value)) {
        const op = consume().value;
        const right = parsePower();
        if (op === '*') {
          left = Number(left) * Number(right);
        } else if (op === '/') {
          const denom = Number(right);
          if (denom === 0) {
            throw { isCellError: true, code: '#DIV/0!' };
          }
          left = Number(left) / denom;
        } else if (op === '%') {
          const denom = Number(right);
          if (denom === 0) {
            throw { isCellError: true, code: '#DIV/0!' };
          }
          left = Number(left) % denom;
        }
      }
      return left;
    }

    function parsePower() {
      let left = parseUnary();
      if (peek().type === TokenType.OPERATOR && peek().value === '^') {
        consume();
        const right = parsePower();
        left = Math.pow(Number(left), Number(right));
      }
      return left;
    }

    function parseUnary() {
      if (peek().type === TokenType.OPERATOR && (peek().value === '+' || peek().value === '-')) {
        const op = consume().value;
        const operand = parseUnary();
        return op === '-' ? -Number(operand) : +Number(operand);
      }
      return parsePrimary();
    }

    function parsePrimary() {
      const tok = peek();

      if (tok.type === TokenType.NUMBER) {
        consume();
        return tok.value;
      }

      if (tok.type === TokenType.STRING) {
        consume();
        return tok.value;
      }

      if (tok.type === TokenType.CELL_REF) {
        consume();
        return resolveCell(tok.value);
      }

      if (tok.type === TokenType.RANGE_REF) {
        consume();
        return resolveRange(tok.value);
      }

      if (tok.type === TokenType.IDENTIFIER) {
        const funcName = consume().value;
        if (peek().type === TokenType.LPAREN) {
          consume(TokenType.LPAREN);
          const args = [];
          if (peek().type !== TokenType.RPAREN) {
            args.push(parseArgument());
            while (peek().type === TokenType.COMMA) {
              consume(TokenType.COMMA);
              args.push(parseArgument());
            }
          }
          consume(TokenType.RPAREN);
          return evaluateFunction(funcName, args);
        }
        // Identifier without parens - check if boolean
        if (funcName === 'TRUE') return true;
        if (funcName === 'FALSE') return false;
        throw new Error(`Unknown identifier '${funcName}'`);
      }

      if (tok.type === TokenType.LPAREN) {
        consume(TokenType.LPAREN);
        const expr = parseExpression();
        consume(TokenType.RPAREN);
        return expr;
      }

      throw new Error(`Unexpected token ${tok.type} (${tok.value})`);
    }

    function parseArgument() {
      // Argument can be a range reference or a full expression
      if (peek().type === TokenType.RANGE_REF) {
        const tok = consume();
        return resolveRange(tok.value);
      }
      return parseExpression();
    }

    function flattenNumbers(args) {
      const nums = [];
      function walk(item) {
        if (Array.isArray(item)) {
          for (const sub of item) walk(sub);
        } else if (item !== null && item !== undefined && item !== '') {
          const n = Number(item);
          if (!isNaN(n)) {
            nums.push(n);
          }
        }
      }
      for (const arg of args) walk(arg);
      return nums;
    }

    function evaluateFunction(name, args) {
      const fn = name.toUpperCase();
      if (fn === 'SUM') {
        const nums = flattenNumbers(args);
        return nums.reduce((acc, v) => acc + v, 0);
      }
      if (fn === 'AVG' || fn === 'AVERAGE') {
        const nums = flattenNumbers(args);
        if (nums.length === 0) {
          throw { isCellError: true, code: '#DIV/0!' };
        }
        const sum = nums.reduce((acc, v) => acc + v, 0);
        return sum / nums.length;
      }
      if (fn === 'MIN') {
        const nums = flattenNumbers(args);
        if (nums.length === 0) return 0;
        return Math.min(...nums);
      }
      if (fn === 'MAX') {
        const nums = flattenNumbers(args);
        if (nums.length === 0) return 0;
        return Math.max(...nums);
      }
      if (fn === 'COUNT') {
        const nums = flattenNumbers(args);
        return nums.length;
      }
      throw new Error(`Unknown function: ${fn}`);
    }

    try {
      const result = parseExpression();
      if (peek().type !== TokenType.EOF) {
        return '#ERROR!';
      }
      if (typeof result === 'number') {
        if (isNaN(result)) return '#ERROR!';
        if (!isFinite(result)) return '#DIV/0!';
        // Round floating point inaccuracies slightly for clean display (e.g. 0.1 + 0.2)
        const rounded = Math.round(result * 1e10) / 1e10;
        return rounded;
      }
      return result;
    } catch (err) {
      if (err && err.isCellError) {
        return err.code;
      }
      return '#ERROR!';
    }
  }

  // --- Full Workbook / Sheet Recalculation Engine with Dependency Graph ---

  function recalculateSheet(cells) {
    // cells: map of { "A1": "=B1*2", "B1": "100", ... }
    // returns: { calculated: { "A1": 200, "B1": 100 }, errors: { ... } }

    const calculated = {};
    const depsGraph = {}; // cell -> list of cells it depends on
    const cellKeys = Object.keys(cells || {});

    // 1. Build dependencies
    for (const key of cellKeys) {
      const rawVal = cells[key];
      const normKey = key.toUpperCase();
      if (typeof rawVal === 'string' && rawVal.startsWith('=')) {
        depsGraph[normKey] = extractDependencies(rawVal);
      } else {
        depsGraph[normKey] = [];
      }
    }

    // 2. Detect cycles using DFS
    const UNVISITED = 0, VISITING = 1, VISITED = 2;
    const visitState = {};
    const cyclicCells = new Set();

    function detectCycles(node, path) {
      visitState[node] = VISITING;
      const deps = depsGraph[node] || [];
      for (const dep of deps) {
        if (visitState[dep] === VISITING) {
          // Found cycle
          cyclicCells.add(node);
          cyclicCells.add(dep);
          for (const p of path) cyclicCells.add(p);
        } else if (visitState[dep] !== VISITED) {
          detectCycles(dep, [...path, node]);
        }
      }
      visitState[node] = VISITED;
    }

    for (const key of cellKeys) {
      const normKey = key.toUpperCase();
      if (!visitState[normKey]) {
        detectCycles(normKey, []);
      }
    }

    // 3. Mark cyclic cells
    for (const key of cyclicCells) {
      calculated[key] = '#REF!';
    }

    // 4. Evaluate non-cyclic cells in topological order
    const evalCache = {};

    function getCellValue(addr) {
      const norm = addr.toUpperCase().replace(/\$/g, '');
      if (cyclicCells.has(norm)) {
        return '#REF!';
      }
      if (evalCache[norm] !== undefined) {
        return evalCache[norm];
      }
      const raw = cells[norm];
      if (raw === undefined || raw === null) {
        return '';
      }
      if (typeof raw !== 'string' || !raw.startsWith('=')) {
        evalCache[norm] = raw;
        return raw;
      }
      // Recursive evaluate
      const res = evaluateFormula(raw, getCellValue);
      evalCache[norm] = res;
      return res;
    }

    for (const key of cellKeys) {
      const normKey = key.toUpperCase();
      if (cyclicCells.has(normKey)) {
        calculated[normKey] = '#REF!';
      } else {
        calculated[normKey] = getCellValue(normKey);
      }
    }

    return calculated;
  }

  return {
    colNameToIndex,
    indexToColName,
    parseCellAddress,
    formatCellAddress,
    parseRangeAddress,
    expandRange,
    shiftFormulaReferences,
    extractDependencies,
    evaluateFormula,
    recalculateSheet
  };
}));
