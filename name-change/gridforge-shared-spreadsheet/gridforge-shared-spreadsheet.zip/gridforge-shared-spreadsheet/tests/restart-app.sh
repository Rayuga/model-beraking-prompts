#!/bin/bash
set -euo pipefail
exec bash /tests/app-control.sh restart
