# Finding our way around

People should recognize the workbook they're in and be able to start work
without knowing URLs or reading developer notes. Show the workbook title and
give the grid most of the working space.

Keep saving, undo and redo, the formula bar, fill, find and replace, the name
box, and revision history easy to find. Labels can be your own as long as
their purpose is clear. Someone using a keyboard should be able to reach the
controls and see where focus is.

When a formula is invalid, a save is rejected, or an action can't be completed,
tell the person what happened. Keep save feedback and revision information
readable alongside their work. Aim for a clear layout that is comfortable to
use in a normal browser.

Use consistent, readable typography, clear contrast, aligned controls and
distinct visual groups for the workbook, editing controls and history. Keep
this presentation coherent on desktop and narrow phone screens. A wide sheet
can scroll within its own area; surrounding labels and controls should reflow
without overlapping or being cut off. We do not need multiple themes.
